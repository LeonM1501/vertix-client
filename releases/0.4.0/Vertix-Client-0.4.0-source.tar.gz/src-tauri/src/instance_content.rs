// Vertix instance-local content management. No shared gameplay folders.
use crate::{config::HTTP_CLIENT, error::{AppError, CommandError, Result}, state::{State, profile_state::{Profile, ModSource, ModLoader}}, utils::file_utils::write_atomic};
use serde::{Serialize, Deserialize};
use serde_json::Value;
use std::{path::{Path, PathBuf}, collections::{HashMap, HashSet}};
use tokio::fs;
use uuid::Uuid;
use tauri_plugin_opener::OpenerExt;
use tauri_plugin_dialog::DialogExt;

pub(crate) static CONTENT_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());
const META: &str = ".vertix-content.json";
#[derive(Clone, Serialize, Deserialize)]
pub struct ContentItem {
    pub id: String, pub kind: String, pub title: String, pub filename: String,
    pub version: Option<String>, pub project_id: Option<String>, pub version_id: Option<String>,
    pub author: Option<String>, pub icon_url: Option<String>, pub enabled: bool,
    pub relative_path: Option<String>, pub world: Option<String>, pub size: u64,
}
#[derive(Serialize)]
pub struct InstanceFile { pub name: String, pub directory: bool, pub size: u64 }
#[derive(Serialize)]
pub struct InstanceSnapshot { pub items: Vec<ContentItem>, pub worlds: Vec<String>, pub files: Vec<InstanceFile>, pub directory: String, pub running: bool }
pub async fn ensure_stopped(state: &State, id: Uuid) -> Result<()> {
    if state.process_manager.get_process_metadata_by_profile(id).await.iter().any(|p|matches!(p.state, crate::state::process_state::ProcessState::Starting | crate::state::process_state::ProcessState::Running | crate::state::process_state::ProcessState::Stopping)) {
        return Err(AppError::Other("Diese Instanz läuft gerade. Beende Minecraft, bevor du Inhalte änderst oder erneut startest.".into()));
    }
    Ok(())
}
pub async fn isolated_root(state: &State, profile: &Profile) -> Result<PathBuf> {
    if profile.use_shared_minecraft_folder { return Err(AppError::Other("Diese Instanz verwendet einen gemeinsamen Ordner. Erstelle eine getrennte Vertix-Instanz.".into())); }
    let root = state.profile_manager.get_profile_instance_path(profile.id).await?;
    fs::create_dir_all(&root).await?;
    if fs::symlink_metadata(&root).await?.file_type().is_symlink() { return Err(AppError::Other("Verknüpfte Instanzordner werden nicht unterstützt.".into())); }
    Ok(root)
}
fn filename(name: &str) -> Result<&str> {
    if name.is_empty() || name == "." || name == ".." || name.contains(['/', '\\', ':', '\0']) || name.ends_with(['.', ' ']) { return Err(AppError::Other("Ungültiger Dateiname.".into())); }
    Ok(name)
}
async fn safe_target(root: &Path, relative: &str) -> Result<PathBuf> {
    let mut result = root.to_owned();
    for c in Path::new(relative).components() {
        let std::path::Component::Normal(part) = c else { return Err(AppError::Other("Ungültiger Instanzpfad.".into())); };
        filename(&part.to_string_lossy())?; result.push(part);
        if let Ok(meta) = fs::symlink_metadata(&result).await { if meta.file_type().is_symlink() { return Err(AppError::Other("Verknüpfungen außerhalb der Instanz werden nicht verwendet.".into())); } }
    }
    Ok(result)
}
async fn metadata(root: &Path) -> Result<HashMap<String, ContentItem>> {
    match fs::read(root.join(META)).await { Ok(bytes) => Ok(serde_json::from_slice(&bytes)?), Err(e) if e.kind()==std::io::ErrorKind::NotFound => Ok(HashMap::new()), Err(e)=>Err(e.into()) }
}
async fn save_metadata(root: &Path, items: &HashMap<String, ContentItem>) -> Result<()> { write_atomic(root.join(META), serde_json::to_vec_pretty(items)?).await }
async fn scan(root: &Path, profile: &Profile) -> Result<InstanceSnapshot> {
    let meta = metadata(root).await?;
    let mut items = Vec::new(); let mut managed = HashSet::new();
    for m in &profile.mods {
        let (file, project, version_id) = match &m.source {
            ModSource::Modrinth {file_name, project_id, version_id, ..} => (file_name.clone(), Some(project_id.clone()), Some(version_id.clone())),
            ModSource::Local {file_name} => (file_name.clone(),None,None),
            _ => (m.display_name.clone().unwrap_or_else(||"Mod".into()),None,None),
        };
        managed.insert(file.clone());
        let extra = project.as_ref().and_then(|p|meta.get(&format!("mod:{p}")));
        items.push(ContentItem { id: format!("mod:{}",m.id), kind:"mod".into(), title:m.display_name.clone().unwrap_or_else(||file.clone()), filename:file, version:m.version.clone(), project_id:project, version_id,
            author:extra.and_then(|e|e.author.clone()), icon_url:extra.and_then(|e|e.icon_url.clone()), enabled:m.enabled, relative_path:None, world:None, size:0 });
    }
    let mut worlds=Vec::new();
    let saves=safe_target(root,"saves").await?;
    if saves.is_dir() { let mut entries=fs::read_dir(&saves).await?; while let Some(e)=entries.next_entry().await? { if e.file_type().await?.is_dir() && e.path().join("level.dat").is_file() { worlds.push(e.file_name().to_string_lossy().into_owned()); } } }
    worlds.sort();
    let mut dirs=vec![("mod","mods".to_owned(),None),("resourcepack","resourcepacks".to_owned(),None),("shader","shaderpacks".to_owned(),None)];
    for world in &worlds { dirs.push(("datapack",format!("saves/{world}/datapacks"),Some(world.clone()))); }
    for (kind,rel,world) in dirs {
        let path=safe_target(root,&rel).await?; if !path.is_dir() {continue;}
        let mut entries=fs::read_dir(&path).await?;
        while let Some(e)=entries.next_entry().await? {
            if !e.file_type().await?.is_file() {continue;}
            let actual=e.file_name().to_string_lossy().into_owned(); let base=actual.strip_suffix(".disabled").unwrap_or(&actual);
            if !(base.ends_with(".jar") || base.ends_with(".zip")) || (kind=="mod" && managed.contains(base)) {continue;}
            let key=format!("{rel}/{base}"); let extra=meta.get(&key);
            items.push(ContentItem {id:format!("file:{key}"),kind:kind.into(),title:extra.map(|e|e.title.clone()).unwrap_or_else(||base.to_owned()),filename:base.to_owned(),version:extra.and_then(|e|e.version.clone()),project_id:extra.and_then(|e|e.project_id.clone()),version_id:extra.and_then(|e|e.version_id.clone()),author:extra.and_then(|e|e.author.clone()),icon_url:extra.and_then(|e|e.icon_url.clone()),enabled:actual==base,relative_path:Some(format!("{rel}/{actual}")),world:world.clone(),size:e.metadata().await?.len()});
        }
    }
    items.sort_by_key(|i|i.title.to_lowercase());
    let mut files=Vec::new(); let mut entries=fs::read_dir(root).await?;
    while let Some(e)=entries.next_entry().await? {let name=e.file_name().to_string_lossy().into_owned(); if name.starts_with('.') || e.file_type().await?.is_symlink() {continue;} let m=e.metadata().await?; files.push(InstanceFile{name,directory:m.is_dir(),size:if m.is_file(){m.len()}else{0}});}
    files.sort_by_key(|f|(!f.directory,f.name.to_lowercase()));
    Ok(InstanceSnapshot {items,worlds,files,directory:root.to_string_lossy().into_owned(),running:false})
}
#[tauri::command]
pub async fn get_instance_content(profile_id: Uuid) -> std::result::Result<InstanceSnapshot,CommandError> {
    let state=State::get().await?;let profile=state.profile_manager.get_profile(profile_id).await?;let root=isolated_root(&state,&profile).await?;
    let mut data=scan(&root,&profile).await?;data.running=ensure_stopped(&state,profile_id).await.is_err();Ok(data)
}
async fn sync_mods(state: &State, id: Uuid) -> Result<()> {
    let profile=state.profile_manager.get_profile(id).await?;
    crate::minecraft::downloads::ModDownloadService::new().download_mods_to_cache(&profile).await?;
    use crate::config::ProjectDirsExt;
    let (mods,_)=crate::minecraft::downloads::mod_resolver::resolve_target_mods(&profile,None,None,&[],&profile.game_version,profile.loader.as_str(),&crate::config::LAUNCHER_DIRECTORY.meta_dir().join("mod_cache")).await?;
    let root=isolated_root(state,&profile).await?;
    crate::minecraft::installer::sync_vertix_mods(&mods,&safe_target(&root,"mods").await?).await
}
async fn json(url: &str) -> Result<Value> { Ok(HTTP_CLIENT.get(url).send().await?.error_for_status()?.json().await?) }
#[derive(Deserialize)]
pub struct InstallRequest { pub profile_id: Uuid, pub project_id: String, pub kind: String, pub world: Option<String>, pub version_id: Option<String> }
#[tauri::command]
pub async fn install_instance_content(request: InstallRequest) -> std::result::Result<(),CommandError> {
    let _guard=CONTENT_LOCK.lock().await;
    install_content(request).await.map_err(Into::into)
}
async fn install_content(r: InstallRequest) -> Result<()> {
    if !matches!(r.kind.as_str(),"mod"|"resourcepack"|"shader"|"datapack") {return Err(AppError::Other("Unbekannter Inhaltstyp.".into()));}
    filename(&r.project_id)?;
    let state=State::get().await?;ensure_stopped(&state,r.profile_id).await?;
    let original=state.profile_manager.get_profile(r.profile_id).await?;let root=isolated_root(&state,&original).await?;
    if r.kind=="mod" && original.loader==ModLoader::Vanilla {return Err(AppError::Other("Mods benötigen einen Modloader.".into()));}
    let project=json(&format!("https://api.modrinth.com/v2/project/{}",r.project_id)).await?;
    let loaders_filter=match r.kind.as_str(){"mod"=>vec![original.loader.as_str()],"datapack"=>vec!["datapack"],"resourcepack"=>vec!["minecraft"],_=>vec!["iris","optifine"]};
    let mut url=reqwest::Url::parse(&format!("https://api.modrinth.com/v2/project/{}/version",r.project_id)).map_err(|e|AppError::Other(e.to_string()))?;
    url.query_pairs_mut().append_pair("game_versions",&serde_json::to_string(&[&original.game_version])?);
    url.query_pairs_mut().append_pair("loaders",&serde_json::to_string(&loaders_filter)?);
    let versions=json(url.as_str()).await?;
    let list=versions.as_array().ok_or_else(||AppError::Other("Ungültige Versionsliste.".into()))?;
    let version=if let Some(id)=&r.version_id {list.iter().find(|v|v["id"].as_str()==Some(id))} else {list.iter().find(|v|v["version_type"]=="release").or_else(||list.first())}.ok_or_else(||AppError::Other("Keine kompatible Version für diese Instanz gefunden.".into()))?;
    // Prevent cross-type files: v2 uses loaders to distinguish datapacks/shaders/packs.
    let loaders=version["loaders"].as_array().ok_or_else(||AppError::Other("Versionsinformationen fehlen.".into()))?;
    if (r.kind=="resourcepack" && !loaders.iter().any(|v|v=="minecraft")) || (r.kind=="shader" && !loaders.iter().any(|v|matches!(v.as_str(),Some("iris"|"optifine")))) {return Err(AppError::Other("Dieser Inhalt hat nicht den ausgewählten Typ.".into()));}
    let file=version["files"].as_array().and_then(|f|f.iter().find(|v|v["primary"]==true).or_else(||f.first())).ok_or_else(||AppError::Other("Download fehlt.".into()))?;
    let name=filename(file["filename"].as_str().ok_or_else(||AppError::Other("Dateiname fehlt.".into()))?)?;
    let url=file["url"].as_str().ok_or_else(||AppError::Other("Download fehlt.".into()))?;
    let parsed=reqwest::Url::parse(url).map_err(|e|AppError::Other(e.to_string()))?;
    if parsed.scheme()!="https" || parsed.host_str()!=Some("cdn.modrinth.com") {return Err(AppError::Other("Unbekannte Modrinth-Downloadquelle.".into()));}
    let hash=file["hashes"]["sha1"].as_str().ok_or_else(||AppError::Other("Prüfsumme fehlt.".into()))?;
    let title=project["title"].as_str().unwrap_or(name).to_owned();let vid=version["id"].as_str().unwrap_or_default().to_owned();
    let mut meta=metadata(&root).await?;
    let author=if let Ok(members)=json(&format!("https://api.modrinth.com/v2/project/{}/members",r.project_id)).await {
        members.as_array().and_then(|a|a.iter().find(|m|m["role"]=="Owner").or_else(||a.first())).and_then(|m|m["user"]["username"].as_str()).map(str::to_owned)
    }else{None};
    let mut record=ContentItem{id:String::new(),kind:r.kind.clone(),title:title.clone(),filename:name.into(),version:version["version_number"].as_str().map(str::to_owned),project_id:Some(r.project_id.clone()),version_id:Some(vid.clone()),author,icon_url:project["icon_url"].as_str().map(str::to_owned),enabled:true,relative_path:None,world:r.world.clone(),size:file["size"].as_u64().unwrap_or(0)};
    if r.kind=="mod" {
        state.profile_manager.add_modrinth_mod(r.profile_id,r.project_id.clone(),vid.clone(),name.into(),url.into(),Some(hash.into()),Some(title),record.version.clone(),Some(vec![original.loader.as_str().into()]),Some(vec![original.game_version.clone()]),true).await?;
        let mut updated=state.profile_manager.get_profile(r.profile_id).await?;
        updated.mods.retain(|m|!matches!(&m.source,ModSource::Modrinth{project_id,version_id,..} if project_id==&r.project_id && version_id!=&vid));
        if let Some(previous)=original.mods.iter().find(|m|matches!(&m.source,ModSource::Modrinth{project_id,..} if project_id==&r.project_id)) {
            for m in &mut updated.mods {if matches!(&m.source,ModSource::Modrinth{project_id,..} if project_id==&r.project_id){m.enabled=previous.enabled;}}
        }
        state.profile_manager.update_profile(r.profile_id,updated).await?;
        if let Err(error)=sync_mods(&state,r.profile_id).await { state.profile_manager.update_profile(r.profile_id,original).await?;let _=sync_mods(&state,r.profile_id).await;return Err(error); }
        record.id=format!("mod:{}",r.project_id);meta.insert(record.id.clone(),record);
    } else {
        let directory=match r.kind.as_str(){"resourcepack"=>"resourcepacks".into(),"shader"=>"shaderpacks".into(),_=>{
            let world=r.world.as_deref().ok_or_else(||AppError::Other("Wähle die Welt für dieses Datenpaket.".into()))?;filename(world)?;
            let path=safe_target(&root,&format!("saves/{world}/level.dat")).await?;
            if !path.is_file(){return Err(AppError::Other("Die gewählte Welt wurde nicht gefunden. Erstelle sie zuerst in Minecraft.".into()));}
            format!("saves/{world}/datapacks")
        }};
        let previous=meta.iter().find(|(_,i)|i.project_id.as_ref()==Some(&r.project_id)&&i.kind==r.kind&&i.world==r.world).map(|(k,i)|(k.clone(),i.clone()));
        record.enabled=previous.as_ref().map_or(true,|(_,i)|i.enabled);
        let relative=format!("{directory}/{name}");let actual=if record.enabled{relative.clone()}else{format!("{relative}.disabled")};
        let target=safe_target(&root,&actual).await?;fs::create_dir_all(target.parent().unwrap()).await?;
        if target.exists() && !meta.contains_key(&relative) {return Err(AppError::Other("Eine lokale Datei mit diesem Namen existiert bereits. Bitte zuerst in der Instanz verwalten.".into()));}
        crate::utils::download_utils::DownloadUtils::download_with_sha1(url,&target,hash).await?;
        if let Some((key,old))=previous {if key!=relative {let old_path=old.relative_path.as_deref().unwrap_or(&key);let old_path=safe_target(&root,old_path).await?;if old_path.is_file(){fs::remove_file(old_path).await?;}meta.remove(&key);}}
        record.id=format!("file:{relative}");record.relative_path=Some(actual);meta.insert(relative,record);
    }
    save_metadata(&root,&meta).await?;Ok(())
}
#[tauri::command]
pub async fn change_instance_content(profile_id: Uuid, item_id: String, action: String) -> std::result::Result<(),CommandError> {
    let _guard=CONTENT_LOCK.lock().await;let state=State::get().await?;ensure_stopped(&state,profile_id).await?;
    let profile=state.profile_manager.get_profile(profile_id).await?;let root=isolated_root(&state,&profile).await?;
    let item=scan(&root,&profile).await?.items.into_iter().find(|i|i.id==item_id).ok_or_else(||AppError::Other("Inhalt nicht mehr gefunden. Bitte aktualisieren.".into()))?;
    if action=="update" {let project=item.project_id.ok_or_else(||AppError::Other("Lokale Dateien haben keine automatische Updatequelle.".into()))?;return install_content(InstallRequest{profile_id,project_id:project,kind:item.kind,world:item.world,version_id:None}).await.map_err(Into::into);}
    if !matches!(action.as_str(),"toggle"|"remove"){return Err(AppError::Other("Unbekannte Inhaltsaktion.".into()).into());}
    if let Some(id)=item.id.strip_prefix("mod:") {
        let id=Uuid::parse_str(id).map_err(|e|AppError::Other(e.to_string()))?;
        if action=="remove"{state.profile_manager.delete_mod(profile_id,id).await?;}else{state.profile_manager.set_mod_enabled(profile_id,id,!item.enabled).await?;}
        sync_mods(&state,profile_id).await?;
    } else if let Some(rel)=&item.relative_path {
        let path=safe_target(&root,rel).await?;
        if action=="remove"{fs::remove_file(&path).await.map_err(AppError::Io)?;}else{let next=if item.enabled{format!("{rel}.disabled")}else{rel.trim_end_matches(".disabled").to_owned()};let next=safe_target(&root,&next).await?;if next.exists(){return Err(AppError::Other("Die Zieldatei existiert bereits.".into()).into());}fs::rename(&path,next).await.map_err(AppError::Io)?;}
        let mut meta=metadata(&root).await?;let key=item.id.trim_start_matches("file:");if action=="remove"{meta.remove(key);}else if let Some(record)=meta.get_mut(key){record.enabled=!item.enabled;record.relative_path=Some(if item.enabled{format!("{key}.disabled")}else{key.into()});}save_metadata(&root,&meta).await?;
    }
    Ok(())
}
#[tauri::command]
pub async fn import_instance_content(app: tauri::AppHandle, profile_id: Uuid, kind: String, world: Option<String>) -> std::result::Result<u32,CommandError> {
    let state=State::get().await?;ensure_stopped(&state,profile_id).await?;let profile=state.profile_manager.get_profile(profile_id).await?;let root=isolated_root(&state,&profile).await?;
    let folder=match kind.as_str(){"mod" if profile.loader!=ModLoader::Vanilla=>"mods".into(),"resourcepack"=>"resourcepacks".into(),"shader"=>"shaderpacks".into(),"datapack"=>{let w=world.as_deref().ok_or_else(||AppError::Other("Wähle eine Welt für den Import.".into()))?;filename(w)?;if !safe_target(&root,&format!("saves/{w}/level.dat")).await?.is_file(){return Err(AppError::Other("Welt nicht gefunden.".into()).into());}format!("saves/{w}/datapacks")},_=>return Err(AppError::Other("Für Mods ist ein Modloader erforderlich.".into()).into())};
    let (send,recv)=tokio::sync::oneshot::channel();let extension=if kind=="mod"{"jar"}else{"zip"};
    app.dialog().file().set_title("Inhalte in diese Instanz importieren").add_filter("Minecraft-Inhalte",&[extension]).pick_files(move|files|{let _=send.send(files);});
    let Some(files)=recv.await.map_err(|_|AppError::Other("Dateiauswahl geschlossen.".into()))? else{return Ok(0);};
    let _guard=CONTENT_LOCK.lock().await;ensure_stopped(&state,profile_id).await?;
    let dir=safe_target(&root,&folder).await?;fs::create_dir_all(&dir).await.map_err(AppError::Io)?;let mut count=0;
    for file in files {let source=file.into_path().map_err(|e|AppError::Other(e.to_string()))?;let name=source.file_name().and_then(|n|n.to_str()).ok_or_else(||AppError::Other("Dateiname fehlt.".into()))?;filename(name)?;if !name.ends_with(&format!(".{extension}")){continue;}let target=safe_target(&root,&format!("{folder}/{name}")).await?;if target.exists() || target.with_file_name(format!("{name}.disabled")).exists(){return Err(AppError::Other(format!("{name} ist bereits vorhanden. Vorhandene Dateien werden nicht überschrieben.")).into());}fs::copy(source,target).await.map_err(AppError::Io)?;count+=1;}
    Ok(count)
}
#[tauri::command]
pub async fn open_instance_path(app: tauri::AppHandle, profile_id: Uuid, relative: Option<String>) -> std::result::Result<(),CommandError> {
    let state=State::get().await?;let profile=state.profile_manager.get_profile(profile_id).await?;let root=isolated_root(&state,&profile).await?;
    let path=if let Some(rel)=relative{safe_target(&root,&rel).await?}else{root};
    if !path.exists(){return Err(AppError::Other("Dieser Ordner oder diese Datei wurde noch nicht angelegt.".into()).into());}
    app.opener().open_path(path.to_string_lossy(),None::<&str>).map_err(|e|AppError::Other(e.to_string()))?;Ok(())
}
#[tauri::command]
pub async fn read_instance_log(profile_id: Uuid) -> std::result::Result<String,CommandError> {
    use tokio::io::{AsyncReadExt,AsyncSeekExt};
    let state=State::get().await?;let profile=state.profile_manager.get_profile(profile_id).await?;let root=isolated_root(&state,&profile).await?;let path=safe_target(&root,"logs/latest.log").await?;
    if !path.is_file(){return Ok("Noch kein Spielprotokoll vorhanden. Starte diese Instanz zuerst.".into());}
    let mut file=fs::File::open(path).await.map_err(AppError::Io)?;let length=file.metadata().await.map_err(AppError::Io)?.len();if length>262144{file.seek(std::io::SeekFrom::End(-262144)).await.map_err(AppError::Io)?;}
    let mut bytes=Vec::new();file.take(262144).read_to_end(&mut bytes).await.map_err(AppError::Io)?;let text=String::from_utf8_lossy(&bytes);
    let secret=regex::Regex::new(r"(?i)(--accessToken\s+|Bearer\s+)[^\s]+").unwrap();Ok(secret.replace_all(&text,"$1[geschützt]").into_owned())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    async fn files_and_world_datapacks_never_cross_instance_roots() {
        let temp=tempfile::tempdir().unwrap();let a=temp.path().join("a");let b=temp.path().join("b");fs::create_dir_all(a.join("resourcepacks")).await.unwrap();fs::create_dir_all(b.join("resourcepacks")).await.unwrap();
        fs::write(a.join("resourcepacks/pack.zip"),b"a").await.unwrap();fs::write(b.join("resourcepacks/pack.zip"),b"b").await.unwrap();
        fs::create_dir_all(a.join("saves/World/datapacks")).await.unwrap();fs::write(a.join("saves/World/level.dat"),b"test").await.unwrap();fs::write(a.join("saves/World/datapacks/data.zip"),b"data").await.unwrap();
        let profile:Profile=serde_json::from_value(serde_json::json!({"name":"Test","path":"test","game_version":"1.21.1","loader":"fabric"})).unwrap();
        let data=scan(&a,&profile).await.unwrap();assert_eq!(data.items.len(),2);assert_eq!(data.worlds,vec!["World"]);assert!(data.items.iter().any(|i|i.world.as_deref()==Some("World")));
        let target=safe_target(&a,"resourcepacks/pack.zip").await.unwrap();fs::rename(&target,target.with_file_name("pack.zip.disabled")).await.unwrap();
        assert!(!scan(&a,&profile).await.unwrap().items.iter().find(|i|i.kind=="resourcepack").unwrap().enabled);assert_eq!(fs::read(b.join("resourcepacks/pack.zip")).await.unwrap(),b"b");
        assert!(safe_target(&a,"../b/resourcepacks/pack.zip").await.is_err());assert!(safe_target(&a,"C:/outside").await.is_err());
    }
}
