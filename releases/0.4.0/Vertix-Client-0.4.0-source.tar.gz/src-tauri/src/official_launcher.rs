// Vertix official-launcher handoff, 2026-10-09.
// Direct launch prefers Vertix's own OAuth session and retains the official
// launcher's short-lived game-session fallback; its Microsoft credentials are never reused.
use crate::config::{ProjectDirsExt, HTTP_CLIENT, LAUNCHER_DIRECTORY};
use crate::error::{AppError, CommandError, Result};
use crate::minecraft::downloads::ModDownloadService;
use crate::minecraft::modloader::ModloaderFactory;
use crate::state::profile_state::{ModLoader, Profile};
use crate::state::State;
use crate::utils::file_utils::write_atomic;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::process::Stdio;
use tauri_plugin_dialog::DialogExt;
use tauri_plugin_opener::OpenerExt;
use tokio::{fs, process::Command};
use uuid::Uuid;

const PROFILE_FILES: [&str; 2] = ["launcher_profiles.json", "launcher_profiles_microsoft_store.json"];
static PREPARING: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

#[derive(Default, Deserialize, Serialize)]
struct BridgeConfig { minecraft_dir: Option<PathBuf>, executable: Option<PathBuf> }
#[derive(Clone)]
enum LauncherTarget { Exe(PathBuf), Store(String) }
#[derive(Serialize)]
pub struct LauncherStatus {
    installed: bool,
    initialized: bool,
    running: bool,
    minecraft_dir: String,
    launcher_path: Option<String>,
    session_available: bool,
    player_name: Option<String>,
}
#[derive(Serialize)]
pub struct PreparedProfile {
    pub installation_name: String,
    pub game_directory: String,
    pub version_id: String,
}

fn config_path() -> PathBuf { LAUNCHER_DIRECTORY.root_dir().join("official-launcher.json") }
async fn config() -> Result<BridgeConfig> {
    match fs::read(config_path()).await {
        Ok(bytes) => Ok(serde_json::from_slice(&bytes)?),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(BridgeConfig::default()),
        Err(e) => Err(e.into()),
    }
}
async fn save_config(c: &BridgeConfig) -> Result<()> {
    fs::create_dir_all(LAUNCHER_DIRECTORY.root_dir()).await?;
    write_atomic(config_path(), serde_json::to_vec_pretty(c)?).await
}
fn minecraft_dir(c: &BridgeConfig) -> PathBuf {
    c.minecraft_dir.clone().unwrap_or_else(|| {
        if cfg!(target_os = "windows") { dirs::config_dir().unwrap_or_default().join(".minecraft") }
        else if cfg!(target_os = "macos") { dirs::data_dir().unwrap_or_default().join("minecraft") }
        else { dirs::home_dir().unwrap_or_default().join(".minecraft") }
    })
}
fn hidden(command: &mut Command) {
    #[cfg(windows)]
    command.creation_flags(0x08000000);
    #[cfg(not(windows))]
    let _ = command;
}
fn launcher_running() -> bool {
    let mut system = sysinfo::System::new();
    system.refresh_processes(sysinfo::ProcessesToUpdate::All, true);
    system.processes().values().any(|p| {
        let name = p.name().to_string_lossy().to_lowercase();
        matches!(name.as_str(), "minecraftlauncher.exe" | "minecraft.exe" | "minecraft-launcher")
    })
}
async fn detect_target(c: &BridgeConfig) -> Option<LauncherTarget> {
    if let Some(path) = &c.executable { if path.is_file() { return Some(LauncherTarget::Exe(path.clone())); } }
    #[cfg(windows)]
    {
        for var in ["ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"] {
            if let Some(base) = std::env::var_os(var) {
                for suffix in ["Minecraft Launcher/MinecraftLauncher.exe", "Programs/Minecraft Launcher/MinecraftLauncher.exe"] {
                    let path = PathBuf::from(&base).join(suffix);
                    if path.is_file() { return Some(LauncherTarget::Exe(path)); }
                }
            }
        }
        // Read installed package identity only; never touch the account database.
        let mut command = Command::new("powershell.exe");
        hidden(&mut command);
        command.args(["-NoProfile", "-NonInteractive", "-Command",
            "$p=Get-AppxPackage -Name Microsoft.4297127D64EC6; if($p){$m=$p|Get-AppxPackageManifest; foreach($a in $m.Package.Applications.Application){if($a.Id -eq 'Minecraft'){Write-Output ($p.PackageFamilyName+'!'+$a.Id);break}}}"]);
        if let Ok(Ok(output)) = tokio::time::timeout(std::time::Duration::from_secs(12), command.output()).await {
            let id = String::from_utf8_lossy(&output.stdout).trim().to_owned();
            if id.starts_with("Microsoft.4297127D64EC6_") && id.contains('!') { return Some(LauncherTarget::Store(id)); }
        }
    }
    #[cfg(not(windows))]
    for path in ["/usr/bin/minecraft-launcher", "/Applications/Minecraft.app/Contents/MacOS/launcher"] {
        if Path::new(path).is_file() { return Some(LauncherTarget::Exe(path.into())); }
    }
    None
}
#[tauri::command]
pub async fn get_official_launcher_status() -> std::result::Result<LauncherStatus, CommandError> {
    let c = config().await?;
    let root = minecraft_dir(&c);
    let target = detect_target(&c).await;
    let session = read_session(&root).await.ok();
    Ok(LauncherStatus {
        installed: target.is_some(), initialized: PROFILE_FILES.iter().any(|name| root.join(name).is_file()),
        running: launcher_running(), minecraft_dir: root.to_string_lossy().into_owned(),
        launcher_path: target.map(|t| match t { LauncherTarget::Exe(p) => p.to_string_lossy().into_owned(), LauncherTarget::Store(id) => format!("Microsoft Store · {id}") }),
        session_available: session.is_some(), player_name: session.map(|s| s.username),
    })
}
#[tauri::command]
pub async fn choose_official_launcher(app: tauri::AppHandle, kind: String) -> std::result::Result<bool, CommandError> {
    let (send, receive) = tokio::sync::oneshot::channel();
    match kind.as_str() {
        "executable" => { app.dialog().file().set_title("Offiziellen Minecraft Launcher auswählen").add_filter("Minecraft Launcher", &["exe"]).pick_file(move |path| { let _ = send.send(path); }); }
        "directory" => { app.dialog().file().set_title("Minecraft-Datenordner des offiziellen Launchers auswählen").pick_folder(move |path| { let _ = send.send(path); }); }
        _ => return Err(AppError::Other("Unbekannte Auswahl.".into()).into()),
    }
    let Some(file) = receive.await.map_err(|_| AppError::Other("Dateiauswahl geschlossen.".into()))? else { return Ok(false); };
    let path = file.into_path().map_err(|e| AppError::Other(e.to_string()))?;
    let mut c = config().await?;
    if kind == "executable" {
        let name = path.file_name().unwrap_or_default().to_string_lossy().to_lowercase();
        if !matches!(name.as_str(), "minecraftlauncher.exe" | "minecraft.exe") { return Err(AppError::Other("Bitte MinecraftLauncher.exe des offiziellen Launchers wählen.".into()).into()); }
        c.executable = Some(path);
    } else {
        if !PROFILE_FILES.iter().any(|name| path.join(name).is_file()) { return Err(AppError::Other("Hier fehlen die Installationen des offiziellen Launchers. Öffne ihn zuerst einmal und wähle danach seinen Minecraft-Datenordner.".into()).into()); }
        c.minecraft_dir = Some(path);
    }
    save_config(&c).await?;
    Ok(true)
}
#[tauri::command]
pub async fn open_official_launcher() -> std::result::Result<(), CommandError> {
    let c = config().await?;
    match detect_target(&c).await.ok_or_else(|| AppError::Other("Der offizielle Minecraft Launcher ist noch nicht installiert oder wurde nicht gefunden. Öffne Einstellungen → Minecraft Launcher.".into()))? {
        LauncherTarget::Exe(path) => { let mut command = Command::new(path); if c.minecraft_dir.is_some() { command.arg("--workDir").arg(minecraft_dir(&c)); } command.stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn().map_err(AppError::Io)?; }
        LauncherTarget::Store(id) => { Command::new("explorer.exe").arg(format!("shell:AppsFolder\\{id}")).spawn().map_err(AppError::Io)?; }
    }
    Ok(())
}
#[tauri::command]
pub fn open_official_launcher_download(app: tauri::AppHandle) -> std::result::Result<(), CommandError> {
    app.opener().open_url("https://www.minecraft.net/download", None::<&str>).map_err(|e| AppError::Other(e.to_string()))?;
    Ok(())
}

async fn get_json(url: &str) -> Result<Value> {
    Ok(HTTP_CLIENT.get(url).send().await?.error_for_status()?.json().await?)
}
fn component(value: &str) -> Result<&str> {
    if value.is_empty() || !value.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_')) || value == "." || value == ".." {
        return Err(AppError::Other("Ungültige Versionskennung.".into()));
    }
    Ok(value)
}

// Deserialize only the Minecraft game-session fields. No Azure/refresh tokens,
// passwords or credential-store blobs are accessed, copied or returned to the UI.
#[derive(Deserialize)]
struct SessionFile {
    accounts: std::collections::HashMap<String, CachedSession>,
    #[serde(rename = "activeAccountLocalId")]
    active: String,
}
#[derive(Deserialize)]
struct CachedSession {
    #[serde(rename = "accessToken")]
    token: String,
    #[serde(rename = "accessTokenExpiresAt")]
    expires: String,
    #[serde(rename = "minecraftProfile")]
    profile: Value,
    #[serde(rename = "localId", default)]
    local_id: String,
}
struct GameSession { token: String, expires: chrono::DateTime<chrono::Utc>, username: String, id: Uuid }
fn parse_session(bytes: &[u8]) -> Result<GameSession> {
    let file: SessionFile = serde_json::from_slice(bytes).map_err(|_| session_error())?;
    let selected = file.accounts.get(&file.active).or_else(||file.accounts.values().find(|a|a.local_id == file.active)).ok_or_else(session_error)?;
    let expires = chrono::DateTime::parse_from_rfc3339(&selected.expires).map_err(|_|session_error())?.with_timezone(&chrono::Utc);
    if expires <= chrono::Utc::now() + chrono::Duration::seconds(60) || selected.token.is_empty() { return Err(session_error()); }
    let id = selected.profile["id"].as_str().and_then(|s|Uuid::parse_str(s).ok()).ok_or_else(session_error)?;
    let username = selected.profile["name"].as_str().ok_or_else(session_error)?.to_owned();
    Ok(GameSession { token: selected.token.clone(), expires, username, id })
}
fn session_error() -> AppError { AppError::Other("Keine gültige Minecraft-Sitzung gefunden. Öffne den offiziellen Launcher, melde dich dort an und wähle Java Edition. Danach in Vertix erneut auf Spielen klicken. Eine eigene Microsoft-App-ID ist nicht nötig.".into()) }
async fn read_session(root: &Path) -> Result<GameSession> {
    for name in ["launcher_accounts_microsoft_store.json", "launcher_accounts.json"] {
        if let Ok(bytes) = fs::read(root.join(name)).await { if let Ok(session) = parse_session(&bytes) { return Ok(session); } }
    }
    Err(session_error())
}
async fn validated_session(root: &Path) -> Result<crate::minecraft::minecraft_auth::Credentials> {
    let session = read_session(root).await?;
    let response = HTTP_CLIENT.get("https://api.minecraftservices.com/minecraft/profile").bearer_auth(&session.token).send().await?;
    if !response.status().is_success() { return Err(session_error()); }
    let profile: Value = response.json().await?;
    let id = profile["id"].as_str().and_then(|s|Uuid::parse_str(s).ok()).ok_or_else(session_error)?;
    if id != session.id { return Err(session_error()); }
    let entitlement = HTTP_CLIENT.get("https://api.minecraftservices.com/entitlements/mcstore").bearer_auth(&session.token).send().await?;
    if !entitlement.status().is_success() { return Err(session_error()); }
    let entitlement: Value = entitlement.json().await?;
    if !entitlement["items"].as_array().is_some_and(|items|items.iter().any(|i|matches!(i["name"].as_str(),Some("game_minecraft" | "product_minecraft")))) {
        return Err(AppError::Other("Das aktive Konto hat keine bestätigte Berechtigung für Minecraft: Java Edition. Bitte im offiziellen Launcher prüfen.".into()));
    }
    Ok(crate::minecraft::minecraft_auth::Credentials {
        id, username: profile["name"].as_str().ok_or_else(session_error)?.to_owned(),
        access_token: session.token, refresh_token: String::new(), expires: session.expires,
        norisk_credentials: crate::minecraft::minecraft_auth::NoRiskCredentials { production: None, experimental: None },
        active: true, ignore_child_protection_warning: false, auth_flow: None, mc_access_token_expires: Some(session.expires),
    })
}
#[tauri::command]
pub async fn launch_vertix_instance(profile_id: Uuid) -> std::result::Result<(), CommandError> {
    let _guard = PREPARING.try_lock().map_err(|_|AppError::Other("Ein Spielstart oder eine Vorbereitung läuft bereits.".into()))?;
    let _content = crate::instance_content::CONTENT_LOCK.lock().await;
    let c = config().await?;
    let state = State::get().await?;
    crate::instance_content::ensure_stopped(&state, profile_id).await?;
    let mut profile = state.profile_manager.get_profile(profile_id).await?;
    crate::instance_content::isolated_root(&state, &profile).await?;
    progress(Some(&state), profile_id, "Minecraft-Sitzung wird geprüft …").await;
    let credentials = match crate::vertix_auth::credentials().await? {
        Some(account) => account,
        None => match validated_session(&minecraft_dir(&c)).await {
            Ok(session) => session,
            Err(_) => return Err(AppError::Other("Bitte melde dich oben rechts mit deinem Microsoft-Konto an, um Minecraft zu starten.".into()).into()),
        },
    };
    // This snapshot is intentionally independent of all upstream packs/migrations.
    profile.selected_norisk_pack_id = None; profile.sync_pack_ids.clear(); profile.is_standard_version = false;
    progress(Some(&state), profile_id, "Minecraft und Modloader werden vorbereitet …").await;
    crate::minecraft::installer::install_minecraft_version(&profile.game_version, profile.loader.as_str(), &profile,
        Some(credentials), None, None, None, Vec::new(), true).await?;
    let mut saved = state.profile_manager.get_profile(profile_id).await?;
    saved.last_played = Some(chrono::Utc::now()); state.profile_manager.update_profile(profile_id, saved).await?;
    Ok(())
}
async fn base_version(root: &Path, version: &str) -> Result<Value> {
    component(version)?;
    let path = root.join("versions").join(version).join(format!("{version}.json"));
    if path.is_file() { return Ok(serde_json::from_slice(&fs::read(&path).await?)?); }
    let manifest = get_json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json").await?;
    let url = manifest["versions"].as_array().and_then(|a| a.iter().find(|v| v["id"] == version)).and_then(|v| v["url"].as_str()).ok_or_else(|| AppError::VersionNotFound(version.to_owned()))?;
    let data = get_json(url).await?;
    fs::create_dir_all(path.parent().unwrap()).await?;
    write_atomic(&path, serde_json::to_vec_pretty(&data)?).await?;
    Ok(data)
}
async fn loader_manifest(profile: &Profile, loader_version: &str) -> Result<Value> {
    let version = component(&profile.game_version)?;
    let loader = component(loader_version.trim_end_matches(" (stable)").trim())?;
    let url = match profile.loader {
        ModLoader::Fabric => format!("https://meta.fabricmc.net/v2/versions/loader/{version}/{loader}/profile/json"),
        ModLoader::Quilt => format!("https://meta.quiltmc.org/v3/versions/loader/{version}/{loader}/profile/json"),
        _ => return Err(AppError::Other("Dieser Loader benötigt seinen Installer.".into())),
    };
    let data = get_json(&url).await?;
    if data["inheritsFrom"] != version || !data["mainClass"].is_string() || !data["libraries"].is_array() { return Err(AppError::Other("Der Modloader hat keine gültige Launcher-Version geliefert.".into())); }
    Ok(data)
}

// Forge/NeoForge's own client installer generates the official-launcher format.
// Run it in Vertix staging, then merge only its version and libraries, never its profiles.
async fn forge_manifest(profile: &Profile, loader_version: &str, base: &Value, root: &Path) -> Result<Value> {
    use crate::minecraft::downloads::java_download::JavaDownloadService;
    use crate::minecraft::dto::JavaDistribution;
    use crate::utils::download_utils::{DownloadConfig, DownloadUtils};
    let loader = component(loader_version)?;
    let (url, cache_name) = if profile.loader == ModLoader::Forge {
        let full = if loader.starts_with(&format!("{}-", profile.game_version)) { loader.to_owned() } else { format!("{}-{loader}", profile.game_version) };
        (format!("https://maven.minecraftforge.net/net/minecraftforge/forge/{full}/forge-{full}-installer.jar"), format!("forge-{full}"))
    } else { (format!("https://maven.neoforged.net/releases/net/neoforged/neoforge/{loader}/neoforge-{loader}-installer.jar"), format!("neoforge-{loader}")) };
    let staging = LAUNCHER_DIRECTORY.meta_dir().join("official-loader-cache").join(&cache_name);
    fs::create_dir_all(&staging).await?;
    let complete = staging.join("vertix-version.json");
    let data = if complete.exists() { serde_json::from_slice(&fs::read(&complete).await?)? } else {
        let jar = staging.join("installer.jar");
        DownloadUtils::download_file(&url, &jar, DownloadConfig::new().with_retries(3)).await?;
        let java_major = base["javaVersion"]["majorVersion"].as_u64().unwrap_or(8).max(8) as u32;
        let java = JavaDownloadService::new().get_or_download_java(java_major, &JavaDistribution::Temurin, None).await?;
        write_atomic(staging.join("launcher_profiles.json"), br#"{"profiles":{}}"#).await?;
        let version_dir = staging.join("versions").join(&profile.game_version);
        fs::create_dir_all(&version_dir).await?;
        write_atomic(version_dir.join(format!("{}.json",profile.game_version)), serde_json::to_vec_pretty(base)?).await?;
        let client = version_dir.join(format!("{}.jar",profile.game_version));
        let client_url = base["downloads"]["client"]["url"].as_str().ok_or_else(|| AppError::Other("Minecraft-Clientdownload fehlt.".into()))?;
        DownloadUtils::download_file(client_url, &client, DownloadConfig::new().with_retries(3)).await?;
        let log = std::fs::File::create(staging.join("vertix-installer.log"))?;
        let error_log = log.try_clone()?;
        let mut command = Command::new(java);
        hidden(&mut command);
        command.kill_on_drop(true).current_dir(&staging).arg("-jar").arg(&jar).arg("--installClient").arg(&staging).stdout(log).stderr(error_log);
        let status = tokio::time::timeout(std::time::Duration::from_secs(1200), command.status()).await.map_err(|_| AppError::Other(format!("Modloader-Installation dauert zu lange. Protokoll: {}", staging.join("vertix-installer.log").display())))??;
        if !status.success() { return Err(AppError::Other(format!("Der {}-Installer konnte diese Version nicht vorbereiten. Protokoll: {}",profile.loader.as_str(),staging.join("vertix-installer.log").display()))); }
        let profiles: Value = serde_json::from_slice(&fs::read(staging.join("launcher_profiles.json")).await?)?;
        let id = profiles["profiles"].as_object().and_then(|p|p.values().find_map(|v|v["lastVersionId"].as_str())).ok_or_else(|| AppError::Other("Der Modloader-Installer hat keine Spielversion angelegt.".into()))?;
        component(id)?;
        let data: Value = serde_json::from_slice(&fs::read(staging.join("versions").join(id).join(format!("{id}.json"))).await?)?;
        write_atomic(&complete,serde_json::to_vec_pretty(&data)?).await?;
        data
    };
    // Keep the official installer's generated library layout, including processor outputs.
    copy_libraries(&staging.join("libraries"), &root.join("libraries")).await?;
    Ok(data)
}
async fn copy_libraries(source: &Path, destination: &Path) -> Result<()> {
    let mut stack = vec![(source.to_owned(), destination.to_owned())];
    while let Some((from,to))=stack.pop() {
        if !from.exists() { continue; }
        fs::create_dir_all(&to).await?;
        let mut entries=fs::read_dir(&from).await?;
        while let Some(entry)=entries.next_entry().await? {
            let target=to.join(entry.file_name()); let kind=entry.file_type().await?;
            if kind.is_dir() { stack.push((entry.path(),target)); }
            else if kind.is_file() && !target.exists() { fs::copy(entry.path(),target).await?; }
        }
    }
    Ok(())
}

fn merged_installation(mut document: Value, id: Uuid, name: &str, version: &str, directory: &Path, memory: u32) -> Result<Value> {
    if !document.is_object() { return Err(AppError::Other("Die Installationsdatei des Minecraft Launchers ist ungültig.".into())); }
    if document.get("profiles").is_none() { document["profiles"]=json!({}); }
    let profiles=document["profiles"].as_object_mut().ok_or_else(||AppError::Other("Die Installationsliste des Minecraft Launchers ist ungültig.".into()))?;
    let key=format!("vertix-{id}");
    // Replace only Vertix's own installation; preserve every other installation and setting.
    let created=profiles.get(&key).and_then(|p|p.get("created")).cloned().unwrap_or_else(||json!(chrono::Utc::now().to_rfc3339()));
    profiles.insert(key.clone(),json!({"name":format!("Vertix · {name}"),"type":"custom","created":created,
        "lastUsed":chrono::Utc::now().to_rfc3339(),"lastVersionId":version,"gameDir":directory,
        "javaArgs":format!("-Xms1024M -Xmx{memory}M"),"icon":"Furnace"}));
    document["selectedProfile"]=json!(key);
    Ok(document)
}
async fn write_installation(root: &Path, profile: &Profile, version: &str, game_dir: &Path) -> Result<()> {
    let files:Vec<PathBuf>=PROFILE_FILES.iter().map(|name|root.join(name)).filter(|p|p.is_file()).collect();
    if files.is_empty() { return Err(AppError::Other("Öffne zuerst den offiziellen Minecraft Launcher, melde dich an und schließe ihn wieder. Danach kann Vertix die Installation hinzufügen.".into())); }
    // Parse all files before writing any. Never print or expose their account-related fields.
    let mut changes=Vec::new();
    for file in files {
        let original=fs::read(&file).await?;
        let merged=merged_installation(serde_json::from_slice(&original)?,profile.id,&profile.name,version,game_dir,profile.settings.memory.max)?;
        changes.push((file,original,serde_json::to_vec_pretty(&merged)?));
    }
    for (file,original,merged) in changes {
        if launcher_running() || fs::read(&file).await? != original { return Err(AppError::Other("Der offizielle Launcher hat seine Installationen gerade geändert. Schließe ihn und bereite das Profil erneut vor.".into())); }
        let backup=file.with_extension(format!("json.vertix-backup-{}",Uuid::new_v4()));
        write_atomic(&backup,&original).await?;
        write_atomic(&file,&merged).await?;
    }
    Ok(())
}

async fn progress(state: Option<&State>, profile_id: Uuid, message: &str) {
    if let Some(state) = state {
        let _ = state.emit_event(crate::state::event_state::EventPayload {
            event_id: Uuid::new_v4(), event_type: crate::state::event_state::EventType::TaskProgress,
            target_id: Some(profile_id), message: message.into(), progress: None, error: None,
        }).await;
    }
}

#[tauri::command]
pub async fn prepare_official_profile(profile_id: Uuid) -> std::result::Result<PreparedProfile, CommandError> {
    let _guard=PREPARING.try_lock().map_err(|_|AppError::Other("Ein Profil wird bereits vorbereitet. Bitte kurz warten.".into()))?;
    let _content=crate::instance_content::CONTENT_LOCK.lock().await;
    let c=config().await?; let root=minecraft_dir(&c);
    if detect_target(&c).await.is_none() { return Err(AppError::Other("Installiere zuerst den offiziellen Minecraft Launcher und melde dich dort mit deinem Minecraft-Konto an. Du benötigst keine eigene Microsoft-App-ID.".into()).into()); }
    if launcher_running() { return Err(AppError::Other("Bitte den offiziellen Minecraft Launcher vollständig schließen und anschließend das Profil erneut vorbereiten.".into()).into()); }
    if !PROFILE_FILES.iter().any(|name|root.join(name).is_file()) { return Err(AppError::Other("Öffne den offiziellen Launcher zuerst einmal, melde dich dort an und schließe ihn wieder. Danach hier erneut versuchen.".into()).into()); }
    let state=State::get().await?;
    crate::instance_content::ensure_stopped(&state,profile_id).await?;
    let profile=state.profile_manager.get_profile(profile_id).await?;
    if profile.use_shared_minecraft_folder { return Err(AppError::Other("Dieses Profil verwendet einen gemeinsamen Spielordner. Erstelle ein eigenes Vertix-Profil mit getrenntem Ordner.".into()).into()); }
    let game_dir=crate::instance_content::isolated_root(&state,&profile).await?;
    let prepared=prepare_files(&root,&profile,&game_dir,Some(state.as_ref())).await?;
    progress(Some(state.as_ref()),profile.id,"Installation im Minecraft Launcher eintragen …").await;
    write_installation(&root,&profile,&prepared.version_id,&game_dir).await?;
    Ok(prepared)
}
async fn prepare_files(root: &Path, profile: &Profile, game_dir: &Path, state: Option<&State>) -> Result<PreparedProfile> {
    fs::create_dir_all(game_dir).await?;
    progress(state,profile.id,"Minecraft-Version wird vorbereitet …").await;
    let base=base_version(root,&profile.game_version).await?;
    let version_id=if profile.loader==ModLoader::Vanilla { profile.game_version.clone() } else {
        progress(state,profile.id,"Modloader wird vorbereitet …").await;
        let loader=ModloaderFactory::resolve_loader_version(profile,&profile.game_version,None).await.version.ok_or_else(||AppError::Other("Keine kompatible Modloader-Version gefunden.".into()))?;
        let mut manifest=match profile.loader {
            ModLoader::Fabric | ModLoader::Quilt => loader_manifest(profile,&loader).await?,
            ModLoader::Forge | ModLoader::NeoForge => forge_manifest(profile,&loader,&base,root).await?,
            ModLoader::Vanilla => unreachable!(),
        };
        let id=format!("vertix-{}",profile.id);
        manifest["id"]=json!(id);
        let directory=root.join("versions").join(&id);fs::create_dir_all(&directory).await?;
        write_atomic(directory.join(format!("{id}.json")),serde_json::to_vec_pretty(&manifest)?).await?;
        id
    };
    if profile.loader!=ModLoader::Vanilla {
        progress(state,profile.id,"Profil-Mods werden heruntergeladen und synchronisiert …").await;
        ModDownloadService::new().download_mods_to_cache(profile).await?;
        let mods_dir=game_dir.join("mods");fs::create_dir_all(&mods_dir).await?;
        // Local unmanaged JARs already live here and stay untouched by the managed-file synchronizer.
        let (mods,_)=crate::minecraft::downloads::mod_resolver::resolve_target_mods(profile,None,None,&[],&profile.game_version,profile.loader.as_str(),&LAUNCHER_DIRECTORY.meta_dir().join("mod_cache")).await?;
        crate::minecraft::installer::sync_vertix_mods(&mods,&mods_dir).await?;
    }
    Ok(PreparedProfile{installation_name:format!("Vertix · {}",profile.name),game_directory:game_dir.to_string_lossy().into_owned(),version_id})
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cached_session_uses_only_active_game_account_and_rejects_expiry() {
        let id=Uuid::new_v4();
        let mut doc=json!({"activeAccountLocalId":"a","accounts":{"a":{"accessToken":"fake-test-session","accessTokenExpiresAt":(chrono::Utc::now()+chrono::Duration::hours(1)).to_rfc3339(),"minecraftProfile":{"id":id.simple().to_string(),"name":"Test"},"azureToken":"must-not-be-reused"}}});
        let session=parse_session(&serde_json::to_vec(&doc).unwrap()).unwrap();assert_eq!(session.id,id);assert_eq!(session.token,"fake-test-session");
        doc["activeAccountLocalId"]=json!("missing");assert!(parse_session(&serde_json::to_vec(&doc).unwrap()).is_err());
        doc["activeAccountLocalId"]=json!("a");doc["accounts"]["a"]["accessTokenExpiresAt"]=json!("2000-01-01T00:00:00Z");assert!(parse_session(&serde_json::to_vec(&doc).unwrap()).is_err());
    }
    #[tokio::test]
    #[ignore = "Checks installed launcher and validates the locally signed-in game session with Minecraft"]
    async fn live_installed_launcher_and_session_are_valid() {
        let c=config().await.unwrap();assert!(detect_target(&c).await.is_some());
        let credentials=validated_session(&minecraft_dir(&c)).await.unwrap();assert!(!credentials.access_token.is_empty());assert!(credentials.refresh_token.is_empty());
    }
    fn sample_profile(name: &str, loader: &str) -> Profile {
        serde_json::from_value(json!({"name":name,"path":name,"game_version":"1.21.1","loader":loader})).unwrap()
    }
    #[test]
    fn preserves_existing_installations_and_fields_and_isolates_profiles() {
        let root=tempfile::tempdir().unwrap();let a=Uuid::new_v4();let b=Uuid::new_v4();
        let original=json!({"profiles":{"unrelated":{"name":"Existing","gameDir":"keep"}},"authenticationDatabase":{"sentinel":"untouched"},"settings":{"keep":true}});
        let first=merged_installation(original.clone(),a,"A","1.21.1",&root.path().join("a"),4096).unwrap();
        let second=merged_installation(first,b,"B","vertix-fabric",&root.path().join("b"),8192).unwrap();
        assert_eq!(second["profiles"]["unrelated"],original["profiles"]["unrelated"]);
        assert_eq!(second["authenticationDatabase"],original["authenticationDatabase"]);
        assert_eq!(second["settings"],original["settings"]);
        assert_ne!(second["profiles"][format!("vertix-{a}")]["gameDir"],second["profiles"][format!("vertix-{b}")]["gameDir"]);
        assert_eq!(second["profiles"][format!("vertix-{b}")]["javaArgs"],"-Xms1024M -Xmx8192M");
    }
    #[test]
    fn repeated_export_updates_only_its_own_entry() {
        let id=Uuid::new_v4();let path=Path::new("C:/test/instance");
        let first=merged_installation(json!({"profiles":{}}),id,"Old","1.21",path,4096).unwrap();
        let created=first["profiles"][format!("vertix-{id}")]["created"].clone();
        let next=merged_installation(first,id,"New","1.21.1",path,6144).unwrap();
        assert_eq!(next["profiles"].as_object().unwrap().len(),1);
        assert_eq!(next["profiles"][format!("vertix-{id}")]["created"],created);
        assert_eq!(next["profiles"][format!("vertix-{id}")]["lastVersionId"],"1.21.1");
    }
    #[test]
    fn rejects_invalid_documents_and_version_paths() {
        assert!(merged_installation(json!({"profiles":[]}),Uuid::new_v4(),"a","v",Path::new("a"),4096).is_err());
        for s in ["../escape", "C:/escape", "..", "a\\b", ""] { assert!(component(s).is_err()); }
    }
    #[tokio::test]
    async fn sync_removes_only_managed_mods_and_keeps_profile_files_separate() {
        use crate::minecraft::downloads::mod_resolver::TargetMod;
        let dir=tempfile::tempdir().unwrap();let a=dir.path().join("a/mods");let b=dir.path().join("b/mods");
        fs::create_dir_all(&a).await.unwrap();fs::create_dir_all(&b).await.unwrap();
        fs::write(a.join("local.jar"),b"local").await.unwrap();fs::write(b.join("other.jar"),b"other").await.unwrap();
        let source=dir.path().join("cache.jar");fs::write(&source,b"mod").await.unwrap();
        let m=TargetMod{mod_id:"test".into(),filename:"managed.jar".into(),cache_path:source,sha1:None};
        crate::minecraft::installer::sync_vertix_mods(&[m],&a).await.unwrap();
        assert!(a.join("managed.jar").exists());assert!(!b.join("managed.jar").exists());
        crate::minecraft::installer::sync_vertix_mods(&[],&a).await.unwrap();
        assert!(!a.join("managed.jar").exists());assert!(a.join("local.jar").exists());assert!(b.join("other.jar").exists());
    }
    #[tokio::test]
    #[ignore = "Live Mojang, Fabric, Quilt and Modrinth metadata and mod download"]
    async fn live_preparation_exports_three_isolated_profiles_and_downloads_real_mod() {
        let temp=tempfile::tempdir().unwrap();let root=temp.path().join("launcher");fs::create_dir_all(&root).await.unwrap();
        for name in PROFILE_FILES { fs::write(root.join(name),br#"{"profiles":{"existing":{"name":"Keep me"}},"settings":{"keep":true}}"#).await.unwrap(); }
        let vanilla=sample_profile("Vanilla","vanilla");let vanilla_dir=temp.path().join("instances/vanilla");
        let a=prepare_files(&root,&vanilla,&vanilla_dir,None).await.unwrap();
        write_installation(&root,&vanilla,&a.version_id,&vanilla_dir).await.unwrap();
        let mut fabric=sample_profile("Fabric","fabric");let fabric_dir=temp.path().join("instances/fabric");
        let versions=get_json("https://api.modrinth.com/v2/project/AANobbMI/version?loaders=%5B%22fabric%22%5D&game_versions=%5B%221.21.1%22%5D").await.unwrap();
        let version=&versions[0];let file=version["files"].as_array().unwrap().iter().find(|f|f["primary"]==true).unwrap();
        fabric.mods.push(serde_json::from_value(json!({"enabled":true,"display_name":"Sodium","version":version["version_number"],"game_versions":["1.21.1"],"associated_loader":"fabric","source":{"type":"modrinth","project_id":"AANobbMI","version_id":version["id"],"file_name":file["filename"],"download_url":file["url"],"file_hash_sha1":file["hashes"]["sha1"]}})).unwrap());
        let b=prepare_files(&root,&fabric,&fabric_dir,None).await.unwrap();
        write_installation(&root,&fabric,&b.version_id,&fabric_dir).await.unwrap();
        let mod_file=fabric_dir.join("mods").join(file["filename"].as_str().unwrap());
        assert!(fs::metadata(&mod_file).await.unwrap().len()>1000);
        assert!(!vanilla_dir.join("mods").join(file["filename"].as_str().unwrap()).exists());
        fabric.mods[0].enabled=false;
        prepare_files(&root,&fabric,&fabric_dir,None).await.unwrap();assert!(!mod_file.exists());
        let quilt=sample_profile("Quilt","quilt");let quilt_dir=temp.path().join("instances/quilt");
        let c=prepare_files(&root,&quilt,&quilt_dir,None).await.unwrap();
        write_installation(&root,&quilt,&c.version_id,&quilt_dir).await.unwrap();
        for file_name in PROFILE_FILES {
            let doc:Value=serde_json::from_slice(&fs::read(root.join(file_name)).await.unwrap()).unwrap();
            assert_eq!(doc["profiles"].as_object().unwrap().len(),4);assert_eq!(doc["settings"]["keep"],true);
            assert_eq!(doc["profiles"]["existing"]["name"],"Keep me");
            let paths:std::collections::HashSet<_>=[&vanilla,&fabric,&quilt].iter().map(|p|doc["profiles"][format!("vertix-{}",p.id)]["gameDir"].as_str().unwrap().to_owned()).collect();assert_eq!(paths.len(),3);
        }
        for id in [&b.version_id,&c.version_id] {
            let manifest:Value=serde_json::from_slice(&fs::read(root.join("versions").join(id).join(format!("{id}.json"))).await.unwrap()).unwrap();
            assert_eq!(manifest["id"],id.as_str());assert_eq!(manifest["inheritsFrom"],"1.21.1");
        }
    }
}
