import { Box, Check, FolderOpen, HardDrive, Layers3, Settings2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { Profile } from './api';
import * as api from './api';
import { LoaderVersion } from './LoaderVersion';
export type InstanceChanges = { name: string; memory: number; game_version: string; loader: api.Loader; loader_version: string | null };

export function InstanceSettings({ profile, directory, locked, canSave, onSave, onClose, onOpenFolder }: {
  profile: Profile; directory: string; locked: boolean; canSave: boolean;
  onSave: (changes: InstanceChanges) => void; onClose: () => void; onOpenFolder: () => void;
}) {
  const [section, setSection] = useState<'general' | 'installation'>('general');
  const [name, setName] = useState(profile.name);
  const [memory, setMemory] = useState(profile.settings.memory.max);
  const [gameVersion, setGameVersion] = useState(profile.game_version), [platform, setPlatform] = useState(profile.loader), [loaderVersion, setLoaderVersion] = useState(profile.loader_version?.replace(' (stable)', '') || '');
  const [versions, setVersions] = useState([profile.game_version]), [versionError, setVersionError] = useState(''), [loaderValid, setLoaderValid] = useState(true);
  const changedInstallation = gameVersion !== profile.game_version || platform !== profile.loader || loaderVersion !== (profile.loader_version?.replace(' (stable)', '') || '');
  useEffect(() => { const c = new AbortController(); api.minecraftVersions(c.signal).then(list => setVersions([...new Set([profile.game_version, ...list])])).catch(e => { if (!c.signal.aborted) setVersionError(String(e)); }); return () => c.abort(); }, []);
  const maxMemory = Math.max(32768, Math.ceil(profile.settings.memory.max / 512) * 512);
  const loader = profile.loader === 'vanilla' ? 'Vanilla' : profile.loader[0].toUpperCase() + profile.loader.slice(1);
  const ram = (memory / 1024).toLocaleString('de', { maximumFractionDigits: 2 });
  return <>
    <div className="instance-settings-layout">
      <nav className="instance-settings-nav" aria-label="Einstellungsbereiche">
        <div className="settings-instance"><Box size={24} /><strong>{profile.name}</strong><small>{loader} · {profile.game_version}</small></div>
        <button type="button" className={section === 'general' ? 'active' : ''} aria-current={section === 'general' ? 'page' : undefined} onClick={() => setSection('general')}><Settings2 size={17} />Allgemein</button>
        <button type="button" className={section === 'installation' ? 'active' : ''} aria-current={section === 'installation' ? 'page' : undefined} onClick={() => setSection('installation')}><Layers3 size={17} />Installation</button>
      </nav>
      <div className="instance-settings-content">
        {section === 'general' ? <>
          <div className="settings-section-heading"><span>DEINE INSTANZ</span><h3>Ganz nach deinem Spiel.</h3><p>Name und Leistung für diese Instanz einstellen.</p></div>
          <label className="field">Name<input autoFocus disabled={locked} value={name} maxLength={60} onChange={e => setName(e.target.value)} /></label>
          <section className="settings-ram" aria-labelledby="settings-ram-title">
            <div className="settings-ram-heading"><div><HardDrive size={18} /><h4 id="settings-ram-title">Arbeitsspeicher</h4></div><output htmlFor="instance-ram">{ram}<small> GB RAM</small></output></div>
            <p>Maximaler RAM für Minecraft. Lass ausreichend Speicher für Windows und andere Programme frei.</p>
            <input id="instance-ram" aria-label="Arbeitsspeicher in MB" aria-valuetext={`${ram} GB RAM`} type="range" min={1024} max={maxMemory} step={512} value={memory} disabled={locked} onChange={e => setMemory(Number(e.target.value))} />
            <div className="settings-ram-scale"><span>1 GB</span><span>{maxMemory / 1024} GB</span></div>
            <div className="settings-ram-presets" aria-label="RAM-Voreinstellungen">{[2048,4096,6144,8192].map(value => <button type="button" key={value} disabled={locked} aria-pressed={memory === value} className={memory === value ? 'active' : ''} onClick={() => setMemory(value)}>{value / 1024} GB</button>)}</div>
          </section>
        </> : <>
          <div className="settings-section-heading"><span>DEIN SETUP</span><h3>Installation im Überblick.</h3><p>Versionen und Dateien dieser Instanz.</p></div>
          <div className="form-row"><label className="field">Minecraft-Version<select aria-label="Minecraft-Version" disabled={locked} value={gameVersion} onChange={e => { setGameVersion(e.target.value); setLoaderVersion(''); setLoaderValid(false); }}>{versions.map(v => <option key={v}>{v}</option>)}</select></label><label className="field">Modloader<select aria-label="Modloader" disabled={locked} value={platform} onChange={e => { setPlatform(e.target.value as api.Loader); setLoaderVersion(''); setLoaderValid(e.target.value === 'vanilla'); }}>{['vanilla','fabric','forge','neoforge','quilt'].map(v => <option key={v} value={v}>{v === 'neoforge' ? 'NeoForge' : v[0].toUpperCase() + v.slice(1)}</option>)}</select></label></div>
          <LoaderVersion loader={platform} gameVersion={gameVersion} value={loaderVersion} onChange={setLoaderVersion} disabled={locked} onValid={setLoaderValid} />
          {versionError && <p className="inline-error">Versionsliste konnte nicht geladen werden: {versionError}</p>}
          <div className="info-box"><Layers3 size={18} /><span>{changedInstallation ? 'Vor dem Versionswechsel Welten sichern. Bestehende Mods werden nicht automatisch angepasst; inkompatible Inhalte können den Spielstart verhindern.' : 'Standardmäßig wird die neueste kompatible Modloader-Version verwendet. Du kannst hier eine bestimmte Version festlegen.'}</span></div>
          <section className="settings-folder"><h4>Instanzordner</h4><p>Welten, Mods und Konfigurationen an einem Ort.</p><code>{directory || 'Der Ordner wird beim ersten Start angelegt.'}</code><button type="button" className="button" disabled={!canSave || locked} onClick={onOpenFolder}><FolderOpen size={16} />Ordner öffnen</button></section>
        </>}
      </div>
    </div>
    <div className="dialog-actions settings-footer"><span>{locked ? 'Änderungen sind während laufender Aktionen gesperrt.' : 'Gilt nur für diese Instanz.'}</span><button className="button" disabled={locked} onClick={onClose}>Abbrechen</button><button className="button light" disabled={locked || !canSave || !name.trim() || (changedInstallation && !loaderValid)} onClick={() => onSave({ name: name.trim(), memory, game_version: gameVersion, loader: platform, loader_version: loaderVersion || null })}><Check size={16} />Speichern</button></div>
  </>;
}
