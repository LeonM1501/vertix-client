import type { Profile } from './api';
export type ContentVersion = { id: string; version_number: string; version_type: string; game_versions: string[]; loaders: string[]; files: unknown[] };
export function compatibleVersion(versions: ContentVersion[], profile: Pick<Profile, 'game_version' | 'loader'>): { version?: ContentVersion; reason?: string } {
  if (profile.loader === 'vanilla') return { reason: 'Nicht kompatibel · Vanilla unterstützt keine Mods' };
  const withLoader = versions.filter(v => v.loaders.includes(profile.loader) && v.files.length > 0);
  if (!withLoader.length) return { reason: `Nicht kompatibel · ${profile.loader} wird nicht unterstützt` };
  const matching = withLoader.filter(v => v.game_versions.includes(profile.game_version));
  const version = matching.find(v => v.version_type === 'release') || matching[0];
  return version ? { version } : { reason: `Nicht kompatibel · keine Version für Minecraft ${profile.game_version}` };
}
