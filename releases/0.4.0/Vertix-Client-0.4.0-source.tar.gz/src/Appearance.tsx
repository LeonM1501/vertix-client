import { useLayoutEffect, useState } from 'react';
import { Check } from 'lucide-react';
export const designs = [
  { id: 'mono', name: 'Mono', description: 'Seitenleiste. Klare Flächen. Alles an seinem Platz.', layout: 'left' },
  { id: 'paper', name: 'Papier', description: 'Helle Bibliothek. Große Schrift. Navigation rechts.', layout: 'right' },
  { id: 'terminal', name: 'Terminal', description: 'Navigation oben. Dichte Listen. Direkter Zugriff.', layout: 'top' },
  { id: 'gallery', name: 'Galerie', description: 'Schmale Symbolleiste. Große Karten. Raum für Instanzen.', layout: 'rail' },
  { id: 'focus', name: 'Fokus', description: 'Dein Spiel im Mittelpunkt. Navigation am unteren Rand.', layout: 'bottom' },
] as const;
export type Design = typeof designs[number]['id'];
export type Appearance = { design: Design; density: 'comfortable' | 'compact'; scale: number; corners: 'square' | 'soft' };
const initial: Appearance = { design: 'mono', density: 'comfortable', scale: 100, corners: 'soft' };
export function readAppearance(): Appearance {
  try {
    const v = JSON.parse(localStorage.getItem('vertix-appearance-v1') || '{}');
    return { design: designs.some(d => d.id === v.design) ? v.design : initial.design, density: v.density === 'compact' ? 'compact' : 'comfortable', scale: [90,100,110,120].includes(v.scale) ? v.scale : 100, corners: v.corners === 'square' ? 'square' : 'soft' };
  } catch { return initial; }
}
export function useAppearance() {
  const [appearance, setAppearance] = useState(readAppearance);
  useLayoutEffect(() => {
    try { localStorage.setItem('vertix-appearance-v1', JSON.stringify(appearance)); } catch { /* Keep this session usable when browser storage is full. */ }
    const root = document.documentElement;
    root.dataset.design = appearance.design; root.dataset.density = appearance.density; root.dataset.corners = appearance.corners;
    root.style.setProperty('--ui-scale', String(appearance.scale / 100));
  }, [appearance]);
  return [appearance, setAppearance] as const;
}
export function AppearanceSettings({ value, onChange }: { value: Appearance; onChange: (value: Appearance) => void }) {
  return <section className="appearance-settings"><div className="section-heading"><div><h2>Deine Oberfläche</h2><p>Fünf Anordnungen. Ein Klick zum Wechseln.</p></div><span className="settings-autosave">Wird automatisch gespeichert</span></div>
    <div className="design-options">{designs.map(d => <button type="button" aria-label={`Design ${d.name}`} aria-pressed={value.design === d.id} className={`design-option ${value.design === d.id ? 'selected' : ''}`} key={d.id} onClick={() => onChange({ ...value, design: d.id })}>
      <div aria-hidden="true" className={`design-mini ${d.layout} ${d.id}`}><i className="mini-nav" /><div className="mini-main"><i className="mini-title" /><i className="mini-feature" /><div><i /><i /><i /></div></div></div>
      <div className="design-option-heading"><strong>{d.name}</strong>{value.design === d.id && <Check size={16} />}</div><p>{d.description}</p>
    </button>)}</div>
    <div className="appearance-controls"><label className="field">Abstände<select aria-label="Abstände" value={value.density} onChange={e => onChange({ ...value, density: e.target.value as Appearance['density'] })}><option value="comfortable">Entspannt</option><option value="compact">Kompakt</option></select></label>
      <label className="field">Schriftgröße<select aria-label="Schriftgröße" value={value.scale} onChange={e => onChange({ ...value, scale: Number(e.target.value) })}>{[90,100,110,120].map(n => <option key={n} value={n}>{n}%</option>)}</select></label>
      <label className="field">Ecken<select aria-label="Ecken" value={value.corners} onChange={e => onChange({ ...value, corners: e.target.value as Appearance['corners'] })}><option value="soft">Leicht gerundet</option><option value="square">Gerade</option></select></label>
    </div><button className="text-button" onClick={() => onChange(initial)}>Darstellung zurücksetzen</button>
  </section>;
}
