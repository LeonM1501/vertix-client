import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowDownToLine, ArrowRight, Box, Check, ChevronRight, CircleHelp, Gamepad2, Layers3, LoaderCircle, Minus, MoreHorizontal, Package, Play, Plus, RefreshCw, Search, Settings2, ShieldCheck, SlidersHorizontal, Sparkles, Square, Trash2, UserRound, X } from 'lucide-react';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { listen } from '@tauri-apps/api/event';
import * as api from './api';
import type { AccountStatus, Loader, Profile } from './api';
import { InstanceWorkspace } from './Instance';
import { version as appVersion } from '../package.json';

type Page = 'play' | 'profiles' | 'mods' | 'settings' | 'instance';
const loaderLabels: Record<Loader, string> = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };
const nav = [{ id: 'play', label: 'Spielen', icon: Gamepad2 }, { id: 'profiles', label: 'Meine Instanzen', icon: Layers3 }, { id: 'mods', label: 'Inhalte entdecken', icon: Package }] as const;
const errorText = (e: unknown): string => typeof e === 'string' ? e : e instanceof Error ? e.message : e && typeof e === 'object' && 'message' in e ? String(e.message) : JSON.stringify(e);

export function App() {
  const [page, setPage] = useState<Page>('play');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [selectedId, setSelectedId] = useState(localStorage.getItem('vertix-selected-profile') || '');
  const [account, setAccount] = useState<AccountStatus | null>(null);
  const [accountOpen, setAccountOpen] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Profile | null>(null);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [launchId, setLaunchId] = useState<string | null>(null);
  const [progress, setProgress] = useState('');
  const [ready, setReady] = useState(!api.desktop);
  const [startupError, setStartupError] = useState('');
  const [notice, setNotice] = useState<{ text: string; error?: boolean } | null>(null);
  const [profileQuery, setProfileQuery] = useState('');
  const [updateInfo, setUpdateInfo] = useState<api.AppUpdateInfo | null>(null);
  const [updateState, setUpdateState] = useState<'available' | 'downloading' | 'downloaded'>('available');
  const [downloadPercent, setDownloadPercent] = useState<number>(0);
  const noticeTimer = useRef<ReturnType<typeof setTimeout>>();
  const contentRef = useRef<HTMLElement>(null);
  useEffect(() => { contentRef.current?.scrollTo({ top: 0 }); }, [page]);
  const selected = profiles.find(p => p.id === selectedId) || profiles[0];
  const notify = (text: string, error = false) => { clearTimeout(noticeTimer.current); setNotice({ text, error }); noticeTimer.current = setTimeout(() => setNotice(null), error ? 12000 : 5000); };
  const reload = async () => { const list = await api.profiles(); setProfiles(list); return list; };
  const reloadAccount = async () => { if (!api.desktop) return null; const value = await api.call<AccountStatus>('get_vertix_account'); setAccount(value); return value; };
  async function signIn() {
    setSigningIn(true); setAuthError('');
    try { setAccount(await api.call<AccountStatus>('sign_in_vertix')); setAccountOpen(false); notify('Mit Minecraft angemeldet.'); }
    catch (e) { setAuthError(errorText(e)); } finally { setSigningIn(false); }
  }
  const perform = async (fn: () => Promise<unknown>, success?: string) => { try { await fn(); if (success) notify(success); } catch (e) { notify(errorText(e), true); } };
  useEffect(() => {
    let disposed = false, pending = false;
    const load = async () => {
      if (pending) return; pending = true;
      try {
        if (api.desktop) { const s = await api.call<{ ready: boolean; error: string | null }>('vertix_status'); if (disposed) return; if (s.error) { setStartupError(s.error); return; } if (!s.ready) return; }
        await reload(); await reloadAccount(); if (!disposed) setReady(true);
      } finally { pending = false; }
    };
    load().catch(e => { if (!disposed) setStartupError(errorText(e)); });
    const timer = api.desktop ? setInterval(() => { if (!ready) load().catch(e => setStartupError(errorText(e))); }, 1000) : undefined;
    return () => { disposed = true; clearInterval(timer); };
  }, [ready]);
  useEffect(() => { if (selected) localStorage.setItem('vertix-selected-profile', selected.id); }, [selected?.id]);
  useEffect(() => {
    if (!api.desktop) return;
    const listener = listen<{ message: string }>('state_event', event => setProgress(event.payload.message));
    return () => { listener.then(f => f()).catch(console.error); };
  }, []);
  useEffect(() => { const close = (e: KeyboardEvent) => { if (e.key === 'Escape') { setCreateOpen(false); setDeleteTarget(null); setAboutOpen(false); } }; document.addEventListener('keydown', close); return () => document.removeEventListener('keydown', close); }, [launchId]);

  useEffect(() => {
    if (!api.desktop) return;
    const check = () => {
      api.checkAppUpdate().then(info => {
        if (info && info.update_available) {
          setUpdateInfo(info);
          // Keep an active download or completed download across background checks.
        }
      }).catch(console.error);
    };
    check();
    const interval = setInterval(check, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!api.desktop) return;
    const unlisten = listen<{ percent: number; done: boolean }>('update_download_progress', event => {
      setDownloadPercent(event.payload.percent);
      if (event.payload.done) {
        setUpdateState('downloaded');
      }
    });
    return () => { unlisten.then(f => f()).catch(console.error); };
  }, []);

  async function handleUpdateClick() {
    if (!updateInfo) return;
    if (updateState === 'available') {
      setUpdateState('downloading');
      setDownloadPercent(0);
      try {
        await api.downloadAppUpdate(updateInfo.installer_url);
        setUpdateState('downloaded');
        notify('Update heruntergeladen! Klicke jetzt erneut auf den Button, um es zu installieren.');
      } catch (e) {
        setUpdateState('available');
        notify(errorText(e), true);
      }
    } else if (updateState === 'downloaded') {
      try {
        notify('Vertix wird beendet und das Setup gestartet …');
        await api.installAppUpdate();
      } catch (e) {
        notify(errorText(e), true);
      }
    }
  }

  async function launch() {
    if (!selected) { setCreateOpen(true); return; }
    if (!api.desktop) { notify('Instanzen startest du in der Desktop-App.', true); return; }
    if (launchId) return;
    setLaunchId(selected.id); setProgress('Minecraft-Konto wird geprüft …');
    try {
      const ownAccount = await reloadAccount();
      if (!ownAccount?.signed_in) {
        setAccountOpen(true);
        throw new Error('Melde dich zuerst oben rechts mit deinem Microsoft-Konto an.');
      }
      setProgress('Minecraft wird vorbereitet …');
      await api.call('launch_vertix_instance', { profileId: selected.id });
      await reload();
      notify('Minecraft wurde gestartet.');
    } catch (e) { notify(errorText(e), true); } finally { setLaunchId(null); setProgress(''); }
  }

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><img src="/vertix.svg" alt="" /><div>VERTIX<span>MAKE IT YOURS.</span></div></div><div className="nav-caption">DEIN LAUNCHER</div>
      <nav aria-label="Hauptnavigation">{nav.map(item => <button key={item.id} aria-label={item.label} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}><item.icon size={19} /><span>{item.label}</span>{page === item.id && <span className="nav-dot" />}</button>)}</nav>
      <div className="sidebar-profiles"><div className="sidebar-section-label"><span>DEINE INSTANZEN</span><button aria-label="Profil erstellen" className="icon-button" disabled={!ready} onClick={() => setCreateOpen(true)}><Plus size={16} /></button></div>{profiles.length ? profiles.slice(0, 6).map(p => <button className={`sidebar-profile ${selected?.id === p.id ? 'selected' : ''}`} key={p.id} onClick={() => { setSelectedId(p.id); setPage('instance'); }}><Box size={16} /><span>{p.name}<small>{p.game_version} · {loaderLabels[p.loader]}</small></span></button>) : <div className="sidebar-empty">Hier beginnt dein Setup.<br />Erstelle dein erstes Profil.</div>}</div>
      <div className="sidebar-bottom">
        {updateInfo && (
          <button
            className={`update-banner-button ${updateState}`}
            onClick={handleUpdateClick}
            disabled={updateState === 'downloading'}
            title={updateState === 'downloaded' ? 'Klicken, um Update jetzt zu installieren' : updateState === 'downloading' ? `Download läuft (${downloadPercent}%)` : 'Update herunterladen'}
          >
            {updateState === 'available' && (
              <>
                <ArrowDownToLine size={16} />
                <div className="update-text">
                  <span>Update verfügbar</span>
                  <small>v{updateInfo.latest_version} laden</small>
                </div>
              </>
            )}
            {updateState === 'downloading' && (
              <>
                <LoaderCircle size={16} className="spin" />
                <div className="update-text">
                  <span>Lädt herunter …</span>
                  <small>{downloadPercent}%</small>
                </div>
              </>
            )}
            {updateState === 'downloaded' && (
              <>
                <Sparkles size={16} />
                <div className="update-text">
                  <span>Jetzt installieren</span>
                  <small>Setup ausführen</small>
                </div>
              </>
            )}
          </button>
        )}
        <button aria-label="Einstellungen" className={`nav-item ${page === 'settings' ? 'active' : ''}`} onClick={() => setPage('settings')}><Settings2 size={19} /><span>Einstellungen</span></button>
        <button className="nav-item" aria-label="Über Vertix" onClick={() => setAboutOpen(true)}><CircleHelp size={19} /><span>Über Vertix</span></button>
        <div className="build-label"><span className="status-dot" />{api.desktop ? 'Desktop' : 'Designvorschau'}<span>v{appVersion}</span></div>
      </div>
    </aside>
    <div className="main-shell"><header className="topbar" data-tauri-drag-region><div className="breadcrumb"><span>Launcher</span><ChevronRight size={13} /><strong>{page === 'play' ? 'Spielen' : page === 'profiles' ? 'Meine Instanzen' : page === 'mods' ? 'Inhalte entdecken' : page === 'instance' ? selected?.name || 'Instanz' : 'Einstellungen'}</strong></div><div className="topbar-actions"><button className="account-button" onClick={() => setAccountOpen(true)} disabled={!ready || !!launchId}><div className="avatar"><UserRound size={16} /></div><span>{account?.username || 'Bei Minecraft anmelden'}<small>{account?.signed_in ? 'Microsoft-Konto verbunden' : 'Microsoft-Anmeldung'}</small></span><ArrowRight size={14} /></button>{api.desktop && <div className="window-controls"><button aria-label="Minimieren" onClick={() => perform(() => getCurrentWindow().minimize())}><Minus size={15} /></button><button aria-label="Maximieren" onClick={() => perform(() => getCurrentWindow().toggleMaximize())}><Square size={12} /></button><button aria-label="Schließen" onClick={() => perform(() => getCurrentWindow().close())}><X size={17} /></button></div>}</div>
    </header>
    {!ready ? <main className="startup"><LoaderCircle className="spin" size={28} /><h1>{startupError ? 'Vertix konnte nicht starten' : 'Dein Launcher wird vorbereitet.'}</h1><p>{startupError || 'Profile und lokale Einstellungen werden geladen.'}</p></main> : <main ref={contentRef} className="page-content">
      {page === 'play' && <><div className="page-heading"><div><div className="eyebrow">DEIN SPIEL. DEINE REGELN.</div><h1>Bereit für die nächste Welt?</h1><p>Ein Launcher. Dein ganz eigenes Minecraft.</p></div><span className="edition-label"><span className="status-dot" />JAVA EDITION</span></div><section className="hero"><Terrain /><div className="hero-shade" /><div className="hero-content"><div className="hero-tag"><span />DEIN NÄCHSTES ABENTEUER</div><h2>Weniger Launcher.<br />Mehr Minecraft.</h2><p>Deine Welten, deine Mods, dein Tempo.<br />Alles andere bleibt draußen.</p><button className="button light" onClick={() => selected ? launch() : setCreateOpen(true)} disabled={!!launchId}>{selected ? <Play size={16} fill="currentColor" /> : <Plus size={17} />}{selected ? 'Spielen' : 'Erstes Profil erstellen'}<ArrowRight size={16} /></button></div><div className="hero-coordinate">VERTIX / JAVA<br /><span>THE WORLD IS YOURS.</span></div></section><div className="section-heading"><div><h2>Deine Profile <span className="count">{profiles.length.toString().padStart(2, '0')}</span></h2><p>Für jede Welt das passende Setup.</p></div><button className="text-button" onClick={() => setPage('profiles')}>Alle Profile<ArrowRight size={16} /></button></div><div className="profile-grid">{profiles.slice(0, 3).map(p => <ProfileCard key={p.id} profile={p} selected={selected?.id === p.id} onSelect={() => { setSelectedId(p.id); setPage('instance'); }} onDetails={() => { setSelectedId(p.id); setPage('instance'); }} />)}<button className="new-profile-card" onClick={() => setCreateOpen(true)}><span className="plus-square"><Plus size={23} /></span><strong>{profiles.length ? 'Neues Profil' : 'Dein erstes Profil'}</strong><span>Version wählen. Mods hinzufügen. Loslegen.</span></button></div><div className="bottom-notes"><div><ShieldCheck size={19} /><span><strong>Dein Setup bleibt deins.</strong> Profile werden lokal gespeichert.</span></div><button onClick={() => setPage('mods')}>Mach mehr aus deinem Spiel<ArrowRight size={16} /></button></div></>}
      {page === 'profiles' && <><div className="page-heading"><div><div className="eyebrow">DEINE BIBLIOTHEK</div><h1>Meine Instanzen</h1><p>Getrennte Welten, Versionen und Mods. Ganz nach dir.</p></div><button className="button light" onClick={() => setCreateOpen(true)}><Plus size={17} />Profil erstellen</button></div><div className="toolbar"><label className="search-field"><Search size={18} /><input aria-label="Profile suchen" placeholder="Deine Profile durchsuchen …" value={profileQuery} onChange={e => setProfileQuery(e.target.value)} /></label><span>{profiles.length} Profile</span></div><div className="profile-grid library">{profiles.filter(p => p.name.toLowerCase().includes(profileQuery.toLowerCase())).map(p => <ProfileCard key={p.id} profile={p} selected={selected?.id === p.id} onSelect={() => { setSelectedId(p.id); setPage('instance'); }} onDetails={() => { setSelectedId(p.id); setPage('instance'); }} onDelete={() => setDeleteTarget(p)} />)}{!profiles.length && <div className="empty-state"><Layers3 size={38} /><h2>Platz für deine Ideen.</h2><p>Starte mit einem leeren Profil. Du bestimmst, was reinkommt.</p><button className="button light" onClick={() => setCreateOpen(true)}><Plus size={16} />Erstes Profil erstellen</button></div>}{!!profiles.length && !profiles.some(p => p.name.toLowerCase().includes(profileQuery.toLowerCase())) && <div className="empty-state"><Search size={30} /><h2>Kein Profil gefunden.</h2><p>Versuche einen anderen Namen.</p></div>}</div></>}
      {(page === 'mods' || page === 'instance') && (selected ? <InstanceWorkspace key={selected.id + page} profile={selected} onBack={() => setPage('profiles')} onLaunch={launch} onReload={reload} notify={notify} launching={!!launchId} initialBrowse={page === 'mods'} /> : <div className="empty-state"><Package size={38} /><h2>Erst deine Instanz. Dann dein Inhalt.</h2><p>Erstelle eine getrennte Instanz und verwalte dort Mods, Pakete und Shader.</p><button className="button light" onClick={() => setCreateOpen(true)}><Plus size={16} />Instanz erstellen</button></div>)}
      {page === 'settings' && <Settings account={account} onAccount={() => setAccountOpen(true)} />}
    </main>}
    <footer className="launchbar"><div className="launch-profile"><div className="profile-mini"><Box size={22} /></div><div><strong>{selected?.name || 'Noch kein Profil ausgewählt'}</strong><span>{selected ? `${selected.game_version} · ${loaderLabels[selected.loader]} · ${selected.settings.memory.max / 1024} GB RAM` : 'Dein nächstes Abenteuer beginnt mit einem Profil.'}</span></div></div><div className="launch-action"><span>{launchId ? progress : account?.signed_in ? 'Direktstart mit deinem Minecraft-Konto.' : 'Bei Minecraft anmelden zum Spielen.'}</span><button className="button light launch-button" disabled={!ready || !!launchId} onClick={launch}>{launchId ? <LoaderCircle className="spin" size={18} /> : <Play size={17} fill="currentColor" />}{launchId ? 'Wird vorbereitet …' : selected ? 'Spielen' : 'Profil erstellen'}<ChevronRight size={17} /></button></div></footer></div>
    {accountOpen && <Modal title={account?.signed_in ? 'Dein Minecraft-Konto' : 'Bei Minecraft anmelden'} subtitle="Microsoft · Java Edition" onClose={() => { if (!signingIn) setAccountOpen(false); }}><p className="dialog-copy">{account?.signed_in ? `Angemeldet als ${account.username}. Dieses Konto wird für deine getrennten Instanzen verwendet.` : 'Melde dich mit einem Microsoft-Konto an, das Minecraft: Java Edition besitzt. Vertix öffnet dafür das offizielle Anmeldefenster.'}</p>{signingIn && <div className="info-box"><LoaderCircle className="spin" size={20} /><span>Schließe die Microsoft-Anmeldung im Anmeldefenster ab. Anschließend prüft Vertix deine Spielberechtigung.</span></div>}{authError && <p role="alert" className="inline-error">{authError}</p>}<div className="dialog-actions">{signingIn ? <button className="button" onClick={() => perform(() => api.call('cancel_vertix_login'))}>Anmeldung abbrechen</button> : <><button className="button" onClick={() => setAccountOpen(false)}>Schließen</button>{account?.signed_in ? <button className="button" onClick={() => perform(async () => { await api.call('sign_out_vertix'); await reloadAccount(); setAccountOpen(false); }, 'In Vertix abgemeldet.')}><UserRound size={16} />Abmelden</button> : <button className="button light" disabled={!api.desktop} onClick={signIn}><ArrowRight size={16} />Mit Microsoft anmelden</button>}</>}</div></Modal>}
    {notice && <div role="status" className={`toast ${notice.error ? 'error' : ''}`}><span>{notice.text}</span><button className="icon-button" aria-label="Hinweis schließen" onClick={() => setNotice(null)}><X size={16} /></button></div>}
    {createOpen && <CreateProfile onClose={() => setCreateOpen(false)} onCreated={async id => { await reload(); setSelectedId(id); setCreateOpen(false); setPage('instance'); notify(api.desktop ? 'Dein Profil wurde erstellt.' : 'Vorschauprofil gespeichert. Minecraft ist in der Desktop-App verfügbar.'); }} notify={notify} />}
    {deleteTarget && <Modal title="Profil löschen?" subtitle={deleteTarget.name} onClose={() => setDeleteTarget(null)}><p className="dialog-copy">Dieses Profil einschließlich seiner lokalen Dateien und Welten wird in den Papierkorb des Launchers verschoben.</p><div className="dialog-actions"><button className="button" onClick={() => setDeleteTarget(null)}>Behalten</button><button className="button danger" onClick={() => perform(async () => { await api.deleteProfile(deleteTarget.id); await reload(); setDeleteTarget(null); }, 'Profil gelöscht.')}><Trash2 size={16} />Profil löschen</button></div></Modal>}
    {aboutOpen && <Modal title="Vertix Client" subtitle={`Version ${appVersion} · Ein unabhängiger Launcher`} onClose={() => setAboutOpen(false)}><div className="about-mark"><img src="/vertix.svg" alt="Vertix" /><p>Dein Spiel. Dein Setup.</p></div><p className="dialog-copy">Vertix ist ein unabhängiger Minecraft Launcher. Dein Spiel. Dein Setup. Schnell, sauber und direkt spielbereit.</p><p className="dialog-copy">Lizenz: GNU GPLv3. Du darfst diese Software unter den Bedingungen der GPLv3 weitergeben und verändern. Es besteht keine Gewährleistung. Minecraft ist eine Marke von Mojang / Microsoft. Vertix ist kein offizielles Minecraft-Produkt.</p><div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', margin: '14px 0 18px' }}><button className="button" onClick={async () => { try { const info = await api.checkAppUpdate(); if (info?.update_available) { setUpdateInfo(info); setUpdateState('available'); notify(`Update v${info.latest_version} verfügbar! Siehe Button unten links.`); } else { notify(`Vertix ist auf dem neuesten Stand (v${appVersion}).`); } } catch (e) { notify(errorText(e), true); } }}><RefreshCw size={15} />Nach Updates suchen</button></div><a className="text-button" href="/LICENSE.txt" target="_blank" rel="noreferrer">Vollständige Lizenz lesen<ArrowRight size={16} /></a></Modal>}
  </div>;
}

function ProfileCard({ profile: p, selected, onSelect, onDetails, onDelete }: { profile: Profile; selected: boolean; onSelect: () => void; onDetails: () => void; onDelete?: () => void }) {
  return <article className={`profile-card ${selected ? 'selected' : ''}`}><button className={`profile-cover ${p.loader}`} aria-label={`${p.name} auswählen`} onClick={onSelect}><div className="cover-grid" /><Box size={40} strokeWidth={1} /><span>{loaderLabels[p.loader].toUpperCase()}</span>{selected && <span className="selected-badge"><Check size={12} />AUSGEWÄHLT</span>}</button><div className="profile-card-body"><div><button className="profile-name" onClick={onSelect}>{p.name}</button><p>{p.game_version}<span>·</span>{loaderLabels[p.loader]}<span>·</span>{p.mods.length} Mods</p></div><button className="icon-button" aria-label={`${p.name} verwalten`} onClick={onDetails}><MoreHorizontal size={20} /></button>{onDelete && <button className="icon-button" aria-label={`${p.name} löschen`} onClick={onDelete}><Trash2 size={15} /></button>}</div></article>;
}

function Modal({ title, subtitle, onClose, children, wide = false }: { title: string; subtitle?: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { const previous = document.activeElement as HTMLElement; const app = document.querySelectorAll<HTMLElement>('.app-shell > .sidebar, .app-shell > .main-shell'); app.forEach(el => { el.inert = true; }); ref.current?.focus(); return () => { app.forEach(el => { el.inert = false; }); previous?.focus(); }; }, []);
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} ref={ref} onKeyDown={e => { if (e.key !== 'Tab') return; const f = [...(ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled), a, input, select') || [])]; if (!f.length) return; if (e.shiftKey && (document.activeElement === f[0] || document.activeElement === ref.current)) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); } }}><div className="modal-heading"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div><button className="icon-button" aria-label="Dialog schließen" onClick={onClose}><X size={20} /></button></div>{children}</div></div>;
}

function CreateProfile({ onClose, onCreated, notify }: { onClose: () => void; onCreated: (id: string) => Promise<void>; notify: (t: string, e?: boolean) => void }) {
  const [name, setName] = useState(''), [version, setVersion] = useState('');
  const [versions, setVersions] = useState<string[]>([]), [loader, setLoader] = useState<Loader>('fabric');
  const [memory, setMemory] = useState(4096), [busy, setBusy] = useState(false), [versionError, setVersionError] = useState(''), [attempt, setAttempt] = useState(0);
  useEffect(() => { const c = new AbortController(); setVersionError(''); api.minecraftVersions(c.signal).then(list => { setVersions(list); setVersion(list[0] || ''); }).catch(e => { if (!c.signal.aborted) setVersionError(errorText(e)); }); return () => c.abort(); }, [attempt]);
  async function submit(e: FormEvent) { e.preventDefault(); if (busy || !name.trim() || !version) return; setBusy(true); try { await onCreated(await api.createProfile(name.trim(), version, loader, memory)); } catch (e) { notify(errorText(e), true); } finally { setBusy(false); } }
  return <Modal title="Mach es zu deinem Profil." subtitle="Ein frischer Start. Ohne vorinstallierte Mods." onClose={() => { if (!busy) onClose(); }}><form onSubmit={submit}><label className="field">Profilname<input required maxLength={60} placeholder="Zum Beispiel: Meine Survival-Welt" value={name} onChange={e => setName(e.target.value)} /></label><div className="form-row"><label className="field">Minecraft-Version<select aria-label="Minecraft-Version" value={version} onChange={e => setVersion(e.target.value)} disabled={!versions.length}>{!versions.length && <option value="">Versionen werden geladen …</option>}{versions.map(v => <option key={v} value={v}>{v}</option>)}</select></label><label className="field">Modloader<select value={loader} onChange={e => setLoader(e.target.value as Loader)}>{Object.entries(loaderLabels).map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select></label></div>{versionError && <div className="inline-error">{versionError}<button type="button" className="text-button" onClick={() => setAttempt(a => a + 1)}>Erneut laden</button></div>}<label className="field">Arbeitsspeicher<span className="range-label">{memory / 1024} GB RAM</span><input type="range" min={2048} max={16384} step={1024} value={memory} onChange={e => setMemory(Number(e.target.value))} /></label><div className="info-box"><Box size={19} /><span>{loader === 'vanilla' ? 'Vanilla enthält keine Mods. Wähle einen Modloader, wenn du Mods installieren möchtest.' : `${loaderLabels[loader]} wird für diese Instanz vorbereitet. Mods kannst du anschließend selbst hinzufügen.`}</span></div>{!api.desktop && <p className="preview-note">Designvorschau: Dieses Profil wird nur im Browser gespeichert.</p>}<div className="dialog-actions"><button type="button" className="button" onClick={onClose} disabled={busy}>Abbrechen</button><button className="button light" disabled={busy || !version || !name.trim()}>{busy ? <LoaderCircle size={17} className="spin" /> : <Plus size={17} />}Profil erstellen</button></div></form></Modal>;
}

function Settings({ account, onAccount }: { account: AccountStatus | null; onAccount: () => void }) {
  return <>
    <div className="page-heading">
      <div>
        <div className="eyebrow">SO, WIE DU ES MAGST.</div>
        <h1>Einstellungen</h1>
        <p>Dein Launcher. Dein Setup.</p>
      </div>
    </div>
    <section className="settings-panel">
      <div className="settings-icon"><UserRound size={23} /></div>
      <div>
        <h2>Dein Minecraft-Konto</h2>
        <p>{account?.signed_in ? `Angemeldet als ${account.username}. Deine Instanzen können direkt gestartet werden.` : "Mit deinem Microsoft-Konto anmelden und Minecraft direkt aus Vertix starten."}</p>
        <div className="settings-actions">
          <button className="button light" disabled={!api.desktop} onClick={onAccount}>
            <UserRound size={16} />{account?.signed_in ? "Konto verwalten" : "Mit Microsoft anmelden"}
          </button>
        </div>
        <p>Vertix verwendet die offizielle Microsoft- und Xbox-Live-Anmeldung. Deine Sitzung wird sicher auf deinem PC gespeichert.</p>
      </div>
    </section>
    <section className="settings-panel">
      <div className="settings-icon"><Layers3 size={23} /></div>
      <div>
        <h2>Ein Konto. Getrennte Profile.</h2>
        <p>Jedes Vertix-Profil hat einen eigenen Spielordner für Welten, Mods, Einstellungen, Ressourcenpakete und Serverlisten. Neue Profile übernehmen keine Welten oder Mods anderer Profile.</p>
        <p>Nur dein Minecraft-Konto und technische Downloads wie Bibliotheken und Assets werden gemeinsam genutzt. Jede Instanz startet mit einem eigenen Spielordner. Es werden keine Welten oder Einstellungen aus anderen Instanzen übernommen.</p>
      </div>
    </section>
    <section className="settings-panel">
      <div className="settings-icon"><SlidersHorizontal size={23} /></div>
      <div>
        <h2>Schlicht. Absichtlich.</h2>
        <p>Graphit, Schwarz und ruhige Kontraste. Arbeitsspeicher stellst du pro Profil ein.</p>
        <div className="appearance-preview">
          <span /><span /><span /><span /><strong>Graphit</strong><Check size={16} />
        </div>
      </div>
    </section>
  </>;
}

function Terrain() {
  return <svg className="terrain" viewBox="0 0 1100 420" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="sky" x2="0" y2="1"><stop stopColor="#343b3d" /><stop offset="1" stopColor="#87877e" /></linearGradient></defs><rect width="1100" height="420" fill="url(#sky)" /><rect x="812" y="67" width="60" height="60" fill="#ceccba" opacity=".6" /><path d="M300 253h80v-46h54v-43h49v-40h61v38h43v40h68v-26h48v-37h39v-37h44v52h39v39h61v-38h48v51h69v-38h56v56h46v196H300z" fill="#5a625d" /><path d="M470 310h56v-44h48v-36h62v39h57v-58h49v-47h56v52h47v31h59v-29h47v44h46v-34h65v67h38v125H470z" fill="#444c45" /><path d="M580 420v-82h45v-34h54v25h62v-37h46v-31h54v34h65v35h72v-24h66v42h56v72z" fill="#343d34" /><path d="M674 420v-33h62v-46h66v-28h48v26h73v34h74v-28h56v51h47v24z" fill="#252c26" /><path d="M1000 420v-54h-37v-57h-29v-36h-57v29h-27v35h-44v83z" fill="#4f5545" /><path d="M939 366h-46v-26h-29v-30h-43v-17h-26v20h-33v32h-49v75h226z" fill="#686957" /><path d="M880 420v-32h-39v-26h-31v-25h-30v22h-34v28h-36v33z" fill="#8a8870" /><g fill="#232c25">{[640, 706, 948, 1030].map((x, i) => <g key={x} transform={`translate(${x},${213 + i % 2 * 35})`}><rect x="-5" y="0" width="10" height="102" fill="#3b3b30" /><path d="M-30 15h13v-29h12v-32h10v32h12v29h13v28h13v20h-86V43h13z" /></g>)}</g><g fill="#9b9d88" opacity=".11"><rect x="541" y="165" width="47" height="39" /><rect x="705" y="141" width="39" height="35" /><rect x="789" y="158" width="36" height="37" /><rect x="956" y="228" width="46" height="38" /></g></svg>;
}
