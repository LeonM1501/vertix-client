import { Box, Check, FolderOpen, HardDrive, Layers3, Settings2 } from 'lucide-react';
import { useState } from 'react';
import type { Profile } from './api';

export function InstanceSettings({ profile, directory, locked, canSave, onSave, onClose, onOpenFolder }: {
  profile: Profile; directory: string; locked: boolean; canSave: boolean;
  onSave: (name: string, memory: number) => void; onClose: () => void; onOpenFolder: () => void;
}) {
  const [section, setSection] = useState<'general' | 'installation'>('general');
  const [name, setName] = useState(profile.name);
  const [memory, setMemory] = useState(profile.settings.memory.max);
  const maxMemory = Math.max(32768, Math.ceil(profile.settings.memory.max / 512) * 512);
  const loader = profile.loader === 'vanilla' ? 'Vanilla' : profile.loader[0].toUpperCase() + profile.loader.slice(1);
  const ram = (memory / 1024).toLocaleString('de', { maximumFractionDigits: 2 });
  return <>
    <div className="instance-settings-layout">
      <nav className="instance-settings-nav" aria-label="Einstellungsbereiche">
        <div className="settings-instance"><Box size={24} /><strong>{profile.name}</strong><small>{loader} · {profile.game_version}</small></div>
        <button type="button" className={section === 'general' ? 'active' : ''} aria-current={section === 'general' ? 'page' : undefined} onClick={() => setSection('general')}><Settings2 size={17} />Allgemein</button>
        <button type="button" className={section === 'installation' ? 'active' : ''} aria-current={section === 'installation' ? 'page' : undefined} onClick={() => setSection('installation')}><Layers3 size={17} />Installation</button>
      </nav>
      <div className="instance-settings-content">
        {section === 'general' ? <>
          <div className="settings-section-heading"><span>DEINE INSTANZ</span><h3>Ganz nach deinem Spiel.</h3><p>Name und Leistung für diese Instanz einstellen.</p></div>
          <label className="field">Name<input autoFocus disabled={locked} value={name} maxLength={60} onChange={e => setName(e.target.value)} /></label>
          <section className="settings-ram" aria-labelledby="settings-ram-title">
            <div className="settings-ram-heading"><div><HardDrive size={18} /><h4 id="settings-ram-title">Arbeitsspeicher</h4></div><output htmlFor="instance-ram">{ram}<small> GB RAM</small></output></div>
            <p>Maximaler RAM für Minecraft. Lass ausreichend Speicher für Windows und andere Programme frei.</p>
            <input id="instance-ram" aria-label="Arbeitsspeicher in MB" aria-valuetext={`${ram} GB RAM`} type="range" min={1024} max={maxMemory} step={512} value={memory} disabled={locked} onChange={e => setMemory(Number(e.target.value))} />
            <div className="settings-ram-scale"><span>1 GB</span><span>{maxMemory / 1024} GB</span></div>
            <div className="settings-ram-presets" aria-label="RAM-Voreinstellungen">{[2048,4096,6144,8192].map(value => <button type="button" key={value} disabled={locked} aria-pressed={memory === value} className={memory === value ? 'active' : ''} onClick={() => setMemory(value)}>{value / 1024} GB</button>)}</div>
          </section>
        </> : <>
          <div className="settings-section-heading"><span>DEIN SETUP</span><h3>Installation im Überblick.</h3><p>Versionen und Dateien dieser Instanz.</p></div>
          <dl className="settings-installation-info"><div><dt>Plattform</dt><dd>{loader}</dd></div><div><dt>Minecraft-Version</dt><dd>{profile.game_version}</dd></div>{profile.loader !== 'vanilla' && <div><dt>Modloader-Version</dt><dd>{profile.loader_version || 'Automatisch beim Spielstart'}</dd></div>}<div><dt>Arbeitsspeicher</dt><dd>{ram} GB</dd></div></dl>
          <div className="info-box"><Layers3 size={18} /><span>Für eine andere Minecraft-Version oder einen anderen Modloader erstellst du eine neue Instanz. So bleiben deine Welten und Inhalte getrennt.</span></div>
          <section className="settings-folder"><h4>Instanzordner</h4><p>Welten, Mods und Konfigurationen an einem Ort.</p><code>{directory || 'Der Ordner wird beim ersten Start angelegt.'}</code><button type="button" className="button" disabled={!canSave || locked} onClick={onOpenFolder}><FolderOpen size={16} />Ordner öffnen</button></section>
        </>}
      </div>
    </div>
    <div className="dialog-actions settings-footer"><span>{locked ? 'Änderungen sind während laufender Aktionen gesperrt.' : 'Gilt nur für diese Instanz.'}</span><button className="button" disabled={locked} onClick={onClose}>Abbrechen</button><button className="button light" disabled={locked || !canSave || !name.trim()} onClick={() => onSave(name.trim(), memory)}><Check size={16} />Speichern</button></div>
  </>;
}
