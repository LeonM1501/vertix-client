!include "MUI2.nsh"
!include "FileFunc.nsh"

; Application Name and Output Installer
Name "Vertix Client"
!ifndef ARTIFACT_DIR
!define ARTIFACT_DIR "artifacts"
!endif
!ifndef APP_VERSION
!define APP_VERSION "0.1.0"
!endif
OutFile "${ARTIFACT_DIR}\Vertix-Client-Setup.exe"
Unicode True

; Default Installation Directory on Main SSD: AppData\Local\Programs\Vertix Client
InstallDir "$LOCALAPPDATA\Programs\Vertix Client"
InstallDirRegKey HKCU "Software\VertixClient" "InstallLocation"

; Run with user privileges so no admin prompt is required
RequestExecutionLevel user

; Installer branding and appearance
!define MUI_ICON "src-tauri\icons\icon.ico"
!define MUI_UNICON "src-tauri\icons\icon.ico"
!define MUI_ABORTWARNING

; Welcome page
!insertmacro MUI_PAGE_WELCOME

; License page
!insertmacro MUI_PAGE_LICENSE "LICENSE"

; Directory selection page (user can customize installation location)
!insertmacro MUI_PAGE_DIRECTORY

; Components page (user can toggle Start menu, Desktop, and Taskbar shortcuts)
!insertmacro MUI_PAGE_COMPONENTS

; Installation progress page
!insertmacro MUI_PAGE_INSTFILES

; Finish page with optional launch
!define MUI_FINISHPAGE_RUN "$INSTDIR\Vertix Client.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Vertix Client jetzt starten"
!insertmacro MUI_PAGE_FINISH

; Uninstaller pages
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; Language
!insertmacro MUI_LANGUAGE "German"

; Core section (Mandatory)
Section "Vertix Client (erforderlich)" SecCore
    SectionIn RO
    SetOutPath "$INSTDIR"
    
    ; Copy executable and metadata
    File "${ARTIFACT_DIR}\Vertix Client.exe"
    File "${ARTIFACT_DIR}\WebView2Loader.dll"
    File "${ARTIFACT_DIR}\libunwind.dll"
    File /nonfatal "LICENSE"
    File /nonfatal "NOTICE.md"
    
    ; Create Uninstaller
    WriteUninstaller "$INSTDIR\Uninstall.exe"
    
    ; Store installation directory in registry
    WriteRegStr HKCU "Software\VertixClient" "InstallLocation" "$INSTDIR"
    
    ; Register in Windows Installed Apps / Control Panel
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "DisplayName" "Vertix Client"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "DisplayIcon" "$INSTDIR\Vertix Client.exe"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "DisplayVersion" "${APP_VERSION}"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "Publisher" "Vertix"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "UninstallString" "$\"$INSTDIR\Uninstall.exe$\""
    WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "NoModify" 1
    WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "NoRepair" 1
SectionEnd

; Start Menu Shortcut Section (Checked by default)
Section "Startmenü-Verknüpfung" SecStartMenu
    CreateDirectory "$SMPROGRAMS\Vertix Client"
    CreateShortcut "$SMPROGRAMS\Vertix Client\Vertix Client.lnk" "$INSTDIR\Vertix Client.exe" "" "$INSTDIR\Vertix Client.exe" 0
    CreateShortcut "$SMPROGRAMS\Vertix Client\Deinstallieren.lnk" "$INSTDIR\Uninstall.exe" "" "$INSTDIR\Uninstall.exe" 0
SectionEnd

; Desktop Shortcut Section (Checked by default)
Section "Desktop-Verknüpfung" SecDesktop
    CreateShortcut "$DESKTOP\Vertix Client.lnk" "$INSTDIR\Vertix Client.exe" "" "$INSTDIR\Vertix Client.exe" 0
SectionEnd

; Taskbar Shortcut Section (Unchecked by default, user selectable)
Section /o "An Taskleiste anheften" SecTaskbar
    CreateDirectory "$APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar"
    CreateShortcut "$APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Vertix Client.lnk" "$INSTDIR\Vertix Client.exe" "" "$INSTDIR\Vertix Client.exe" 0
SectionEnd

; Descriptions for components
!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
    !insertmacro MUI_DESCRIPTION_TEXT ${SecCore} "Die Programmdateien von Vertix Client."
    !insertmacro MUI_DESCRIPTION_TEXT ${SecStartMenu} "Erstellt Verknüpfungen im Startmenü (standardmäßig aktiviert)."
    !insertmacro MUI_DESCRIPTION_TEXT ${SecDesktop} "Erstellt eine Verknüpfung auf dem Desktop (standardmäßig aktiviert)."
    !insertmacro MUI_DESCRIPTION_TEXT ${SecTaskbar} "Heftet das Programm an die Windows-Taskleiste an."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

; Uninstaller Section
Section "Uninstall"
    ; Remove shortcuts
    Delete "$DESKTOP\Vertix Client.lnk"
    Delete "$SMPROGRAMS\Vertix Client\Vertix Client.lnk"
    Delete "$SMPROGRAMS\Vertix Client\Deinstallieren.lnk"
    RMDir "$SMPROGRAMS\Vertix Client"
    Delete "$APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Vertix Client.lnk"
    
    ; Remove application files
    Delete "$INSTDIR\Vertix Client.exe"
    Delete "$INSTDIR\WebView2Loader.dll"
    Delete "$INSTDIR\libunwind.dll"
    Delete "$INSTDIR\LICENSE"
    Delete "$INSTDIR\NOTICE.md"
    Delete "$INSTDIR\Uninstall.exe"
    RMDir "$INSTDIR"
    
    ; Remove registry keys
    DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient"
    DeleteRegKey HKCU "Software\VertixClient"
SectionEnd
