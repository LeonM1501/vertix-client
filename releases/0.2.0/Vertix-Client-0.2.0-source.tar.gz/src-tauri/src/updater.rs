use crate::error::{AppError, Result};
use log::{error, info, warn};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use tauri::{AppHandle, Emitter};

fn newer_version(candidate: &str, current: &str) -> bool {
    match (semver::Version::parse(candidate), semver::Version::parse(current)) {
        (Ok(candidate), Ok(current)) => candidate > current,
        _ => false,
    }
}

#[cfg(test)]
mod update_tests {
    use super::newer_version;
    #[test]
    fn only_offer_newer_valid_releases() {
        assert!(newer_version("0.2.0", "0.1.0"));
        assert!(!newer_version("0.2.0", "0.2.0"));
        assert!(!newer_version("0.1.0", "0.2.0"));
        assert!(!newer_version("invalid", "0.2.0"));
        assert!(!newer_version("0.2.0-beta.1", "0.2.0"));
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppUpdateInfo {
    pub current_version: String,
    pub latest_version: String,
    pub title: String,
    pub release_notes: String,
    pub installer_url: String,
    pub update_available: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UpdateProgressPayload {
    pub percent: u32,
    pub downloaded_bytes: u64,
    pub total_bytes: u64,
    pub done: bool,
}

fn get_updates_dir() -> PathBuf {
    if let Ok(app_data) = std::env::var("APPDATA") {
        PathBuf::from(app_data).join("vertix").join("updates")
    } else if let Some(home) = dirs::home_dir() {
        home.join("AppData").join("Roaming").join("vertix").join("updates")
    } else {
        PathBuf::from("C:\\vertix-updates")
    }
}

fn get_trigger_file() -> PathBuf {
    if let Ok(app_data) = std::env::var("APPDATA") {
        PathBuf::from(app_data).join("vertix").join("update_release.json")
    } else if let Some(home) = dirs::home_dir() {
        home.join("AppData").join("Roaming").join("vertix").join("update_release.json")
    } else {
        PathBuf::from("C:\\vertix-update-trigger.json")
    }
}

#[tauri::command]
pub async fn check_vertix_update(app: AppHandle) -> std::result::Result<Option<AppUpdateInfo>, String> {
    let current_version = app.package_info().version.to_string();

    // 1. Check local trigger file (%APPDATA%\vertix\update_release.json)
    let trigger_path = get_trigger_file();
    if trigger_path.is_file() {
        if let Ok(content) = std::fs::read_to_string(&trigger_path) {
            if let Ok(info) = serde_json::from_str::<serde_json::Value>(&content) {
                let latest_version = info["version"].as_str().unwrap_or("0.2.0").to_string();
                let title = info["title"].as_str().unwrap_or("Neues Vertix Update verfügbar").to_string();
                let notes = info["notes"].as_str().unwrap_or("Enthält Verbesserungen und Optimierungen.").to_string();
                let installer_url = info["installer_url"].as_str().unwrap_or("").to_string();

                let is_newer = newer_version(&latest_version, &current_version);
                if is_newer {
                    return Ok(Some(AppUpdateInfo {
                        current_version,
                        latest_version,
                        title,
                        release_notes: notes,
                        installer_url,
                        update_available: true,
                    }));
                }
            }
        }
    }

    // 2. Check remote update manifest if available (silent fallback on network error)
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(3))
        .build();

    if let Ok(client) = client {
        // Can be configured to point to GitHub Releases or release CDN
        let url = "https://raw.githubusercontent.com/LeonM1501/vertix-client/main/version.json";
        if let Ok(res) = client.get(url).send().await {
            if res.status().is_success() {
                if let Ok(json) = res.json::<serde_json::Value>().await {
                    let latest_version = json["version"].as_str().unwrap_or("").to_string();
                    if newer_version(&latest_version, &current_version) {
                        let title = json["title"].as_str().unwrap_or("Neues Vertix Update").to_string();
                        let notes = json["notes"].as_str().unwrap_or("Neue Version verfügbar.").to_string();
                        let installer_url = json["installer_url"].as_str().unwrap_or("").to_string();
                        return Ok(Some(AppUpdateInfo {
                            current_version,
                            latest_version,
                            title,
                            release_notes: notes,
                            installer_url,
                            update_available: true,
                        }));
                    }
                }
            }
        }
    }

    Ok(None)
}

#[tauri::command]
pub async fn simulate_release_update(
    app: AppHandle,
    version: Option<String>,
    installer_url: Option<String>,
) -> std::result::Result<AppUpdateInfo, String> {
    let current_version = app.package_info().version.to_string();
    let latest_version = version.unwrap_or_else(|| "0.2.0".to_string());
    let installer = installer_url.unwrap_or_default();

    let trigger_path = get_trigger_file();
    if let Some(parent) = trigger_path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }

    let payload = serde_json::json!({
        "version": latest_version,
        "title": format!("Vertix Client Update v{}", latest_version),
        "notes": "Installer & Updater Verbesserungen, SSD Optimierung.",
        "installer_url": installer
    });

    std::fs::write(&trigger_path, serde_json::to_string_pretty(&payload).unwrap())
        .map_err(|e| format!("Fehler beim Schreiben des Update-Triggers: {e}"))?;

    Ok(AppUpdateInfo {
        current_version,
        latest_version,
        title: format!("Vertix Client Update"),
        release_notes: "Neue Version bereit zum Download.".to_string(),
        installer_url: installer,
        update_available: true,
    })
}

#[tauri::command]
pub async fn clear_release_trigger() -> std::result::Result<(), String> {
    let trigger_path = get_trigger_file();
    if trigger_path.exists() {
        let _ = std::fs::remove_file(trigger_path);
    }
    Ok(())
}

#[tauri::command]
pub async fn download_vertix_update(
    app: AppHandle,
    installer_url: String,
) -> std::result::Result<String, String> {
    let updates_dir = get_updates_dir();
    std::fs::create_dir_all(&updates_dir)
        .map_err(|e| format!("Fehler beim Erstellen des Update-Ordners: {e}"))?;

    let target_file = updates_dir.join("Vertix-Client-Setup.exe");

    info!("[Updater] Downloading installer to {:?}", target_file);

    // If HTTP(S) URL
    if installer_url.starts_with("http://") || installer_url.starts_with("https://") {
        let client = reqwest::Client::new();
        let mut response = client.get(&installer_url).send().await
            .map_err(|e| format!("Download-Anfrage fehlgeschlagen: {e}"))?;

        if !response.status().is_success() {
            return Err(format!("Download-Server antwortete mit Status: {}", response.status()));
        }

        let total_bytes = response.content_length().unwrap_or(0);
        let mut downloaded_bytes: u64 = 0;
        let mut file = tokio::fs::File::create(&target_file).await
            .map_err(|e| format!("Zieldatei konnte nicht erstellt werden: {e}"))?;

        use tokio::io::AsyncWriteExt;
        while let Some(chunk) = response.chunk().await.map_err(|e| format!("Fehler beim Lesen des Streams: {e}"))? {
            downloaded_bytes += chunk.len() as u64;
            file.write_all(&chunk).await
                .map_err(|e| format!("Fehler beim Schreiben des Installers: {e}"))?;

            let percent = if total_bytes > 0 {
                ((downloaded_bytes as f64 / total_bytes as f64) * 100.0) as u32
            } else {
                50
            };

            let _ = app.emit("update_download_progress", UpdateProgressPayload {
                percent,
                downloaded_bytes,
                total_bytes,
                done: false,
            });
        }
        file.flush().await.map_err(|e| format!("Flush-Fehler: {e}"))?;
    } else {
        // Local source fallback (e.g. testing or pre-staged file)
        let source_candidate = if !installer_url.is_empty() && Path::new(&installer_url).exists() {
            PathBuf::from(&installer_url)
        } else {
            // Check common locations
            let candidates = [
                PathBuf::from("E:\\Vertix-Client-Source\\artifacts\\Vertix-Client-Setup.exe"),
                dirs::home_dir().map(|h| h.join("Desktop").join("Vertix-Client-Setup.exe")).unwrap_or_default(),
                PathBuf::from("C:\\Users\\Leonx\\Desktop\\Vertix-Client-Setup.exe"),
            ];
            candidates.into_iter().find(|p| p.is_file()).unwrap_or_else(|| target_file.clone())
        };

        if source_candidate.is_file() && source_candidate != target_file {
            let total = std::fs::metadata(&source_candidate).map(|m| m.len()).unwrap_or(1);
            let _ = app.emit("update_download_progress", UpdateProgressPayload {
                percent: 30,
                downloaded_bytes: total / 3,
                total_bytes: total,
                done: false,
            });
            tokio::time::sleep(tokio::time::Duration::from_millis(300)).await;

            std::fs::copy(&source_candidate, &target_file)
                .map_err(|e| format!("Kopieren des Installers fehlgeschlagen: {e}"))?;

            let _ = app.emit("update_download_progress", UpdateProgressPayload {
                percent: 80,
                downloaded_bytes: (total * 8) / 10,
                total_bytes: total,
                done: false,
            });
            tokio::time::sleep(tokio::time::Duration::from_millis(200)).await;
        } else if !target_file.is_file() {
            return Err("Kein Installer gefunden und keine gültige Download-URL angegeben.".to_string());
        }
    }

    let total = std::fs::metadata(&target_file).map(|m| m.len()).unwrap_or(0);
    let _ = app.emit("update_download_progress", UpdateProgressPayload {
        percent: 100,
        downloaded_bytes: total,
        total_bytes: total,
        done: true,
    });

    info!("[Updater] Update installer downloaded successfully to {:?}", target_file);
    Ok(target_file.to_string_lossy().into_owned())
}

#[tauri::command]
pub async fn install_vertix_update(app: AppHandle) -> std::result::Result<(), String> {
    let updates_dir = get_updates_dir();
    let installer_path = updates_dir.join("Vertix-Client-Setup.exe");

    let final_installer = if installer_path.is_file() {
        installer_path
    } else {
        // Fallback to desktop or artifacts
        let candidates = [
            dirs::home_dir().map(|h| h.join("Desktop").join("Vertix-Client-Setup.exe")).unwrap_or_default(),
            PathBuf::from("E:\\Vertix-Client-Source\\artifacts\\Vertix-Client-Setup.exe"),
        ];
        candidates.into_iter().find(|p| p.is_file())
            .ok_or_else(|| "Installationsdatei Vertix-Client-Setup.exe nicht gefunden. Bitte zuerst herunterladen.".to_string())?
    };

    info!("[Updater] Launching installer: {:?}", final_installer);

    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const DETACHED_PROCESS: u32 = 0x00000008;

        std::process::Command::new(&final_installer)
            .creation_flags(DETACHED_PROCESS)
            .spawn()
            .map_err(|e| format!("Installer konnte nicht gestartet werden: {e}"))?;
    }

    #[cfg(not(windows))]
    {
        std::process::Command::new(&final_installer)
            .spawn()
            .map_err(|e| format!("Installer konnte nicht gestartet werden: {e}"))?;
    }

    // Clear release trigger so it doesn't loop
    let _ = clear_release_trigger().await;

    // Gracefully exit current process
    app.exit(0);
    Ok(())
}
