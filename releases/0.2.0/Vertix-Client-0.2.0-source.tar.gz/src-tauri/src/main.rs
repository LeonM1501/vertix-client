#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]
#![allow(warnings)]
// A packaged app must serve its embedded UI, never the Vite development URL.
#[cfg(all(not(debug_assertions), not(feature = "custom-protocol")))]
compile_error!("Release builds require --features custom-protocol. Use build-release.ps1.");
// Vertix entry point, 2026-10-08. Upstream cloud, advertisements, telemetry,
// remote updates, cosmetics, friends, capture and automatic profiles are excluded.
use vertix_client_lib::{commands, logging, state, official_launcher};
use std::sync::{Arc, OnceLock};

static STARTUP: OnceLock<Result<(), String>> = OnceLock::new();
#[derive(serde::Serialize)]
struct Status { ready: bool, error: Option<String> }
#[tauri::command]
fn vertix_status() -> Status { match STARTUP.get() { Some(Ok(())) => Status { ready: true, error: None }, Some(Err(e)) => Status { ready: false, error: Some(e.clone()) }, None => Status { ready: false, error: None } } }

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _, _| {
            use tauri::Manager;
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.show();
                let _ = window.set_focus();
            }
        }))
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .setup(|app| {
            let handle = Arc::new(app.handle().clone());
            tauri::async_runtime::spawn(async move {
                let _ = logging::setup_logging().await;
                let result = state::State::init(handle).await.map_err(|e| e.to_string());
                if let Err(error) = &result { log::error!("Vertix startup: {error}"); }
                let _ = STARTUP.set(result);
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            vertix_status,
            vertix_client_lib::vertix_auth::get_vertix_account,
            vertix_client_lib::vertix_auth::sign_in_vertix,
            vertix_client_lib::vertix_auth::cancel_vertix_login,
            vertix_client_lib::vertix_auth::sign_out_vertix,
            official_launcher::get_official_launcher_status, official_launcher::choose_official_launcher,
            official_launcher::open_official_launcher, official_launcher::open_official_launcher_download,
            official_launcher::prepare_official_profile,
            official_launcher::launch_vertix_instance,
            vertix_client_lib::instance_content::get_instance_content,
            vertix_client_lib::instance_content::install_instance_content,
            vertix_client_lib::instance_content::change_instance_content,
            vertix_client_lib::instance_content::import_instance_content,
            vertix_client_lib::instance_content::open_instance_path,
            vertix_client_lib::instance_content::read_instance_log,
            commands::profile_command::list_profiles, commands::profile_command::get_profile, commands::profile_command::create_profile, commands::profile_command::update_profile, commands::profile_command::delete_profile,
            commands::profile_command::add_modrinth_mod_to_profile, commands::profile_command::get_custom_mods, commands::profile_command::import_local_mods, commands::profile_command::open_profile_folder,
            commands::profile_command::set_custom_mod_enabled, commands::profile_command::delete_custom_mod, commands::profile_command::set_profile_mod_enabled, commands::profile_command::delete_mod_from_profile,
            vertix_client_lib::updater::check_vertix_update,
            vertix_client_lib::updater::simulate_release_update,
            vertix_client_lib::updater::clear_release_trigger,
            vertix_client_lib::updater::download_vertix_update,
            vertix_client_lib::updater::install_vertix_update
        ])
        .run(tauri::generate_context!())
        .expect("Vertix could not start");
}
