import { useRef, useState } from 'react';
import { Box, Castle, Compass, Cpu, Gem, Globe2, Leaf, Pickaxe, Rocket, Shield, Sword, Trees, Upload, X } from 'lucide-react';
import type { Profile } from './api';
export type IconConfig = { symbol: string; background: string; image?: string | null };
const symbols = { box: Box, pickaxe: Pickaxe, trees: Trees, sword: Sword, castle: Castle, globe: Globe2, compass: Compass, leaf: Leaf, gem: Gem, shield: Shield, cpu: Cpu, rocket: Rocket };
const backgrounds = ['#242830','#343b49','#34433b','#454033','#463940','#303e4b','#49454f','#e4dfd3'];
export const defaultIcon: IconConfig = { symbol: 'box', background: backgrounds[0], image: null };
export function profileIcon(p: Profile): IconConfig { return p.vertix_icon || p.extra?.vertix_icon || defaultIcon; }
export function ProfileIcon({ profile, value, size = 42 }: { profile?: Profile; value?: IconConfig; size?: number }) {
  const config = value || (profile ? profileIcon(profile) : defaultIcon), Symbol = symbols[config.symbol as keyof typeof symbols] || Box;
  return <span className="profile-icon" style={{ width: size, height: size, background: config.background, color: config.background === '#e4dfd3' ? '#242830' : '#f1eee7' }}>{config.image ? <img src={config.image} alt="" /> : <Symbol size={Math.round(size * .52)} strokeWidth={1.5} />}</span>;
}
export function IconEditor({ value, onChange }: { value: IconConfig; onChange: (value: IconConfig) => void }) {
  const input = useRef<HTMLInputElement>(null), [error, setError] = useState('');
  async function upload(file?: File) {
    if (!file) return; setError('');
    if (!['image/png','image/jpeg','image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) { setError('Wähle ein PNG-, JPG- oder WebP-Bild bis 5 MB.'); return; }
    const url = URL.createObjectURL(file);
    try {
      const image = new Image(); image.src = url; await image.decode();
      const canvas = document.createElement('canvas'); canvas.width = canvas.height = 256;
      const context = canvas.getContext('2d')!; const side = Math.min(image.width, image.height);
      context.drawImage(image,(image.width-side)/2,(image.height-side)/2,side,side,0,0,256,256);
      onChange({ ...value, image: canvas.toDataURL('image/png') });
    } catch { setError('Dieses Bild konnte nicht gelesen werden.'); } finally { URL.revokeObjectURL(url); }
  }
  return <section className="icon-editor" aria-label="Instanzbild bearbeiten"><div className="icon-preview"><ProfileIcon value={value} size={96}/><span>Dein Instanzbild</span><div><button type="button" className="button small" onClick={()=>input.current?.click()}><Upload size={14}/>Eigenes Bild</button>{value.image && <button type="button" className="icon-button" aria-label="Eigenes Bild entfernen" onClick={()=>onChange({...value,image:null})}><X size={15}/></button>}</div><input ref={input} hidden type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>upload(e.target.files?.[0])}/></div><div><h4>Hintergrund</h4><div className="icon-backgrounds">{backgrounds.map(background=><button type="button" aria-label={`Hintergrund ${background}`} aria-pressed={value.background===background} style={{background}} key={background} onClick={()=>onChange({...value,background})}/>)}</div><h4>Symbol</h4><div className="icon-symbols">{Object.entries(symbols).map(([symbol,Symbol])=><button type="button" aria-label={`Symbol ${symbol}`} aria-pressed={!value.image && value.symbol===symbol} key={symbol} onClick={()=>onChange({...value,symbol,image:null})}><Symbol size={25} strokeWidth={1.5}/></button>)}</div></div>{error && <p role="alert" className="inline-error">{error}</p>}</section>;
}
