package client.vertix.core.gui;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class HudEditorScreen extends Screen {

    private final Screen parent;
    private boolean snapping = true, grid = false;
    private int guideX = -1, guideY = -1;
    private SettingsPopup popup;
    private final java.util.Map<String,int[]> original = new java.util.HashMap<>();
    private MenuLayout.Rect controls() { return new MenuLayout.Rect(Math.max(4,width/2-164),height-36,Math.min(328,width-8),28); }

    private Module draggingModule = null;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("Vertix HUD Editor"));
        this.parent = parent;
        for (Module m : VertixCoreMod.getInstance().getModuleManager().getModules()) if(m.isHud()) original.put(m.getId(),new int[]{m.getX(),m.getY()});
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float delta) {
        // Semi-transparent overlay so world is visible
        RenderUtils.drawRect(extractor, 0, 0, width, height, 0x55000000);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float delta) {
        super.extractRenderState(extractor, mouseX, mouseY, delta);

        // Top info bar
        int barW = Math.min(360, width - 20);
        int barH = 34;
        int barX = (width - barW) / 2;
        int barY = height - 72;
        RenderUtils.drawCard(extractor, barX, barY, barW, barH, RenderUtils.COLOR_BG_MAIN, RenderUtils.COLOR_BORDER_DEFAULT);
        RenderUtils.drawCenteredText(extractor, font, "HUD BEARBEITEN", barX + barW / 2, barY + 7, RenderUtils.COLOR_TEXT_PRIMARY, false);
        RenderUtils.drawCenteredText(extractor, font, "Ziehen · Rechtsklick: Einstellungen", barX + barW / 2, barY + 21, RenderUtils.COLOR_TEXT_SECONDARY, false);

        if(grid) {
            for(int x=0;x<width;x+=16) for(int y=0;y<height;y+=16) RenderUtils.drawRect(extractor,x,y,1,1,0x445C626A);
        }
        if(guideX>=0) RenderUtils.drawRect(extractor,guideX,0,1,height,0xAAECE9E2);
        if(guideY>=0) RenderUtils.drawRect(extractor,0,guideY,width,1,0xAAECE9E2);
        // Render each active HUD module with an interactive outline
        for (Module m : VertixCoreMod.getInstance().getModuleManager().getModules()) {
            if (!m.isHud() || !m.isEnabled()) continue;

            m.renderHudPlaceholder(extractor, minecraft);

            boolean hovered = mouseX >= m.getX() && mouseX < m.getX() + m.getWidth()
                    && mouseY >= m.getY() && mouseY < m.getY() + m.getHeight();
            int outlineCol = (m == draggingModule) ? RenderUtils.COLOR_ACCENT
                    : hovered ? RenderUtils.COLOR_BORDER_HOVER : RenderUtils.COLOR_BORDER_DEFAULT;
            RenderUtils.drawOutline(extractor, m.getX() - 1, m.getY() - 1, m.getWidth() + 2, m.getHeight() + 2, outlineCol);

            // Label only the element being edited; keep badges on screen.
            if (hovered || m == draggingModule) {
                String label = RenderUtils.fit(font, m.getName(), Math.max(0, width - 12));
                int badgeW = font.width(label) + 8;
                int badgeX = Math.max(2, Math.min(width - badgeW - 2, m.getX()));
                int badgeY = m.getY() >= 16 ? m.getY() - 15 : m.getY() + m.getHeight() + 3;
                badgeY = Math.max(2, Math.min(height - 14, badgeY));
                RenderUtils.drawRect(extractor, badgeX, badgeY, badgeW, 12, RenderUtils.COLOR_BG_MAIN);
                RenderUtils.drawText(extractor, font, label, badgeX + 4, badgeY + 2, RenderUtils.COLOR_TEXT_PRIMARY, false);
            }
        }
        MenuLayout.Rect c=controls();
        RenderUtils.drawCard(extractor,c.x(),c.y(),c.w(),c.h(),RenderUtils.COLOR_BG_MAIN,RenderUtils.COLOR_BORDER_DEFAULT);
        RenderUtils.drawText(extractor,font,"Raster " + (grid?"AN":"AUS"),c.x()+8,c.y()+10,RenderUtils.COLOR_TEXT_SECONDARY,false);
        RenderUtils.drawText(extractor,font,"Einrasten " + (snapping?"AN":"AUS"),c.x()+82,c.y()+10,RenderUtils.COLOR_TEXT_SECONDARY,false);
        RenderUtils.drawText(extractor,font,"Rückgängig",c.x()+190,c.y()+10,RenderUtils.COLOR_TEXT_SECONDARY,false);
        RenderUtils.drawText(extractor,font,"Fertig",c.right()-42,c.y()+10,RenderUtils.COLOR_TEXT_PRIMARY,false);
        if(popup!=null) {RenderUtils.drawRect(extractor,0,0,width,height,0x38000000);popup.render(extractor,mouseX,mouseY,minecraft);}
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if(popup!=null) {popup.mouseReleased();if(!popup.isMouseInside(event.x(),event.y()) || popup.mouseClicked(event.x(),event.y(),event.button()))popup=null;return true;}
        MenuLayout.Rect c=controls();
        if(event.button()==InputConstants.MOUSE_BUTTON_LEFT && c.contains(event.x(),event.y())) {
            int local=(int)event.x()-c.x();
            if(local<76)grid=!grid;
            else if(local<185)snapping=!snapping;
            else if(local<c.w()-52) {for(Module m:VertixCoreMod.getInstance().getModuleManager().getModules()){int[] pos=original.get(m.getId());if(pos!=null){m.setX(pos[0]);m.setY(pos[1]);}}}
            else onClose();
            return true;
        }
        if (event.button() != InputConstants.MOUSE_BUTTON_LEFT && event.button()!=InputConstants.MOUSE_BUTTON_RIGHT) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();

        // Check if any HUD module was clicked
        java.util.List<Module> hitModules=VertixCoreMod.getInstance().getModuleManager().getModules();
        for (int i=hitModules.size()-1;i>=0;i--) {
            Module m=hitModules.get(i);
            if (!m.isHud() || !m.isEnabled()) continue;

            if (mx >= m.getX() && mx <= m.getX() + m.getWidth() && my >= m.getY() && my <= m.getY() + m.getHeight()) {
                if(event.button()==InputConstants.MOUSE_BUTTON_RIGHT) {if(!m.getSettings().isEmpty())popup=new SettingsPopup(m,m.getX(),m.getY(),width,height);return true;}
                draggingModule = m;
                dragOffsetX = (int) (mx - m.getX());
                dragOffsetY = (int) (my - m.getY());
                return true;
            }
        }

        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if(popup!=null){popup.mouseDragged(event.x(),event.y());return true;}
        if (draggingModule != null) {
            int newX = (int) (event.x() - dragOffsetX);
            int newY = (int) (event.y() - dragOffsetY);

            int[][] others=VertixCoreMod.getInstance().getModuleManager().getModules().stream().filter(m->m.isHud() && m.isEnabled() && m!=draggingModule).map(m->new int[]{m.getX(),m.getY(),m.getWidth(),m.getHeight()}).toArray(int[][]::new);
            HudPlacement.Position position=HudPlacement.place(newX,newY,draggingModule.getWidth(),draggingModule.getHeight(),width,height,snapping,others);
            draggingModule.setX(position.x());draggingModule.setY(position.y());guideX=position.guideX();guideY=position.guideY();
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if(popup!=null){popup.mouseReleased();return true;}
        guideX=guideY=-1;
        if (draggingModule != null) {
            draggingModule = null;
            // Persist new layout
            VertixCoreMod.getInstance().getConfigManager().saveConfig(VertixCoreMod.getInstance().getModuleManager().getModules());
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if(popup!=null && event.key()==InputConstants.KEY_ESCAPE){popup.mouseReleased();popup=null;return true;}
        if (event.key() == InputConstants.KEY_ESCAPE /* ESC */ || event.key() == InputConstants.KEY_RSHIFT /* R-SHIFT */) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical) {if(popup!=null){popup.mouseScrolled(vertical);return true;}return super.mouseScrolled(x,y,horizontal,vertical);}

    @Override
    public void onClose() {
        VertixCoreMod.getInstance().getConfigManager().saveConfig(VertixCoreMod.getInstance().getModuleManager().getModules());
        if (minecraft != null) {
            minecraft.setScreenAndShow(parent);
        }
    }
}
