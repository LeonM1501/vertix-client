import client.vertix.core.gui.HudPlacement;
public final class HudPlacementTest {
    public static void main(String[] args) {
        var center=HudPlacement.place(123,111,80,20,320,240,true,new int[0][]);
        if(center.x()!=120 || center.y()!=110 || center.guideX()!=160 || center.guideY()!=120)throw new AssertionError(center);
        var free=HudPlacement.place(123,111,80,20,320,240,false,new int[0][]);
        if(free.x()!=123 || free.y()!=111 || free.guideX()!=-1)throw new AssertionError(free);
        var aligned=HudPlacement.place(48,81,60,18,640,480,true,new int[][]{{50,40,60,40}});
        if(aligned.x()!=50 || aligned.y()!=80)throw new AssertionError(aligned);
        for(int w:new int[]{160,320,640,1280})for(int h:new int[]{120,240,720}) {
            var p=HudPlacement.place(-999,999,80,20,w,h,true,new int[0][]);
            if(p.x()<2 || p.y()<2 || p.x()+80>w-2 || p.y()+20>h-2)throw new AssertionError(p);
        }
        System.out.println("HUD placement: center, neighbour, free movement and 12 viewport cases passed.");
    }
}
