# Vertix Client 0.8.1 / Core 1.3.1

- R-Shift öffnet direkt die Modübersicht über der sichtbaren Spielwelt. Der vorgeschaltete Startdialog entfällt. Tabs führen zu Mods, Profilen und dem HUD-Editor.
- Die Einstellungsfenster verwenden ein schwebendes, halbtransparentes Vertix-Layout mit Trennlinie, aufklappbaren Gruppen und eingerückten Zeilen. Bezeichnungen stehen links, Bedienelemente rechts.
- Checkboxen ersetzen die bisherigen AN-/AUS-Schaltflächen in den Einstellungen. Auswahlfelder lassen sich in beide Richtungen durchschalten. Zahlenwert und Schieberegler stehen kompakt nebeneinander; Farben behalten eine eigene Vorschau.
- Die gleichen Einstellungsfenster sind über die Modkarten und per Rechtsklick auf HUD-Elemente erreichbar. Änderungen werden weiterhin automatisch gespeichert.

Nach dem Client-Update Minecraft neu starten. Core 1.3.1 wird für unterstützte Fabric-Instanzen mit Minecraft 26.2 oder 26.3 eingesetzt. Eigene HUD-Farben und gespeicherte Modulwerte bleiben erhalten.
