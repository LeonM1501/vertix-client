# Prüfung von Client 0.8.0 / Core 1.3.0

18. Oktober 2026. Die Tests verwenden eigene temporäre Verzeichnisse und eine Offline-Spielidentität. Persönliche Welten und die laufende Minecraft-Instanz werden nicht verändert.

- TypeScript-Prüfung und Vite-Produktionsbuild erfolgreich.
- Bestehende RAM-, Kompatibilitäts- und Mod-Update-Regressionen erfolgreich.
- `node scripts/test-project-description.mjs`: Markdown, Tabellen, Bilder und bereinigtes HTML; aktive HTML-Inhalte werden entfernt.
- `node scripts/test-profile-icon.mjs`: gespeicherte Instanzbilder einschließlich der flachen Rust-Serialisierung und Symbol-Fallbacks.
- `cargo test --manifest-path scripts/native-content-tests/Cargo.toml --locked`: sieben Tests gegen die tatsächlichen Produktionsmodule. Prüft eigene Mods, lokal veränderte Dateien, alte Verwaltungslisten, fehlende weiterhin aktivierte Downloads, verschachtelte Welt-/Paketordner, Import beim Spielen, unsichere Archivpfade sowie eine vollständige Logdatei über zwei MB mit Token-Ausblendung.
- Java-Platzierungs- und Layouttests erfolgreich, einschließlich kleiner Fenster und freier Platzierung.
- Core 1.3.0 für Minecraft 26.2 und 26.3 gebaut und jeweils im echten Spiel geprüft: Modmenü öffnen, HUD direkt verschieben, HUD-Editor, Rechtsklick-Einstellungen und Screenshot-Erfassung. Beide isolierten Läufe melden PASS.
- Alle sechs Launcher-Designs in der Browser-Vorschau geprüft; Projektbeschreibung und Versionsfilter mit AppleSkin sowie Instanzbilder und angeheftete Navigation bedient.

Die Offline-Spieltests prüfen weder eine Microsoft-Anmeldung noch einen echten Discord-Stream. Bereits vor diesem Update verlorene Dateien können nur aus vorhandenen Sicherungen wiederhergestellt werden. Das persönliche Desktop-Setup wird für dieses Release nicht ersetzt.
