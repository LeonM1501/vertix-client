param(
    [string]$JdkHome = 'C:/Program Files/Java/jdk-26.0.2',
    [string]$MetadataRoot = "$PSScriptRoot/../artifacts/core-meta",
    [string]$Version = '26.2',
    [string]$AssetsRoot = "$env:APPDATA/vertix/VertixClient/meta/assets",
    [string]$JavaHome = $JdkHome
)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
$runTag = [guid]::NewGuid().ToString('N')
$testRoot = Join-Path $root "artifacts/verification/0.8.1/ui-$Version-$runTag"
New-Item "$testRoot/classes","$testRoot/game/mods","$testRoot/appdata","$testRoot/natives" -ItemType Directory -Force | Out-Null
$metadataFile = Join-Path $MetadataRoot "versions/$Version/version.json"
if (Test-Path $metadataFile) {
    $meta = Get-Content $metadataFile -Raw | ConvertFrom-Json
} else {
    $manifest = Invoke-RestMethod https://piston-meta.mojang.com/mc/game/version_manifest_v2.json -TimeoutSec 30
    $meta = Invoke-RestMethod ($manifest.versions | Where-Object id -eq $Version).url -TimeoutSec 30
    $meta | ConvertTo-Json -Depth 30 | Set-Content $metadataFile
}
$libraries = @()
foreach ($lib in $meta.libraries) {
    $a = $lib.downloads.artifact
    if (!$a -or $lib.name -match 'natives-(linux|macos|windows-arm64)') { continue }
    $path = Join-Path "$MetadataRoot/libraries" $a.path
    if (!(Test-Path $path)) {
        New-Item (Split-Path $path) -ItemType Directory -Force | Out-Null
        Invoke-WebRequest $a.url -OutFile $path -TimeoutSec 60
    }
    if ((Get-FileHash $path -Algorithm SHA1).Hash.ToLowerInvariant() -ne $a.sha1) { throw "Invalid library: $($lib.name)" }
    $libraries += $path
    if ($lib.name -match 'natives-windows$') {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [IO.Compression.ZipFile]::OpenRead($path)
        try {
            foreach ($entry in $zip.Entries | Where-Object Name -Like '*.dll') {
                [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path "$testRoot/natives" $entry.Name), $true)
            }
        } finally { $zip.Dispose() }
    }
}
# One version per artifact: a user's cache may contain several loader/ASM versions.
$libraries += Get-ChildItem "$MetadataRoot/libraries/net/fabricmc","$MetadataRoot/libraries/org/ow2/asm" -Recurse -Filter '*.jar' |
    Group-Object { $_.Directory.Parent.FullName } | ForEach-Object {
        $_.Group | Sort-Object { try { [version]($_.Directory.Name -replace '[^0-9.].*$','') } catch { [version]'0.0' } } | Select-Object -Last 1 -ExpandProperty FullName
    }
$minecraft = Join-Path $MetadataRoot "versions/$Version/$Version.jar"
$core = Join-Path $root "src-tauri/resources/mods/vertix-core-fabric-$Version-1.3.1.jar"
$classpath = (@($minecraft, $core) + $libraries) -join ';'
& "$JdkHome/bin/javac.exe" --release 21 -proc:none -encoding UTF-8 -cp $classpath -d "$testRoot/classes" "$root/vertix-core-mod/src/test/java/client/vertix/test/UiRuntimeTest.java"
if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed' }
@{schemaVersion=1;id='vertix_streaming_test';version='1';environment='client';mixins=@('streaming-test.mixins.json')} | ConvertTo-Json | Set-Content "$testRoot/classes/fabric.mod.json"
@{required=$true;package='client.vertix.test';compatibilityLevel='JAVA_21';client=@('UiRuntimeTest');injectors=@{defaultRequire=1}} | ConvertTo-Json -Depth 4 | Set-Content "$testRoot/classes/streaming-test.mixins.json"
& "$JdkHome/bin/jar.exe" --create --file "$testRoot/game/mods/streaming-test.jar" -C "$testRoot/classes" .
Copy-Item $core "$testRoot/game/mods/" -Force
$classpath = (@($minecraft) + $libraries) -join ';'
'fullscreen:false' | Set-Content "$testRoot/game/options.txt"
# Separate config and offline identity; never use or mutate the user's instances/account.
$env:APPDATA = "$testRoot/appdata"
$argsFile = "$testRoot/launch.args"
@('--enable-native-access=ALL-UNNAMED', '-Xmx2G', "-Djava.library.path=$testRoot/natives", "-Dorg.lwjgl.librarypath=$testRoot/natives", "-Dfabric.gameJarPath=$minecraft", '-cp', $classpath, 'net.fabricmc.loader.impl.launch.knot.KnotClient', '--username', 'VertixTest', '--uuid', '00000000000000000000000000000000', '--accessToken', '0', '--version', $Version, '--gameDir', "$testRoot/game", '--assetsDir', $AssetsRoot, '--assetIndex', $meta.assetIndex.id, '--width', '960', '--height', '540') | ForEach-Object { '"' + $_.Replace('\','/') + '"' } | Set-Content $argsFile
$process = Start-Process cmd.exe -ArgumentList "/d /c `"`"$JavaHome/bin/java.exe`" @`"$argsFile`" > `"$testRoot/stdout.log`" 2>&1`"" -WorkingDirectory "$testRoot/game" -WindowStyle Hidden -PassThru
$process.Id | Set-Content "$testRoot/process-id.txt"
Write-Host "Started isolated Minecraft $Version test, PID $($process.Id). Evidence: $testRoot"
$deadline = (Get-Date).AddMinutes(4)
while (!$process.WaitForExit(1000)) {
    if ((Get-Date) -gt $deadline) {
        & taskkill.exe /PID $process.Id /T /F | Out-Null
        throw "Minecraft $Version test timed out; see $testRoot/stdout.log"
    }
}
if (!(Select-String -Path "$testRoot/stdout.log" -Pattern 'VERTIX_UI_TEST_PASSED' -Quiet)) {
    throw "Minecraft $Version streaming test failed (exit $($process.ExitCode)); see $testRoot/stdout.log"
}
Write-Host "Minecraft $Version UI render and input assertions passed."
