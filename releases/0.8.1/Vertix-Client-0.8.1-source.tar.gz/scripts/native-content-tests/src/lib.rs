//! Exercises the production file algorithms without a WebView or user profile.
pub mod error {
    #[derive(Debug,thiserror::Error)]
    pub enum AppError {
        #[error("{0}")] Other(String),
        #[error(transparent)] Io(#[from] std::io::Error),
        #[error(transparent)] Json(#[from] serde_json::Error),
    }
    pub type Result<T> = std::result::Result<T,AppError>;
}
pub mod minecraft { pub mod downloads { pub mod mod_resolver {
    #[derive(Clone)]
    pub struct TargetMod {pub mod_id:String,pub filename:String,pub cache_path:std::path::PathBuf,pub sha1:Option<String>}
}}}
pub mod utils {
    pub mod file_utils {
        pub async fn write_atomic(path:impl AsRef<std::path::Path>,data:impl AsRef<[u8]>) -> crate::error::Result<()> {tokio::fs::write(path,data).await?;Ok(())}
    }
    pub mod trash_utils {
        pub async fn move_path_to_trash(path:impl AsRef<std::path::Path>,_:Option<&str>) -> crate::error::Result<()> {
            let path=path.as_ref();let trash=path.parent().unwrap().join(".test-trash");tokio::fs::create_dir_all(&trash).await?;
            tokio::fs::rename(path,trash.join(path.file_name().unwrap())).await?;Ok(())
        }
    }
}
#[path="../../../src-tauri/src/managed_mods.rs"] pub mod managed_mods;
#[path="../../../src-tauri/src/content_import.rs"] pub mod content_import;

#[path="../../../src-tauri/src/instance_log.rs"] pub mod instance_log;
