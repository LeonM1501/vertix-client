import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import {pathToFileURL} from 'node:url';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
fs.mkdirSync('artifacts',{recursive:true});
const output=ts.transpileModule(fs.readFileSync('src/ProfileIcon.tsx','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}}).outputText;
fs.writeFileSync('artifacts/profile-icon-test.mjs',output);
const {profileIcon,ProfileIcon}=await import(pathToFileURL(process.cwd()+'/artifacts/profile-icon-test.mjs'));
const icon={symbol:'pickaxe',background:'#343b49',image:null};
// Rust serializes Profile.extra with serde(flatten), so persisted icons are root fields.
const profile={id:'test',name:'Survival',vertix_icon:icon};
assert.deepEqual(profileIcon(profile),icon);
assert.match(renderToStaticMarkup(React.createElement(ProfileIcon,{profile})),/lucide-pickaxe/);
assert.deepEqual(profileIcon({extra:{vertix_icon:icon}}),icon);
assert.equal(profileIcon({}).symbol,'box');
console.log('Instance icons: flattened persistence shape, legacy shape, SVG rendering and fallback passed.');
