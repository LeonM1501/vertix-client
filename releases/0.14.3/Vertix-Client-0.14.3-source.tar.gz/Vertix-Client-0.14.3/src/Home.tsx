import { useEffect, useRef } from 'react';
import { ArrowRight, Check, ChevronDown, Layers3, LoaderCircle, Play, Plus, SlidersHorizontal } from 'lucide-react';
import type { AccountStatus, Profile } from './api';
import type { Design } from './Appearance';
import type { CatalogKind } from './contentCompatibility';
import { ProfileIcon } from './ProfileIcon';
import { SkinPreview } from './SkinPreview';

export function Home({ design, account, profiles, selected, launching, progress, onSelect, onLaunch, onCreate, onOpen, onLibrary }: {
  design: Design; account: AccountStatus|null; profiles: Profile[]; selected?: Profile; launching: boolean; progress: string; onSelect: (id:string)=>void; onLaunch: () => void; onCreate: () => void; onOpen: (id: string) => void; onLibrary: () => void; onDiscover: (kind?: CatalogKind) => void;
}) {
  const picker=useRef<HTMLDetailsElement>(null);
  useEffect(()=>{
    const close=(e:PointerEvent)=>{if(!picker.current?.contains(e.target as Node))picker.current?.removeAttribute('open');};
    document.addEventListener('pointerdown',close);
    return()=>document.removeEventListener('pointerdown',close);
  },[]);
  useEffect(()=>{if(launching)picker.current?.removeAttribute('open');},[launching]);
  return <div className={`home home-launchpad home-${design}`}>
    <div className="launchpad-layout">
      <section className="player-panel" aria-label="Spieler und Schnellstart">
        <div className="launchpad-grid launchpad-grid-top" aria-hidden="true"/><div className="launchpad-grid launchpad-grid-bottom" aria-hidden="true"/>
        <div className="player-panel-toolbar"><span>VERTIX / JAVA EDITION</span><div><button onClick={onLibrary}><Layers3 size={15}/> Instanzen</button><button onClick={onCreate}><Plus size={15}/> Neue Instanz</button></div></div>
        <SkinPreview key={account?.account_id||'guest'} accountId={account?.account_id} username={account?.username}/>
        <div className="home-launch-area">
          <div className="home-launch-control">
            <button className="home-play" disabled={launching} onClick={selected?onLaunch:onCreate}>{launching?<LoaderCircle className="spin" size={22}/>:selected?<Play size={22} fill="currentColor"/>:<Plus size={22}/>}<span><strong>{launching?'Wird vorbereitet …':selected?'Spielen':'Instanz erstellen'}</strong><small>{selected?.name||'Dein nächstes Abenteuer'}</small></span></button>
            {!!profiles.length&&<details className="instance-picker" ref={picker} onKeyDown={e=>{if(e.key==='Escape'){picker.current?.removeAttribute('open');picker.current?.querySelector('summary')?.focus();}}}>
              <summary aria-label="Instanz auswählen" aria-disabled={launching} onClick={e=>{if(launching)e.preventDefault();}}><ChevronDown size={20}/></summary>
              <div className="instance-picker-list"><header><span>INSTANZ WÄHLEN</span><small>{profiles.length} verfügbar</small></header>{profiles.map(p=><button key={p.id} aria-label={`${p.name} auswählen · ${p.game_version} · ${p.loader}`} disabled={launching} aria-pressed={p.id===selected?.id} onClick={()=>{onSelect(p.id);picker.current?.removeAttribute('open');picker.current?.querySelector('summary')?.focus();}}><ProfileIcon profile={p} size={35}/><span><strong>{p.name}</strong><small>{p.game_version} · {p.loader}</small></span>{selected?.id===p.id&&<Check size={16}/>}</button>)}</div>
            </details>}
          </div>
          <p className="home-launch-meta" role="status">{launching?progress:selected?`Minecraft ${selected.game_version} · ${selected.loader} · ${selected.settings.memory.max/1024} GB RAM`:'Vanilla oder Modpack. Du entscheidest.'}</p>
          {selected&&<button className="text-button home-manage" onClick={()=>onOpen(selected.id)}><SlidersHorizontal size={14}/>Instanz verwalten<ArrowRight size={14}/></button>}
        </div>
      </section>
    </div>
  </div>;
}
