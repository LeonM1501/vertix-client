package client.vertix.core.mixin;

import client.vertix.core.performance.EntityCollisionCandidates;
import net.minecraft.util.AbortableIterationConsumer;
import net.minecraft.util.ClassInstanceMultiMap;
import net.minecraft.world.level.entity.EntityAccess;
import net.minecraft.world.level.entity.EntitySection;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Mixin(EntitySection.class)
public class TntSectionIndexMixin<T extends EntityAccess> {
    @Unique private List<T> vertix$colliders;

    @Redirect(method="getEntities(Lnet/minecraft/world/level/entity/EntityTypeTest;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/util/AbortableIterationConsumer;)Lnet/minecraft/util/Continuation;",at=@At(value="INVOKE",target="Lnet/minecraft/util/ClassInstanceMultiMap;find(Ljava/lang/Class;)Ljava/util/Collection;"))
    @SuppressWarnings({"rawtypes","unchecked"})
    private Collection vertix$candidates(ClassInstanceMultiMap<T> storage,Class base,EntityTypeTest type,AABB bounds,AbortableIterationConsumer consumer){
        if(type!=EntityCollisionCandidates.TYPE)return storage.find(base);
        if(vertix$colliders==null){
            vertix$colliders=new ArrayList<>();
            for(T entity:storage)if(!EntityCollisionCandidates.isNonColliding(entity))vertix$colliders.add(entity);
        }
        return vertix$colliders;
    }
    @Inject(method="add",at=@At("RETURN"))
    private void vertix$added(T entity,CallbackInfo ci){
        if(vertix$colliders!=null&&!EntityCollisionCandidates.isNonColliding(entity))vertix$colliders.add(entity);
    }
    @Inject(method="remove",at=@At("RETURN"))
    private void vertix$removed(T entity,CallbackInfoReturnable<Boolean> ci){
        if(ci.getReturnValueZ()&&vertix$colliders!=null&&!EntityCollisionCandidates.isNonColliding(entity))vertix$colliders.remove(entity);
    }
}
