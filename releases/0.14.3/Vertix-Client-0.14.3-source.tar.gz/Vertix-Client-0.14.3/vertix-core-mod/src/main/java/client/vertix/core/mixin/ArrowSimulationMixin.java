package client.vertix.core.mixin;

import client.vertix.core.performance.RenderOptimizer;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.entity.projectile.arrow.SpectralArrow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Arrow.class,SpectralArrow.class})
public class ArrowSimulationMixin {
    @Inject(method="tick",at=@At("HEAD"),cancellable=true)
    private void vertix$reduceHiddenArrowWork(CallbackInfo ci){
        if(RenderOptimizer.skipArrowClientTick((AbstractArrow)(Object)this))ci.cancel();
    }
}
