package client.vertix.core.forge.mixin;

import client.vertix.core.performance.RenderOptimizer;
import client.vertix.core.performance.EntityCollisionCandidates;
import net.minecraft.world.entity.item.PrimedTnt;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PrimedTnt.class)
public class TntClientTickMixin {
    @Inject(method="tick",at=@At("HEAD"),cancellable=true)
    private void vertix$hiddenClientTnt(CallbackInfo ci){
        var tnt=(PrimedTnt)(Object)this;
        if(!tnt.level().isClientSide()||!EntityCollisionCandidates.isVanillaTnt(tnt)||!RenderOptimizer.hide(tnt))return;
        // Only hidden client prediction is omitted; the server still simulates every TNT.
        tnt.setFuse(tnt.getFuse()-1);
        if(tnt.getFuse()<=0)tnt.discard();
        ci.cancel();
    }
}
