package client.vertix.core.forge.mixin;

import client.vertix.core.performance.RenderOptimizer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientLevel.class)
public class TntSoundMixin {
    @Inject(method="playSound",at=@At("HEAD"),cancellable=true)
    private void vertix$burstSound(double x,double y,double z,SoundEvent sound,SoundSource source,float volume,float pitch,boolean delayed,long seed,CallbackInfo ci){
        if((sound==SoundEvents.GENERIC_EXPLODE||sound==SoundEvents.TNT_PRIMED)&&RenderOptimizer.rejectTntSound())ci.cancel();
    }
}
