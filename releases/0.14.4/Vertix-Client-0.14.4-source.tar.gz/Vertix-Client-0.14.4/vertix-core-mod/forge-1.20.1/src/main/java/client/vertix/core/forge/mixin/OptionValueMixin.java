package client.vertix.core.forge.mixin;

import client.vertix.core.modules.qol.PerformanceModeModule;
import net.minecraft.client.OptionInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Serialize original video values without rebuilding the renderer on every save. */
@Mixin(OptionInstance.class)
public class OptionValueMixin {
    @Inject(method="get()Ljava/lang/Object;",at=@At("RETURN"),cancellable=true)
    private void vertix$savedValue(CallbackInfoReturnable<Object> ci){
        var mode=PerformanceModeModule.savingOptions();
        if(mode!=null)ci.setReturnValue(mode.savedOptionValue((OptionInstance<?>)(Object)this,ci.getReturnValue()));
    }
}
