package client.vertix.core.forge.mixin;

import client.vertix.core.performance.EntityCollisionCandidates;
import client.vertix.core.performance.RenderOptimizer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntity.class)
public class ItemSimulationMixin {
    @Shadow private int age;
    @Shadow private int pickupDelay;

    @Redirect(method="tick",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/Level;noCollision(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Z"))
    private boolean vertix$itemCollisions(Level level,Entity item,AABB bounds){
        return EntityCollisionCandidates.noCollision(level,item,bounds);
    }
    @Inject(method="tick",at=@At("HEAD"),cancellable=true)
    private void vertix$hiddenClientItem(CallbackInfo ci){
        var item=(ItemEntity)(Object)this;
        if(!item.level().isClientSide()||!EntityCollisionCandidates.isVanillaItem(item)||!RenderOptimizer.hide(item))return;
        // Only prediction is reduced; pickup, movement, merging and lifetime stay authoritative on the server.
        if(item.getItem().isEmpty())item.discard();
        else{
            if(age!=-32768)age++;
            if(pickupDelay>0&&pickupDelay!=32767)pickupDelay--;
            item.xo=item.getX();item.yo=item.getY();item.zo=item.getZ();
        }
        ci.cancel();
    }
}
