package client.vertix.core.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.entity.player.Player;
import java.util.Map;

/** Client-side particles around Vertix players; nothing is sent to the server. */
final class Auras {
    private static final Map<String, SimpleParticleType> TYPES = Map.of("hearts", ParticleTypes.HEART, "flames", ParticleTypes.FLAME,
        "sparkles", ParticleTypes.END_ROD, "notes", ParticleTypes.NOTE, "snow", ParticleTypes.SNOWFLAKE);
    private static int ticks;
    private Auras() {}

    static void tick(Minecraft mc) {
        if (mc.level == null || ++ticks % 5 != 0) return;
        // "Decreased" particles halves the rate, "Minimal" switches auras off.
        int setting = mc.options.particles().get().ordinal();
        if (setting >= 2 || (setting == 1 && ticks % 10 != 0)) return;
        for (Player player : mc.level.players()) {
            var loadout = CosmeticsClient.get(player.getUUID());
            if (loadout == null || loadout.aura() == null || player.isInvisible() || player.distanceToSqr(mc.player) > 32 * 32) continue;
            SimpleParticleType type = TYPES.get(loadout.aura());
            if (type == null) continue;
            // Keep the own aura out of the first-person view.
            if (player == mc.player && mc.options.getCameraType().isFirstPerson()) continue;
            double angle = player.tickCount * 0.35 + player.getId(), r = 0.55;
            double up = type == ParticleTypes.SNOWFLAKE ? -0.02 : 0.02;
            mc.level.addParticle(type, player.getX() + Math.cos(angle) * r, player.getY() + 0.3 + (player.tickCount % 20) / 12.0, player.getZ() + Math.sin(angle) * r, 0, up, 0);
        }
    }
}
