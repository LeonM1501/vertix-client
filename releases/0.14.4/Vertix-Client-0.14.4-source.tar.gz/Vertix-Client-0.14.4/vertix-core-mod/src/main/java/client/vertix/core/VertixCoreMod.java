package client.vertix.core;

import client.vertix.core.cosmetics.CosmeticsClient;
import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.api.Module;
import client.vertix.core.performance.RenderOptimizer;
import client.vertix.core.modules.qol.AppleSkinModule;
import client.vertix.core.modules.visual.GammaModule;
import client.vertix.core.modules.visual.WorldFire;
import client.vertix.core.modules.visual.GlowingGlintsModule;
import client.vertix.core.modules.pvp.TotemCounterModule;
import client.vertix.core.api.ModuleManager;
import client.vertix.core.api.StreamingWindow;
import client.vertix.core.modules.qol.DiscordStreamingModule;
import client.vertix.core.config.ConfigManager;
import client.vertix.core.gui.VertixMenuScreen;
import client.vertix.core.gui.HudEditorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class VertixCoreMod implements ClientModInitializer {

    private static VertixCoreMod instance;

    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private KeyMapping keyOpenMenu,keyZoom,keyCopy;
    private final client.vertix.core.performance.FrameStats frameStats=new client.vertix.core.performance.FrameStats();
    private int statsTicks;
    private Object statsLevel;
    public client.vertix.core.performance.FrameStats getFrameStats(){return frameStats;}
    public KeyMapping getKeyZoom(){return keyZoom;}
    public boolean isOpenMenuKey(net.minecraft.client.input.KeyEvent event){return keyOpenMenu!=null&&keyOpenMenu.matches(event);}
    public void onFrame(Minecraft mc){if(mc.player!=null)frameStats.record(System.nanoTime());}

    // CPS Tracking
    private final List<Long> leftClicks = new ArrayList<>();
    private final List<Long> rightClicks = new ArrayList<>();
    private boolean wasLeftPressed = false;
    private boolean wasRightPressed = false;

    public static VertixCoreMod getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        this.moduleManager = new ModuleManager();
        this.configManager = new ConfigManager();

        // Register Keybind for 'Open Vertix Menu' (Default: RIGHT SHIFT = 344)
        try {
            KeyMapping.Category category = KeyMapping.Category.register(net.minecraft.resources.Identifier.fromNamespaceAndPath("vertix", "main"));
            this.keyOpenMenu = new KeyMapping("key.vertix.open_menu", InputConstants.KEY_RSHIFT, category);
            KeyMappingHelper.registerKeyMapping(this.keyOpenMenu);
            keyZoom=KeyMappingHelper.registerKeyMapping(new KeyMapping("key.vertix.zoom",InputConstants.KEY_C,category));
            keyCopy=KeyMappingHelper.registerKeyMapping(new KeyMapping("key.vertix.copy_coordinates",InputConstants.KEY_F6,category));
        } catch (Throwable e) {
            System.err.println("[VertixCoreMod] KeyMappingHelper registration fallback: " + e.getMessage());
            try {
                this.keyOpenMenu = new KeyMapping("key.vertix.open_menu", InputConstants.KEY_RSHIFT, KeyMapping.Category.MISC);
            } catch (Throwable ignored) {}
        }

        // Load persistent universal settings across versions
        this.configManager.loadConfig(this.moduleManager.getModules());

        System.out.println("[VertixCoreMod] Ingame Mod Menu & Universal Module System initialized successfully!");
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public KeyMapping getKeyOpenMenu() {
        return keyOpenMenu;
    }

    public int getLeftCps() {
        return leftClicks.size();
    }

    public int getRightCps() {
        return rightClicks.size();
    }

    public void onTick(Minecraft client) {
        if (client == null) return;
        ((StreamingWindow) (Object) client.getWindow()).vertix$setStreaming(DiscordStreamingModule.active() != null);

        if(statsLevel!=client.level){statsLevel=client.level;frameStats.clear();}
        if(++statsTicks%20==0)frameStats.refresh();
        if(keyCopy!=null&&keyCopy.consumeClick()&&client.player!=null&&client.gui.screen()==null){
            var p=client.player;String position=(int)Math.floor(p.getX())+" "+(int)Math.floor(p.getY())+" "+(int)Math.floor(p.getZ())+" ("+client.level.dimension().identifier().getPath()+")";
            client.keyboardHandler.setClipboard(position);
            client.gui.hud.setOverlayMessage(net.minecraft.network.chat.Component.literal("Koordinaten kopiert: "+position),false);
        }
        RenderOptimizer.tick(client);
        CosmeticsClient.tick(client);
        ((AppleSkinModule)moduleManager.getModule("appleskin")).sync();
        ((GammaModule)moduleManager.getModule("gamma")).sync();
        WorldFire.sync();
        ((GlowingGlintsModule)moduleManager.getModule("glowing_glints")).sync();
        ((TotemCounterModule)moduleManager.getModule("totem_counter")).sync();
        // 1. CPS Tracking
        if (client.mouseHandler != null) {
            long now = System.currentTimeMillis();
            boolean left = client.mouseHandler.isLeftPressed();
            boolean right = client.mouseHandler.isRightPressed();

            if (left && !wasLeftPressed) {
                leftClicks.add(now);
            }
            if (right && !wasRightPressed) {
                rightClicks.add(now);
            }
            wasLeftPressed = left;
            wasRightPressed = right;

            purgeOldClicks(leftClicks, now);
            purgeOldClicks(rightClicks, now);
        }

        // 2. Keybind to Open / Close Menu
        boolean keyPressed = false;
        if (keyOpenMenu != null && keyOpenMenu.consumeClick()) {
            keyPressed = true;
        }

        if (keyPressed) {
            if (client.gui.screen() == null) {
                client.setScreenAndShow(new VertixMenuScreen());
            }
        }

        // 3. Tick active modules
        if (moduleManager != null) {
            for (Module m : moduleManager.getModules()) {
                if (m.isEnabled()) {
                    m.onTick(client);
                }
            }
        }
    }

    public void onModuleKey(String key){
        var mc=Minecraft.getInstance();if(mc.player==null||mc.gui.screen()!=null)return;
        boolean changed=false;
        for(Module module:moduleManager.getModules())if(!module.getHotkey().isEmpty()&&module.getHotkey().equals(key)){
            module.toggle();changed=true;
        }
        if(changed){configManager.setActivePreset(client.vertix.core.config.Preset.CUSTOM);configManager.saveConfig(moduleManager.getModules());}
    }

    private void purgeOldClicks(List<Long> clicks, long now) {
        Iterator<Long> it = clicks.iterator();
        while (it.hasNext()) {
            if (now - it.next() > 1000) {
                it.remove();
            } else {
                break;
            }
        }
    }

    public void onRenderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (client == null || moduleManager == null) return;
        // The editor draws its own matching previews; avoid drawing each HUD twice.
        if (client.gui.screen() instanceof HudEditorScreen) return;



        for (Module m : moduleManager.getModules()) {
            if (m.isHud() && m.isEnabled()) {
                try {
                    m.drawHud(extractor, deltaTracker, client,false);
                } catch (Throwable t) {
                    // Prevent single module render failure from breaking the HUD
                }
            }
        }
    }
}
