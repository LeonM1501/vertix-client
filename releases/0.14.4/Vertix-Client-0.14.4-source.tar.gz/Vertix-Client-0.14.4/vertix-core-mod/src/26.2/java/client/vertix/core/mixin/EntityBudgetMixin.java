package client.vertix.core.mixin;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.world.entity.Entity;
import client.vertix.core.performance.RenderOptimizer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(EntityRenderDispatcher.class)
public class EntityBudgetMixin {
    @Inject(require=0,method="shouldRender",at=@At("HEAD"),cancellable=true)
    private void budget(Entity entity,Frustum f,double x,double y,double z,CallbackInfoReturnable<Boolean> ci){if(RenderOptimizer.hide(entity))ci.setReturnValue(false);}
}
