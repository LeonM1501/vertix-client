import { invoke, isTauri } from '@tauri-apps/api/core';
export const desktop = isTauri();
export type Loader = 'vanilla' | 'fabric' | 'forge' | 'neoforge' | 'quilt';
export type Mod = { id: string; display_name: string | null; enabled: boolean; version: string | null; vertix_catalog_id?: string; source: { type: string; project_id?: string; file_name?: string } };
export type Profile = { id: string; name: string; game_version: string; loader: Loader; loader_version?: string | null; last_played?: string; mods: Mod[]; settings: { memory: { min: number; max: number }; [key: string]: unknown }; state?: string; vertix_icon?: import("./ProfileIcon").IconConfig; extra?: { vertix_icon?: import("./ProfileIcon").IconConfig; [key: string]: unknown } };
export type LauncherStatus = { installed: boolean; initialized: boolean; running: boolean; minecraft_dir: string; launcher_path: string | null; session_available: boolean; player_name: string | null };
export type PreparedProfile = { installation_name: string; game_directory: string; version_id: string };
export type AccountSummary = { id: string; username: string; active: boolean };
export type AccountStatus = { client_id: string; signed_in: boolean; username: string | null; account_id: string | null; accounts: AccountSummary[] };
export type Project = { project_id: string; title: string; description: string; author: string; icon_url: string | null; downloads: number; provider?: 'modrinth' | 'curseforge' | 'both' };
export type ContentKind = 'mod' | 'resourcepack' | 'datapack' | 'shader';
export type ContentItem = { id: string; kind: ContentKind; title: string; filename: string; version: string | null; project_id: string | null; version_id: string | null; author: string | null; icon_url: string | null; enabled: boolean; relative_path: string | null; world: string | null; size: number };
export type InstanceSnapshot = { items: ContentItem[]; worlds: string[]; files: { name: string; directory: boolean; size: number }[]; directory: string; running: boolean; pending_restart?: boolean; pending_content?: string[] };
export type SearchResult = { hits: Project[]; total_hits: number; offset: number; limit: number; warning?: string | null };
export type SearchOptions = { kind: ContentKind; query: string; sort: string; offset: number; limit: number; category: string };
export async function searchContent(profile: Profile, options: SearchOptions, signal?: AbortSignal): Promise<SearchResult> {
  if (desktop && options.kind === 'mod') return call<SearchResult>('search_mod_catalog', {request:{query:options.query,game_version:profile.game_version,loader:profile.loader,sort:options.sort,offset:options.offset,limit:options.limit,category:options.category}});
  const facets = [[`${options.kind === 'datapack' ? 'all_project_types' : 'project_type'}:${options.kind}`], [`versions:${profile.game_version}`]];
  if (options.kind === 'mod') facets.push([`categories:${profile.loader}`]);
  if (options.kind === 'datapack') facets.push(['categories:datapack']);
  if (options.category) facets.push([`categories:${options.category}`]);
  const params = new URLSearchParams({ query: options.query, index: options.sort, offset: String(options.offset), limit: String(options.limit), facets: JSON.stringify(facets) });
  return getJSON<SearchResult>(`https://api.modrinth.com/v2/search?${params}`, signal);
}
export function modProjectId(mod: Mod): string | undefined { return mod.vertix_catalog_id || (mod.source.type.toLowerCase() === 'curseforge' ? `cf:${mod.source.project_id}` : mod.source.project_id); }
export async function catalogVersions(id: string, signal?: AbortSignal, game?: string, loader?: string, kind: ContentKind = 'mod'): Promise<import('./contentCompatibility').ContentVersion[]> {
  if(desktop && kind==='mod') return call('catalog_versions',{projectId:id,gameVersion:game||null,loader:loader||null});
  const params=new URLSearchParams();if(game)params.set('game_versions',JSON.stringify([game]));if(loader)params.set('loaders',JSON.stringify([loader]));
  return getJSON(`https://api.modrinth.com/v2/project/${encodeURIComponent(id)}/version?${params}`,signal);
}
export async function catalogProject<T>(id: string, signal?: AbortSignal, kind: ContentKind = 'mod'): Promise<T> {
  return desktop&&kind==='mod' ? call('catalog_project',{projectId:id}) : getJSON(`https://api.modrinth.com/v2/project/${encodeURIComponent(id)}`,signal);
}
export async function catalogSearch(options:{kind:ContentKind;query:string;loader?:string;version?:string;sort:string;page:number},signal?:AbortSignal):Promise<SearchResult>{
  if(desktop&&options.kind==='mod')return call('search_mod_catalog',{request:{query:options.query,game_version:options.version||null,loader:options.loader||null,sort:options.sort,offset:options.page*20,limit:20}});
  const facets=[[`project_type:${options.kind}`]];if(options.version)facets.push([`versions:${options.version}`]);if(options.kind==='mod'&&options.loader)facets.push([`categories:${options.loader}`]);
  const params=new URLSearchParams({query:options.query,index:options.sort,offset:String(options.page*20),limit:'20',facets:JSON.stringify(facets)});
  return getJSON(`https://api.modrinth.com/v2/search?${params}`,signal);
}
export async function instance(profile: Profile): Promise<InstanceSnapshot> {
  if (desktop) return call('get_instance_content', { profileId: profile.id });
  return { items: profile.mods.map(m => ({ id: `mod:${m.id}`, kind: 'mod', title: m.display_name || 'Mod', filename: m.source.file_name || '', version: m.version, project_id: m.source.project_id || null, version_id: null, author: null, icon_url: null, enabled: m.enabled, relative_path: null, world: null, size: 0 })), worlds: [], files: [], directory: 'Dateien sind in der Desktop-App verfügbar.', running: false };
}
type Version = { id: string; version_number: string; loaders: string[]; game_versions: string[]; files: { primary: boolean; filename: string; url: string; hashes: { sha1: string } }[] };
const storageKey = 'vertix-preview-profiles-v1';
export async function call<T>(command: string, args?: Record<string, unknown>): Promise<T> { if (!desktop) throw new Error('Diese Funktion ist in der Desktop-App verfügbar.'); return invoke<T>(command, args); }
export function previewProfiles(): Profile[] { try { return JSON.parse(localStorage.getItem(storageKey) || '[]'); } catch { return []; } }
export async function profiles(): Promise<Profile[]> { return desktop ? call('list_profiles') : previewProfiles(); }
export async function createProfile(name: string, version: string, loader: Loader, memory: number, loaderVersion = ''): Promise<string> {
  if (desktop) {
    const id = await call<string>('create_profile', { params: { name, game_version: version, loader, loader_version: loaderVersion || null, use_shared_minecraft_folder: false } });
    const profile = await call<Profile>('get_profile', { id });
    await call('update_profile', { id, params: { settings: { ...profile.settings, memory: { min: 1024, max: memory } } } });
    return id;
  }
  const id = crypto.randomUUID();
  localStorage.setItem(storageKey, JSON.stringify([...previewProfiles(), { id, name, game_version: version, loader, loader_version: loaderVersion || null, mods: [], settings: { memory: { min: 1024, max: memory } } }]));
  return id;
}
export async function deleteProfile(id: string) { if (desktop) await call('delete_profile', { id }); else localStorage.setItem(storageKey, JSON.stringify(previewProfiles().filter(p => p.id !== id))); }
export async function getJSON<T>(url: string, signal?: AbortSignal): Promise<T> { const r = await fetch(url, { signal }); if (!r.ok) throw new Error(`Der Dienst antwortet mit HTTP ${r.status}. Bitte erneut versuchen.`); return r.json(); }
export async function minecraftVersions(signal?: AbortSignal): Promise<string[]> { const data = await getJSON<{ versions: { id: string; type: string }[] }>('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json', signal); return data.versions.filter(v => v.type === 'release').map(v => v.id); }
export async function loaderVersions(loader: Loader, minecraftVersion: string): Promise<string[]> {
  if (desktop) return call('loader_versions', { loader, minecraftVersion });
  if (loader === 'vanilla') return [];
  if (loader === 'fabric' || loader === 'quilt') {
    const list = await getJSON<{ loader: { version: string } }[]>(`https://meta.${loader}mc.${loader === 'fabric' ? 'net' : 'org'}/v${loader === 'fabric' ? '2' : '3'}/versions/loader/${encodeURIComponent(minecraftVersion)}`);
    return list.map(v => v.loader.version);
  }
  throw new Error('Diese Versionsliste ist in der Desktop-App verfügbar.');
}
export async function searchMods(query: string, profile: Profile, signal?: AbortSignal): Promise<Project[]> {
  return (await searchContent(profile,{kind:'mod',query,sort:'downloads',offset:0,limit:30,category:''},signal)).hits;
}
export async function installMod(project: Project, profile: Profile) {
  const params = new URLSearchParams({ loaders: JSON.stringify([profile.loader]), game_versions: JSON.stringify([profile.game_version]) });
  const versions = await getJSON<Version[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(project.project_id)}/version?${params}`);
  const v = versions[0]; const f = v?.files.find(f => f.primary) || v?.files[0];
  if (!v || !f) throw new Error('Für dieses Profil wurde keine kompatible Version gefunden.');
  await call('add_modrinth_mod_to_profile', { profileId: profile.id, projectId: project.project_id, versionId: v.id, fileName: f.filename, downloadUrl: f.url, fileHashSha1: f.hashes.sha1, modName: project.title, versionNumber: v.version_number, loaders: v.loaders, gameVersions: v.game_versions });
}

export type AppUpdateInfo = {
  current_version: string;
  latest_version: string;
  title: string;
  release_notes: string;
  installer_url: string;
  update_available: boolean;
};

export async function checkAppUpdate(): Promise<AppUpdateInfo | null> {
  if (!desktop) return null;
  return call<AppUpdateInfo | null>('check_vertix_update');
}

export async function downloadAppUpdate(installerUrl: string): Promise<string> {
  if (!desktop) throw new Error('Nur in Desktop-App möglich');
  return call<string>('download_vertix_update', { installerUrl });
}

export async function installAppUpdate(): Promise<void> {
  if (!desktop) throw new Error('Nur in Desktop-App möglich');
  return call('install_vertix_update');
}

export async function simulateReleaseUpdate(version?: string, installerUrl?: string): Promise<AppUpdateInfo> {
  if (!desktop) throw new Error('Nur in Desktop-App möglich');
  return call<AppUpdateInfo>('simulate_release_update', { version, installerUrl });
}

