import { getCurrentWebview } from '@tauri-apps/api/webview';
import { PackImport } from './PackImport';
import { ClientImport } from './ClientImport';
import { Intro } from './Intro';
import { Cosmetics } from './Cosmetics';
import { QuickSwitch } from './QuickSwitch';
import { ProviderSettings } from './ProviderSettings';
import { ProfileIcon } from "./ProfileIcon";
import { AccountMenu } from './AccountMenu';
import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowDownToLine, ArrowRight, Box, Check, ChevronRight, CircleHelp, Gamepad2, Layers3, LoaderCircle, Minus, MoreHorizontal, Package, Pin, Play, Plus, RefreshCw, Search, Settings2, ShieldCheck, SlidersHorizontal, Sparkles, Square, Trash2, UserRound, X } from 'lucide-react';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { listen } from '@tauri-apps/api/event';
import * as api from './api';
import type { AccountStatus, Loader, Profile } from './api';
import { InstanceWorkspace } from './Instance';
import { ContentCatalog } from './ContentCatalog';
import type { CatalogKind } from './contentCompatibility';
import { LoaderVersion } from './LoaderVersion';
import { RamHint } from './RamHint';
import { Home } from './Home';
import { useAppearance, AppearanceSettings, type Appearance } from './Appearance';
import { SettingsSync } from './SettingsSync';
import { version as appVersion } from '../package.json';

type Page = 'play' | 'profiles' | 'mods' | 'settings' | 'instance' | 'cosmetics';
const loaderLabels: Record<Loader, string> = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };
const nav = [{ id: 'play', label: 'Start', icon: Gamepad2 }, { id: 'profiles', label: 'Instanzen', icon: Layers3 }, { id: 'mods', label: 'Entdecken', icon: Package }, { id: 'cosmetics', label: 'Cosmetics', icon: Sparkles }] as const;
const errorText = (e: unknown): string => typeof e === 'string' ? e : e instanceof Error ? e.message : e && typeof e === 'object' && 'message' in e ? String(e.message) : JSON.stringify(e);

export function App() {
  const [pinned, setPinned] = useState<string[]>(()=>{try{const value=JSON.parse(localStorage.getItem('vertix-pinned-instances-v1')||'[]');return Array.isArray(value)?value.filter((v:unknown)=>typeof v==='string'):[];}catch{return [];}});
  const togglePin=(id:string)=>setPinned(ids=>{const next=ids.includes(id)?ids.filter(v=>v!==id):[...ids,id];localStorage.setItem('vertix-pinned-instances-v1',JSON.stringify(next));return next;});
  const [appearance, setAppearance] = useAppearance();
  const [page, setPage] = useState<Page>('play');
  const [quickOpen,setQuickOpen]=useState(false);
  const [catalogKind, setCatalogKind] = useState<CatalogKind>('mod');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [selectedId, setSelectedId] = useState(localStorage.getItem('vertix-selected-profile') || '');
  const [account, setAccount] = useState<AccountStatus | null>(null);
  // Profile id -> process id of every Minecraft that is starting or running.
  const [running, setRunning] = useState<Record<string, string>>({});
  useEffect(() => {
    if (!api.desktop) return;
    const poll = () => api.call<{ id: string; profile_id: string; state: unknown }[]>('get_processes').then(list => setRunning(Object.fromEntries(list.filter(p => p.state === 'Running' || p.state === 'Starting').map(p => [p.profile_id, p.id])))).catch(() => {});
    poll(); const timer = setInterval(poll, 2000); return () => clearInterval(timer);
  }, []);
  const stopGame = async (profileId: string) => { const id = running[profileId]; if (!id) return; try { await api.call('stop_process', { processId: id }); notify('Minecraft wird beendet.'); } catch (e) { notify(e instanceof Error ? e.message : String(e), true); } };
  const [introOpen, setIntroOpen] = useState(() => { try { return sessionStorage.getItem('vertix-intro-shown') !== '1'; } catch { return true; } });
  const closeIntro = useCallback(() => { try { sessionStorage.setItem('vertix-intro-shown', '1'); } catch { /* shows again next start */ } setIntroOpen(false); }, []);
  const [accountOpen, setAccountOpen] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [packOpen,setPackOpen]=useState(false),[packBusy,setPackBusy]=useState(false),[packPath,setPackPath]=useState<string|undefined>();
  const [deleteTarget, setDeleteTarget] = useState<Profile | null>(null);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [launchId, setLaunchId] = useState<string | null>(null);
  const [progress, setProgress] = useState('');
  const [ready, setReady] = useState(!api.desktop);
  const [startupError, setStartupError] = useState('');
  const [notice, setNotice] = useState<{ text: string; error?: boolean } | null>(null);
  const [profileQuery, setProfileQuery] = useState('');
  const [updateInfo, setUpdateInfo] = useState<api.AppUpdateInfo | null>(null);
  const [updateState, setUpdateState] = useState<'available' | 'downloading' | 'downloaded'>('available');
  const [downloadPercent, setDownloadPercent] = useState<number>(0);
  const noticeTimer = useRef<ReturnType<typeof setTimeout>>();
  const contentRef = useRef<HTMLElement>(null);
  useEffect(() => { contentRef.current?.scrollTo({ top: 0 }); }, [page]);
  const selected = profiles.find(p => p.id === selectedId) || profiles[0];
  useEffect(()=>{const handler=(e:KeyboardEvent)=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&!createOpen&&!deleteTarget&&!aboutOpen&&!accountOpen&&!packOpen){e.preventDefault();setQuickOpen(v=>!v);}};document.addEventListener('keydown',handler);return()=>document.removeEventListener('keydown',handler);},[createOpen,deleteTarget,aboutOpen,accountOpen,packOpen]);
  const notify = (text: string, error = false) => { clearTimeout(noticeTimer.current); setNotice({ text, error }); noticeTimer.current = setTimeout(() => setNotice(null), error ? 12000 : 5000); };
  useEffect(()=>{if(!api.desktop)return;const off=getCurrentWebview().onDragDropEvent(event=>{if(event.payload.type!=='drop'||packBusy||(page!=='profiles'&&!createOpen&&!packOpen))return;const paths=event.payload.paths.filter(path=>/\.(zip|mrpack)$/i.test(path));if(paths.length!==1){notify('Ziehe genau eine .mrpack- oder CurseForge-.zip-Datei hinein.',true);return;}setPackPath(paths[0]);setCreateOpen(false);setPackOpen(true);});return()=>{void off.then(f=>f());};},[page,createOpen,packOpen,packBusy]);
  const reload = async () => { const list = await api.profiles(); setProfiles(list); return list; };
  const reloadAccount = async () => { if (!api.desktop) return null; const value = await api.call<AccountStatus>('get_vertix_account'); setAccount(value); return value; };
  async function changeAccount(command:string,accountId:string){
    try{setAccount(await api.call<AccountStatus>(command,{accountId}));}
    catch(e){notify(errorText(e),true);}
  }
  async function signIn() {
    setSigningIn(true); setAuthError('');
    try { setAccount(await api.call<AccountStatus>('sign_in_vertix')); setAccountOpen(false); notify('Mit Minecraft angemeldet.'); }
    catch (e) { setAuthError(errorText(e)); } finally { setSigningIn(false); }
  }
  const perform = async (fn: () => Promise<unknown>, success?: string) => { try { await fn(); if (success) notify(success); } catch (e) { notify(errorText(e), true); } };
  useEffect(() => {
    let disposed = false, pending = false;
    const load = async () => {
      if (pending) return; pending = true;
      try {
        if (api.desktop) { const s = await api.call<{ ready: boolean; error: string | null }>('vertix_status'); if (disposed) return; if (s.error) { setStartupError(s.error); return; } if (!s.ready) return; }
        await reload(); await reloadAccount(); if (!disposed) setReady(true);
      } finally { pending = false; }
    };
    load().catch(e => { if (!disposed) setStartupError(errorText(e)); });
    const timer = api.desktop ? setInterval(() => { if (!ready) load().catch(e => setStartupError(errorText(e))); }, 1000) : undefined;
    return () => { disposed = true; clearInterval(timer); };
  }, [ready]);
  useEffect(() => { if (selected) localStorage.setItem('vertix-selected-profile', selected.id); }, [selected?.id]);
  useEffect(() => {
    if (!api.desktop) return;
    const listener = listen<{ message: string }>('state_event', event => setProgress(event.payload.message));
    return () => { listener.then(f => f()).catch(console.error); };
  }, []);
  useEffect(() => { const close = (e: KeyboardEvent) => { if (e.key === 'Escape') { setCreateOpen(false); setDeleteTarget(null); setAboutOpen(false); } }; document.addEventListener('keydown', close); return () => document.removeEventListener('keydown', close); }, [launchId]);

  useEffect(() => {
    if (!api.desktop) return;
    const check = () => {
      api.checkAppUpdate().then(info => {
        if (info && info.update_available) {
          setUpdateInfo(info);
          // Keep an active download or completed download across background checks.
        }
      }).catch(console.error);
    };
    check();
    const interval = setInterval(check, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!api.desktop) return;
    const unlisten = listen<{ percent: number; done: boolean }>('update_download_progress', event => {
      setDownloadPercent(event.payload.percent);
      if (event.payload.done) {
        setUpdateState('downloaded');
      }
    });
    return () => { unlisten.then(f => f()).catch(console.error); };
  }, []);

  async function handleUpdateClick() {
    if (!updateInfo) return;
    if (updateState === 'available') {
      setUpdateState('downloading');
      setDownloadPercent(0);
      try {
        await api.downloadAppUpdate(updateInfo.installer_url);
        setUpdateState('downloaded');
        notify('Update heruntergeladen! Klicke jetzt erneut auf den Button, um es zu installieren.');
      } catch (e) {
        setUpdateState('available');
        notify(errorText(e), true);
      }
    } else if (updateState === 'downloaded') {
      try {
        notify('Das Update wird installiert. Vertix startet anschließend automatisch neu …');
        await api.installAppUpdate();
      } catch (e) {
        notify(errorText(e), true);
      }
    }
  }

  async function launch(profile = selected) {
    if (!profile) { setCreateOpen(true); return; }
    if (!api.desktop) { notify('Instanzen startest du in der Desktop-App.', true); return; }
    if (launchId) return;
    if (running[profile.id]) { notify('Diese Instanz läuft bereits.'); return; }
    setSelectedId(profile.id); setLaunchId(profile.id); setProgress('Minecraft-Konto wird geprüft …');
    try {
      const ownAccount = await reloadAccount();
      if (!ownAccount?.signed_in) {
        setAccountOpen(true);
        throw new Error('Melde dich zuerst oben rechts mit deinem Microsoft-Konto an.');
      }
      setProgress('Minecraft wird vorbereitet …');
      await api.call('launch_vertix_instance', { profileId: profile.id });
      await reload();
      notify('Minecraft wurde gestartet.');
    } catch (e) { notify(errorText(e), true); } finally { setLaunchId(null); setProgress(''); }
  }

  return <div className="app-shell" data-page={page}>
    {introOpen && <Intro name={account?.username ?? null} instance={selected?.name ?? null} ready={ready} onDone={closeIntro} />}
    <aside className="sidebar"><div className="brand"><img src="/vertix.svg" alt="" /><div>VERTIX<span>MAKE IT YOURS.</span></div></div><div className="nav-caption">DEIN LAUNCHER</div>
      <button className="command-shortcut" title="Schnellzugriff (Strg + K)" onClick={()=>setQuickOpen(true)}><Search size={15}/><span>Schnellzugriff</span><kbd>Strg K</kbd></button><nav aria-label="Hauptnavigation">{nav.map(item => <button key={item.id} aria-label={item.label} title={item.label} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}><item.icon size={19} /><span>{item.label}</span>{page === item.id && <span className="nav-dot" />}</button>)}</nav>
      <div className="sidebar-profiles"><div className="sidebar-section-label"><span>ANGEHEFTET</span><button aria-label="Profil erstellen" className="icon-button" disabled={!ready} onClick={() => setCreateOpen(true)}><Plus size={16} /></button></div>{profiles.some(p=>pinned.includes(p.id)) ? profiles.filter(p=>pinned.includes(p.id)).map(p => <button aria-label={`${p.name} öffnen`} title={p.name} className={`sidebar-profile ${selected?.id === p.id ? 'selected' : ''}`} key={p.id} onClick={() => { setSelectedId(p.id); setPage('instance'); }}><ProfileIcon profile={p} size={29}/><span>{p.name}<small>{p.game_version} · {loaderLabels[p.loader]}</small></span></button>) : <div className="sidebar-empty">Hefte Instanzen über das Pin-Symbol in deiner Bibliothek an.</div>}</div>
      <div className="sidebar-bottom">
        {updateInfo && (
          <button
            className={`update-banner-button ${updateState}`}
            onClick={handleUpdateClick}
            disabled={updateState === 'downloading'}
            title={updateState === 'downloaded' ? 'Klicken, um Update jetzt zu installieren' : updateState === 'downloading' ? `Download läuft (${downloadPercent}%)` : 'Update herunterladen'}
          >
            {updateState === 'available' && (
              <>
                <ArrowDownToLine size={16} />
                <div className="update-text">
                  <span>Update verfügbar</span>
                  <small>v{updateInfo.latest_version} laden</small>
                </div>
              </>
            )}
            {updateState === 'downloading' && (
              <>
                <LoaderCircle size={16} className="spin" />
                <div className="update-text">
                  <span>Lädt herunter …</span>
                  <small>{downloadPercent}%</small>
                </div>
              </>
            )}
            {updateState === 'downloaded' && (
              <>
                <Sparkles size={16} />
                <div className="update-text">
                  <span>Jetzt installieren</span>
                  <small>Vertix neu starten</small>
                </div>
              </>
            )}
          </button>
        )}
        <button aria-label="Einstellungen" title="Einstellungen" className={`nav-item ${page === 'settings' ? 'active' : ''}`} onClick={() => setPage('settings')}><Settings2 size={19} /><span>Einstellungen</span></button>
        <button className="nav-item" aria-label="Über Vertix" title="Über Vertix" onClick={() => setAboutOpen(true)}><CircleHelp size={19} /><span>Über Vertix</span></button>
        <div className="build-label"><span className="status-dot" />{api.desktop ? 'Desktop' : 'Designvorschau'}<span>v{appVersion}</span></div>
      </div>
    </aside>
    <div className="main-shell"><header className="topbar" data-tauri-drag-region><div className="breadcrumb">{page==='play'?<strong className="launchpad-brand">VERTIX CLIENT<small>v{appVersion}</small></strong>:<><span>Launcher</span><ChevronRight size={13} /><strong>{page === 'profiles' ? 'Meine Instanzen' : page === 'mods' ? 'Inhalte entdecken' : page === 'instance' ? selected?.name || 'Instanz' : page === 'cosmetics' ? 'Cosmetics' : 'Einstellungen'}</strong></>}</div><div className="topbar-actions"><AccountMenu status={account} disabled={!ready || !!launchId || signingIn} onAdd={() => { setAuthError(''); setAccountOpen(true); }} onSelect={id => changeAccount('select_vertix_account',id)} onRemove={id => changeAccount('remove_vertix_account',id)} />{api.desktop && <div className="window-controls"><button aria-label="Minimieren" onClick={() => perform(() => getCurrentWindow().minimize())}><Minus size={15} /></button><button aria-label="Maximieren" onClick={() => perform(() => getCurrentWindow().toggleMaximize())}><Square size={12} /></button><button aria-label="Schließen" onClick={() => perform(() => getCurrentWindow().close())}><X size={17} /></button></div>}</div>
    </header>
    {(appearance.design==='focus'||appearance.design==='terminal') && profiles.some(p=>pinned.includes(p.id)) && <nav className="pinned-dock" aria-label="Angeheftete Instanzen">{profiles.filter(p=>pinned.includes(p.id)).map(p=><button key={p.id} onClick={()=>{setSelectedId(p.id);setPage('instance');}}><ProfileIcon profile={p} size={25}/>{p.name}</button>)}</nav>}
    {!ready ? <main className="startup"><LoaderCircle className="spin" size={28} /><h1>{startupError ? 'Vertix konnte nicht starten' : 'Dein Launcher wird vorbereitet.'}</h1><p>{startupError || 'Instanzen und Einstellungen werden geladen.'}</p></main> : <main ref={contentRef} className="page-content">
      {page === 'play' && <Home account={account} progress={progress} onSelect={setSelectedId} design={appearance.design} profiles={profiles} selected={selected} launching={!!launchId} onLaunch={() => launch()} running={!!(selected && running[selected.id])} onStop={() => selected && void stopGame(selected.id)} onCreate={() => setCreateOpen(true)} onImport={() => { setPackPath(undefined); setPackOpen(true); }} onOpen={id => { setSelectedId(id); setPage('instance'); }} onLibrary={() => setPage('profiles')} onDiscover={(kind = 'mod') => { setCatalogKind(kind); setPage('mods'); }} />}
      {page === 'profiles' && <><div className="page-heading"><div><div className="eyebrow">DEINE BIBLIOTHEK</div><h1>Meine Instanzen</h1><p>Getrennte Welten, Versionen und Mods. Modpacks hier hineinziehen oder importieren.</p></div><div className="profile-create-actions"><button className="button" disabled={!ready} onClick={()=>{setPackPath(undefined);setPackOpen(true);}}><ArrowDownToLine size={17}/>Importieren</button><button className="button light" onClick={() => setCreateOpen(true)}><Plus size={17} />Instanz erstellen</button></div></div><div className="toolbar"><label className="search-field"><Search size={18} /><input aria-label="Instanzen suchen" placeholder="Instanzen durchsuchen …" value={profileQuery} onChange={e => setProfileQuery(e.target.value)} /></label><span>{profiles.length} Instanzen</span></div><div className="profile-grid library">{profiles.filter(p => p.name.toLowerCase().includes(profileQuery.toLowerCase())).map(p => <ProfileCard key={p.id} onLaunch={() => launch(p)} launching={!!launchId} profile={p} pinned={pinned.includes(p.id)} onPin={()=>togglePin(p.id)} selected={selected?.id === p.id} onSelect={() => { setSelectedId(p.id); setPage('instance'); }} onDetails={() => { setSelectedId(p.id); setPage('instance'); }} onDelete={() => setDeleteTarget(p)} />)}{!profiles.length && <div className="empty-state"><Layers3 size={38} /><h2>Platz für deine Ideen.</h2><p>Starte leer oder zieh von deinem alten Client um.</p><button className="button light" onClick={() => setCreateOpen(true)}><Plus size={16} />Erste Instanz erstellen</button></div>}{!!profiles.length && !profiles.some(p => p.name.toLowerCase().includes(profileQuery.toLowerCase())) && <div className="empty-state"><Search size={30} /><h2>Keine Instanz gefunden.</h2><p>Versuche einen anderen Namen.</p></div>}</div></>}
      {page === 'cosmetics' && <Cosmetics notify={notify} accountName={account?.username ?? null} accountId={account?.account_id ?? null} />}{page === 'mods' && <ContentCatalog key={catalogKind} initialKind={catalogKind} profiles={profiles} onReload={reload} notify={notify} />}
      {page === 'instance' && (selected ? <InstanceWorkspace key={selected.id + page} profile={selected} onBack={() => setPage('profiles')} onLaunch={() => launch()} onReload={reload} notify={notify} launching={!!launchId} initialBrowse={false} pinned={pinned.includes(selected.id)} onPin={()=>togglePin(selected.id)} /> : <div className="empty-state"><Package size={38} /><h2>Erst deine Instanz. Dann dein Inhalt.</h2><p>Erstelle eine getrennte Instanz und verwalte dort Mods, Pakete und Shader.</p><button className="button light" onClick={() => setCreateOpen(true)}><Plus size={16} />Instanz erstellen</button></div>)}
      {page === 'settings' && <Settings account={account} onAccount={() => setAccountOpen(true)} appearance={appearance} onAppearance={setAppearance} />}
    </main>}
    <footer className="launchbar"><div className="launch-profile"><div className="profile-mini"><ProfileIcon profile={selected} size={42}/></div><div><strong>{selected?.name || 'Noch keine Instanz ausgewählt'}</strong><span>{selected ? `${selected.game_version} · ${loaderLabels[selected.loader]} · ${selected.settings.memory.max / 1024} GB RAM` : 'Dein nächstes Abenteuer beginnt mit einer Instanz.'}</span></div></div><div className="launch-action"><span>{launchId ? progress : account?.signed_in ? 'Direktstart mit deinem Minecraft-Konto.' : 'Bei Minecraft anmelden zum Spielen.'}</span><button className="button light launch-button" disabled={!ready || !!launchId} onClick={() => launch()}>{launchId ? <LoaderCircle className="spin" size={18} /> : <Play size={17} fill="currentColor" />}{launchId ? 'Wird vorbereitet …' : selected ? 'Spielen' : 'Instanz erstellen'}<ChevronRight size={17} /></button></div></footer></div>
    {accountOpen && <Modal title="Microsoft-Konto hinzufügen" subtitle="Microsoft · Java Edition" onClose={() => { if (!signingIn) setAccountOpen(false); }}><p className="dialog-copy">Melde dich mit einem Microsoft-Konto an, das Minecraft: Java Edition besitzt. Vorhandene Konten bleiben gespeichert. Das hinzugefügte Konto wird für den nächsten Spielstart ausgewählt.</p>{signingIn && <div className="info-box"><LoaderCircle className="spin" size={20} /><span>Schließe die Microsoft-Anmeldung im Anmeldefenster ab. Anschließend prüft Vertix deine Spielberechtigung.</span></div>}{authError && <p role="alert" className="inline-error">{authError}</p>}<div className="dialog-actions">{signingIn ? <button className="button" onClick={() => perform(() => api.call('cancel_vertix_login'))}>Anmeldung abbrechen</button> : <><button className="button" onClick={() => setAccountOpen(false)}>Schließen</button><button className="button light" disabled={!api.desktop} onClick={signIn}><Plus size={16} />Konto hinzufügen</button></>}</div></Modal>}
    {notice && <div role="status" className={`toast ${notice.error ? 'error' : ''}`}><span>{notice.text}</span><button className="icon-button" aria-label="Hinweis schließen" onClick={() => setNotice(null)}><X size={16} /></button></div>}
    {packOpen && <Modal title="Importieren" onClose={()=>{if(!packBusy)setPackOpen(false);}}>{!packPath&&<ClientImport onBusy={setPackBusy} onImported={async id=>{await reload();setSelectedId(id);setPackOpen(false);setPage('instance');notify('Umzug fertig. Deine Instanz ist jetzt in Vertix.');}}/>}<PackImport sourcePath={packPath} onBusy={setPackBusy} onImported={async id=>{await reload();setSelectedId(id);setPackOpen(false);setPage('instance');notify('Dein Modpack wurde vollständig als neue Instanz importiert.');}}/></Modal>}
    {createOpen && <CreateProfile onImport={()=>{setCreateOpen(false);setPackPath(undefined);setPackOpen(true);}} onClose={() => setCreateOpen(false)} onCreated={async id => { await reload(); setSelectedId(id); setCreateOpen(false); setPage('instance'); notify(api.desktop ? 'Deine Instanz ist bereit.' : 'Vorschauprofil gespeichert. Minecraft ist in der Desktop-App verfügbar.'); }} notify={notify} />}
    {deleteTarget && <Modal title="Profil löschen?" subtitle={deleteTarget.name} onClose={() => setDeleteTarget(null)}><p className="dialog-copy">Diese Instanz einschließlich seiner lokalen Dateien und Welten wird in den Papierkorb des Launchers verschoben.</p><div className="dialog-actions"><button className="button" onClick={() => setDeleteTarget(null)}>Behalten</button><button className="button danger" onClick={() => perform(async () => { await api.deleteProfile(deleteTarget.id); await reload(); setDeleteTarget(null); }, 'Instanz gelöscht.')}><Trash2 size={16} />Instanz löschen</button></div></Modal>}
    {quickOpen&&<Modal title="Schnellzugriff" subtitle="Deine Instanzen und Aktionen. Direkt erreichbar." onClose={()=>setQuickOpen(false)}><QuickSwitch onClose={()=>setQuickOpen(false)} actions={[
      ...profiles.map(p=>({id:p.id,title:p.name,detail:`Instanz · ${p.game_version} · ${loaderLabels[p.loader]}`,run:()=>{setSelectedId(p.id);setPage('instance');}})),
      {id:'new',title:'Neue Instanz',detail:'Eine frische Installation zusammenstellen',run:()=>setCreateOpen(true)},
      ...nav.map(n=>({id:'page-'+n.id,title:n.label,detail:'Seite öffnen',run:()=>setPage(n.id)})),
      {id:'settings',title:'Einstellungen',detail:'Design, Konto und Inhaltsquellen',run:()=>setPage('settings')}
    ]}/></Modal>}
    {aboutOpen && <Modal title="Vertix Client" subtitle={`Version ${appVersion} · Ein unabhängiger Launcher`} onClose={() => setAboutOpen(false)}><div className="about-mark"><img src="/vertix.svg" alt="Vertix" /><p>Dein Spiel. Dein Setup.</p></div><p className="dialog-copy">Vertix ist ein unabhängiger Minecraft Launcher. Dein Spiel. Dein Setup. Schnell, sauber und direkt spielbereit.</p><p className="dialog-copy">Lizenz: GNU GPLv3. Du darfst diese Software unter den Bedingungen der GPLv3 weitergeben und verändern. Es besteht keine Gewährleistung. Minecraft ist eine Marke von Mojang / Microsoft. Vertix ist kein offizielles Minecraft-Produkt.</p><div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', margin: '14px 0 18px' }}><button className="button" onClick={async () => { try { const info = await api.checkAppUpdate(); if (info?.update_available) { setUpdateInfo(info); setUpdateState('available'); notify(`Update v${info.latest_version} verfügbar! Siehe Button unten links.`); } else { notify(`Vertix ist auf dem neuesten Stand (v${appVersion}).`); } } catch (e) { notify(errorText(e), true); } }}><RefreshCw size={15} />Nach Updates suchen</button></div><a className="text-button" href="/LICENSE.txt" target="_blank" rel="noreferrer">Vollständige Lizenz lesen<ArrowRight size={16} /></a></Modal>}
  </div>;
}

function ProfileCard({ profile: p, selected, onSelect, onDetails, onDelete, pinned, onPin, onLaunch, launching }: { onLaunch:()=>void; launching:boolean; pinned: boolean; onPin:()=>void; profile: Profile; selected: boolean; onSelect: () => void; onDetails: () => void; onDelete?: () => void }) {
  return <article className={`profile-card ${selected ? 'selected' : ''}`}><button className={`profile-cover ${p.loader}`} aria-label={`${p.name} auswählen`} onClick={onSelect}><ProfileIcon profile={p} size={62}/><span>{loaderLabels[p.loader].toUpperCase()}</span>{selected && <span className="selected-badge"><Check size={12} />AUSGEWÄHLT</span>}</button><div className="profile-card-body"><button className={`icon-button pin-button ${pinned?'is-pinned':''}`} aria-label={`${p.name} ${pinned?'lösen':'anheften'}`} aria-pressed={pinned} onClick={onPin}><Pin size={16}/></button><div><button className="profile-name" onClick={onSelect}>{p.name}</button><p>{p.game_version}<span>·</span>{loaderLabels[p.loader]}</p></div><button className="button library-play" disabled={launching} aria-label={`${p.name} spielen`} onClick={onLaunch}><Play size={15} fill="currentColor"/><span>Spielen</span></button><button className="icon-button" aria-label={`${p.name} verwalten`} onClick={onDetails}><MoreHorizontal size={20} /></button>{onDelete && <button className="icon-button" aria-label={`${p.name} löschen`} onClick={onDelete}><Trash2 size={15} /></button>}</div></article>;
}

function Modal({ title, subtitle, onClose, children, wide = false }: { title: string; subtitle?: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { const previous = document.activeElement as HTMLElement; const app = document.querySelectorAll<HTMLElement>('.app-shell > .sidebar, .app-shell > .main-shell'); app.forEach(el => { el.inert = true; }); ref.current?.focus(); return () => { app.forEach(el => { el.inert = false; }); previous?.focus(); }; }, []);
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} ref={ref} onKeyDown={e => { if (e.key !== 'Tab') return; const f = [...(ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled), a, input, select') || [])]; if (!f.length) return; if (e.shiftKey && (document.activeElement === f[0] || document.activeElement === ref.current)) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); } }}><div className="modal-heading"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div><button className="icon-button" aria-label="Dialog schließen" onClick={onClose}><X size={20} /></button></div>{children}</div></div>;
}

function CreateProfile({ onClose, onCreated, notify, onImport }: { onImport:()=>void; onClose: () => void; onCreated: (id: string) => Promise<void>; notify: (t: string, e?: boolean) => void }) {
  const [name, setName] = useState(''), [version, setVersion] = useState('');
  const [versions, setVersions] = useState<string[]>([]), [loader, setLoader] = useState<Loader>('fabric');
  const [loaderVersion, setLoaderVersion] = useState(''), [loaderValid, setLoaderValid] = useState(false);
  const [memory, setMemory] = useState(4096), [busy, setBusy] = useState(false), [versionError, setVersionError] = useState(''), [attempt, setAttempt] = useState(0);
  useEffect(() => { const c = new AbortController(); setVersionError(''); api.minecraftVersions(c.signal).then(list => { setVersions(list); setVersion(list[0] || ''); }).catch(e => { if (!c.signal.aborted) setVersionError(errorText(e)); }); return () => c.abort(); }, [attempt]);
  async function submit(e: FormEvent) { e.preventDefault(); if (busy || !name.trim() || !version || !loaderValid) return; setBusy(true); try { await onCreated(await api.createProfile(name.trim(), version, loader, memory, loaderVersion)); } catch (e) { notify(errorText(e), true); } finally { setBusy(false); } }
  return <Modal title="Neue Instanz" subtitle="Ein frischer Start. Ohne vorinstallierte Mods." onClose={() => { if (!busy) onClose(); }}><button type="button" className="pack-create-link button" onClick={onImport}><ArrowDownToLine size={16}/>Von NoRisk, Dawn &amp; Co. umziehen oder Modpack importieren</button><form onSubmit={submit}><label className="field">Name<input required maxLength={60} placeholder="Zum Beispiel: Meine Survival-Welt" value={name} onChange={e => setName(e.target.value)} /></label><div className="form-row"><label className="field">Minecraft-Version<select aria-label="Minecraft-Version" value={version} onChange={e => { setVersion(e.target.value); setLoaderVersion(''); setLoaderValid(loader === 'vanilla'); }} disabled={!versions.length}>{!versions.length && <option value="">Versionen werden geladen …</option>}{versions.map(v => <option key={v} value={v}>{v}</option>)}</select></label><label className="field">Modloader<select value={loader} onChange={e => { setLoader(e.target.value as Loader); setLoaderVersion(''); setLoaderValid(e.target.value === 'vanilla'); }}>{Object.entries(loaderLabels).map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select></label></div><LoaderVersion loader={loader} gameVersion={version} value={loaderVersion} onChange={setLoaderVersion} disabled={busy} onValid={setLoaderValid} />{versionError && <div className="inline-error">{versionError}<button type="button" className="text-button" onClick={() => setAttempt(a => a + 1)}>Erneut laden</button></div>}<label className="field">Arbeitsspeicher<span className="range-label">{memory / 1024} GB RAM</span><input type="range" min={2048} max={16384} step={1024} value={memory} onChange={e => setMemory(Number(e.target.value))} /></label><RamHint mods={0} current={memory} onApply={setMemory} /><div className="info-box"><Box size={19} /><span>{loader === 'vanilla' ? 'Vanilla enthält keine Mods. Wähle einen Modloader, wenn du Mods installieren möchtest.' : `${loaderLabels[loader]} wird für diese Instanz vorbereitet. Mods kannst du anschließend selbst hinzufügen.`}</span></div>{!api.desktop && <p className="preview-note">Designvorschau: Diese Instanz wird nur im Browser gespeichert.</p>}<div className="dialog-actions"><button type="button" className="button" onClick={onClose} disabled={busy}>Abbrechen</button><button className="button light" disabled={busy || !version || !name.trim() || !loaderValid}>{busy ? <LoaderCircle size={17} className="spin" /> : <Plus size={17} />}Instanz erstellen</button></div></form></Modal>;
}

function Settings({ account, onAccount, appearance, onAppearance }: { account: AccountStatus | null; onAccount: () => void; appearance: Appearance; onAppearance: (value: Appearance) => void }) {
  return <>
    <div className="page-heading">
      <div>
        <div className="eyebrow">SO, WIE DU ES MAGST.</div>
        <h1>Einstellungen</h1>
        <p>Dein Launcher. Dein Setup.</p>
      </div>
    </div>
    <AppearanceSettings value={appearance} onChange={onAppearance} />
    <ProviderSettings />
    <SettingsSync />
    <section className="settings-panel">
      <div className="settings-icon"><UserRound size={23} /></div>
      <div>
        <h2>Dein Minecraft-Konto</h2>
        <p>{account?.signed_in ? `Angemeldet als ${account.username}. Deine Instanzen können direkt gestartet werden.` : "Mit deinem Microsoft-Konto anmelden und Minecraft direkt aus Vertix starten."}</p>
        <div className="settings-actions">
          <button className="button light" disabled={!api.desktop} onClick={onAccount}>
            <UserRound size={16} />{account?.signed_in ? "Weiteres Konto hinzufügen" : "Mit Microsoft anmelden"}
          </button>
        </div>
        <p>Vertix verwendet die offizielle Microsoft- und Xbox-Live-Anmeldung. Deine Sitzung wird sicher auf deinem PC gespeichert.</p>
      </div>
    </section>
    <section className="settings-panel">
      <div className="settings-icon"><Layers3 size={23} /></div>
      <div>
        <h2>Ein Konto. Getrennte Instanzen.</h2>
        <p>Jede Instanz hat ihren eigenen Ordner für Welten, Mods und Einstellungen.</p>
        <p>Dein Minecraft-Konto und technische Downloads werden gemeinsam genutzt. Jede Instanz startet mit einem eigenen Spielordner. Mit der optionalen Synchronisierung kannst du ausgewählte Tasten und Spieloptionen gemeinsam verwenden.</p>
      </div>
    </section>

  </>;
}

