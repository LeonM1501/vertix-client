import { type ReactNode, useEffect, useRef, useState } from 'react';
import { LoaderCircle, RotateCcw } from 'lucide-react';
import * as api from './api';
import { skinFaces, skinParts } from './skinGeometry';
import { hatArt, wingArt, wingTexture } from './cosmeticArt';

type Skin = { base64: string; variant: 'classic' | 'slim' };
const px = (n:number) => `calc(${n} * var(--skin-pixel))`;
const wrap = (deg:number) => ((deg + 180) % 360 + 360) % 360 - 180;
// Survives page switches so the preview never flashes the default skin while reloading.
const skinCache=new Map<string,Skin>();
export function SkinPreview({ accountId, username, cape, hat, wings, children }: { accountId?: string | null; username?: string | null; cape?: string | null; hat?: string | null; wings?: string | null; children?: ReactNode }) {
  const [skin,setSkin]=useState<Skin|null>(()=>accountId?skinCache.get(accountId)??null:null), [loading,setLoading]=useState(false), [failed,setFailed]=useState(false), [retry,setRetry]=useState(0);
  const [loaded,setLoaded]=useState(''), [legacy,setLegacy]=useState(false), [rotation,setRotation]=useState(-25);
  const drag=useRef<{x:number;r:number;moved:boolean}|null>(null);
  const [waving,setWaving]=useState(false);
  // Wave once the skin is visible (after the intro, if one is playing) and whenever the intro ends.
  useEffect(()=>{const wave=()=>setWaving(true);window.addEventListener('vertix-wave',wave);return()=>window.removeEventListener('vertix-wave',wave);},[]);
  useEffect(()=>{
    let cancelled=false;
    const cached=accountId?skinCache.get(accountId)??null:null;
    setSkin(cached); setFailed(false); setLoading(false);
    if(api.desktop && accountId){
      setLoading(!cached);
      api.call<Skin>('get_vertix_skin',{accountId}).then(value=>{skinCache.set(accountId,value);if(!cancelled)setSkin(value);}).catch(()=>{if(!cancelled&&!cached)setFailed(true);}).finally(()=>{if(!cancelled)setLoading(false);});
    }
    return ()=>{cancelled=true;};
  },[accountId,retry]);
  const source=skin?`data:image/png;base64,${skin.base64}`:'/skins/steve.png';
  const ready=loaded===source;
  useEffect(()=>{if(ready&&!document.documentElement.dataset.intro)setWaving(true);},[ready]);
  return <div className="skin-preview">
    <div className="skin-name"><span className="eyebrow">{accountId?'DEIN SPIELER':'DEIN SPIELRAUM'}</span><strong>{username||'Bereit für deine Welt.'}</strong></div>
    <div className="skin-stage" role="slider" tabIndex={0} aria-valuemin={-180} aria-valuemax={180} aria-valuenow={rotation} aria-valuetext={`${rotation} Grad`} aria-label={accountId && skin && ready?`3D-Skin von ${username}`:'Minecraft-Standardskin als Vorschau'} onPointerDown={e=>{drag.current={x:e.clientX,r:rotation,moved:false};e.currentTarget.setPointerCapture(e.pointerId);}} onPointerMove={e=>{if(drag.current&&Math.abs(e.clientX-drag.current.x)>3)drag.current.moved=true;if(drag.current)setRotation(Math.round(wrap(drag.current.r+(e.clientX-drag.current.x)*.6)));}} onPointerUp={()=>{if(drag.current&&!drag.current.moved)setWaving(true);drag.current=null;}} onPointerCancel={()=>{drag.current=null;}} onDoubleClick={()=>setRotation(-25)} onKeyDown={e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();setRotation(r=>wrap(r+(e.key==='ArrowLeft'?-15:15)));}}}>
      <svg className="skin-floor" viewBox="0 0 600 160" aria-hidden="true"><path d="M0 150L230 0M120 160L260 0M240 160L290 0M360 160L320 0M480 160L350 0M600 150L380 0M0 150H600M70 100H530M145 58H455M205 25H395"/></svg>
      <div className="skin-platform"/>
      <div className={`skin-model${waving?' waving':''}`} onAnimationEnd={e=>{if(e.animationName==='skin-wave')setWaving(false);}} style={{transform:`translateX(-50%) rotateX(-6deg) rotateY(${rotation}deg)`,visibility:ready?'visible':'hidden'}}>
        {skinParts(skin?.variant==='slim',legacy).map(p=><div key={p.name} className={`skin-part skin-${p.name}`} style={{left:px(p.x),top:px(p.y),width:px(p.w),height:px(p.h),transform:p.mirrored?'scaleX(-1)':undefined}}>
          {[p.uv,...(p.overlay?[p.overlay]:[])].map((uv,index)=><div key={index} className={`skin-cube ${index?'skin-overlay':''}`}>
            {skinFaces(p,uv).map(f=><i key={f.name} className={`skin-face skin-face-${f.name}`} style={{width:px(f.w),height:px(f.h),backgroundImage:`url("${source}")`,backgroundSize:`${px(64)} ${px(legacy?32:64)}`,backgroundPosition:`${px(-f.u)} ${px(-f.v)}`,transform:`translate(-50%,-50%) ${f.rotation} translateZ(${px(f.offset)})`}}/>)}</div>)}
          {p.name==='head'&&<HatModel id={hat??null}/>}
          {p.name==='body'&&<WingModel id={wings??null}/>}
        </div>)}
        {cape&&<div className="skin-part skin-cape" style={{left:px(3),top:px(8),width:px(10),height:px(16),transform:`translateZ(${px(-2.6)}) rotateX(-9deg) rotateY(180deg)`}}>
          <div className="skin-cube">{skinFaces({name:'cape',x:3,y:8,w:10,h:16,d:1,uv:[0,0]}).map(f=><i key={f.name} className={`skin-face skin-face-${f.name}`} style={{width:px(f.w),height:px(f.h),backgroundImage:`url("${cape}")`,backgroundSize:`${px(64)} ${px(32)}`,backgroundPosition:`${px(-f.u)} ${px(-f.v)}`,transform:`translate(-50%,-50%) ${f.rotation} translateZ(${px(f.offset)})`}}/>)}</div>
        </div>}
      </div>
      {children}
      {(!ready||loading)&&<LoaderCircle size={22} className="skin-loading spin" aria-label="Skin wird geladen"/>}
    </div>
    <img className="skin-texture" src={source} alt="" onLoad={e=>{const image=e.currentTarget;if(image.naturalWidth>=64&&image.naturalWidth<=1024&&[1,2].includes(image.naturalWidth/image.naturalHeight)){setLegacy(image.naturalWidth/image.naturalHeight===2);setLoaded(source);}else{setSkin(null);setFailed(true);}}} onError={()=>{if(skin){setSkin(null);setFailed(true);}}}/>
    <div className="skin-controls"><span>Ziehen zum Drehen</span><button className="icon-button" aria-label="Skin-Drehung zurücksetzen" onClick={()=>setRotation(-25)}><RotateCcw size={14}/></button></div>
    <div className="skin-caption" role="status">{loading?'Dein Skin wird geladen …':failed?<><span>Skin gerade nicht erreichbar · Standardvorschau</span><button onClick={()=>setRetry(n=>n+1)}>Erneut laden</button></>:!accountId?'Melde dich an, um deinen Skin zu sehen.':!api.desktop?'Skin-Vorschau ist in der Desktop-App verfügbar.':null}</div>
  </div>;
}

/** Hat boxes in head space (model pixels, top of head at y = -8, face towards -z), drawn as CSS cubes. */
function HatModel({ id }: { id: string | null }) {
  const art = hatArt(id); if (!art) return null;
  return <div className={`skin-hat${art.bob ? ' bob' : ''}`}>{art.boxes.map(([a, b, c, d, e, f, top, bottom, glow], i) => {
    const w = d - a, h = e - b, depth = f - c, side = `linear-gradient(#${top},#${bottom})`;
    const faces: [string, number, number, string, number, string][] = [
      ['front', w, h, 'rotateY(0deg)', depth / 2, side], ['back', w, h, 'rotateY(180deg)', depth / 2, side],
      ['right', depth, h, 'rotateY(-90deg)', w / 2, side], ['left', depth, h, 'rotateY(90deg)', w / 2, side],
      ['top', w, depth, 'rotateX(90deg)', h / 2, `#${top}`], ['bottom', w, depth, 'rotateX(-90deg)', h / 2, `#${bottom}`],
    ];
    return <div key={i} className={`skin-box${glow ? ' glow' : ''}`} style={{ left: px(a + 4), top: px(b + 8), width: px(w), height: px(h), transform: `translateZ(${px(-(c + f) / 2)})` }}>
      {faces.map(([name, fw, fh, rotation, offset, background]) => <i key={name} className={`skin-face skin-face-${name}`} style={{ width: px(fw), height: px(fh), background, transform: `translate(-50%,-50%) ${rotation} translateZ(${px(offset)})` }} />)}
    </div>;
  })}</div>;
}

/** Both wings as textured planes hinged behind the shoulders, flapping like in game. */
function WingModel({ id }: { id: string | null }) {
  const art = wingArt(id); if (!art || !id) return null;
  const texture = wingTexture(id), w = art.rows[0].length * art.scale, h = art.rows.length * art.scale;
  return <>{[-1, 1].map(side => <div key={side} className={`skin-wing${id === 'butterfly' ? ' fast' : ''}`} style={{ left: px(4 + side), top: px(2.5), ['--side' as string]: side, transform: `translateZ(${px(-2.3)}) rotateY(${side * 24}deg) rotateZ(${-side * 18}deg) scaleX(${side})` }}>
    <div className="skin-wing-flap"><i style={{ left: px(-art.anchor[0] * art.scale), top: px(-art.anchor[1] * art.scale), width: px(w), height: px(h), backgroundImage: `url("${texture}")` }} /></div>
  </div>)}</>;
}
