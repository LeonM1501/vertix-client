import { useEffect, useMemo, useRef, useState } from 'react';

const SEEN = 'vertix-intro-seen';
const greeting = (hour: number) => hour < 5 ? 'Noch wach?' : hour < 11 ? 'Guten Morgen' : hour < 17 ? 'Hey' : hour < 22 ? 'Guten Abend' : 'Späte Runde?';
const readSeen = () => { try { return localStorage.getItem(SEEN) === '1'; } catch { return false; } };
// The Vertix V in a 64-unit box, same outline as public/vertix.svg.
const V = [[17, 19], [25.2, 19], [32, 37.6], [38.8, 19], [47, 19], [35.6, 46], [28.4, 46]];
const inside = (x: number, y: number) => {
  let hit = false;
  for (let i = 0, j = V.length - 1; i < V.length; j = i++) {
    const [xi, yi] = V[i], [xj, yj] = V[j];
    if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) hit = !hit;
  }
  return hit;
};
const hex = (value: string) => { const m = value.trim().match(/^#([0-9a-f]{6})$/i); const n = parseInt(m ? m[1] : 'a78bfa', 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);

type Pixel = { tx: number; ty: number; sx: number; sy: number; delay: number; spin: number; color: string; burst: [number, number] };

/** Pixels swirl in from the edges and assemble into the V; on leave they burst outward. */
function Swarm({ leaving }: { leaving: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const leaveAt = useRef<number | null>(null);
  useEffect(() => { if (leaving && leaveAt.current === null) leaveAt.current = performance.now(); }, [leaving]);
  useEffect(() => {
    const el = canvas.current; const ctx = el?.getContext('2d'); if (!el || !ctx) return;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = window.innerWidth, h = window.innerHeight;
    el.width = w * dpr; el.height = h * dpr; ctx.scale(dpr, dpr);
    const size = Math.min(260, w * 0.32), cell = Math.max(4, Math.round(size / 52)), unit = size / 30;
    const cx = w / 2, cy = h / 2 - size * 0.42;
    const from = hex(getComputedStyle(document.documentElement).getPropertyValue('--accent')), to = [224, 64, 251];
    const pixels: Pixel[] = [];
    for (let gy = 17; gy <= 47; gy += cell / unit) for (let gx = 15; gx <= 49; gx += cell / unit) {
      if (!inside(gx, gy)) continue;
      const tx = cx + (gx - 32) * unit, ty = cy + (gy - 32.5) * unit;
      const t = (gx - 17) / 30, angle = Math.random() * Math.PI * 2, far = Math.hypot(w, h) * (0.55 + Math.random() * 0.3);
      const c = from.map((v, i) => Math.round(v + (to[i] - v) * t));
      pixels.push({ tx, ty, sx: cx + Math.cos(angle) * far, sy: cy + Math.sin(angle) * far, delay: Math.random() * 0.55 + t * 0.25,
        spin: (Math.random() < 0.5 ? -1 : 1) * (0.8 + Math.random()), color: `rgb(${c[0]},${c[1]},${c[2]})`,
        burst: [(tx - cx) / size + (Math.random() - 0.5) * 0.6, (ty - cy) / size + (Math.random() - 0.5) * 0.6] });
    }
    const start = performance.now(); let frame = 0;
    const draw = (now: number) => {
      const t = (now - start) / 1000, out = leaveAt.current === null ? 0 : (now - leaveAt.current) / 1000;
      ctx.clearRect(0, 0, w, h);
      for (const p of pixels) {
        const k = reduced ? 1 : easeOut(Math.min(1, Math.max(0, (t - p.delay) / 1.15)));
        // Spiral in: the angle around the centre unwinds as the pixel lands.
        const dx = p.sx - p.tx, dy = p.sy - p.ty, a = (1 - k) * p.spin * 2.4;
        let x = p.tx + (dx * Math.cos(a) - dy * Math.sin(a)) * (1 - k);
        let y = p.ty + (dx * Math.sin(a) + dy * Math.cos(a)) * (1 - k);
        let alpha = Math.min(1, k * 1.6);
        if (out > 0) { const f = out * out * 1400; x += p.burst[0] * f; y += p.burst[1] * f; alpha *= Math.max(0, 1 - out * 1.8); }
        // A light sweep runs across the finished V.
        const band = (Math.max(0, t - 1.6) % 2.4) / 1.2 - 0.6;
        const sweep = k === 1 && out === 0 ? Math.max(0, 1 - Math.abs((p.tx - cx) / size - band) * 6) : 0;
        ctx.globalAlpha = alpha;
        ctx.fillStyle = sweep > 0 ? `rgba(255,255,255,${0.35 + sweep * 0.65})` : p.color;
        const s = cell - 1 + (1 - k) * 2;
        ctx.fillRect(x - s / 2, y - s / 2, s, s);
        if (sweep > 0) { ctx.globalAlpha = alpha * (1 - sweep * 0.6); ctx.fillStyle = p.color; ctx.fillRect(x - s / 2, y - s / 2, s, s); }
      }
      ctx.globalAlpha = 1;
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, []);
  return <canvas ref={canvas} className="intro-swarm" aria-hidden="true" />;
}

/** Start-up intro with a personal greeting. Any click or key skips it. */
export function Intro({ name, instance, ready, onDone }: { name: string | null; instance: string | null; ready: boolean; onDone: () => void }) {
  const [phase, setPhase] = useState<'play' | 'leave'>('play');
  const firstTime = useMemo(() => !readSeen(), []);
  const reduced = useMemo(() => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches, []);
  // Wait briefly for the account so the greeting can use the real name.
  const [named, setNamed] = useState(ready);
  useEffect(() => { if (ready) setNamed(true); const t = setTimeout(() => setNamed(true), 1200); return () => clearTimeout(t); }, [ready]);
  useEffect(() => {
    document.documentElement.dataset.intro = 'playing';
    const leave = setTimeout(() => setPhase('leave'), reduced ? 1600 : 4300);
    const skip = () => setPhase('leave');
    window.addEventListener('keydown', skip); window.addEventListener('pointerdown', skip);
    return () => { clearTimeout(leave); window.removeEventListener('keydown', skip); window.removeEventListener('pointerdown', skip); };
  }, [reduced]);
  useEffect(() => {
    if (phase !== 'leave') return;
    const t = setTimeout(() => {
      try { localStorage.setItem(SEEN, '1'); } catch { /* the intro still works without storage */ }
      delete document.documentElement.dataset.intro;
      window.dispatchEvent(new Event('vertix-wave'));
      onDone();
    }, reduced ? 200 : 700);
    return () => clearTimeout(t);
  }, [phase, reduced, onDone]);
  const title = firstTime ? 'Willkommen bei Vertix' : greeting(new Date().getHours());
  const subtitle = instance ? `${instance} wartet auf dich.` : firstTime ? 'Lass uns deine erste Welt bauen.' : 'Deine Welten warten.';
  return <div className={`intro ${phase}`} role="dialog" aria-label={`${title}${name ? ', ' + name : ''}`}>
    <div className="intro-glow" aria-hidden="true" />
    <Swarm leaving={phase === 'leave'} />
    <div className={`intro-text ${named ? 'show' : ''}`}>
      <span className="intro-kicker">{title}</span>
      <strong>{name ? `${name}.` : 'Schön, dass du da bist.'}</strong>
      <p>{subtitle}</p>
    </div>
    <span className="intro-skip">Klicken oder Taste drücken zum Überspringen</span>
  </div>;
}
