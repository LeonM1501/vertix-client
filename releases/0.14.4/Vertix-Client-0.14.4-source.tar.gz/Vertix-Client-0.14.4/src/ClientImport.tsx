import { useEffect, useState } from 'react';
import { ArrowRight, LoaderCircle } from 'lucide-react';
import * as api from './api';
import type { Loader } from './api';

type ClientInstance = { client: string; name: string; game_version: string; loader: Loader; loader_version: string | null; dir: string };
const loaderNames: Record<Loader, string> = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };
const errorText = (e: unknown) => typeof e === 'string' ? e : e && typeof e === 'object' && 'message' in e ? String(e.message) : 'Der Umzug hat nicht geklappt.';

export function ClientImport({ onImported, onBusy }: { onImported: (id: string) => Promise<void>; onBusy: (busy: boolean) => void }) {
  const [items, setItems] = useState<ClientInstance[] | null>(api.desktop ? null : []), [busy, setBusy] = useState(''), [error, setError] = useState('');
  useEffect(() => { if (api.desktop) api.call<ClientInstance[]>('scan_client_instances').then(setItems).catch(() => setItems([])); }, []);
  if (items === null) return <p className="client-import-status"><LoaderCircle className="spin" size={15} />Suche nach NoRisk, Dawn & Co. …</p>;
  if (!items.length) return null;
  async function take(item: ClientInstance) {
    setBusy(item.dir); onBusy(true); setError('');
    try { await onImported(await api.call<string>('import_client_instance', { client: item.client, dir: item.dir })); }
    catch (e) { setError(errorText(e)); }
    finally { setBusy(''); onBusy(false); }
  }
  return <section className="client-import">
    <header><h3>Von deinem alten Client</h3><p>Ein Klick kopiert Mods, Welten, Configs und Einstellungen. Der alte Client bleibt unverändert, Logins werden nie übernommen.</p></header>
    <div className="client-import-list">{items.map(item => <button key={item.client + item.dir} disabled={!!busy} onClick={() => void take(item)} aria-label={`${item.name} aus ${item.client} übernehmen`}>
      <span className="client-badge">{item.client}</span>
      <span className="client-import-name"><strong>{item.name}</strong><small>{item.game_version} · {loaderNames[item.loader]}</small></span>
      {busy === item.dir ? <LoaderCircle className="spin" size={16} /> : <ArrowRight size={16} />}
    </button>)}</div>
    {error && <p role="alert" className="inline-error">{error}</p>}
  </section>;
}
