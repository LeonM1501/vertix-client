param([string]$ArtifactDirectory = "$PSScriptRoot\artifacts", [switch]$Fast)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$cargoBin = Join-Path $env:USERPROFILE '.cargo\bin'
if (-not ($env:PATH -split ';' -contains $cargoBin)) {
    $env:PATH = "$cargoBin;$env:PATH"
}
node node_modules/typescript/bin/tsc --noEmit
if ($LASTEXITCODE -ne 0) { throw 'TypeScript validation failed.' }
node node_modules/vite/bin/vite.js build
if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
# Run inside src-tauri so its .cargo/config.toml (static MSVC runtime) applies, as with the Tauri CLI.
Push-Location src-tauri
# -Fast skips whole-program LTO for local testing; published releases always use the full release profile.
$cargoProfile = if ($Fast) { 'local' } else { 'release' }
try { cargo build --profile $cargoProfile --locked --bin vertix-client --features custom-protocol } finally { Pop-Location }
if ($LASTEXITCODE -ne 0) { throw 'Native release build failed; no artifact was copied.' }

# Cargo allows a cache outside the checkout; copy the executable actually built there.
$releaseTarget = if ($env:CARGO_TARGET_DIR) { [IO.Path]::GetFullPath($env:CARGO_TARGET_DIR) } else { Join-Path $PSScriptRoot 'src-tauri\target' }
$releaseExe = Join-Path $releaseTarget "$cargoProfile\vertix-client.exe"
New-Item -ItemType Directory -Path $ArtifactDirectory -Force | Out-Null
$artifactExe = Join-Path $ArtifactDirectory 'Vertix Client.exe'

if (Test-Path $releaseExe) {
    Copy-Item -Force $releaseExe $artifactExe
    # The Windows GNU LLVM executable imports this runtime DLL; MSVC builds link their runtime and need none.
    $rustHost = (& rustc -vV | Select-String '^host:').ToString()
    if ($rustHost -match 'windows-gnu') {
        $rustSysroot = (& rustc --print sysroot).Trim()
        if ($LASTEXITCODE -ne 0) { throw 'Could not locate the Rust runtime.' }
        $unwindDll = Join-Path $rustSysroot 'bin\libunwind.dll'
        if (-not (Test-Path -LiteralPath $unwindDll)) { throw 'Required libunwind.dll is missing from the toolchain.' }
        Copy-Item -LiteralPath $unwindDll -Destination (Join-Path $ArtifactDirectory 'libunwind.dll') -Force
    }
    Write-Host "SUCCESS: Updated artifacts\Vertix Client.exe from $releaseExe"
} else {
    Write-Error "Release executable not found at $releaseExe"
}
