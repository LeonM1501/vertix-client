# Vertix Core 1.7.9 – Performance für dichte Szenen

Core 1.7.9 ergänzt konfigurierbare Optimierungen für Item-Gruppen, Pfeile, TNT, Partikel und Explosionseffekte. Eine adaptive FPS-Schwelle steuert die stärkere Reduktion bei vielen Items oder Pfeilen. Die Kollisionssuche überspringt Vanilla-Items und TNT, die selbst nicht kollidieren.

Die Einstellungen bleiben über den bestehenden ConfigManager gespeichert. Item-Gruppen bleiben einsammelbar und Server-Explosionen werden nicht unterdrückt. Ein bestimmter FPS-Zuwachs wird nicht zugesagt.

Bedienung und Prüfgrenzen: [Client 0.14.3](0.14.3.md). Herkunft und Lizenzen: [THIRD_PARTY.md](../vertix-core-mod/THIRD_PARTY.md).
