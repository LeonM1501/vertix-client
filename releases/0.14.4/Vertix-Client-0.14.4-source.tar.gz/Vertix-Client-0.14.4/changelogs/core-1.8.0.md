# Vertix Core 1.8.0 – Cosmetics und Freecam

Core 1.8.0 lädt die Cosmetics anderer Vertix-Spieler (nur lesend, ohne Anmeldung) und zeichnet Capes, Hüte, Flügel, Auren, Nametag-Stile und das Vertix-Logo in Tabliste und Nametag. Hüte und Flügel stammen aus `assets/vertix/cosmetics.json`, die auch der Launcher für seine Vorschau nutzt.

Die Freecam löst die Kamera vom Spieler, interpoliert die Bewegung pro Frame und blendet die Hand aus. Das neue Modul „Nametag“ soll den eigenen Namen in F5 und in der Freecam zeigen. Die Performance-Mixins sind optional (`require = 0`), damit Konflikte mit Lithium nicht mehr zum Absturz führen. Die In-Game-Menüs nutzen die Schrift Inter (OFL) und neu gezeichnete Formen.

Bedienung und Prüfgrenzen: [Client 0.14.4](0.14.4.md). Herkunft und Lizenzen: [THIRD_PARTY.md](../vertix-core-mod/THIRD_PARTY.md).
