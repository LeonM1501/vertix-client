// Generates the voxel art for wings, hats and aura icons. The mod renders it in game and the launcher draws its
// previews from the same file, so both always match. Run: node scripts/gen-cosmetics.mjs
import { writeFileSync } from 'node:fs';

const OUT = new URL('../vertix-core-mod/src/main/resources/assets/vertix/cosmetics.json', import.meta.url);

/** Bitmap helper: a grid of palette keys, '.' is empty. */
function grid(w, h) {
  const cells = Array.from({ length: h }, () => Array(w).fill('.'));
  return {
    w, h, cells,
    get: (x, y) => (x < 0 || y < 0 || x >= w || y >= h ? '.' : cells[y][x]),
    set: (x, y, c) => { if (x >= 0 && y >= 0 && x < w && y < h) cells[y][x] = c; },
    rows: () => cells.map((r) => r.join('')),
  };
}
const filled = (g, x, y) => g.get(x, y) !== '.';
function line(g, x0, y0, x1, y1, c, thick = 1, onlyFilled = false) {
  const steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) * 2 + 1;
  for (let i = 0; i <= steps; i++) {
    const x = x0 + ((x1 - x0) * i) / steps, y = y0 + ((y1 - y0) * i) / steps;
    for (let dx = 0; dx < thick; dx++) for (let dy = 0; dy < thick; dy++) {
      const px = Math.round(x) + dx, py = Math.round(y) + dy;
      if (!onlyFilled || 'pPqmn'.includes(g.get(px, py))) g.set(px, py, c);
    }
  }
}
function inside(poly, x, y) {
  let hit = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) hit = !hit;
  }
  return hit;
}
/** Adds a one-pixel ring of `c` around everything drawn. */
function outline(g, c, diagonal = true) {
  const add = [];
  for (let y = 0; y < g.h; y++) for (let x = 0; x < g.w; x++) {
    if (filled(g, x, y)) continue;
    const n = [[1, 0], [-1, 0], [0, 1], [0, -1], ...(diagonal ? [[1, 1], [1, -1], [-1, 1], [-1, -1]] : [])];
    if (n.some(([dx, dy]) => filled(g, x + dx, y + dy))) add.push([x, y]);
  }
  for (const [x, y] of add) g.set(x, y, c);
}

// Feathered wing like a classic angel wing: covert band on top, striped feathers, jagged tips.
function featherWing() {
  const W = 18, H = 18, g = grid(W, H);
  for (let x = 0; x < W; x++) {
    const t = x / (W - 1);
    const top = Math.round(7 - 7 * Math.sin(t * Math.PI * 0.55) + Math.max(0, t - 0.82) * 22);
    const bottom = Math.round(11 + 5.2 * Math.sin(t * Math.PI * 0.92)) + ((x >> 1) % 2 === 0 ? 1 : 0);
    for (let y = top; y <= Math.min(H - 1, bottom); y++) {
      const d = y - top;
      let c = d === 0 ? 'H' : d === 1 ? 'w' : d === 2 ? 'A' : d === 3 ? 'w' : x % 2 === 0 ? 'W' : 'f';
      if (d > 3 && y >= bottom - 1) c = y === bottom ? 'S' : 'G';
      if (x < 2 && d > 2 && c !== 'S') c = 'G';
      g.set(x, y, c);
    }
  }
  return { anchor: [0, 8], scale: 1.05, rows: g.rows() };
}

// Bat wing: bones spread from the elbow, dark membrane with arched edges, glowing rim.
function batWing() {
  const W = 25, H = 21, g = grid(W, H), o = 1;
  const poly = [[0, 6], [7, 1], [22, 2], [19.5, 7], [21, 13], [17, 11.5], [16, 17], [12, 13.5], [10, 18], [6, 13], [2, 13]].map(([x, y]) => [x + o, y + o]);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (inside(poly, x + 0.5, y + 0.5)) g.set(x, y, 'K');
  const bone = (x0, y0, x1, y1, t = 1) => line(g, x0 + o, y0 + o, x1 + o, y1 + o, 'r', t);
  bone(0, 5, 7, 1, 2); bone(7, 1, 22, 2); bone(7, 2, 21, 13); bone(7, 2, 16, 17); bone(7, 2, 10, 18);
  line(g, 1 + o, 4 + o, 7 + o, 0 + o, 'R'); line(g, 8 + o, 1 + o, 21 + o, 1 + o, 'R');
  // Claw at the wrist and spikes past each finger tip.
  g.set(7 + o, 0, 'c'); g.set(22 + o, 2 + o, 'c'); g.set(21 + o, 14 + o, 'c'); g.set(16 + o, 18 + o, 'c'); g.set(10 + o, 19 + o, 'c');
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++)
    if (g.get(x, y) === 'K' && [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => 'rR'.includes(g.get(x + dx, y + dy)))) g.set(x, y, 'k');
  outline(g, 'O');
  return { anchor: [1, 7], scale: 0.85, rows: g.rows() };
}

// Butterfly: big upper lobe, smaller lower lobe, dark rim and glowing spots.
function butterflyWing() {
  const W = 17, H = 19, g = grid(W, H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const upper = ((x - 8.5) / 8) ** 2 + ((y - 5.5) / 5.3) ** 2, lower = ((x - 6) / 5.6) ** 2 + ((y - 13.5) / 4.6) ** 2;
    if (upper <= 1) g.set(x, y, upper < 0.25 ? 'P' : upper < 0.6 ? 'p' : 'q');
    else if (lower <= 1 && y > 8) g.set(x, y, lower < 0.4 ? 'm' : 'n');
  }
  const rim = [];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++)
    if (filled(g, x, y) && [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => !filled(g, x + dx, y + dy))) rim.push([x, y]);
  for (const [x, y] of rim) g.set(x, y, 'D');
  for (const [x, y] of [[12, 4], [13, 4], [12, 5], [13, 5], [10, 2], [6, 14], [7, 14], [6, 15]]) g.set(x, y, 'L');
  line(g, 0, 9, 13, 3, 'v', 1, true); line(g, 0, 9, 8, 15, 'v', 1, true);
  return { anchor: [0, 9], scale: 0.9, rows: g.rows() };
}

const feather = featherWing(), bat = batWing(), butterfly = butterflyWing();
// Palette entries: [rgb, glows]. Glowing pixels ignore world light.
const wings = {
  angel: { ...feather, palette: { H: ['ffffff'], w: ['f3f6fa'], A: ['c7d0dc'], W: ['ffffff'], f: ['e6ebf2'], G: ['d3dae4'], S: ['bcc6d3'] } },
  frost: { ...feather, palette: { H: ['ffffff'], w: ['e3f5ff'], A: ['8fd0f2'], W: ['f2fbff'], f: ['cfeafb'], G: ['9fd4f2', 1], S: ['6fbfee', 1] } },
  phoenix: { ...feather, palette: { H: ['fff6d5'], w: ['ffe08a'], A: ['f59e0b'], W: ['ffd166'], f: ['ffb547'], G: ['ff7a29', 1], S: ['ff3d1f', 1] } },
  dragon: { ...bat, palette: { K: ['1a090c'], k: ['2c0e13'], r: ['8c1c1c'], R: ['b92a2a'], c: ['e5e7eb'], O: ['ff2a2a', 1] } },
  void: { ...bat, palette: { K: ['0f0a1c'], k: ['1d1233'], r: ['5b21b6'], R: ['7c3aed'], c: ['e9d5ff'], O: ['b26bff', 1] } },
  butterfly: { ...butterfly, palette: { P: ['6d28d9'], p: ['a855f7'], q: ['f0abfc'], m: ['db2777'], n: ['f9a8d4'], D: ['2e1065'], L: ['fff7ed', 1], v: ['3b0764'] } },
};

// Hats: boxes in head space (model pixels, y down, top of the head at y = -8, face towards -z).
// Each box: [x0, y0, z0, x1, y1, z1, topColour, bottomColour, glow].
const hats = {};
const B = (list, x0, y0, z0, x1, y1, z1, top, bottom = top, glow = 0) => list.push([x0, y0, z0, x1, y1, z1, top, bottom, glow].map((v) => (typeof v === 'number' ? Math.round(v * 100) / 100 : v)));
{
  const b = [], gold = ['ffe9a3', 'c4881c'];
  B(b, -3.9, -9.4, -3.9, 3.9, -8.2, 3.9, '7e22ce', '581c87');
  for (const [x0, z0, x1, z1] of [[-4.5, -4.5, 4.5, -3.9], [-4.5, 3.9, 4.5, 4.5], [-4.5, -3.9, -3.9, 3.9], [3.9, -3.9, 4.5, 3.9]]) {
    B(b, x0, -10, z0, x1, -8, z1, ...gold); B(b, x0 - 0.05, -8.4, z0 - 0.05, x1 + 0.05, -8, z1 + 0.05, 'fff3c4', 'e0a93a');
  }
  const spike = (cx, cz, ax) => [[1.6, 1.2], [1, 1], [0.5, 0.8]].reduce((y, [w, h]) => {
    const [x0, x1, z0, z1] = ax ? [cx - w / 2, cx + w / 2, cz - 0.3, cz + 0.3] : [cx - 0.3, cx + 0.3, cz - w / 2, cz + w / 2];
    B(b, x0, y - h, z0, x1, y, z1, ...gold); return y - h;
  }, -10);
  for (const p of [-3.2, 0, 3.2]) { spike(p, -4.2, 1); spike(p, 4.2, 1); spike(-4.2, p, 0); spike(4.2, p, 0); }
  for (const [x, z, c] of [[0, -4.6, 'ff2d55'], [-2.4, -4.6, '3b82f6'], [2.4, -4.6, '22c55e'], [0, 4.6, 'a855f7'], [-4.6, 0, 'ff2d55'], [4.6, 0, '3b82f6']])
    B(b, x - (z ? 0.55 : 0.15), -9.5, z - (z ? 0.15 : 0.55), x + (z ? 0.55 : 0.15), -8.5, z + (z ? 0.15 : 0.55), c, c, 1);
  hats.crown = { boxes: b };
}
{
  const b = [];
  for (let i = 0; i < 40; i++) { const a = (i * Math.PI * 2) / 40, x = Math.cos(a) * 4.4, z = Math.sin(a) * 4.4; B(b, x - 0.45, -12.6, z - 0.45, x + 0.45, -12, z + 0.45, 'fffbe0', 'ffcc33', 1); }
  hats.halo = { boxes: b, bob: 1 };
}
{
  const b = [];
  B(b, -5.6, -8.7, -5.6, 5.6, -8, 5.6, '2a2a33', '0e0e12'); B(b, -5.7, -8.9, -5.7, 5.7, -8.7, -5.3, '3a3a46'); B(b, -5.7, -8.9, 5.3, 5.7, -8.7, 5.7, '3a3a46');
  B(b, -3.7, -15.6, -3.7, 3.7, -8.7, 3.7, '34343f', '111116'); B(b, -3.75, -15.7, -3.75, 3.75, -15.5, 3.75, '4a4a58');
  B(b, -3.8, -10.4, -3.8, 3.8, -8.7, 3.8, 'b794f6', '6d28d9');
  B(b, -1, -10.2, -3.95, 1, -9, -3.8, 'f5e8ff', 'd8b4fe', 1);
  hats.tophat = { boxes: b };
}
{
  const b = [];
  for (const s of [-1, 1]) for (let i = 0; i < 5; i++) {
    const w = 3.2 - i * 0.62, cx = s * (2.6 + i * 0.16), y = -8 - i * 0.75;
    B(b, cx - w / 2, y - 0.75, -1.4, cx + w / 2, y, 0, '4a4a52', '232327');
    if (i < 3) B(b, cx - w / 2 + 0.45, y - 0.75, -1.5, cx + w / 2 - 0.45, y, -1.4, 'fbcfe8', 'f472b6');
  }
  hats.cat_ears = { boxes: b };
}
{
  const b = [];
  for (const s of [-1, 1]) for (let i = 0; i < 9; i++) {
    const t = i / 8, x = s * (2.5 + 2.7 * t * t), y = -8.2 - 4.4 * t + 1.1 * t * t * t, r = 0.95 * (1 - t * 0.7);
    const mix = (a, c) => [0, 8, 16].reduce((n, sh) => n | Math.round(((a >> sh) & 255) + ((((c >> sh) & 255) - ((a >> sh) & 255)) * t)) << sh, 0).toString(16).padStart(6, '0');
    B(b, x - r, y - r, -1.6 - r, x + r, y + r, -1.6 + r, mix(0xff5a5a, 0x3b0707), mix(0xd11f1f, 0x1f0303));
  }
  hats.devil_horns = { boxes: b };
}
{
  const b = [];
  B(b, -5.8, -8.7, -5.8, 5.8, -8, 5.8, '5b21b6', '2e1065'); B(b, -4.3, -9.9, -4.3, 4.3, -8.7, 4.3, 'fde68a', 'd97706');
  const widths = [8.2, 7.2, 6.2, 5.2, 4.3, 3.4, 2.6, 1.8, 1.1];
  widths.forEach((w, i) => {
    const h = w / 2, lean = 0.06 * i * i, top = -9.9 - (i + 1) * 1.25;
    B(b, -h + lean * 0.4, top, -h + lean, h + lean * 0.4, top + 1.25, h + lean, i % 2 ? '8b5cf6' : '7c3aed', i % 2 ? '6d28d9' : '5b21b6');
    if (i === 2 || i === 5) B(b, -0.35 + lean * 0.4, top + 0.3, -h + lean - 0.12, 0.35 + lean * 0.4, top + 0.95, -h + lean, 'fff7b0', 'fde047', 1);
  });
  B(b, 0.6, -21.6, 2.9, 1.6, -20.6, 3.9, 'fff7b0', 'fde047', 1);
  hats.wizard = { boxes: b };
}
{
  const b = [];
  for (let i = 0; i <= 10; i++) { const t = i / 10, x = -4.7 + 9.4 * t, y = -8.3 - Math.sin(t * Math.PI) * 1.3; B(b, x - 0.6, y - 0.7, -0.75, x + 0.6, y + 0.1, 0.75, '3f3f46', '18181b'); }
  for (const s of [-1, 1]) {
    B(b, s * 4.6 - 0.35, -8, -0.55, s * 4.6 + 0.35, -5.2, 0.55, '3f3f46', '27272a');
    B(b, s * 4.95 - 0.8, -5.4, -1.6, s * 4.95 + 0.8, -1.6, 1.6, '27272a', '0a0a0c');
    B(b, s * 4.95 - 0.8, -5.0, -1.9, s * 4.95 + 0.8, -2.0, 1.9, '27272a', '0a0a0c');
    B(b, s * 5.8 - 0.06, -4.7, -1.2, s * 5.8 + 0.06, -2.3, 1.2, 'c084fc', '7c3aed', 1);
  }
  hats.headphones = { boxes: b };
}
{
  const b = [];
  for (const s of [-1, 1]) for (let i = 0; i < 8; i++) {
    const w = i > 5 ? 1.2 - (i - 6) * 0.35 : 1.7, x = s * (1.8 + i * 0.12), y = -8 - i * 0.85, z = i > 4 ? -(i - 4) * 0.35 : 0;
    B(b, x - w / 2, y - 0.85, z - 0.45, x + w / 2, y, z + 0.35, 'ffffff', 'ececec');
    if (i > 0 && i < 6) B(b, x - w / 2 + 0.4, y - 0.85, z - 0.55, x + w / 2 - 0.4, y, z - 0.45, 'fbcfe8', 'f9a8d4');
  }
  hats.bunny_ears = { boxes: b, sway: 1 };
}

// Launcher-only pixel icons for the particle auras (the game uses vanilla particles).
const auras = {
  hearts: { rows: ['.RR.RR.', 'RHRRRRR', 'RRRRRRR', '.RRRRR.', '..RRR..', '...R...'], palette: { R: ['ef4444'], H: ['fecaca'] } },
  flames: { rows: ['...Y...', '..YO...', '..YOO..', '.YOORO.', '.OORRO.', 'ORRRRRO', '.ORRRO.'], palette: { Y: ['fde047'], O: ['f97316'], R: ['dc2626'] } },
  sparkles: { rows: ['...W...', '...W...', '..WYW..', 'WWYYYWW', '..WYW..', '...W...', '...W...'], palette: { W: ['fef9c3'], Y: ['ffffff'] } },
  notes: { rows: ['..GGGG', '..G..G', '..G..G', '..G..G', 'GGG.GGG', 'GGG.GGG'], palette: { G: ['22c55e'] } },
  snow: { rows: ['B..B..B', '.B.B.B.', '..BBB..', 'BBBWBBB', '..BBB..', '.B.B.B.', 'B..B..B'], palette: { B: ['7dd3fc'], W: ['ffffff'] } },
};

writeFileSync(OUT, JSON.stringify({ wings, hats, auras }));
console.log('wrote', OUT.pathname, Object.keys(wings), Object.keys(hats));
