//! Vertix cosmetics login. Proves the active Minecraft account with its Mojang-signed player certificate
//! (the key Minecraft uses for chat signing): the challenge is signed locally, the private key and the
//! Minecraft token never leave this machine except to Mojang itself.
use crate::config::HTTP_CLIENT;
use crate::error::{AppError, CommandError};
use base64::engine::general_purpose::STANDARD as B64;
use base64::Engine;
use serde::Serialize;
use serde_json::{json, Value};

pub const API: &str = "https://vertix-api.vertixclient.workers.dev";

#[derive(Serialize)]
pub struct CosmeticsSession { token: String, uuid: String, name: String, expires: i64 }

fn fail(message: impl Into<String>) -> CommandError { AppError::Other(message.into()).into() }
fn offline(e: reqwest::Error) -> CommandError { log::warn!("[Cosmetics] Vertix API unreachable: {e}"); fail("Der Vertix-Server ist gerade nicht erreichbar.") }

async fn api(path: &str, body: Value) -> Result<Value, CommandError> {
    let response = HTTP_CLIENT.post(format!("{API}{path}")).json(&body).send().await.map_err(offline)?;
    let ok = response.status().is_success();
    let value: Value = response.json().await.map_err(offline)?;
    if ok { Ok(value) } else { Err(fail(value["error"].as_str().unwrap_or("Anmeldung bei Vertix fehlgeschlagen.").to_string())) }
}

fn pem_der(pem: &str) -> Option<Vec<u8>> {
    let body: String = pem.lines().filter(|line| !line.starts_with("-----")).collect();
    B64.decode(body.trim()).ok()
}

/// Signs `message` with the certificate's RSA key (PKCS#8, or PKCS#1 despite the PEM label).
fn sign(private_der: &[u8], message: &[u8]) -> Option<Vec<u8>> {
    let key = ring::signature::RsaKeyPair::from_pkcs8(private_der).or_else(|_| ring::signature::RsaKeyPair::from_der(private_der)).ok()?;
    let mut signature = vec![0; key.public().modulus_len()];
    key.sign(&ring::signature::RSA_PKCS1_SHA256, &ring::rand::SystemRandom::new(), message, &mut signature).ok()?;
    Some(signature)
}

#[tauri::command]
pub async fn cosmetics_login() -> Result<CosmeticsSession, CommandError> {
    let account = crate::vertix_auth::credentials().await.map_err(|e| { log::warn!("[Cosmetics] Reading the Minecraft account failed: {e}"); e })?
        .ok_or_else(|| fail("Melde dich zuerst oben rechts mit deinem Minecraft-Konto an."))?;
    let uuid = account.id.simple().to_string();

    let response = HTTP_CLIENT.post("https://api.minecraftservices.com/player/certificates").bearer_auth(&account.access_token).body("")
        .send().await.map_err(|_| fail("Mojang ist gerade nicht erreichbar."))?;
    if !response.status().is_success() {
        log::warn!("[Cosmetics] Player certificate request answered HTTP {}", response.status());
        return Err(fail("Dein Minecraft-Zertifikat konnte nicht geladen werden. Melde dich im Launcher neu an."));
    }
    let certificate: Value = response.json().await.map_err(|_| fail("Ungültige Antwort von Mojang."))?;
    let field = |path: &str| certificate.pointer(path).and_then(Value::as_str).ok_or_else(|| { log::warn!("[Cosmetics] Certificate lacks {path}"); fail("Ungültige Antwort von Mojang.") });
    let public_der = pem_der(field("/keyPair/publicKey")?).ok_or_else(|| fail("Ungültiges Minecraft-Zertifikat."))?;
    let private_der = pem_der(field("/keyPair/privateKey")?).ok_or_else(|| fail("Ungültiges Minecraft-Zertifikat."))?;
    let expires_at = chrono::DateTime::parse_from_rfc3339(field("/expiresAt")?).map_err(|_| fail("Ungültiges Minecraft-Zertifikat."))?.timestamp_millis();

    let challenge = api("/v1/auth/challenge", json!({ "uuid": uuid })).await.inspect_err(|_| log::warn!("[Cosmetics] Challenge request failed"))?;
    let server_id = challenge["serverId"].as_str().ok_or_else(|| fail("Ungültige Antwort vom Vertix-Server."))?;
    // Same text the API checks: binds the signature to this challenge and this account.
    let signature = sign(&private_der, format!("vertix-login:{server_id}:{uuid}").as_bytes()).ok_or_else(|| { log::warn!("[Cosmetics] Signing with the certificate key failed"); fail("Anmeldung konnte nicht signiert werden.") })?;
    let session = api("/v1/auth/verify", json!({
        "uuid": uuid, "name": account.username, "serverId": server_id, "publicKey": B64.encode(&public_der),
        "expiresAt": expires_at, "keySignature": field("/publicKeySignatureV2")?, "signature": B64.encode(signature),
    })).await.inspect_err(|e| log::warn!("[Cosmetics] Verify failed: {}", e.message))?;
    log::info!("[Cosmetics] Signed in as {}", account.username);
    let text = |key: &str| session[key].as_str().map(String::from).ok_or_else(|| fail("Ungültige Antwort vom Vertix-Server."));
    Ok(CosmeticsSession { token: text("token")?, uuid: text("uuid")?, name: text("name")?, expires: session["expires"].as_i64().unwrap_or(0) })
}
