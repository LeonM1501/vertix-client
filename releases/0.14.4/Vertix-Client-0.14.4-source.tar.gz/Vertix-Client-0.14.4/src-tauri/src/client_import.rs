// Moves instances from other launchers (NoRisk, Dawn, Modrinth App, Prism, CurseForge) into Vertix.
use crate::error::{AppError, CommandError};
use crate::state::profile_state::{ModLoader, Profile, ProfileState};
use crate::state::State;
use serde::Serialize;
use serde_json::{json, Value};
use sqlx::sqlite::{SqliteConnectOptions, SqlitePool, SqlitePoolOptions};
use sqlx::Row;
use std::path::{Path, PathBuf};
use uuid::Uuid;

#[derive(Serialize, Clone)]
pub struct ClientInstance { pub client: &'static str, pub name: String, pub game_version: String, pub loader: ModLoader, pub loader_version: Option<String>, pub dir: String, #[serde(skip)] profile: Option<Profile> }

// Directories that belong to the old launcher, not to the player.
const SKIP_DIRS: [&str; 16] = ["logs", "crash-reports", "cache", ".cache", "downloads", ".fabric", ".mixin.out", "natives", "versions", "libraries", "assets", "debug", "tmp", "temp", "NoRiskClientLauncher", ".dawn"];
// Top-level files are copied only from this list, so launcher accounts and tokens never move.
const KEEP_FILES: [&str; 5] = ["options.txt", "optionsof.txt", "optionsshaders.txt", "servers.dat", "optionsNRC.json"];

fn fail(message: impl Into<String>) -> CommandError { AppError::Other(message.into()).into() }
fn appdata() -> Option<PathBuf> { dirs::config_dir() }
fn loader(raw: &str) -> Option<ModLoader> { serde_json::from_value(json!(raw.to_ascii_lowercase().replace(['-', '_'], ""))).ok() }
fn read_json(path: &Path) -> Option<Value> { serde_json::from_str(&std::fs::read_to_string(path).ok()?).ok() }
fn subdirs(path: &Path) -> Vec<PathBuf> { std::fs::read_dir(path).map(|it| it.flatten().map(|e| e.path()).filter(|p| p.is_dir()).collect()).unwrap_or_default() }
fn instance(client: &'static str, name: String, game_version: String, loader: ModLoader, loader_version: Option<String>, dir: PathBuf) -> ClientInstance {
    ClientInstance { client, name, game_version, loader, loader_version, dir: dir.to_string_lossy().into_owned(), profile: None }
}

async fn read_only(path: &Path) -> Option<SqlitePool> {
    if !path.is_file() { return None; }
    SqlitePoolOptions::new().max_connections(1).connect_with(SqliteConnectOptions::new().filename(path).read_only(true)).await.ok()
}

async fn norisk() -> Vec<ClientInstance> {
    let Some(root) = appdata().map(|d| d.join("norisk").join("NoRiskClientV3")) else { return vec![] };
    let Some(pool) = read_only(&root.join("meta").join("app.db")).await else { return vec![] };
    // NoRisk shares Vertix's profile schema; a panic on a future schema change only drops this source.
    let store = crate::state::profile_store::ProfileStore::new(crate::state::db::handle_with_pool(pool));
    let Ok(Ok(profiles)) = tokio::spawn(async move { store.load_all().await }).await else { return vec![] };
    profiles.into_values().filter(|p| !p.is_standard_version).filter_map(|p| {
        let dir = root.join("data").join("profiles").join(&p.path);
        dir.is_dir().then(|| ClientInstance { profile: Some(p.clone()), ..instance("NoRisk", p.name, p.game_version, p.loader, p.loader_version, dir) })
    }).collect()
}

fn dawn() -> Vec<ClientInstance> {
    let Some(root) = appdata().map(|d| d.join(".dawn").join("profiles")) else { return vec![] };
    subdirs(&root).into_iter().filter_map(|dir| {
        let p = read_json(&dir.join("profile.json"))?;let p = &p["profile"];
        let l = loader(p["loader"]["kind"].as_str().unwrap_or("vanilla"))?;
        Some(instance("Dawn", p["name"].as_str()?.into(), p["minecraftVersion"].as_str()?.into(), l, p["loader"]["version"].as_str().map(Into::into), dir.join(".minecraft")))
    }).filter(|i| Path::new(&i.dir).is_dir()).collect()
}

async fn modrinth() -> Vec<ClientInstance> {
    let Some(root) = appdata().map(|d| d.join("ModrinthApp")) else { return vec![] };
    let Some(pool) = read_only(&root.join("app.db")).await else { return vec![] };
    let rows = sqlx::query("SELECT path, name, game_version, mod_loader, mod_loader_version FROM profiles").fetch_all(&pool).await.unwrap_or_default();
    rows.iter().filter_map(|r| {
        let l = loader(&r.try_get::<String, _>("mod_loader").ok()?)?;
        let dir = root.join("profiles").join(r.try_get::<String, _>("path").ok()?);
        dir.is_dir().then(|| instance("Modrinth App", r.try_get("name").unwrap_or_default(), r.try_get("game_version").unwrap_or_default(), l, r.try_get::<Option<String>, _>("mod_loader_version").ok().flatten(), dir))
    }).collect()
}

fn prism() -> Vec<ClientInstance> {
    let Some(root) = appdata().map(|d| d.join("PrismLauncher").join("instances")) else { return vec![] };
    subdirs(&root).into_iter().filter_map(|dir| {
        let pack = read_json(&dir.join("mmc-pack.json"))?;
        let components = pack["components"].as_array()?;
        let version = |uid: &str| components.iter().find(|c| c["uid"] == uid).and_then(|c| c["version"].as_str()).map(String::from);
        let game = version("net.minecraft")?;
        let (l, lv) = [("net.fabricmc.fabric-loader", ModLoader::Fabric), ("org.quiltmc.quilt-loader", ModLoader::Quilt), ("net.neoforged", ModLoader::NeoForge), ("net.minecraftforge", ModLoader::Forge)]
            .into_iter().find_map(|(uid, l)| version(uid).map(|v| (l, Some(v)))).unwrap_or((ModLoader::Vanilla, None));
        let name = std::fs::read_to_string(dir.join("instance.cfg")).ok().and_then(|c| c.lines().find_map(|l| l.strip_prefix("name=").map(String::from))).unwrap_or_else(|| dir.file_name().unwrap_or_default().to_string_lossy().into());
        let game_dir = [".minecraft", "minecraft"].into_iter().map(|d| dir.join(d)).find(|d| d.is_dir())?;
        Some(instance("Prism", name, game, l, lv, game_dir))
    }).collect()
}

fn curseforge() -> Vec<ClientInstance> {
    let Some(root) = dirs::home_dir().map(|d| d.join("curseforge").join("minecraft").join("Instances")) else { return vec![] };
    subdirs(&root).into_iter().filter_map(|dir| {
        let m = read_json(&dir.join("minecraftinstance.json"))?;
        let (l, lv) = match m["baseModLoader"]["name"].as_str() { Some(raw) => { let (kind, v) = raw.split_once('-')?; (loader(kind)?, Some(v.to_string())) } None => (ModLoader::Vanilla, None) };
        Some(instance("CurseForge", m["name"].as_str()?.into(), m["gameVersion"].as_str()?.into(), l, lv, dir))
    }).collect()
}

async fn scan() -> Vec<ClientInstance> {
    let mut all = norisk().await;
    all.extend(dawn());all.extend(modrinth().await);all.extend(prism());all.extend(curseforge());
    all
}

fn copy_tree(from: &Path, to: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(to)?;
    for entry in std::fs::read_dir(from)?.flatten() {
        let kind = entry.file_type()?;
        if kind.is_symlink() { continue; }
        if kind.is_dir() { copy_tree(&entry.path(), &to.join(entry.file_name()))?; } else { std::fs::copy(entry.path(), to.join(entry.file_name()))?; }
    }
    Ok(())
}

pub fn copy_player_files(from: &Path, to: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(to)?;
    for entry in std::fs::read_dir(from)?.flatten() {
        let name = entry.file_name().to_string_lossy().into_owned();let kind = entry.file_type()?;
        if kind.is_dir() && !SKIP_DIRS.contains(&name.as_str()) { copy_tree(&entry.path(), &to.join(&name))?; }
        else if kind.is_file() && KEEP_FILES.contains(&name.as_str()) { std::fs::copy(entry.path(), to.join(&name))?; }
    }
    Ok(())
}

#[tauri::command]
pub async fn scan_client_instances() -> Result<Vec<ClientInstance>, CommandError> { Ok(scan().await) }

#[tauri::command]
pub async fn import_client_instance(client: String, dir: String) -> Result<String, CommandError> {
    // Only folders found by the scan can be imported, never an arbitrary path from the UI.
    let found = scan().await.into_iter().find(|i| i.client == client && i.dir == dir).ok_or_else(|| fail("Diese Instanz wurde nicht mehr gefunden. Lade die Liste neu."))?;
    let _guard = crate::instance_content::CONTENT_LOCK.lock().await;
    let state = State::get().await?;
    let id = Uuid::new_v4();
    let segment = format!("{}-{}", sanitize_filename::sanitize(&found.name).chars().take(70).collect::<String>(), id.simple());
    let mut profile = match found.profile.clone() {
        Some(mut p) => { p.sync_pack_ids.clear();p.disabled_norisk_mods_detailed.clear();p.selected_norisk_pack_id = None;p.source_standard_profile_id = None;p.preferred_account_id = None;p.last_played = None;p.playtime_seconds = 0;p.state = ProfileState::NotInstalled;p.use_shared_minecraft_folder = false;p.group = None;p }
        None => serde_json::from_value(json!({"id": id, "name": found.name, "path": segment, "game_version": found.game_version, "loader": found.loader, "loader_version": found.loader_version, "created": chrono::Utc::now(), "use_shared_minecraft_folder": false})).map_err(AppError::Json)?,
    };
    profile.id = id;profile.path = segment;profile.created = chrono::Utc::now();
    profile.extra.insert("vertix_import".into(), json!({"format": "client", "client": found.client, "original_name": found.name}));
    let base = crate::state::profile_state::default_profile_path();tokio::fs::create_dir_all(&base).await.map_err(AppError::Io)?;
    let stage = tempfile::Builder::new().prefix(".vertix-client-").tempdir_in(&base).map_err(AppError::Io)?;
    let (from, to) = (PathBuf::from(&found.dir), stage.path().to_path_buf());
    tokio::task::spawn_blocking(move || copy_player_files(&from, &to)).await.map_err(|e| fail(e.to_string()))?.map_err(|e| fail(format!("Dateien konnten nicht kopiert werden: {e}")))?;
    let destination = state.profile_manager.calculate_instance_path_for_profile(&profile)?;
    if destination.exists() { return Err(fail("Der neue Instanzordner existiert bereits.")); }
    tokio::fs::rename(stage.path(), &destination).await.map_err(AppError::Io)?;
    state.profile_manager.create_profile(profile).await?;
    Ok(id.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn player_files_move_but_launcher_secrets_stay() {
        let t = tempfile::tempdir().unwrap();let (a, b) = (t.path().join("a"), t.path().join("b"));
        for d in ["mods", "saves/world", "kubejs", "logs", "versions"] { std::fs::create_dir_all(a.join(d)).unwrap(); }
        for f in ["mods/x.jar", "saves/world/level.dat", "kubejs/s.js", "logs/latest.log", "options.txt", "launcher_msa_credentials_microsoft_store.bin", "accounts.json"] { std::fs::write(a.join(f), "x").unwrap(); }
        copy_player_files(&a, &b).unwrap();
        for f in ["mods/x.jar", "saves/world/level.dat", "kubejs/s.js", "options.txt"] { assert!(b.join(f).exists(), "{f} missing"); }
        for f in ["logs", "versions", "launcher_msa_credentials_microsoft_store.bin", "accounts.json"] { assert!(!b.join(f).exists(), "{f} copied"); }
    }
    #[test]
    fn loader_names_from_other_launchers() {
        assert_eq!(loader("Fabric"), Some(ModLoader::Fabric));assert_eq!(loader("neo-forge"), Some(ModLoader::NeoForge));assert_eq!(loader("neoforge"), Some(ModLoader::NeoForge));assert_eq!(loader("liteloader"), None);
    }
}
