// Upload checks for cape images. Only real PNGs in the 2:1 cape layout are stored.
import { UserError } from './catalog.js';

export const MAX_CAPE_BYTES = 256 * 1024;
const SIGNATURE = [137, 80, 78, 71, 13, 10, 26, 10];

/** Returns { width, height } or throws a user-facing message. */
export function inspectCape(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length < 33) throw new UserError('Das ist keine PNG-Datei.');
  if (bytes.length > MAX_CAPE_BYTES) throw new UserError('Das Bild ist größer als 256 KB.');
  if (!SIGNATURE.every((b, i) => bytes[i] === b)) throw new UserError('Das ist keine PNG-Datei.');
  // The first chunk of every valid PNG is IHDR: length 13, then width and height as big-endian uint32.
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (view.getUint32(8) !== 13 || String.fromCharCode(...bytes.slice(12, 16)) !== 'IHDR') throw new UserError('Die PNG-Datei ist beschädigt.');
  const width = view.getUint32(16), height = view.getUint32(20);
  if (width !== height * 2) throw new UserError('Capes brauchen das Seitenverhältnis 2:1, zum Beispiel 64×32.');
  if (width < 64 || width > 1024 || width % 64 !== 0) throw new UserError('Erlaubte Breiten: 64, 128, 256, 512 oder 1024 Pixel.');
  return { width, height };
}
