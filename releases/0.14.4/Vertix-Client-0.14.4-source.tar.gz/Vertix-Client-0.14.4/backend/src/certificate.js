// Account proof without calling Mojang: the launcher sends its Mojang-signed player certificate
// (the one Minecraft uses for chat signing) and signs our challenge with the matching private key.
import { UserError } from './catalog.js';
import { PLAYER_CERTIFICATE_KEYS } from './mojangKeys.js';

const fromBase64 = (text) => Uint8Array.from(atob(text), (c) => c.charCodeAt(0));
const importKey = (der, hash) => crypto.subtle.importKey('spki', der, { name: 'RSASSA-PKCS1-v1_5', hash }, false, ['verify']);
const verify = (key, signature, data) => crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, signature, data);

/** The exact text the launcher signs; binding the uuid stops a signature being replayed for another account. */
export const loginMessage = (serverId, uuid) => new TextEncoder().encode(`vertix-login:${serverId}:${uuid}`);

/** Mojang's V2 certificate payload: uuid (16 bytes), expiry in epoch millis (8 bytes), then the public key DER. */
export function certificatePayload(uuid, expiresAt, publicKeyDer) {
  const out = new Uint8Array(24 + publicKeyDer.length), view = new DataView(out.buffer);
  for (let i = 0; i < 16; i++) out[i] = parseInt(uuid.slice(i * 2, i * 2 + 2), 16);
  view.setBigInt64(16, BigInt(expiresAt));
  out.set(publicKeyDer, 24);
  return out;
}

/** Throws unless the certificate is Mojang-signed for this uuid, unexpired, and signed the challenge. */
export async function verifyLogin({ uuid, serverId, publicKey, expiresAt, keySignature, signature }, mojangKeys = PLAYER_CERTIFICATE_KEYS) {
  if (!Number.isSafeInteger(expiresAt) || expiresAt <= Date.now()) throw new UserError('Dein Minecraft-Zertifikat ist abgelaufen. Starte den Launcher neu.');
  let der, mojangSignature, playerSignature;
  try { der = fromBase64(publicKey); mojangSignature = fromBase64(keySignature); playerSignature = fromBase64(signature); }
  catch { throw new UserError('Ungültiges Zertifikat.'); }
  const payload = certificatePayload(uuid, expiresAt, der);
  let trusted = false;
  for (const key of mojangKeys) {
    if (await verify(await importKey(fromBase64(key), 'SHA-1'), mojangSignature, payload)) { trusted = true; break; }
  }
  if (!trusted) throw new UserError('Mojang hat dieses Zertifikat nicht ausgestellt.');
  let playerKey;
  try { playerKey = await importKey(der, 'SHA-256'); } catch { throw new UserError('Ungültiges Zertifikat.'); }
  if (!(await verify(playerKey, playerSignature, loginMessage(serverId, uuid)))) throw new UserError('Die Anmeldung wurde nicht von deinem Konto signiert.');
}
