// Every cosmetic the backend accepts. Launcher and mod read the same list from GET /v1/catalog.
// Built-in capes are pattern recipes; the mod and launcher paint them locally, so no images are stored.
/** Errors whose message is safe to show to players. */
export class UserError extends Error {}

export const CATALOG = {
  capes: [
    { id: 'vertix', name: 'Vertix', pattern: 'gradient', colors: ['#8b5cf6', '#e040fb'] },
    { id: 'midnight', name: 'Midnight', pattern: 'gradient', colors: ['#0f172a', '#312e81'] },
    { id: 'sunset', name: 'Sunset', pattern: 'gradient', colors: ['#f97316', '#db2777'] },
    { id: 'ocean', name: 'Ocean', pattern: 'waves', colors: ['#0ea5e9', '#1e3a8a'] },
    { id: 'toxic', name: 'Toxic', pattern: 'stripes', colors: ['#84cc16', '#14532d'] },
    { id: 'galaxy', name: 'Galaxy', pattern: 'stars', colors: ['#1e1b4b', '#7c3aed'] },
    { id: 'inferno', name: 'Inferno', pattern: 'flames', colors: ['#fde047', '#dc2626'] },
    { id: 'frost', name: 'Frost', pattern: 'stars', colors: ['#e0f2fe', '#38bdf8'] },
    { id: 'sakura', name: 'Sakura', pattern: 'waves', colors: ['#fbcfe8', '#ec4899'] },
    { id: 'gold', name: 'Gold', pattern: 'stripes', colors: ['#fde68a', '#b45309'] },
    { id: 'aurora', name: 'Aurora', pattern: 'aurora', colors: ['#22d3ee', '#a855f7'] },
    { id: 'carbon', name: 'Carbon', pattern: 'checker', colors: ['#18181b', '#3f3f46'] },
  ],
  hats: [
    { id: 'crown', name: 'Krone' }, { id: 'halo', name: 'Heiligenschein' }, { id: 'tophat', name: 'Zylinder' },
    { id: 'cat_ears', name: 'Katzenohren' }, { id: 'devil_horns', name: 'Teufelshörner' }, { id: 'wizard', name: 'Zauberhut' },
    { id: 'headphones', name: 'Kopfhörer' }, { id: 'bunny_ears', name: 'Hasenohren' },
  ],
  wings: [
    { id: 'angel', name: 'Engel' }, { id: 'frost', name: 'Frostschwingen' }, { id: 'phoenix', name: 'Phönix' },
    { id: 'dragon', name: 'Drache' }, { id: 'void', name: 'Void' }, { id: 'butterfly', name: 'Schmetterling' },
  ],
  auras: [
    { id: 'hearts', name: 'Herzen' }, { id: 'flames', name: 'Flammen' }, { id: 'sparkles', name: 'Funken' },
    { id: 'notes', name: 'Noten' }, { id: 'snow', name: 'Schnee' },
  ],
  nametags: [
    { id: 'default', name: 'Standard', colors: ['#ffffff'] }, { id: 'neon', name: 'Neon', colors: ['#8b5cf6', '#e040fb'] },
    { id: 'gold', name: 'Gold', colors: ['#fde68a', '#f59e0b'] }, { id: 'ice', name: 'Eis', colors: ['#e0f2fe', '#38bdf8'] },
    { id: 'fire', name: 'Feuer', colors: ['#fde047', '#ef4444'] }, { id: 'toxic', name: 'Toxic', colors: ['#bef264', '#16a34a'] },
    { id: 'sakura', name: 'Sakura', colors: ['#fbcfe8', '#ec4899'] }, { id: 'rainbow', name: 'Regenbogen', colors: ['#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#a855f7'], animated: true },
  ],
};

const ids = (list) => new Set(list.map((item) => item.id));
const ALLOWED = { hat: ids(CATALOG.hats), wings: ids(CATALOG.wings), aura: ids(CATALOG.auras), nametag: ids(CATALOG.nametags), cape: ids(CATALOG.capes) };

/** Returns the cleaned loadout or throws a message. `uploads` is the set of the player's own active cape ids. */
export function cleanLoadout(input, uploads) {
  if (!input || typeof input !== 'object') throw new UserError('Ungültige Auswahl.');
  const out = {};
  for (const slot of ['hat', 'wings', 'aura', 'cape']) {
    const value = input[slot];
    if (value == null || value === '') { out[slot] = null; continue; }
    if (typeof value !== 'string') throw new UserError(`Ungültiger Wert für ${slot}.`);
    if (slot === 'cape' && value.startsWith('upload:')) {
      if (!uploads.has(value.slice(7))) throw new UserError('Dieses Cape gehört dir nicht oder wurde entfernt.');
      out.cape = value; continue;
    }
    if (!ALLOWED[slot].has(value)) throw new UserError(`Unbekanntes Cosmetic: ${value}`);
    out[slot] = value;
  }
  const tag = input.nametag ?? 'default';
  if (!ALLOWED.nametag.has(tag)) throw new UserError(`Unbekannter Nametag-Stil: ${tag}`);
  out.nametag = tag;
  return out;
}
