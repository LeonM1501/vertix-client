// Vertix API: who plays with Vertix, their cosmetics, and uploaded capes.
// Ownership of a Minecraft account is proven with the Mojang-signed player certificate; the API never sees a Minecraft token.
import { CATALOG, cleanLoadout, UserError } from './catalog.js';
import { inspectCape, MAX_CAPE_BYTES } from './png.js';
import { verifyLogin } from './certificate.js';

const CORS = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'authorization, content-type', 'access-control-allow-methods': 'GET, POST, PUT, DELETE, OPTIONS' };
const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', ...CORS, ...extra } });
const fail = (message, status = 400) => json({ error: message }, status);
const now = () => Math.floor(Date.now() / 1000);
const hex = (bytes) => [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
const randomHex = (n) => hex(crypto.getRandomValues(new Uint8Array(n)));
const sha256 = async (text) => hex(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))));
export const normalizeUuid = (value) => { const s = String(value ?? '').toLowerCase().replace(/-/g, ''); return /^[0-9a-f]{32}$/.test(s) ? s : null; };
const NAME = /^[A-Za-z0-9_]{1,16}$/;
const MAX_CAPES = 10, REPORTS_TO_HIDE = 5, SESSION_DAYS = 30;

async function body(request) { try { return await request.json(); } catch { throw new UserError('Ungültige Anfrage.'); } }
async function sessionUuid(request, env) {
  const match = (request.headers.get('authorization') ?? '').match(/^Bearer ([0-9a-f]{64})$/);
  if (!match) return null;
  const row = await env.DB.prepare('SELECT uuid FROM sessions WHERE token_hash = ? AND expires > ?').bind(await sha256(match[1]), now()).first();
  return row?.uuid ?? null;
}
function sameSecret(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
const capeUrl = (origin, id) => `${origin}/v1/capes/${id}.png`;

/** Public view of players; uploaded capes appear only while active. */
async function players(env, origin, uuids) {
  const out = {};
  for (let i = 0; i < uuids.length; i += 90) {
    const chunk = uuids.slice(i, i + 90), marks = chunk.map(() => '?').join(',');
    const rows = (await env.DB.prepare(`SELECT p.uuid, p.name, p.nametag, p.hat, p.wings, p.aura, p.cape, c.status AS cape_status
      FROM players p LEFT JOIN capes c ON p.cape = 'upload:' || c.id WHERE p.uuid IN (${marks})`).bind(...chunk).all()).results;
    for (const r of rows) {
      const uploaded = r.cape?.startsWith('upload:');
      out[r.uuid] = { name: r.name, nametag: r.nametag, hat: r.hat, wings: r.wings, aura: r.aura,
        cape: uploaded ? (r.cape_status === 'active' ? { url: capeUrl(origin, r.cape.slice(7)) } : null) : (r.cape ? { builtin: r.cape } : null) };
    }
  }
  return out;
}

async function route(request, env) {
  const url = new URL(request.url), path = url.pathname, method = request.method, origin = url.origin;
  if (method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (method === 'GET' && path === '/v1/catalog') return json(CATALOG, 200, { 'cache-control': 'public, max-age=3600' });

  if (method === 'POST' && path === '/v1/auth/challenge') {
    const uuid = normalizeUuid((await body(request)).uuid);
    if (!uuid) return fail('Ungültige Minecraft-UUID.');
    const serverId = randomHex(20);
    // The challenges table keys a one-time server id to the uuid that may answer it (stored in the name column).
    await env.DB.batch([
      env.DB.prepare('DELETE FROM challenges WHERE expires < ?').bind(now()),
      env.DB.prepare('INSERT INTO challenges (server_id, name, expires) VALUES (?, ?, ?)').bind(serverId, uuid, now() + 120),
    ]);
    return json({ serverId });
  }
  if (method === 'POST' && path === '/v1/auth/verify') {
    const input = await body(request), uuid = normalizeUuid(input.uuid);
    if (!uuid || !NAME.test(input.name ?? '') || !/^[0-9a-f]{40}$/.test(input.serverId ?? '')) return fail('Ungültige Anfrage.');
    // Single use: the challenge is consumed even if the proof fails.
    const challenge = await env.DB.prepare('DELETE FROM challenges WHERE server_id = ? AND name = ? AND expires > ? RETURNING name').bind(input.serverId, uuid, now()).first();
    if (!challenge) return fail('Anmeldung abgelaufen. Bitte erneut versuchen.', 401);
    await verifyLogin({ uuid, serverId: input.serverId, publicKey: String(input.publicKey ?? ''), expiresAt: input.expiresAt, keySignature: String(input.keySignature ?? ''), signature: String(input.signature ?? '') });
    // The certificate proves the uuid; the name is the launcher's own profile name and only used for display and reports.
    const token = randomHex(32), expires = now() + SESSION_DAYS * 86400;
    await env.DB.batch([
      env.DB.prepare(`INSERT INTO players (uuid, name, nametag, updated_at, last_seen) VALUES (?, ?, 'default', ?, ?)
        ON CONFLICT(uuid) DO UPDATE SET name = excluded.name, last_seen = excluded.last_seen`).bind(uuid, input.name, now(), now()),
      env.DB.prepare('DELETE FROM sessions WHERE expires < ?').bind(now()),
      env.DB.prepare('INSERT INTO sessions (token_hash, uuid, expires) VALUES (?, ?, ?)').bind(await sha256(token), uuid, expires),
    ]);
    return json({ token, uuid, name: input.name, expires });
  }

  if (method === 'GET' && path === '/v1/players') {
    const uuids = [...new Set((url.searchParams.get('ids') ?? '').split(',').map(normalizeUuid).filter(Boolean))].slice(0, 200);
    return json({ players: uuids.length ? await players(env, origin, uuids) : {} }, 200, { 'cache-control': 'public, max-age=30' });
  }
  const cape = path.match(/^\/v1\/capes\/([0-9a-f]{16})\.png$/);
  if (method === 'GET' && cape) {
    const row = await env.DB.prepare("SELECT png FROM capes WHERE id = ? AND status = 'active'").bind(cape[1]).first();
    if (!row) return fail('Cape nicht gefunden.', 404);
    return new Response(new Uint8Array(row.png), { headers: { 'content-type': 'image/png', 'cache-control': 'public, max-age=86400', 'x-content-type-options': 'nosniff', ...CORS } });
  }

  if (path.startsWith('/v1/admin/')) {
    if (!sameSecret((request.headers.get('authorization') ?? '').replace(/^Bearer /, ''), env.ADMIN_TOKEN)) return fail('Nicht erlaubt.', 403);
    if (method === 'GET' && path === '/v1/admin/reports') {
      const rows = (await env.DB.prepare(`SELECT c.id, c.owner, p.name AS owner_name, c.status, c.created, COUNT(r.reporter) AS reports, GROUP_CONCAT(r.reason, ' | ') AS reasons
        FROM capes c JOIN reports r ON r.cape_id = c.id LEFT JOIN players p ON p.uuid = c.owner GROUP BY c.id ORDER BY reports DESC LIMIT 200`).all()).results;
      return json({ capes: rows.map((r) => ({ ...r, url: capeUrl(origin, r.id) })) });
    }
    const action = path.match(/^\/v1\/admin\/capes\/([0-9a-f]{16})\/(hide|restore)$/);
    if (method === 'POST' && action) {
      await env.DB.prepare('UPDATE capes SET status = ? WHERE id = ?').bind(action[2] === 'hide' ? 'hidden' : 'active', action[1]).run();
      return json({ ok: true });
    }
    return fail('Unbekannter Pfad.', 404);
  }

  const uuid = await sessionUuid(request, env);
  if (!uuid) return fail('Bitte melde dich in Vertix an.', 401);
  if (method === 'GET' && path === '/v1/me') {
    const me = (await players(env, origin, [uuid]))[uuid];
    const raw = await env.DB.prepare('SELECT nametag, hat, wings, aura, cape FROM players WHERE uuid = ?').bind(uuid).first();
    const capes = (await env.DB.prepare('SELECT id, width, height, status, created FROM capes WHERE owner = ? ORDER BY created DESC').bind(uuid).all()).results;
    return json({ uuid, ...me, loadout: raw, uploads: capes.map((c) => ({ ...c, url: capeUrl(origin, c.id) })) });
  }
  if (method === 'PUT' && path === '/v1/me/cosmetics') {
    const owned = new Set((await env.DB.prepare("SELECT id FROM capes WHERE owner = ? AND status = 'active'").bind(uuid).all()).results.map((r) => r.id));
    const loadout = cleanLoadout(await body(request), owned);
    await env.DB.prepare('UPDATE players SET nametag = ?, hat = ?, wings = ?, aura = ?, cape = ?, updated_at = ? WHERE uuid = ?')
      .bind(loadout.nametag, loadout.hat, loadout.wings, loadout.aura, loadout.cape, now(), uuid).run();
    return json({ loadout });
  }
  if (method === 'POST' && path === '/v1/me/capes') {
    if (Number(request.headers.get('content-length') ?? 0) > MAX_CAPE_BYTES) return fail('Das Bild ist größer als 256 KB.', 413);
    const bytes = new Uint8Array(await request.arrayBuffer());
    const { width, height } = inspectCape(bytes);
    const count = await env.DB.prepare('SELECT COUNT(*) AS n FROM capes WHERE owner = ?').bind(uuid).first();
    if (count.n >= MAX_CAPES) return fail(`Du kannst höchstens ${MAX_CAPES} eigene Capes haben. Lösche zuerst eins.`, 409);
    const id = randomHex(8);
    await env.DB.prepare("INSERT INTO capes (id, owner, png, width, height, status, created) VALUES (?, ?, ?, ?, ?, 'active', ?)").bind(id, uuid, bytes, width, height, now()).run();
    return json({ id, url: capeUrl(origin, id), width, height }, 201);
  }
  const own = path.match(/^\/v1\/me\/capes\/([0-9a-f]{16})$/);
  if (method === 'DELETE' && own) {
    await env.DB.batch([
      env.DB.prepare('DELETE FROM capes WHERE id = ? AND owner = ?').bind(own[1], uuid),
      env.DB.prepare('DELETE FROM reports WHERE cape_id = ?').bind(own[1]),
      env.DB.prepare('UPDATE players SET cape = NULL WHERE uuid = ? AND cape = ?').bind(uuid, `upload:${own[1]}`),
    ]);
    return json({ ok: true });
  }
  const report = path.match(/^\/v1\/capes\/([0-9a-f]{16})\/report$/);
  const byName = path.match(/^\/v1\/capes\/by-name\/([A-Za-z0-9_]{1,16})\/report$/);
  if (method === 'POST' && (report || byName)) {
    const { reason } = await body(request);
    // Reporting by name targets the uploaded cape that player currently wears.
    const target = report
      ? await env.DB.prepare('SELECT id, owner FROM capes WHERE id = ?').bind(report[1]).first()
      : await env.DB.prepare("SELECT c.id, c.owner FROM players p JOIN capes c ON p.cape = 'upload:' || c.id WHERE p.name = ? COLLATE NOCASE").bind(byName[1]).first();
    if (!target) return fail(byName ? 'Dieser Spieler trägt kein eigenes Cape.' : 'Cape nicht gefunden.', 404);
    const capeId = target.id;
    if (target.owner === uuid) return fail('Du kannst dein eigenes Cape nicht melden.');
    await env.DB.prepare('INSERT OR IGNORE INTO reports (cape_id, reporter, reason, created) VALUES (?, ?, ?, ?)').bind(capeId, uuid, String(reason ?? '').slice(0, 200), now()).run();
    // Enough independent reports hide the cape until an admin restores it.
    const { n } = await env.DB.prepare('SELECT COUNT(*) AS n FROM reports WHERE cape_id = ?').bind(capeId).first();
    if (n >= REPORTS_TO_HIDE) await env.DB.prepare("UPDATE capes SET status = 'hidden' WHERE id = ? AND status = 'active'").bind(capeId).run();
    return json({ ok: true });
  }
  return fail('Unbekannter Pfad.', 404);
}

export default {
  async fetch(request, env) {
    try { return await route(request, env); }
    catch (error) {
      if (error instanceof UserError) return fail(error.message, 400);
      console.error(error);
      return fail('Serverfehler. Bitte später erneut versuchen.', 500);
    }
  },
};
