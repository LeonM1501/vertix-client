import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cleanLoadout, UserError } from '../src/catalog.js';
import { inspectCape } from '../src/png.js';
import { normalizeUuid } from '../src/worker.js';

const png = (w, h, extra = 0) => { const b = new Uint8Array(33 + extra); b.set([137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82]); const v = new DataView(b.buffer); v.setUint32(16, w); v.setUint32(20, h); return b; };

test('cape PNGs need 2:1 and an allowed width', () => {
  assert.deepEqual(inspectCape(png(64, 32)), { width: 64, height: 32 });
  assert.deepEqual(inspectCape(png(1024, 512)), { width: 1024, height: 512 });
  for (const [w, h] of [[64, 64], [100, 50], [2048, 1024], [32, 16]]) assert.throws(() => inspectCape(png(w, h)), UserError);
  assert.throws(() => inspectCape(new TextEncoder().encode('<svg onload=alert(1)>' + ' '.repeat(40))), UserError);
  assert.throws(() => inspectCape(png(64, 32, 300 * 1024)), /256 KB/);
});

test('loadouts accept only catalog items and own uploads', () => {
  assert.deepEqual(cleanLoadout({ hat: 'crown', cape: 'galaxy', nametag: 'neon' }, new Set()), { hat: 'crown', wings: null, aura: null, cape: 'galaxy', nametag: 'neon' });
  assert.equal(cleanLoadout({ cape: 'upload:abcd' }, new Set(['abcd'])).cape, 'upload:abcd');
  assert.throws(() => cleanLoadout({ cape: 'upload:abcd' }, new Set()), UserError);
  assert.throws(() => cleanLoadout({ hat: 'banana' }, new Set()), UserError);
  assert.throws(() => cleanLoadout({ nametag: '<b>' }, new Set()), UserError);
});

test('uuids are normalised to 32 lowercase hex characters', () => {
  assert.equal(normalizeUuid('069A79F4-44E9-4726-A5BE-FCA90E38AAF5'), '069a79f444e94726a5befca90e38aaf5');
  assert.equal(normalizeUuid('nope'), null);
});

import { verifyLogin, certificatePayload, loginMessage } from '../src/certificate.js';
test('player certificates must be Mojang-signed, unexpired and sign the challenge', async () => {
  const gen = (hash) => crypto.subtle.generateKey({ name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash }, true, ['sign', 'verify']);
  const b64 = (buf) => Buffer.from(buf).toString('base64');
  const mojang = await gen('SHA-1'), player = await gen('SHA-256'), stranger = await gen('SHA-256');
  const mojangKey = b64(await crypto.subtle.exportKey('spki', mojang.publicKey));
  const uuid = '069a79f444e94726a5befca90e38aaf5', serverId = 'a'.repeat(40), expiresAt = Date.now() + 3600_000;
  const playerDer = new Uint8Array(await crypto.subtle.exportKey('spki', player.publicKey));
  const keySignature = b64(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', mojang.privateKey, certificatePayload(uuid, expiresAt, playerDer)));
  const signature = b64(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', player.privateKey, loginMessage(serverId, uuid)));
  const login = { uuid, serverId, publicKey: b64(playerDer), expiresAt, keySignature, signature };
  await verifyLogin(login, [mojangKey]);
  await assert.rejects(verifyLogin({ ...login, uuid: 'f'.repeat(32) }, [mojangKey]), UserError);
  await assert.rejects(verifyLogin({ ...login, serverId: 'b'.repeat(40) }, [mojangKey]), UserError);
  await assert.rejects(verifyLogin({ ...login, expiresAt: Date.now() - 1 }, [mojangKey]), /abgelaufen/);
  await assert.rejects(verifyLogin(login, [b64(await crypto.subtle.exportKey('spki', stranger.publicKey))]), /nicht ausgestellt/);
  const forged = b64(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', stranger.privateKey, loginMessage(serverId, uuid)));
  await assert.rejects(verifyLogin({ ...login, signature: forged }, [mojangKey]), /nicht von deinem Konto/);
});
