package client.vertix.core.mixin;
import net.minecraft.client.MouseHandler;
import client.vertix.core.modules.qol.ZoomModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public class ZoomMouseMixin {
    @Inject(method="onScroll",at=@At("HEAD"),cancellable=true)
    private void scroll(long window,double horizontal,double vertical,CallbackInfo ci){var z=ZoomModule.instance();if(z!=null&&z.scroll(vertical))ci.cancel();}
    @Redirect(method="turnPlayer",at=@At(value="INVOKE",target="Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"))
    private void vertix$turn(net.minecraft.client.player.LocalPlayer player,double x,double y){
        var f=client.vertix.core.modules.qol.FreeCamModule.instance();
        if(client.vertix.core.modules.qol.FreeCamModule.active())f.turn(x,y);
        else {var z=ZoomModule.instance();double scale=z==null?1:z.mouseScale();player.turn(x*scale,y*scale);}
    }
}
