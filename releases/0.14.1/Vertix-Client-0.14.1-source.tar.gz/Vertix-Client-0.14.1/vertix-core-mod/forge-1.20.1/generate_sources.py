"""Adapt shared Vertix modules to Minecraft 1.20.1's rendering/input API.

Generated files live under build/, so module behavior and settings continue to
come from the shared source rather than a divergent copy.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
SHARED = ROOT.parent / 'src/main/java'
OUTPUT = ROOT / 'build/generated/java'
for source in SHARED.rglob('*.java'):
    relative = source.relative_to(SHARED)
    if 'mixin' in relative.parts:
        continue
    body = source.read_text(encoding='utf-8')
    for old, new in {
        'net.minecraft.client.gui.screens.options.controls.KeyBindsScreen': 'net.minecraft.client.gui.screens.controls.KeyBindsScreen',
        'net.minecraft.client.gui.GuiGraphicsExtractor': 'net.minecraft.client.gui.GuiGraphics',
        'GuiGraphicsExtractor': 'GuiGraphics',
        'net.minecraft.client.DeltaTracker': 'client.vertix.core.compat.DeltaTracker',
        'net.minecraft.server.level.ParticleStatus': 'net.minecraft.client.ParticleStatus',
        'net.minecraft.client.input.': 'client.vertix.core.compat.',
        'net.minecraft.resources.Identifier': 'net.minecraft.resources.ResourceLocation',
        '.gui.screen()': '.screen', '.gui.hud.': '.gui.',
        '.setScreenAndShow(': '.setScreen(', '.dimension().identifier()': '.dimension().location()',
        'keyOpenMenu.matches(event)': 'keyOpenMenu.matches(event.key(),event.scancode())',
        'InputConstants.getKey(event)': 'InputConstants.getKey(event.key(),event.scancode())',
        'SharedConstants.getCurrentVersion().packVersion(PackType.CLIENT_RESOURCES).major()': 'SharedConstants.getCurrentVersion().getPackVersion(PackType.CLIENT_RESOURCES)',
        'Math.clamp(': 'Numbers.clamp(',
        'Items.IRON_SWORD.components()!=null': 'Items.IRON_SWORD!=null',
        'g.pose().pushMatrix()': 'g.pose().pushPose()',
        'g.pose().popMatrix()': 'g.pose().popPose()',
        'g.pose().translate(x,y)': 'g.pose().translate(x,y,0)',
        'g.pose().scale(layout.scale(),layout.scale())': 'g.pose().scale((float)layout.scale(),(float)layout.scale(),1)',
        'net.minecraft.world.item.ItemStack.hashItemAndComponents(item.getItem())': 'java.util.Objects.hash(item.getItem().getItem(),item.getItem().getTag())',
        'ItemStack.isSameItemSameComponents(': 'ItemStack.isSameItemSameTags(',
        'MobEffects.SPEED': 'MobEffects.MOVEMENT_SPEED', 'MobEffects.STRENGTH': 'MobEffects.DAMAGE_BOOST',
        'list.getLast()': 'list.get(list.size()-1)',
    }.items():
        body = body.replace(old, new)
    if 'DeltaTracker' in body:
        body = re.sub(r'(?m)^(package [^;]+;)', r'\1\nimport client.vertix.core.compat.DeltaTracker;', body, count=1)
    if 'Numbers.clamp' in body:
        body = re.sub(r'(?m)^(package [^;]+;)', r'\1\nimport client.vertix.core.compat.Numbers;', body, count=1)
    # GuiGraphics in 1.20.1 renders immediately; the modern extractor queues the same calls.
    body = re.sub(r'\b(extractor|g)\.text\(', r'\1.drawString(', body)
    body = re.sub(r'\b(extractor|g)\.itemDecorations\(', r'\1.renderItemDecorations(', body)
    body = re.sub(r'\b(extractor|g)\.item\(', r'\1.renderItem(', body)
    if source.name in ('VertixHomeScreen.java', 'VertixMenuScreen.java', 'HudEditorScreen.java'):
        body = body.replace('import net.minecraft.client.gui.screens.Screen;', 'import net.minecraft.client.gui.screens.Screen;\nimport client.vertix.core.compat.CompatScreen;')
        body = body.replace('extends Screen', 'extends CompatScreen')
        body = body.replace('minecraft.onTextInputFocusChange(this, focused);', '')
    if source.name == 'EffectIcons.java':
        body = re.sub(r'g.blitSprite\([^;]+;', 'g.blit(x,y,0,18,18,mc.getMobEffectTextures().get(effect.getEffect()));', body)
    if source.name == 'VertixCoreMod.java':
        body = body.replace('import net.fabricmc.api.ClientModInitializer;', '').replace('import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;', '')
        body = body.replace(' implements ClientModInitializer', '').replace('    @Override\n    public void onInitializeClient()', '    public void onInitializeClient()')
        start = body.index('        // Register Keybind')
        end = body.index('        // Load persistent', start)
        body = body[:start] + '''        keyOpenMenu=new KeyMapping("key.vertix.open_menu", InputConstants.KEY_RSHIFT,"key.categories.vertix");
        keyZoom=new KeyMapping("key.vertix.zoom",InputConstants.KEY_C,"key.categories.vertix");
        keyCopy=new KeyMapping("key.vertix.copy_coordinates",InputConstants.KEY_F6,"key.categories.vertix");
''' + body[end:]
        body = body.replace('    public KeyMapping getKeyZoom()', '    public KeyMapping getKeyCopy(){return keyCopy;}\n    public KeyMapping getKeyZoom()')
    target = OUTPUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(body, encoding='utf-8')
print(f'Generated shared modules for Forge 1.20.1 in {OUTPUT}')
