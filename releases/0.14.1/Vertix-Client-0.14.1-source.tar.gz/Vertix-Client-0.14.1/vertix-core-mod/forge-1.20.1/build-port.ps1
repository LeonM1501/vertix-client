param([string]$JdkHome=$env:JAVA_HOME,[string]$PythonExe='python')
$ErrorActionPreference='Stop'
if (!$JdkHome -or !(Test-Path -LiteralPath (Join-Path $JdkHome 'bin/javac.exe'))) { throw 'Pass -JdkHome with a full Java 17 JDK.' }
$entry=Get-Content "$PSScriptRoot/../dependencies/integrations/manifest.json" -Raw | ConvertFrom-Json | Where-Object { $_.minecraft -eq '1.20.1' -and $_.project -eq 'appleskin' }
$apple=Join-Path $PSScriptRoot "../dependencies/integrations/$($entry.file)"
if((Get-FileHash $apple -Algorithm SHA512).Hash.ToLowerInvariant() -ne $entry.sha512){throw 'AppleSkin checksum mismatch'}
$previousJavaHome=$env:JAVA_HOME
Push-Location $PSScriptRoot
try {
    $env:JAVA_HOME=$JdkHome
    & ./gradlew.bat build --console plain "-PpythonExe=$PythonExe"
    if ($LASTEXITCODE -ne 0) { throw 'Forge compilation failed.' }
    $jar=Join-Path $PSScriptRoot 'build/libs/vertix-core-forge-1.20.1-1.7.1.jar'
    $destination=Join-Path $PSScriptRoot '../../src-tauri/resources/mods/vertix-core-forge-1.20.1-1.7.1.jar'
    Copy-Item -LiteralPath $jar -Destination $destination
    Write-Host "Built $destination"
} finally { $env:JAVA_HOME=$previousJavaHome; Pop-Location }
