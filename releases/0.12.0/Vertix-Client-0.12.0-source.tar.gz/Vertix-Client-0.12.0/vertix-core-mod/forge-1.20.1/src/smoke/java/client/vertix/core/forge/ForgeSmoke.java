package client.vertix.core.forge;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.StreamingWindow;
import client.vertix.core.gui.*;
import net.minecraft.client.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.nio.file.*;

/** Compiled only with -Psmoke. Test preferences and options live in run/. */
@Mod.EventBusSubscriber(modid="vertix_core",value=Dist.CLIENT)
public final class ForgeSmoke {
    private static int ticks,renders;
    private static boolean opened;
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END)return;
        var mc=Minecraft.getInstance();if(mc.getOverlay()!=null||mc.screen==null)return;
        try{
            var core=VertixCoreMod.getInstance();if(core==null)throw new AssertionError("Core bootstrap missing");
            if(!((Object)mc.getWindow() instanceof StreamingWindow))throw new AssertionError("Window mixin missing");
            if(core.getModuleManager().getModules().size()!=16)throw new AssertionError("Module parity missing: "+core.getModuleManager().getModules().size());
            if(!opened){
                // The real binding is intentionally inactive over other screens.
                // Exercise its no-screen condition without creating a user world.
                opened=true;mc.screen=null;KeyMapping.click(core.getKeyOpenMenu().getDefaultKey());core.onTick(mc);
                if(!(mc.screen instanceof VertixMenuScreen))throw new AssertionError("RSHIFT binding did not open menu");return;
            }
            if(++ticks==2&&!(mc.screen instanceof VertixMenuScreen))throw new AssertionError("RSHIFT key did not open Vertix menu");
            if(ticks==10)mc.setScreen(new HudEditorScreen(mc.screen));
            if(ticks>=30){
                if(renders<5)throw new AssertionError("HUD/menu not rendered");
                core.getConfigManager().saveConfig(core.getModuleManager().getModules());mc.options.save();
                if(!Files.isRegularFile(core.getConfigManager().getGlobalConfigFile().toPath()))throw new AssertionError("Config save failed");
                String options=Files.readString(mc.gameDirectory.toPath().resolve("options.txt"));
                if(!options.contains("key_key.vertix.open_menu:"))throw new AssertionError("Keybind not persisted");
                Files.writeString(Path.of("smoke-result.txt"),"PASS: Forge 1.20.1; 16 modules; RSHIFT; menu; HUD placeholders; mixins; settings save");mc.stop();
            }
        }catch(Throwable failure){try{Files.writeString(Path.of("smoke-result.txt"),"FAIL: "+failure);}catch(Exception ignored){}failure.printStackTrace();mc.stop();}
    }
    @SubscribeEvent public static void render(ScreenEvent.Render.Post e){if(e.getScreen() instanceof VertixMenuScreen||e.getScreen() instanceof HudEditorScreen)renders++;}
}
