# Steuerungssynchronisierung, doppelte Mods und Forge-Port

Für das freigegebene Launcher-Update 0.12.0 vorbereitet. Die
0.11.0-Veröffentlichung, das Desktop-Setup und die persönliche Installation werden
dabei nicht direkt überschrieben; die Auslieferung läuft über das Update-System.

## Bedienung

Unter **Einstellungen → Steuerung & Spieloptionen** die Synchronisierung
aktivieren und eine Vorlage für Minecraft-Tasten sowie optional eine separate
Vorlage für Grafik/UI auswählen. Für Mod-Tasten gibt es pro Loader eine eigene
Vorlage. Damit können Inventar und Hotbar überall gleich sein, während eine
Forge-Mod eine andere Mute-Taste als die Fabric-Mod verwendet.

Die drei Kategorien lassen sich pro Instanz abschalten, auch direkt in deren
Einstellungen unter **Synchronisierung**. Die Vorlage selbst wird für ihre
jeweilige Kategorie nicht überschrieben. Neue Instanzen nehmen bei aktiver
Synchronisierung standardmäßig teil.

Änderungen einer Vorlage werden beim Beenden ihres Minecraft-Prozesses gelesen.
Vor dem nächsten Start übernimmt die Zielinstanz die gewählten Kategorien.
**Jetzt auf ruhende Instanzen anwenden** liest die Vorlagen erneut ein und
aktualisiert gestoppte Ziele; dafür müssen die Vorlagen selbst geschlossen sein.
Laufende Zielinstanzen folgen beim nächsten Start. Eine noch ungespielte Vorlage
ohne options.txt muss zuerst einmal gestartet und beendet werden.

Es werden vanilla Minecraft-Tasten, Maus-/Toggle-Optionen und eine ausdrücklich
definierte Auswahl an Grafik-/UI-Optionen synchronisiert. Mod-Keybind-Zeilen werden
nur innerhalb desselben Loaders übertragen. Bestehende Dateien behalten unbekannte
und nicht gewählte Optionen; Ressourcenpakete, Sound-Geräte, Welten sowie Shader-
und andere Mod-Konfigurationsdateien werden nicht kopiert. Neue options.txt-Dateien
bekommen die Datenversion des vorbereiteten Minecraft-Clients, damit moderne
Tastennamen nicht als alte numerische Belegungen behandelt werden.

## Dateiverhalten

- `meta/vertix-settings-sync.json`: Vorlagen, gespeicherte Werte und Ausnahmen.
- `<Instanz>/.vertix-options-backups/`: bisherige options.txt vor einer Änderung.
- `<Instanz>/mods/.vertix-duplicates/`: erhaltene ältere Mod-Dateien samt Metadaten.
- `<Instanz>/mods/.vertix-duplicate-report.json`: Ergebnis des letzten Eingriffs.

Der Duplikatabgleich liest die eingebetteten IDs und Versionsnummern aus Fabric-,
Quilt- und Forge-/NeoForge-Metadaten. Forge `${file.jarVersion}` wird aus dem
JAR-Manifest aufgelöst. Semantisch vergleichbare Versionen werden geordnet;
eine stabile Version schlägt ihren Release Candidate. Dateinamen und Anzeigenamen
sind kein Identitätsbeweis. Bewusst deaktivierte Dateien bleiben unangetastet.

Gleichversionige identische Dateien dürfen auf eine aktive Kopie reduziert werden.
Bei unterschiedlichen Dateien derselben höchsten Version, überlappenden
Multi-Mod-JARs oder unklarer Versionsordnung bleiben die Konfliktdateien erhalten;
der Start erklärt den Konflikt, statt willkürlich eine Datei auszuwählen.
Erneut bereitgestellte verwaltete ältere Pins erzeugen keine mehrfachen identischen
Sicherungen. Der bestehende Schutz manueller Dateien im Managed-Mod-Synchronisierer
bleibt bestehen. Normale Loader-Abhängigkeiten und Minecraft-Kompatibilität prüft
weiterhin der jeweilige Modloader.

## Vertix Core 1.6.0

Zunächst die vom Nutzer bestätigten vorhandenen Instanzen:

| Loader | Minecraft | Artefakt |
| --- | --- | --- |
| Fabric | 26.2 | vertix-core-fabric-26.2-1.6.0.jar |
| Fabric | 26.3 | vertix-core-fabric-26.3-1.6.0.jar |
| Forge | 1.20.1 | vertix-core-forge-1.20.1-1.6.0.jar |

Der Forge-Port baut dieselben 16 Module und die gemeinsame Menüoberfläche aus
den gemeinsamen Quellen. Die Kompatibilitätsschicht passt Rendering, Tastatur- und
Mausereignisse, Keybind-Registrierung und die alten Minecraft-Schnittstellen an.
Forge-Events und remappte Mixins ersetzen die Fabric-Einstiegspunkte. Andere
Versionen und Loader werden nicht durch eine bloße Metadatenänderung freigegeben.

## Prüfung

- Frontend: `npm run build`.
- Dateialgorithmen: `cargo test --manifest-path scripts/native-content-tests/Cargo.toml`.
- Native Vorlagenauswahl unter Windows: `cargo test --manifest-path src-tauri/Cargo.toml --lib settings_sync::tests --features test-manifest`.
- Fabric-JARs: `vertix-core-mod/build.ps1`.
- Forge: `vertix-core-mod/forge-1.20.1/build-port.ps1` mit Java-17-JDK und Python.
- Forge-Lauftest: `gradlew.bat runClient -Psmoke`; Details in dessen README.

Das Windows-Testmerkmal `test-manifest` ist erforderlich, damit der Testprozess
Common Controls v6 für die mitgelinkten Dialog-Funktionen aktiviert. Ohne dieses
Merkmal kann der Testprozess bereits vor dem Test mit fehlendem TaskDialogIndirect
beenden. Das eigentliche Tauri-Programm bringt sein eigenes Manifest mit.

Der isolierte Forge-47.4.20-Lauftest bestätigt Bootstrap, 16 Module, die
R-Shift-Bindung ohne überlagernden Screen, Menü-/HUD-Vorschau-Rendering und das
Speichern von Konfiguration und Tasten. Keine persönliche Instanz oder Welt wird
dafür gestartet. Gameplay-Tests jedes einzelnen Moduls in einer Welt stehen aus.
Die endgültige Forge-JAR enthält Refmap und Lizenzdateien, aber keine Smoke-Klasse.
