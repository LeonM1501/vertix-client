# Core 1.4.0: Armor HUD — lokale Entwicklungsprüfung

Stand: 19. Oktober 2026. Nicht veröffentlicht. Client-Version bleibt 0.9.0 vorbereitet, öffentliche Update-Metadaten bleiben 0.8.1. Kein Upload, kein Desktop-Setup, keine Änderung an persönlicher Installation oder Profilen.

## Änderungen und Herkunft

MIT-lizenzierte Slot-Auswahl, Haltbarkeits- und Warnregeln aus uku3lig/armor-hud, Commit `233932b08a0fb30501e1104bead784914aff85c4`, in das bestehende Modul `armor_hud` integriert. Keine zweite Armor-HUD-Mod, keine Upstream-Mixins/Configbibliothek/Artwork. Volle Lizenztexte im Source, im Launcher-Notice und in beiden Core-JARs; genaue Zuordnung: `third_party/uku-armor-hud/UPSTREAM.md`.

Eigene Vertix-Darstellung mit horizontaler/vertikaler Anordnung, Slot-Filtern, Haupt-/Nebenhand, Reihenfolge, fünf Haltbarkeitsformaten, relativen/absoluten Warnschwellen, optionalem Ton/Symbol, drei Oberflächen, Skalierung, Deckkraft, Abständen und Farben. Vier einklappbare Einstellungsgruppen, persistiert über den vorhandenen ConfigManager. Alte IDs `orientation`, `held`, `durability` bleiben gültig.

## Build und algorithmische Prüfungen

- `./vertix-core-mod/build.ps1`: beide Versionen erfolgreich mit JDK 24. Warnungen beim Lesen der Minecraft-Klassenversion 69; tatsächliche Laufzeit Java 25. Ein JDK 25 ist für künftige Builds empfohlen.
- `ArmorHudLogicTest`: Slot-Auswahl, Reihenfolge, beide Warnschwellen/Grenzfälle, unzerstörbare Items, Ausgabeformate/Prozentpräzision, Ton nur bei Grenzübertritt und 72 skalierte Layouts bestanden.
- `MenuLayoutTest`: 30 responsive Fälle bestanden.
- `HudPlacementTest`: Bildschirm-/Nachbar-Ausrichtung, freies Verschieben und zwölf Viewports bestanden.
- `cargo check --manifest-path src-tauri/Cargo.toml --lib --locked -j4`: erfolgreich; bestätigt Einbindung beider neuen Artefakte.
- JAR-Prüfung: versionsrichtige Fabric-Metadaten, vollständige unveränderte MIT-Lizenz, neue Logic-Klasse, keine Test-Mixins.
- SHA-256 26.2: `0e60f85c60d1e7b1e968d184f4636502831680c4c919728944677cf4fc660f45`.
- SHA-256 26.3: `8020e0827ae51e35311fc01e85fb3411113874330b9f312254c8183e72cce627`.

## Isolierte Spielprüfungen

`ArmorHudRuntimeTest` läuft ausschließlich als separater Test-Mixin. Das Skript erstellt pro Lauf ein eigenes Spiel-/APPDATA-Verzeichnis und eine flache Offline-Testwelt mit Testausrüstung. Keine echten Welten, Accounts oder Instanzen. Assertions: tatsächliche Ingame-Anzeige; horizontale/vertikale Vorschau und Filter; Größen; Konfigurationsreload inklusive alter Setting-IDs; Maus-Verschieben; Einstellungsfenster/Scrollbereich; Screenshot-Dateien. Beide regulären Läufe mit Java 25/JIT bestanden:

- 26.2: `artifacts/verification/armor-hud/ui-26.2-8e20ea022c8a437c91d1071fbce2b984`.
- 26.3: `artifacts/verification/armor-hud/ui-26.3-73b1264b0b4b4d139ff2784d9d2d4125`.

Ein früher Test entdeckte fehlende Item-Komponenten im 26.3-Titelbildschirm. Produktionskorrektur: vor Bindung der Welt-Daten eigene sichere Slot-Symbole mit Vorschauwerten; keine vorzeitigen ItemStack-Konstruktoren. Dieser Fix ist in beiden obigen erfolgreichen Artefakten enthalten. Das später ergänzte Warten auf das Ende des Lade-Overlays betrifft nur die Test-Screenshot-Aufnahme.

Weitere Diagnose: Ein Lauf (`ui-26.3-52246803d9c349bcba10f4f23534d699`) wurde nach einem großen Uhrzeit-/Ausführungsunterbruch vom Vier-Minuten-Wächter beendet. Ein anschließender Lauf (`ui-26.3-f599fc4b32b544b49a4e1898be7d6c78`) zeigte einen nativen Fehler in `jvm.dll` (Windows-Ereignis 1000, `0xc0000005`, kein Java-Crashbericht der Mod). Die Vorschau ohne Welt wurde dabei erfolgreich aufgenommen. Der anschließende vollständige 26.3-Lauf mit `-JvmArguments '-Xint'` bestand: `artifacts/verification/armor-hud/ui-26.3-33fa1374ad574fdfa63b37b61470c824`. Dabei wurde auch die Vorschau ohne Welt nach Ende des Lade-Overlays visuell bestätigt. Das grenzt den zusätzlichen nativen Fehler auf die Laufzeit ein, beweist aber keine bestimmte JVM-Ursache; Produktions-JVM-Argumente bleiben unverändert.

Zusätzliche bestehende UI-Regression mit `UiRuntimeTest` unter 26.2 bestand: `artifacts/verification/armor-hud-regression/ui-26.2-c8476120a1c64608b0451c2da897bb16` (Modmenü, FPS-HUD-Verschieben, Editor und Einstellungen). Screenshots für horizontale/vertikale/kritische Armor-Anzeige, Gruppeneinstellungen, deren Scrollbereich und FPS-Einstellungen visuell geprüft.

Die Warn-Ton-Grenzlogik ist algorithmisch geprüft; Lautstärke und persönlicher Höreindruck wurden nicht bewertet. Kein echter Multiplayer-/Streamtest und kein Endnutzer-Update installiert.

## Wiederholen

```powershell
./scripts/test-ingame-ui.ps1 -Version 26.2 -TestClassName ArmorHudRuntimeTest -EvidenceGroup armor-hud -JdkHome '<JDK 25>' -MetadataRoot '<offizielle Vertix-Spielmetadaten>' -JavaHome '<Java 25>'
./scripts/test-ingame-ui.ps1 -Version 26.3 -TestClassName ArmorHudRuntimeTest -EvidenceGroup armor-hud -JdkHome '<JDK 25>' -MetadataRoot '<offizielle Vertix-Spielmetadaten>' -JavaHome '<Java 25>'
# Optional nur für die Diagnose: -JvmArguments '-Xint'
```

Vor einer späteren Veröffentlichung müssen Client-EXE, Updatepaket, Installer und korrespondierendes Source-Archiv neu gebaut werden; zuvor vorbereitete 0.9.0-Artefakte enthalten diese Armor-HUD-Änderungen noch nicht.
