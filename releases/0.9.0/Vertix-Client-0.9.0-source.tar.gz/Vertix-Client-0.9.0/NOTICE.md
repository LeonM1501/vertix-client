# Vertix Client — modified distribution

Modified on 2026-10-08 and 2026-10-09. Based on the complete source of NoRiskClient Launcher 0.6.28, by NoRiskk and the upstream contributors. Original copyright and license notices remain applicable. The original license is included in LICENSE. This fork is distributed under GNU GPL version 3; there is no warranty.

Vertix is independent and is not endorsed by or affiliated with NoRiskClient, Mojang or Microsoft. The upstream name is retained only for attribution and in internal compatibility symbols; its branding, artwork and hosted services are not used in the active Vertix interface. The original frontend/artwork is kept in upstream as a source reference and is not bundled in the app.

Changes: original Vertix interface, original SVG mark and terrain, separate application identity and storage, no standard remote profiles, no advertisement/news/social/cosmetics/capture flows, no telemetry or upstream updates. Instance-local content management supports Modrinth mods, resource packs, world data packs and shaders. Microsoft authentication now uses Vertix's own registered public desktop application, authorization-code OAuth with PKCE and a temporary loopback callback. On Windows the session is protected with current-user DPAPI, and the interface receives account status only. Minecraft profile and entitlement are validated before direct launch. Live Minecraft access for this new registration is not yet confirmed and may require approval. An official-launcher fallback can use its short-lived game session or export an isolated installation; its Microsoft refresh credentials and encrypted account stores are not read. Historical upstream authentication commands remain inactive.

When distributing binaries, provide the matching complete corresponding source under GPLv3 and keep applicable notices. Renaming does not remove these requirements. No conclusion is made about availability of the Vertix trademark. Do not use the upstream application ID, updater signing keys, artwork or service credentials. The registered public Vertix client ID is included in the source and build; no client secret was created or bundled. The official-launcher fallback remains available without using Vertix OAuth.
# Additional dependencies in Vertix 0.8.0

License texts for the newly bundled Markdown components and their dependencies are included in THIRD_PARTY_NOTICES.md.

## Vertix Core 1.4.0 — Armor HUD (included in Client 0.9.0)

Armor HUD rules adapted from uku3lig/armor-hud, commit 233932b08a0fb30501e1104bead784914aff85c4, MIT License, Copyright (c) 2021 BerdinskiyBear. Full original notice: third_party/uku-armor-hud/LICENSE and THIRD_PARTY_NOTICES.md; bundled in Core at assets/vertix/licenses/uku-armor-hud-MIT.txt. Origin and changes: third_party/uku-armor-hud/UPSTREAM.md.
