import { ProjectDetails, LocalContentDetails } from "./ProjectDetails";

import { ProfileIcon } from "./ProfileIcon";

import { useEffect, useRef, useState } from 'react';

import { createPortal } from 'react-dom';

import { ArrowLeft, ArrowDownToLine, ArrowRight, Box, Check, ChevronLeft, ChevronRight, Clock3, FileText, Folder, FolderOpen, Globe2, HardDrive, Layers3, LoaderCircle, Package, Pin, Play, Plus, RefreshCw, Search, Settings2, SlidersHorizontal, Trash2, Upload, X } from 'lucide-react';

import * as api from './api';

import { InstanceSettings } from './InstanceSettings';

import { checkModUpdates, type ModUpdate } from './modUpdates';

import type { ContentItem, ContentKind, InstanceSnapshot, Profile, Project } from './api';



const labels: Record<ContentKind, string> = { mod: 'Mods', resourcepack: 'Ressourcenpakete', datapack: 'Datenpakete', shader: 'Shader' };

const empty: InstanceSnapshot = { items: [], worlds: [], files: [], directory: '', running: false };

const message = (e: unknown) => typeof e === 'string' ? e : e instanceof Error ? e.message : e && typeof e === 'object' && 'message' in e ? String(e.message) : 'Die Aktion konnte nicht abgeschlossen werden.';

const formatCount = (n: number) => Intl.NumberFormat('de', { notation: 'compact' }).format(n);

type Notify = (text: string, error?: boolean) => void;



export function InstanceWorkspace({ profile: p, onBack, onLaunch, onReload, notify, launching, initialBrowse = false, pinned = false, onPin }: { profile: Profile; onBack: () => void; onLaunch: () => void; onReload: () => Promise<Profile[]>; notify: Notify; launching: boolean; initialBrowse?: boolean; pinned?: boolean; onPin?:()=>void }) {

  const [data, setData] = useState(empty), [loading, setLoading] = useState(true), [failure, setFailure] = useState('');

  const [browse, setBrowse] = useState(initialBrowse), [tab, setTab] = useState('content');

  const [kind, setKind] = useState<ContentKind | 'all'>('all'), [query, setQuery] = useState(''), [sort, setSort] = useState('az');

  const [busy, setBusy] = useState(false), [settings, setSettings] = useState(false), [remove, setRemove] = useState<ContentItem | null>(null);

  const [details, setDetails] = useState<ContentItem | null>(null);

  const [importOpen, setImportOpen] = useState(false), [importKind, setImportKind] = useState<ContentKind | 'auto'>('auto'), [world, setWorld] = useState('');

  const [log, setLog] = useState(''), [name, setName] = useState(p.name), [memory, setMemory] = useState(p.settings.memory.max);

  const [updates, setUpdates] = useState<Record<string, ModUpdate>>({}), [checkingUpdates, setCheckingUpdates] = useState(false), [updateFailures, setUpdateFailures] = useState(0), [checkAttempt, setCheckAttempt] = useState(0);

  const contentSignature = data.items.filter(i => i.kind === 'mod').map(i => i.id + ':' + i.version_id).sort().join('|');

  useEffect(() => {

    if (loading) return;

    const c = new AbortController(); setUpdates({}); setUpdateFailures(0); setCheckingUpdates(true);

    checkModUpdates(p, data.items, c.signal).then(result => { if (!c.signal.aborted) { setUpdates(result.updates); setUpdateFailures(result.failures); } }).finally(() => { if (!c.signal.aborted) setCheckingUpdates(false); });

    return () => c.abort();

  }, [p.id, p.game_version, p.loader, loading, contentSignature, checkAttempt]);

  const locked = busy || launching || data.running;

  const addingLocked = busy || launching;

  async function refresh() { const result = await api.instance(p); setData(result); setWorld(current => result.worlds.includes(current) ? current : result.worlds[0] || ''); return result; }

  useEffect(() => { let disposed = false; setLoading(true); setFailure(''); setData(empty); setTab('content'); setBrowse(initialBrowse); api.instance(p).then(result => { if (!disposed) { setData(result); setWorld(result.worlds[0] || ''); } }).catch(e => { if (!disposed) setFailure(message(e)); }).finally(() => { if (!disposed) setLoading(false); }); return () => { disposed = true; }; }, [p.id, initialBrowse]);

  useEffect(() => { if (!api.desktop) return; const timer = setInterval(() => { api.instance(p).then(setData).catch(() => {}); }, 5000); return () => clearInterval(timer); }, [p.id]);

  async function action(fn: () => Promise<unknown>, success?: string) { if (busy) return; setBusy(true); try { await fn(); await onReload(); await refresh(); if (success) notify(success); } catch (e) { notify(message(e), true); } finally { setBusy(false); } }

  async function loadLog() { setBusy(true); try { setLog(api.desktop ? await api.call<string>('read_instance_log', { profileId: p.id }) : 'Spielprotokolle sind in der Desktop-App verfügbar.'); } catch (e) { notify(message(e), true); } finally { setBusy(false); } }

  const shown = data.items.filter(item => (kind === 'all' || item.kind === kind) && `${item.title} ${item.filename}`.toLowerCase().includes(query.toLowerCase())).sort((a, b) => sort === 'za' ? b.title.localeCompare(a.title) : sort === 'type' ? a.kind.localeCompare(b.kind) || a.title.localeCompare(b.title) : a.title.localeCompare(b.title));

  async function installUpdate(update: ModUpdate) {

    await api.call('install_instance_content', { request: { profile_id: p.id, project_id: update.projectId, kind: 'mod', world: null, version_id: update.versionId } });

  }

  async function updateAll() {

    await action(async () => {

      let count = 0; const failures: string[] = [];

      for (const update of Object.values(updates)) { try { await installUpdate(update); count++; } catch (e) { failures.push(update.title + ': ' + message(e)); } }

      notify(failures.length ? count + ' Mods aktualisiert. ' + failures.join(' / ') : count + ' Mods aktualisiert.', failures.length > 0);

    });

  }

  if (details && !details.project_id) return <LocalContentDetails item={details} profile={p} onClose={()=>setDetails(null)} onReload={async()=>{await onReload();await refresh();}} notify={notify}/>;
  if (details?.project_id) return <ProjectDetails id={details.project_id} kind={details.kind} world={details.world || undefined} profiles={[p]} onClose={()=>setDetails(null)} onReload={async()=>{await onReload();await refresh();}} notify={notify}/>;

  if (browse) return <ContentBrowser profile={p} data={data} onBack={() => setBrowse(false)} onRefresh={async () => { await onReload(); await refresh(); }} notify={notify} locked={addingLocked} />;

  return <div className="instance-workspace">

    <button className="text-button back-link" onClick={onBack}><ArrowLeft size={15} />Alle Instanzen</button>

    <div className="instance-heading"><div className={`instance-emblem ${p.loader}`}><ProfileIcon profile={p} size={64}/></div><div className="instance-title"><h1>{p.name}</h1><div className="instance-meta"><span><Layers3 size={14} />{p.loader === 'vanilla' ? 'Vanilla' : p.loader.charAt(0).toUpperCase() + p.loader.slice(1)} {p.game_version}</span><span><HardDrive size={14} />{p.settings.memory.max / 1024} GB RAM</span><span><Clock3 size={14} />{p.last_played ? `Zuletzt ${new Date(p.last_played).toLocaleDateString('de')}` : 'Noch nicht gespielt'}</span></div></div><div className="instance-heading-actions"><button className="button light" disabled={locked} onClick={onLaunch}>{launching ? <LoaderCircle size={17} className="spin" /> : <Play size={17} />} {data.running ? 'Spiel läuft' : launching ? 'Startet …' : 'Spielen'}</button><button className="button square" aria-label={pinned?"Instanz lösen":"Instanz anheften"} aria-pressed={pinned} onClick={onPin}><Pin size={18}/></button><button className="button square" aria-label="Instanzeinstellungen" onClick={() => { setName(p.name); setMemory(p.settings.memory.max); setSettings(true); }}><Settings2 size={19} /></button></div></div>

    <div className="instance-tabs">{[{ id: 'content', label: 'Inhalte', icon: Package }, { id: 'files', label: 'Dateien', icon: Folder }, { id: 'worlds', label: 'Welten', icon: Globe2 }, { id: 'logs', label: 'Protokolle', icon: FileText }].map(t => <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => { setTab(t.id); if (t.id === 'logs') loadLog(); }}><t.icon size={16} />{t.label}</button>)}</div>

    {failure && <div className="instance-notice error">{failure}<button className="text-button" onClick={() => action(async () => { await refresh(); setFailure(''); })}>Erneut laden</button></div>}

    {data.running && <div className="instance-notice">Minecraft läuft in dieser Instanz. Beende das Spiel, bevor du Inhalte änderst.</div>}

    {data.pending_restart && <div className="instance-notice pending-notice">Neue Inhalte sind vorgemerkt. Minecraft neu starten, um sie zu laden.{!!data.pending_content?.length && <small>{data.pending_content.slice(0,8).join(' · ')}{data.pending_content.length>8?' …':''}</small>}</div>}

    {tab === 'content' && <>

      <div className="instance-toolbar"><label className="search-field"><Search size={18} /><input aria-label="Installierte Inhalte suchen" placeholder={`${data.items.length} Inhalte durchsuchen …`} value={query} onChange={e => setQuery(e.target.value)} /></label><button className="button" disabled={addingLocked || !api.desktop} onClick={() => { setImportKind('auto'); setImportOpen(true); }}><Upload size={16} />Dateien importieren</button><button className="button light" disabled={addingLocked} onClick={() => setBrowse(true)}><Plus size={17} />Inhalte entdecken</button></div>

      <div className="instance-filters"><select aria-label="Installierte Inhalte sortieren" value={sort} onChange={e => setSort(e.target.value)}><option value="az">Name (A–Z)</option><option value="za">Name (Z–A)</option><option value="type">Inhaltstyp</option></select><div className="content-pills">{(['all', 'mod', 'resourcepack', 'datapack', 'shader'] as const).map(k => <button key={k} className={kind === k ? 'active' : ''} onClick={() => setKind(k)}>{k === 'all' ? 'Alle' : labels[k]}</button>)}</div><div className="filter-actions">{Object.keys(updates).length > 0 && <button className="text-button" disabled={locked || !api.desktop || checkingUpdates} onClick={updateAll}><ArrowDownToLine size={15} />Alle aktualisieren ({Object.keys(updates).length})</button>}<button className="text-button" disabled={busy || launching} onClick={() => action(async () => { await refresh(); setCheckAttempt(n => n + 1); })}><RefreshCw size={15} className={busy ? 'spin' : ''} />Aktualisieren</button></div></div>

      {data.items.some(i => i.kind === 'mod' && i.project_id && i.version_id) && <div className="update-check-status" role="status">{checkingUpdates ? 'Mod-Updates werden geprüft …' : updateFailures ? updateFailures + ' Mods konnten nicht geprüft werden.' : Object.keys(updates).length ? Object.keys(updates).length + ' Mod-Updates verfügbar.' : 'Keine kompatiblen Mod-Updates verfügbar.'}{!checkingUpdates && updateFailures > 0 && <button className="text-button" onClick={() => setCheckAttempt(n => n + 1)}>Erneut prüfen</button>}</div>}

      <div className="content-table"><div className="content-table-head"><span>Projekt</span><span>Version / Datei</span><span>Aktionen</span></div>{loading ? <div className="table-empty"><LoaderCircle className="spin" size={25} /><p>Inhalte werden geladen …</p></div> : shown.length ? shown.map(item => <div className={`content-table-row ${!item.enabled ? 'disabled-content' : ''}`} key={item.id}><div className="content-project">{item.icon_url ? <img src={item.icon_url} alt="" loading="lazy" /> : <div className="content-icon"><Package size={23} /></div>}<div><button className="project-title-link" onClick={()=>setDetails(item)}>{item.title}</button><span>{item.author || (item.project_id ? 'Modrinth' : 'Lokale Datei')}<i />{labels[item.kind]}{item.world && ` · ${item.world}`}</span></div></div><div className="content-version"><strong>{item.version || 'Lokal'}</strong>{updates[item.id] && <small className="content-update-tag">Update: {updates[item.id].version}</small>}<span title={item.filename}>{item.filename}</span></div><div className="content-actions">{item.kind !== 'mod' && item.project_id && <button className="icon-button" aria-label={`${item.title} aktualisieren`} title="Kompatible Version aktualisieren" disabled={locked || !api.desktop} onClick={() => action(() => api.call('change_instance_content', { profileId: p.id, itemId: item.id, action: 'update' }), 'Inhalt aktualisiert.')}><RefreshCw size={16} /></button>}{updates[item.id] && <button className="icon-button" aria-label={`${item.title} aktualisieren`} title={`Auf ${updates[item.id].version} aktualisieren`} disabled={locked || !api.desktop || checkingUpdates} onClick={() => action(() => installUpdate(updates[item.id]), 'Mod aktualisiert.')}><ArrowDownToLine size={16} /></button>}<button className={`toggle ${item.enabled ? 'on' : ''}`} role="switch" aria-checked={item.enabled} aria-label={`${item.title} aktivieren`} disabled={locked || !api.desktop} onClick={() => action(() => api.call('change_instance_content', { profileId: p.id, itemId: item.id, action: 'toggle' }))}><span /></button><button className="icon-button" aria-label={`${item.title} entfernen`} disabled={locked || !api.desktop} onClick={() => setRemove(item)}><Trash2 size={16} /></button></div></div>) : <div className="table-empty"><Package size={32} /><h2>{data.items.length ? 'Keine passenden Inhalte.' : 'Deine Instanz. Dein Inhalt.'}</h2><p>{data.items.length ? 'Ändere die Suche oder den Filter.' : 'Entdecke Mods, Ressourcenpakete, Datenpakete und Shader auf Modrinth.'}</p><button className="button light" onClick={() => setBrowse(true)}><Plus size={16} />Inhalte entdecken</button></div>}</div>

      <p className="instance-footnote">Alle Dateien gehören ausschließlich zu dieser Instanz. Ressourcenpakete und Shader wählst du anschließend in Minecraft aus. Datenpakete werden der gewählten Welt zugeordnet.</p>

    </>}

    {tab === 'files' && <><div className="pane-heading"><div><h2>Instanzdateien</h2><p className="directory-label">{data.directory}</p></div><button className="button" disabled={!api.desktop} onClick={() => action(() => api.call('open_instance_path', { profileId: p.id }))}><FolderOpen size={16} />Ordner öffnen</button></div><div className="file-list">{data.files.map(file => <button key={file.name} onClick={() => action(() => api.call('open_instance_path', { profileId: p.id, relative: file.name }))}>{file.directory ? <Folder size={18} /> : <FileText size={18} />}<strong>{file.name}</strong><span>{file.directory ? 'Ordner' : `${formatCount(file.size)} B`}</span><ArrowRight size={15} /></button>)}{!data.files.length && <div className="table-empty"><Folder size={30} /><p>Diese Instanz ist noch leer. Inhalte und Minecraft legen ihre Dateien hier an.</p></div>}</div></>}

    {tab === 'worlds' && <><div className="pane-heading"><div><h2>Deine Welten</h2><p>Nur Spielstände aus dieser Instanz.</p></div><button className="button" disabled={busy} onClick={() => action(refresh)}><RefreshCw size={16} />Aktualisieren</button></div><div className="world-list">{data.worlds.map(w => <div key={w}><div className="content-icon"><Globe2 size={24} /></div><div><strong>{w}</strong><p>Eigener Spielstand · {data.items.filter(i => i.world === w).length} Datenpakete</p></div><button className="button" onClick={() => action(() => api.call('open_instance_path', { profileId: p.id, relative: `saves/${w}` }))}><FolderOpen size={16} />Weltordner</button></div>)}{!data.worlds.length && <div className="table-empty"><Globe2 size={32} /><h2>Eine neue Welt wartet.</h2><p>Erstelle in Minecraft eine Welt. Sie erscheint danach hier und kann eigene Datenpakete erhalten.</p><button className="button light" disabled={locked} onClick={onLaunch}><Play size={16} />Minecraft starten</button></div>}</div></>}

    {tab === 'logs' && <><div className="pane-heading"><div><h2>Spielprotokoll</h2><p>Vollständige latest.log dieser Instanz. Zugangstokens werden ausgeblendet.</p></div><button className="button" disabled={busy} onClick={loadLog}><RefreshCw size={16} className={busy ? 'spin' : ''} />Neu laden</button></div><pre className="instance-log">{log || 'Protokoll wird geladen …'}</pre></>}

    {settings && <InstanceDialog title="Instanzeinstellungen" className="instance-settings-modal" onClose={() => { if (!busy) setSettings(false); }}><InstanceSettings profile={p} directory={data.directory} locked={locked} canSave={api.desktop} onClose={() => setSettings(false)} onOpenFolder={() => action(() => api.call('open_instance_path', { profileId: p.id }))} onSave={changes => action(async () => { await api.call('configure_vertix_instance', { profileId: p.id, request: changes }); setSettings(false); }, 'Instanz gespeichert.')} /></InstanceDialog>}

    {remove && <InstanceDialog title="Inhalt entfernen?" onClose={() => setRemove(null)}><p className="dialog-copy">„{remove.title}“ wird aus dieser Instanz entfernt. Andere Instanzen bleiben unverändert.</p><div className="dialog-actions"><button className="button" onClick={() => setRemove(null)}>Behalten</button><button className="button danger" disabled={locked} onClick={() => action(async () => { await api.call('change_instance_content', { profileId: p.id, itemId: remove.id, action: 'remove' }); setRemove(null); }, 'Inhalt entfernt.')}><Trash2 size={16} />Entfernen</button></div></InstanceDialog>}

    {importOpen && <InstanceDialog title="Dateien importieren" onClose={() => setImportOpen(false)}><label className="field">Inhaltstyp<select value={importKind} onChange={e => setImportKind(e.target.value as ContentKind | 'auto')}><option value="auto">Automatisch erkennen</option>{Object.entries(labels).filter(([k]) => k !== 'mod' || p.loader !== 'vanilla').map(([k,v]) => <option key={k} value={k}>{v}</option>)}</select></label>{(importKind === 'datapack' || importKind === 'auto') && <WorldSelect worlds={data.worlds} world={world} onChange={setWorld} />}<p className="dialog-copy">JAR- und ZIP-Dateien werden automatisch erkannt. Welten werden entpackt. Für Datenpakete wähle die Zielwelt. Bestehende Dateien werden nicht überschrieben.</p><div className="dialog-actions"><button className="button" onClick={() => setImportOpen(false)}>Abbrechen</button><button className="button light" disabled={addingLocked || (importKind === 'datapack' && !world)} onClick={() => action(async () => { const count = await api.call<number>('import_instance_content', { profileId: p.id, kind: importKind, world: world || null }); setImportOpen(false); if (count) notify(`${count} Dateien ${data.running ? 'für den nächsten Spielstart vorgemerkt' : 'importiert'}.`); })}><Upload size={16} />Dateien auswählen</button></div></InstanceDialog>}

  </div>;

}



function ContentBrowser({ profile: p, data, onBack, onRefresh, notify, locked }: { profile: Profile; data: InstanceSnapshot; onBack: () => void; onRefresh: () => Promise<void>; notify: Notify; locked: boolean }) {

  const [kind,setKind] = useState<ContentKind>(p.loader === 'vanilla' ? 'resourcepack' : 'mod'), [query,setQuery] = useState(''), [sort,setSort] = useState('downloads'), [limit,setLimit] = useState(20), [page,setPage] = useState(0), [category,setCategory] = useState('');

  const [warning,setWarning] = useState(''), [hits,setHits] = useState<Project[]>([]), [total,setTotal] = useState(0), [loading,setLoading] = useState(true), [error,setError] = useState(''), [attempt,setAttempt] = useState(0), [installing,setInstalling] = useState<string | null>(null), [world,setWorld] = useState(data.worlds[0] || '');

  useEffect(() => { const c = new AbortController(); setLoading(true); setError(''); const timer = setTimeout(() => { api.searchContent(p,{kind,query,sort,offset:page * limit,limit,category},c.signal).then(result => { if(!c.signal.aborted){setHits(result.hits); setTotal(result.total_hits);setWarning(result.warning||'');} }).catch(e => { if (!c.signal.aborted) setError(message(e)); }).finally(() => { if (!c.signal.aborted) setLoading(false); }); }, 250); return () => { clearTimeout(timer); c.abort(); }; }, [p.id,p.game_version,p.loader,kind,query,sort,page,limit,category,attempt]);

  const pages = Math.max(1,Math.ceil(total / limit));

  const changeKind = (k: ContentKind) => { setKind(k); setCategory(''); setQuery(''); setPage(0); };

  async function install(project: Project) { if (installing) return; if (!api.desktop) { notify('Inhalte installierst du in der Desktop-App.',true); return; } setInstalling(project.project_id); try { await api.call('install_instance_content',{request:{profile_id:p.id,project_id:project.project_id,kind,world:kind === 'datapack' ? world : null,version_id:null}}); await onRefresh(); notify(`${project.title} in ${p.name} installiert.`); } catch(e) { notify(message(e),true); } finally {setInstalling(null);} }

  const categoryOptions = kind === 'mod' ? [['optimization','Optimierung'],['adventure','Abenteuer'],['technology','Technik'],['utility','Werkzeuge'],['library','Bibliotheken'],['decoration','Dekoration']] : kind === 'resourcepack' ? [['16x','16×'],['32x','32×'],['64x','64×'],['realistic','Realistisch'],['vanilla-like','Vanilla-nah']] : kind === 'shader' ? [['realistic','Realistisch'],['fantasy','Fantasy'],['vanilla-like','Vanilla-nah']] : [['worldgen','Weltgenerierung'],['adventure','Abenteuer'],['utility','Werkzeuge']];

  return <div className="content-browser">{warning && <p className="instance-notice" role="status">{warning}</p>}<div className="browse-heading"><button className="round-back" aria-label="Zur Instanz zurück" onClick={onBack}><ArrowLeft size={21} /></button><div><h1>{p.name}</h1><p>Inhalte entdecken <i />Minecraft {p.game_version}<i />{p.loader}</p></div><span className="source-label">{kind==='mod'?'MODRINTH + CURSEFORGE':'MODRINTH'}</span></div><div className="browse-types">{(Object.keys(labels) as ContentKind[]).map(k => <button className={kind === k ? 'active' : ''} key={k} disabled={k === 'mod' && p.loader === 'vanilla'} onClick={() => changeKind(k)}>{labels[k]}</button>)}</div><label className="search-field browse-search"><Search size={20} /><input aria-label="Inhalte durchsuchen" value={query} onChange={e => {setQuery(e.target.value);setPage(0);}} placeholder={`${labels[kind]} durchsuchen …`} /></label><div className="browse-filters"><label>Sortieren<select aria-label="Inhalte sortieren" value={sort} onChange={e => {setSort(e.target.value);setPage(0);}}><option value="downloads">Beliebt</option><option value="relevance">Relevanz</option><option value="follows">Meist gefolgt</option><option value="updated">Zuletzt aktualisiert</option><option value="newest">Neu hinzugefügt</option></select></label><label>Anzeigen<select aria-label="Ergebnisse pro Seite" value={limit} onChange={e => {setLimit(Number(e.target.value));setPage(0);}}>{[20,40,60].map(n => <option key={n} value={n}>{n}</option>)}</select></label><label><SlidersHorizontal size={14} />Kategorie<select aria-label="Inhaltskategorie" value={category} onChange={e => {setCategory(e.target.value);setPage(0);}}><option value="">Alle Kategorien</option>{categoryOptions.map(([value,label]) => <option value={value} key={value}>{label}</option>)}</select></label><div className="pagination"><button aria-label="Vorherige Seite" disabled={page === 0 || loading} onClick={() => setPage(n => n-1)}><ChevronLeft size={17} /></button><span>{page+1}<small> / {pages.toLocaleString('de')}</small></span><button aria-label="Nächste Seite" disabled={page+1 >= pages || loading} onClick={() => setPage(n => n+1)}><ChevronRight size={17} /></button></div></div><div className="browser-context"><span><Layers3 size={12} />{p.game_version}</span>{kind === 'mod' && <span>{p.loader}</span>}<p>{total.toLocaleString('de')} Ergebnisse · kompatible Versionen für diese Instanz</p></div>

    {kind === 'datapack' && <div className="browser-help"><WorldSelect worlds={data.worlds} world={world} onChange={setWorld} /><p>Datenpakete gehören zu einer Welt. Ohne vorhandene Welt kannst du stöbern; erstelle zum Installieren zuerst eine Welt in dieser Instanz.</p></div>}

    {kind === 'shader' && <div className="instance-notice">Shader benötigen Iris oder OptiFine in dieser Instanz. Das Shaderpaket wählst du danach in den Grafikeinstellungen von Minecraft aus.</div>}

    {loading ? <div className="table-empty"><LoaderCircle className="spin" size={28} /><p>Modrinth wird durchsucht …</p></div> : error ? <div className="table-empty"><h2>Inhalte gerade nicht erreichbar.</h2><p>{error}</p><button className="button" onClick={() => setAttempt(n => n+1)}>Erneut versuchen</button></div> : <div className="browse-results">{hits.map(project => { const installed=data.items.some(i => i.project_id === project.project_id && i.kind === kind && (kind !== 'datapack' || i.world === world));return <article className="browse-result" key={project.project_id}>{project.icon_url ? <img src={project.icon_url} alt="" loading="lazy" /> : <div className="browse-icon"><Package size={35} /></div>}<div className="browse-result-copy"><div><h2>{project.title}</h2><span>von {project.author}</span></div><p>{project.description}</p><div className="result-tags"><span>{labels[kind]}</span><span>{p.game_version}</span>{kind === 'mod' && <span>{p.loader}</span>}</div></div><div className="browse-result-action"><button className={`button small ${installed ? '' : 'light'}`} disabled={installed || !!installing || locked || (kind === 'datapack' && !world)} onClick={() => install(project)}>{installing === project.project_id ? <LoaderCircle className="spin" size={15} /> : installed ? <Check size={15} /> : <Plus size={15} />}{installed ? 'Installiert' : 'Installieren'}</button><span><ArrowDownToLine size={14} />{formatCount(project.downloads)}</span></div></article>;})}{!hits.length && <div className="table-empty"><Search size={30} /><h2>Keine passenden Inhalte gefunden.</h2><p>Ändere den Suchbegriff oder die Kategorie.</p></div>}</div>}

    {!loading && hits.length > 0 && <div className="browse-pagination"><span>Seite {page+1} von {pages.toLocaleString('de')}</span><button className="button" disabled={!page} onClick={() => {setPage(n=>n-1);document.querySelector('.page-content')?.scrollTo({top:0});}}><ChevronLeft size={15} />Zurück</button><button className="button light" disabled={page+1>=pages} onClick={() => {setPage(n=>n+1);document.querySelector('.page-content')?.scrollTo({top:0});}}>Weitere Inhalte<ChevronRight size={15} /></button></div>}

  </div>;

}



function WorldSelect({worlds,world,onChange}:{worlds:string[];world:string;onChange:(world:string)=>void}) { return <label className="field world-select">Zielwelt<select aria-label="Zielwelt für Datenpakete" value={world} onChange={e=>onChange(e.target.value)}>{!worlds.length && <option value="">Noch keine Welt vorhanden</option>}{worlds.map(w=><option key={w} value={w}>{w}</option>)}</select></label>; }

export function InstanceDialog({title,onClose,children,className=''}:{title:string;onClose:()=>void;children:React.ReactNode;className?:string}) {

  const closeRef = useRef(onClose); closeRef.current = onClose;

  useEffect(()=>{const app=document.querySelectorAll<HTMLElement>('.app-shell > .sidebar, .app-shell > .main-shell');const previous=document.activeElement as HTMLElement;app.forEach(e=>e.inert=true);const escape=(e:KeyboardEvent)=>{if(e.key==='Escape')closeRef.current();};document.addEventListener('keydown',escape);return()=>{app.forEach(e=>e.inert=false);previous?.focus();document.removeEventListener('keydown',escape);};},[]);

  return createPortal(<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><div className={`modal ${className}`} role="dialog" aria-modal="true" aria-label={title}><div className="modal-heading"><h2>{title}</h2><button className="icon-button" aria-label="Dialog schließen" onClick={onClose}><X size={18}/></button></div>{children}</div></div>, document.body);

}
