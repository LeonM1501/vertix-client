package client.vertix.core.gui;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.config.Preset;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.List;
import java.util.Locale;
import static client.vertix.core.gui.RenderUtils.*;

public class VertixMenuScreen extends Screen {
    private final Screen parent;
    private boolean presets;
    private Category category = Category.ALL;
    private String query = "";
    private boolean searchFocused;
    private int scroll;
    private SettingsPopup popup;
    private Module draggingHud;
    private int hudOffsetX,hudOffsetY,hudGuideX=-1,hudGuideY=-1;
    private MenuLayout.Rect hudClose(Module m) {return new MenuLayout.Rect(m.getX()+m.getWidth()+3,m.getY(),10,10);}
    private Module hudAt(double x,double y) {
        List<Module> list=modules();for(int i=list.size()-1;i>=0;i--){Module m=list.get(i);if(m.isHud()&&m.isEnabled()&&(new MenuLayout.Rect(m.getX(),m.getY(),m.getWidth(),m.getHeight()).contains(x,y)||hudClose(m).contains(x,y)))return m;}return null;
    }
    private static final Category[] CATEGORIES = Category.values();
    private static final Preset[] PRESETS = { Preset.NORMAL, Preset.PVP, Preset.PERFORMANCE };
    public VertixMenuScreen() { this(null, false); }
    public VertixMenuScreen(Screen parent, boolean presets) {
        super(Component.literal("Vertix Mod Menü")); this.parent = parent; this.presets = presets;
    }
    @Override public boolean isPauseScreen() { return false; }
    private void focusSearch(boolean focused) {
        if (searchFocused != focused) { searchFocused = focused; minecraft.onTextInputFocusChange(this, focused); }
    }
    @Override public void removed() { focusSearch(false); super.removed(); }
    private MenuLayout layout() { return new MenuLayout(width, height); }
    private List<Module> modules() { return VertixCoreMod.getInstance().getModuleManager().getModules(); }
    private void save() { VertixCoreMod.getInstance().getConfigManager().saveConfig(modules()); }
    private List<Module> filtered() {
        String q = query.strip().toLowerCase(Locale.ROOT);
        return modules().stream().filter(m -> (category == Category.ALL || m.getCategory() == category)
                && (m.getName() + " " + m.getDescription()).toLowerCase(Locale.ROOT).contains(q)).toList();
    }
    private MenuLayout.Rect nav(MenuLayout l, int index) {
        return l.nav(index);
    }
    private MenuLayout.Rect tab(MenuLayout l, int index) {
        int w=Math.min(72,(l.panel.w()-120)/3);
        return new MenuLayout.Rect(l.panel.x()+76+index*w,l.panel.y()+10,w-4,24);
    }
    private MenuLayout.Rect settings(MenuLayout.Rect r) { return new MenuLayout.Rect(r.right() - 24, r.y() + 23, 18, 22); }
    private MenuLayout.Rect toggle(MenuLayout.Rect r) { return new MenuLayout.Rect(r.right() - 45, r.bottom() - 23, 36, 17); }
    @Override public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float delta) { drawRect(g, 0, 0, width, height, 0x28000000); }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        MenuLayout l = layout();
        if(minecraft.player==null)for(Module m:modules())if(m.isHud()&&m.isEnabled())m.renderHudPlaceholder(g,minecraft);
        if(hudGuideX>=0)drawRect(g,hudGuideX,0,1,height,0xAAECE9E2);
        if(hudGuideY>=0)drawRect(g,0,hudGuideY,width,1,0xAAECE9E2);
        Module hoverHud=!l.panel.contains(mx,my)?hudAt(mx,my):null;
        if(hoverHud!=null){drawOutline(g,hoverHud.getX()-1,hoverHud.getY()-1,hoverHud.getWidth()+2,hoverHud.getHeight()+2,COLOR_BORDER_HOVER);MenuLayout.Rect x=hudClose(hoverHud);drawText(g,font,"x",x.x()+2,x.y()+1,COLOR_TEXT_SECONDARY,false);}
        drawCard(g, l.panel.x(), l.panel.y(), l.panel.w(), l.panel.h(), 0xD01B1D21, 0x908E9197);
        drawRect(g, l.panel.x() + 1, l.panel.y() + 1, l.panel.w() - 2, 42, 0x70282B30);
        drawText(g,font,"VERTIX",l.panel.x()+12,l.panel.y()+17,COLOR_TEXT_PRIMARY,false);
        for(int i=0;i<3;i++){
            var t=tab(l,i);boolean active=i==(presets?1:0);
            if(active||t.contains(mx,my))drawRect(g,t.x(),t.y(),t.w(),t.h(),active?0x805B6069:0x40434850);
            if(active)drawRect(g,t.x(),t.bottom()-1,t.w(),1,COLOR_ACCENT);
            drawCenteredText(g,font,new String[]{"MODS","PROFILE","HUD"}[i],t.x()+t.w()/2,t.y()+8,active?COLOR_TEXT_PRIMARY:COLOR_TEXT_SECONDARY,false);
        }
        button(g, font, l.close, "x", false, l.close.contains(mx, my));
        drawRect(g, l.rail.right(), l.rail.y(), 1, l.rail.h(), COLOR_BORDER_DEFAULT);
        for (int i = 0; i < CATEGORIES.length; i++) {
            MenuLayout.Rect r = nav(l, i); boolean active = !presets && category == CATEGORIES[i];
            if (active || r.contains(mx, my)) drawRect(g, r.x(), r.y(), r.w(), r.h(), active ? 0xFF303030 : COLOR_BG_CARD);
            if (active) drawRect(g, r.x(), r.y() + 3, 2, r.h() - 6, COLOR_ACCENT);
            String label = CATEGORIES[i] == Category.QOL ? "Komfort" : CATEGORIES[i].getDisplayName();
            drawText(g, font, fit(font, label, r.w() - 14), r.x() + 8, r.y() + (r.h() - 8) / 2, active ? COLOR_TEXT_PRIMARY : COLOR_TEXT_MUTED, false);
        }
        if (presets) renderPresets(g, l, mx, my); else renderMods(g, l, mx, my);
        drawRect(g, l.panel.x() + 1, l.panel.bottom() - 25, l.panel.w() - 2, 1, COLOR_BORDER_DEFAULT);
        String footer = presets ? "Ein Klick aktiviert das Profil." : filtered().size() + " Module   /   " + modules().stream().filter(Module::isEnabled).count() + " aktiv";
        drawText(g, font, fit(font, footer, l.panel.w() - 130), l.panel.x() + 12, l.panel.bottom() - 16, COLOR_TEXT_MUTED, false);
        drawText(g, font, "ESC  Zurück", l.panel.right() - 82, l.panel.bottom() - 16, COLOR_TEXT_SECONDARY, false);
        if (popup != null) { drawRect(g, 0, 0, width, height, 0x38000000); popup.render(g, mx, my, minecraft); }
    }
    private void renderMods(GuiGraphicsExtractor g, MenuLayout l, int mx, int my) {
        drawCard(g, l.search.x(), l.search.y(), l.search.w(), l.search.h(), COLOR_BG_CARD, searchFocused ? COLOR_ACCENT : COLOR_BORDER_DEFAULT);
        String text = query.isEmpty() && !searchFocused ? "Module suchen ..." : query + (searchFocused ? "_" : "");
        drawText(g, font, fit(font, text, l.search.w() - 36), l.search.x() + 8, l.search.y() + 7,
                query.isEmpty() && !searchFocused ? COLOR_TEXT_MUTED : COLOR_TEXT_PRIMARY, false);
        if (!query.isEmpty()) drawText(g, font, "x", l.search.right() - 14, l.search.y() + 7, COLOR_TEXT_SECONDARY, false);
        List<Module> list = filtered(); scroll = Math.clamp(scroll, 0, l.maxScroll(list.size()));
        g.enableScissor(l.content.x(), l.content.y(), l.content.right(), l.content.bottom());
        for (int i = 0; i < list.size(); i++) {
            MenuLayout.Rect r = l.card(i, scroll); if (r.bottom() <= l.content.y() || r.y() >= l.content.bottom()) continue;
            Module m = list.get(i); boolean hover = r.contains(mx, my) && l.content.contains(mx, my);
            drawCard(g, r.x(), r.y(), r.w(), r.h(), m.isEnabled() ? 0xC0484C54 : hover ? 0xB0383B40 : 0x90303439,
                    m.isEnabled() ? COLOR_BORDER_HOVER : hover ? COLOR_BORDER_HOVER : COLOR_BORDER_DEFAULT);
            drawModuleIcon(g, m.getId(), r.x() + 10, r.y() + 13, m.isEnabled() ? COLOR_TEXT_PRIMARY : COLOR_TEXT_MUTED);
            drawText(g, font, fit(font, m.getName(), r.w() - 65), r.x() + 36, r.y() + 10, COLOR_TEXT_PRIMARY, false);
            drawDescription(g, m.getDescription(), r.x() + 36, r.y() + 25, r.w() - 66, 2);
            MenuLayout.Rect s = settings(r);
            if (!m.getSettings().isEmpty()) drawText(g, font, "...", s.x()+2, s.y()+5,
                    s.contains(mx, my) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_MUTED, false);
            drawText(g,font,m.getId().equals("hud_editor")?">":m.isEnabled()?"AN":"AUS",r.right()-25,r.y()+10,m.isEnabled()?COLOR_TEXT_PRIMARY:COLOR_TEXT_MUTED,false);
        }
        if (list.isEmpty()) {
            drawCenteredText(g, font, "Keine Module gefunden", l.content.x() + l.content.w() / 2, l.content.y() + 22, COLOR_TEXT_SECONDARY, false);
            drawCenteredText(g, font, "Suche oder Kategorie ändern.", l.content.x() + l.content.w() / 2, l.content.y() + 39, COLOR_TEXT_MUTED, false);
        }
        g.disableScissor(); scrollbar(g, l, l.maxScroll(list.size()));
    }
    private void drawModuleIcon(GuiGraphicsExtractor g,String id,int x,int y,int color) {
        if(id.contains("fps") || id.contains("cps")){drawOutline(g,x,y,18,21,color);drawText(g,font,id.contains("fps")?"F":"C",x+6,y+7,color,false);}
        else if(id.contains("coordinate") || id.contains("waypoint")){drawOutline(g,x+4,y,10,12,color);drawRect(g,x+8,y+12,2,5,color);drawRect(g,x+3,y+18,12,1,color);}
        else if(id.contains("key")){drawOutline(g,x+6,y,7,7,color);drawOutline(g,x,y+9,7,7,color);drawOutline(g,x+9,y+9,7,7,color);}
        else if(id.contains("zoom")){drawOutline(g,x+1,y+1,12,12,color);drawRect(g,x+12,y+13,5,2,color);drawRect(g,x+6,y+4,1,6,color);drawRect(g,x+4,y+6,5,1,color);}
        else {drawOutline(g,x+1,y+2,16,16,color);drawRect(g,x+6,y+7,6,6,color);}
    }
    private void drawDescription(GuiGraphicsExtractor g, String text, int x, int y, int w, int lines) {
        for (int line = 0; line < lines && !text.isEmpty(); line++) {
            String part = text;
            if (font.width(part) > w) {
                if (line == lines - 1) { part = fit(font, part, w); text = ""; }
                else { while (font.width(part) > w) part = part.substring(0, part.length() - 1);
                    int space = part.lastIndexOf(' '); if (space > 0) part = part.substring(0, space); text = text.substring(part.length()).stripLeading(); }
            } else text = "";
            drawText(g, font, part, x, y + line * 11, COLOR_TEXT_MUTED, false);
        }
    }
    private void renderPresets(GuiGraphicsExtractor g, MenuLayout l, int mx, int my) {
        drawText(g, font, "Deine Spielweise", l.search.x(), l.search.y() + 3, COLOR_TEXT_PRIMARY, false);
        drawText(g, font, fit(font, "Module mit einem Klick abstimmen.", l.search.w()), l.search.x(), l.search.y() + 16, COLOR_TEXT_MUTED, false);
        int max = Math.max(0, PRESETS.length * 80 - 8 - l.content.h()); scroll = Math.clamp(scroll, 0, max);
        g.enableScissor(l.content.x(), l.content.y(), l.content.right(), l.content.bottom());
        for (int i = 0; i < PRESETS.length; i++) {
            Preset p = PRESETS[i]; boolean active = VertixCoreMod.getInstance().getConfigManager().getActivePreset() == p;
            MenuLayout.Rect r = new MenuLayout.Rect(l.content.x(), l.content.y() + i * 80 - scroll, l.content.w(), 72);
            drawCard(g, r.x(), r.y(), r.w(), r.h(), r.contains(mx, my) ? COLOR_BG_CARD_HOVER : COLOR_BG_CARD, active ? COLOR_ACCENT : COLOR_BORDER_DEFAULT);
            drawText(g, font, p.getDisplayName(), r.x() + 12, r.y() + 11, COLOR_TEXT_PRIMARY, false);
            drawDescription(g, p.getDescription(), r.x() + 12, r.y() + 29, r.w() - 24, 2);
            drawText(g, font, active ? "AKTIV" : "Aktivieren", r.right() - 72, r.y() + 11, active ? COLOR_ACCENT : COLOR_TEXT_MUTED, false);
        }
        g.disableScissor(); scrollbar(g, l, max);
    }
    private void scrollbar(GuiGraphicsExtractor g, MenuLayout l, int max) {
        if (max <= 0) return;
        int thumb = Math.max(18, l.content.h() * l.content.h() / (l.content.h() + max));
        drawRect(g, l.content.right() + 5, l.content.y(), 2, l.content.h(), COLOR_BORDER_DEFAULT);
        drawRect(g, l.content.right() + 5, l.content.y() + scroll * (l.content.h() - thumb) / max, 2, thumb, COLOR_TEXT_SECONDARY);
    }
    @Override public boolean mouseClicked(MouseButtonEvent e, boolean twice) {
        double mx = e.x(), my = e.y(); int button = e.button();
        if (popup != null) { popup.mouseReleased(); if (!popup.isMouseInside(mx, my) || popup.mouseClicked(mx, my, button)) popup = null; return true; }
        MenuLayout l = layout();
        if(!l.panel.contains(mx,my)) {
            Module m=hudAt(mx,my);
            if(m!=null && button==InputConstants.MOUSE_BUTTON_LEFT) {
                if(hudClose(m).contains(mx,my)){m.setEnabled(false);VertixCoreMod.getInstance().getConfigManager().setActivePreset(Preset.CUSTOM);save();return true;}
                draggingHud=m;hudOffsetX=(int)mx-m.getX();hudOffsetY=(int)my-m.getY();focusSearch(false);return true;
            }
            if(m!=null && button==InputConstants.MOUSE_BUTTON_RIGHT && !m.getSettings().isEmpty()){focusSearch(false);popup=new SettingsPopup(m,m.getX(),m.getY(),width,height);return true;}
        }
        if (button == InputConstants.MOUSE_BUTTON_LEFT) {
            if (l.close.contains(mx, my)) { save(); minecraft.setScreenAndShow(null); return true; }
            for(int i=0;i<3;i++)if(tab(l,i).contains(mx,my)){
                focusSearch(false);scroll=0;
                if(i==2)minecraft.setScreenAndShow(new HudEditorScreen(this));else presets=i==1;
                return true;
            }
            for (int i = 0; i < CATEGORIES.length; i++) if (nav(l, i).contains(mx, my)) {
                presets = false; category = CATEGORIES[i]; scroll = 0; focusSearch(false); return true;
            }
            focusSearch(!presets && l.search.contains(mx, my));
            if (searchFocused) { if (mx >= l.search.right() - 24) { query = ""; scroll = 0; } return true; }
        }
        if (!l.content.contains(mx, my)) return super.mouseClicked(e, twice);
        if (presets && button == InputConstants.MOUSE_BUTTON_LEFT) {
            for (int i = 0; i < PRESETS.length; i++) if (new MenuLayout.Rect(l.content.x(), l.content.y() + i * 80 - scroll, l.content.w(), 72).contains(mx, my)) {
                VertixCoreMod.getInstance().getConfigManager().applyPreset(PRESETS[i], modules()); return true;
            }
        } else if (!presets) {
            List<Module> list = filtered();
            for (int i = 0; i < list.size(); i++) {
                MenuLayout.Rect r = l.card(i, scroll); if (!r.contains(mx, my)) continue; Module m = list.get(i);
                if ((button == InputConstants.MOUSE_BUTTON_RIGHT || settings(r).contains(mx, my)) && !m.getSettings().isEmpty()) {
                    focusSearch(false); popup = new SettingsPopup(m, r.x(), r.y(), width, height); return true;
                }
                if (button == InputConstants.MOUSE_BUTTON_LEFT) {
                    if (m.getId().equals("hud_editor")) minecraft.setScreenAndShow(new HudEditorScreen(this));
                    else { m.toggle(); VertixCoreMod.getInstance().getConfigManager().setActivePreset(Preset.CUSTOM); save(); }
                    return true;
                }
            }
        }
        return super.mouseClicked(e, twice);
    }
    @Override public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (popup != null) { popup.mouseScrolled(vertical); return true; }
        MenuLayout l = layout(); if (!l.content.contains(mx, my)) return super.mouseScrolled(mx, my, horizontal, vertical);
        int max = presets ? Math.max(0, 232 - l.content.h()) : l.maxScroll(filtered().size());
        scroll = Math.clamp(scroll - (int) (vertical * 24), 0, max); return true;
    }
    @Override public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if(draggingHud!=null){int[][] others=modules().stream().filter(m->m.isHud()&&m.isEnabled()&&m!=draggingHud).map(m->new int[]{m.getX(),m.getY(),m.getWidth(),m.getHeight()}).toArray(int[][]::new);var p=HudPlacement.place((int)e.x()-hudOffsetX,(int)e.y()-hudOffsetY,draggingHud.getWidth(),draggingHud.getHeight(),width,height,true,others);draggingHud.setX(p.x());draggingHud.setY(p.y());hudGuideX=p.guideX();hudGuideY=p.guideY();return true;}
        if (popup != null) { popup.mouseDragged(e.x(), e.y()); return true; } return super.mouseDragged(e, dx, dy);
    }
    @Override public boolean mouseReleased(MouseButtonEvent e) {
        if(draggingHud!=null){draggingHud=null;hudGuideX=hudGuideY=-1;save();return true;}
        if (popup != null) { popup.mouseReleased(); return true; } return super.mouseReleased(e);
    }
    @Override public boolean charTyped(CharacterEvent e) {
        if (searchFocused && query.codePointCount(0, query.length()) < 64) { query += e.codepointAsString(); scroll = 0; return true; }
        return super.charTyped(e);
    }
    @Override public boolean keyPressed(KeyEvent e) {
        if (e.key() == InputConstants.KEY_RSHIFT) { if (popup != null) popup.mouseReleased(); save(); minecraft.setScreenAndShow(null); return true; }
        if (e.key() == InputConstants.KEY_ESCAPE) { if (popup != null) { popup.mouseReleased(); popup = null; } else if (searchFocused) focusSearch(false); else onClose(); return true; }
        if (searchFocused) {
            if (e.key() == InputConstants.KEY_BACKSPACE && !query.isEmpty()) { query = query.substring(0, query.offsetByCodePoints(query.length(), -1)); scroll = 0; return true; }
            if (e.key() == InputConstants.KEY_RETURN) { focusSearch(false); return true; }
        }
        return super.keyPressed(e);
    }
    @Override public void onClose() { if (popup != null) { popup.mouseReleased(); popup = null; return; } save(); minecraft.setScreenAndShow(parent); }
}
