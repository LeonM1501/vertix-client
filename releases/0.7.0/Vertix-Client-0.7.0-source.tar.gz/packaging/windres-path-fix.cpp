#include <fstream>
#include <iterator>
#include <string>
#include <process.h>
#include <cstdlib>
#include <cstdio>
int main(int argc, char **argv) {
    for (int i = 1; i + 1 < argc; ++i) {
        if (std::string(argv[i]) != "--input") continue;
        std::ifstream input(argv[i + 1], std::ios::binary);
        if (!input) return 2;
        std::string text((std::istreambuf_iterator<char>(input)), {});
        input.close();
        const std::string prefix = "\\\\\\\\?\\\\";
        for (size_t p; (p = text.find(prefix)) != std::string::npos;) text.erase(p, prefix.size());
        std::ofstream output(argv[i + 1], std::ios::binary | std::ios::trunc);
        if (!(output << text)) return 3;
    }
    const char *compiler = std::getenv("VERTIX_REAL_WINDRES");
    if (!compiler) return 4;
    return static_cast<int>(_spawnv(_P_WAIT, compiler, const_cast<const char *const *>(argv)));
}
