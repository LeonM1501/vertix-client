# Vertix Client 0.7.0 / Core 1.2.0

- Neues optionales Modul **Discord Streaming** unter R-Shift → Mod Menü → Performance. Vor dem Stream aktivieren; standardmäßig ausgeschaltet.
- Begrenzt Minecraft auf zunächst 60 FPS, einstellbar von 30 bis 240 FPS. Ein niedrigeres Minecraft-Limit sowie Hintergrund-/AFK-Limits bleiben erhalten. Das Modul schafft GPU-Spielraum für die Bildschirmaufnahme; es erhöht nicht die Minecraft-FPS.
- Unter Windows verwendet Vollbild während des Streaming-Modus ein randloses Fenster. F11 und die Rückkehr zur bisherigen Fenstergröße bleiben nutzbar. 26.3 verwendet die vorhandene SDL-Implementierung, 26.2 eine eigene GLFW-Anpassung.
- Randloses Vollbild verwendet die Desktop-Auflösung des Monitors; eine abweichende exklusive Vollbildauflösung wird währenddessen nicht verwendet.
- Ausschalten hebt das zusätzliche FPS-Limit auf und stellt den vorherigen Vollbildmodus wieder her. Minecraft-Optionen werden nicht dauerhaft überschrieben.
- Core 1.2.0 wird beim nächsten Start unterstützter Fabric-Instanzen mit Minecraft 26.2 oder 26.3 installiert. Bereits laufendes Minecraft neu starten.

Die Wirkung auf Discord hängt von GPU, Encoder, Spielszene und Aufnahme-Einstellungen ab. Ein echter Discord-Stream wurde für dieses Release nicht vermessen.
