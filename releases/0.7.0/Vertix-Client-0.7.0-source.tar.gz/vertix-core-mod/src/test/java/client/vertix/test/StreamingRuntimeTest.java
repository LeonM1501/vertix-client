package client.vertix.test;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Setting;
import client.vertix.core.modules.qol.DiscordStreamingModule;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Isolated offline test mod; never packaged in Vertix Core. */
@Mixin(Minecraft.class)
public class StreamingRuntimeTest {
    @Unique private int vertix$ticks;
    @Unique private int vertix$vanillaLimit;
    @Unique private int vertix$windowWidth;
    @Unique private int vertix$windowHeight;

    @Inject(method = "tick", at = @At("TAIL"))
    private void vertix$verify(CallbackInfo ci) throws Exception {
        Minecraft mc = (Minecraft) (Object) this;
        // Do not change the SDL display mode while the startup resource reload is running.
        if (!(mc.gui.screen() instanceof net.minecraft.client.gui.screens.TitleScreen)) return;
        DiscordStreamingModule module = (DiscordStreamingModule) VertixCoreMod.getInstance().getModuleManager().getModule("discord_streaming");
        int tick = ++vertix$ticks;
        if (tick == 40) {
            check(!module.isEnabled(), "streaming must be opt-in");
            vertix$vanillaLimit = mc.getFramerateLimitTracker().getFramerateLimit();
            vertix$windowWidth = mc.getWindow().getWidth();
            vertix$windowHeight = mc.getWindow().getHeight();
            check(module.limit(10) == 10, "retain lower vanilla limits");
            check(module.limit(260) == 60, "default stream cap");
            Setting.NumberSetting fps = module.getSetting("stream_fps", Setting.NumberSetting.class);
            fps.setValue(120.0);
            check(module.limit(260) == 120, "custom stream cap");
            fps.setValue(-100.0);
            check(module.limit(260) == 30, "clamp saved values");
            fps.setValue(30.0);
            try {
                mc.getWindow().getClass().getMethod("setExclusiveFullscreen", boolean.class).invoke(mc.getWindow(), true);
            } catch (NoSuchMethodException ignored) { }
            module.setEnabled(true);
        }
        if (tick == 60) {
            check(mc.getFramerateLimitTracker().getFramerateLimit() == Math.min(30, vertix$vanillaLimit), "live frame limiter injection");
            fullscreen(mc, true);
        }
        if (tick == 90) {
            checkBorderless(mc);
            fullscreen(mc, false);
        }
        if (tick == 120) {
            check(mc.getWindow().getWidth() == vertix$windowWidth && mc.getWindow().getHeight() == vertix$windowHeight, "restore window size after F11");
            fullscreen(mc, true);
        }
        if (tick == 150) {
            checkBorderless(mc);
            module.setEnabled(false);
        }
        if (tick == 180) {
            check(mc.getFramerateLimitTracker().getFramerateLimit() == vertix$vanillaLimit, "restore vanilla frame limiter");
            try {
                mc.getWindow().getClass().getMethod("setExclusiveFullscreen", boolean.class);
                var preference = mc.getWindow().getClass().getDeclaredField("exclusiveFullscreen");
                preference.setAccessible(true);
                check(preference.getBoolean(mc.getWindow()), "restore exclusive fullscreen preference");
            } catch (NoSuchMethodException ignored) { }
            fullscreen(mc, false);
        }
        if (tick == 210) {
            check(mc.getWindow().getWidth() == vertix$windowWidth && mc.getWindow().getHeight() == vertix$windowHeight, "restore bounds after disabling in fullscreen");
            System.out.println("VERTIX_STREAMING_TEST_PASSED");
            mc.stop();
        }
    }

    @Unique private static void fullscreen(Minecraft mc, boolean value) throws Exception {
        try {
            mc.getWindow().getClass().getMethod("setFullscreen", boolean.class).invoke(mc.getWindow(), value);
        } catch (NoSuchMethodException e) {
            mc.getWindow().getClass().getMethod("toggleFullScreen").invoke(mc.getWindow());
        }
        mc.getWindow().updateFullscreenIfChanged();
    }

    @Unique private static void checkBorderless(Minecraft mc) throws Exception {
        long handle = mc.getWindow().handle();
        try {
            check(!(boolean) mc.getWindow().getClass().getMethod("isExclusiveFullscreen").invoke(mc.getWindow()), "no exclusive SDL fullscreen");
        } catch (NoSuchMethodException e) {
            Class<?> glfw = Class.forName("org.lwjgl.glfw.GLFW");
            check((long) glfw.getMethod("glfwGetWindowMonitor", long.class).invoke(null, handle) == 0, "no exclusive GLFW monitor");
            int decorated = glfw.getField("GLFW_DECORATED").getInt(null);
            check((int) glfw.getMethod("glfwGetWindowAttrib", long.class, int.class).invoke(null, handle, decorated) == 0, "no window border");
        }
    }

    @Unique private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
