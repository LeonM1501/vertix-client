package client.vertix.core.mixin;

import client.vertix.core.api.StreamingWindow;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(Window.class)
public abstract class WindowMixin implements StreamingWindow {
    @Shadow private boolean exclusiveFullscreen;
    @Shadow public abstract void setExclusiveFullscreen(boolean exclusive);
    @Unique private boolean vertix$streaming;
    @Unique private boolean vertix$previousExclusive;

    @Override
    public void vertix$setStreaming(boolean enabled) {
        if (Util.getPlatform() != Util.OS.WINDOWS || enabled == vertix$streaming) return;
        vertix$streaming = enabled;
        if (enabled) vertix$previousExclusive = exclusiveFullscreen;
        // Use Minecraft's SDL implementation, including its monitor and failure handling.
        setExclusiveFullscreen(enabled ? false : vertix$previousExclusive);
    }
}
