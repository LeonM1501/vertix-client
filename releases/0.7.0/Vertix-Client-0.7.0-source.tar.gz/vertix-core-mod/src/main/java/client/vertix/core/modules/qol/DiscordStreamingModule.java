package client.vertix.core.modules.qol;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;

public class DiscordStreamingModule extends Module {
    private final Setting.NumberSetting fps = new Setting.NumberSetting("stream_fps", "Streaming-FPS", "Begrenzt Minecraft, damit Discord GPU-Leistung übrig bleibt.", 60, 30, 240, 10, true);

    public DiscordStreamingModule() {
        super("discord_streaming", "Discord Streaming", "Randloses Vollbild unter Windows und FPS-Limit für mehr GPU-Spielraum beim Streamen.", Category.PERFORMANCE, false, false, 0, 0);
        addSetting(fps);
    }

    public static DiscordStreamingModule active() {
        VertixCoreMod core = VertixCoreMod.getInstance();
        if (core == null || core.getModuleManager() == null) return null;
        Module module = core.getModuleManager().getModule("discord_streaming");
        return module instanceof DiscordStreamingModule streaming && streaming.isEnabled() ? streaming : null;
    }

    public int limit(int vanillaLimit) {
        return Math.min(vanillaLimit, Math.max(30, Math.min(240, fps.getValue().intValue())));
    }
}
