package client.vertix.core.mixin;

import client.vertix.core.modules.qol.DiscordStreamingModule;
import com.mojang.blaze3d.platform.FramerateLimitTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FramerateLimitTracker.class)
public class FramerateLimitMixin {
    @Inject(method = "getFramerateLimit", at = @At("RETURN"), cancellable = true)
    private void vertix$streamLimit(CallbackInfoReturnable<Integer> cir) {
        DiscordStreamingModule streaming = DiscordStreamingModule.active();
        if (streaming != null) cir.setReturnValue(streaming.limit(cir.getReturnValue()));
    }
}
