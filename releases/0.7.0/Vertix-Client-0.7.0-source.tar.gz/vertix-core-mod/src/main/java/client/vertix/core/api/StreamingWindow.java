package client.vertix.core.api;

public interface StreamingWindow {
    void vertix$setStreaming(boolean enabled);
}
