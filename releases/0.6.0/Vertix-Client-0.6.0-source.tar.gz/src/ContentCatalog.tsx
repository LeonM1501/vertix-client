import { useEffect, useState } from 'react';
import { Box, ChevronLeft, ChevronRight, Download, LoaderCircle, Package, Search } from 'lucide-react';
import * as api from './api';
import { InstanceDialog } from './Instance';
import { compatibleVersion, type ContentVersion, type CatalogKind } from './contentCompatibility';
const message = (e: unknown) => typeof e === 'string' ? e : e instanceof Error ? e.message : JSON.stringify(e);
const kindLabels: Record<CatalogKind, string> = { mod: 'Mods', shader: 'Shader', resourcepack: 'Ressourcenpakete' };
export function ContentCatalog({ profiles, onReload, notify, initialKind = 'mod' }: { profiles: api.Profile[]; onReload: () => Promise<unknown>; notify: (text: string, error?: boolean) => void; initialKind?: CatalogKind }) {
  const [kind, setKind] = useState<CatalogKind>(initialKind);
  const [query, setQuery] = useState(''), [loader, setLoader] = useState(''), [version, setVersion] = useState(''), [sort, setSort] = useState('downloads'), [page, setPage] = useState(0);
  const [versions, setVersions] = useState<string[]>([]), [hits, setHits] = useState<api.Project[]>([]), [total, setTotal] = useState(0), [loading, setLoading] = useState(true), [error, setError] = useState(''), [attempt, setAttempt] = useState(0), [project, setProject] = useState<api.Project | null>(null);
  useEffect(() => { const c = new AbortController(); api.minecraftVersions(c.signal).then(setVersions).catch(() => {}); return () => c.abort(); }, []);
  useEffect(() => {
    const c = new AbortController(); setLoading(true); setError('');
    const timer = setTimeout(() => {
      const facets = [[`project_type:${kind}`]];
      if (version) facets.push([`versions:${version}`]);
      if (kind === 'mod' && loader) facets.push([`categories:${loader}`]);
      const params = new URLSearchParams({ query, index: sort, offset: String(page * 20), limit: '20', facets: JSON.stringify(facets) });
      api.getJSON<api.SearchResult>(`https://api.modrinth.com/v2/search?${params}`, c.signal).then(result => { if (!c.signal.aborted) { setHits(result.hits); setTotal(result.total_hits); } }).catch(e => { if (!c.signal.aborted) setError(message(e)); }).finally(() => { if (!c.signal.aborted) setLoading(false); });
    }, 250);
    return () => { clearTimeout(timer); c.abort(); };
  }, [kind, query, loader, version, sort, page, attempt]);
  return <div className="content-catalog">
    <div className="page-heading"><div><div className="eyebrow">NEUES FÜR DEINE WELTEN</div><h1>Inhalte entdecken</h1><p>Die passende Instanz wählst du beim Installieren.</p></div><Package size={28} /></div>
    <nav className="browse-types" aria-label="Inhaltstyp">{(Object.keys(kindLabels) as CatalogKind[]).map(value => <button key={value} type="button" aria-pressed={kind === value} className={kind === value ? 'active' : ''} onClick={() => { setKind(value); setLoader(''); setQuery(''); setPage(0); setProject(null); }}>{kindLabels[value]}</button>)}</nav>
    {kind === 'shader' && <p className="instance-notice">Shader benötigen Iris oder OptiFine in der Zielinstanz. Das Shaderpaket wählst du danach in den Grafikeinstellungen von Minecraft aus.</p>}
    <div className="toolbar catalog-filters"><label className="search-field"><Search size={18} /><input aria-label={`${kindLabels[kind]} suchen`} placeholder={`${kindLabels[kind]} auf Modrinth durchsuchen …`} value={query} onChange={e => { setQuery(e.target.value); setPage(0); }} /></label>
      {kind === 'mod' && <label>Modloader<select aria-label="Modloader filtern" value={loader} onChange={e => { setLoader(e.target.value); setPage(0); }}><option value="">Alle Modloader</option>{['fabric','forge','neoforge','quilt'].map(v => <option key={v} value={v}>{v === 'neoforge' ? 'NeoForge' : v[0].toUpperCase() + v.slice(1)}</option>)}</select></label>}
      <label>Minecraft<select aria-label="Minecraft-Version filtern" value={version} onChange={e => { setVersion(e.target.value); setPage(0); }}><option value="">Alle Versionen</option>{versions.map(v => <option key={v}>{v}</option>)}</select></label>
      <label>Sortieren<select aria-label="Inhalte sortieren" value={sort} onChange={e => { setSort(e.target.value); setPage(0); }}><option value="downloads">Downloads</option><option value="relevance">Relevanz</option><option value="updated">Zuletzt aktualisiert</option><option value="newest">Neu erschienen</option></select></label>
    </div>
    {loading ? <div className="table-empty"><LoaderCircle className="spin" /><p>Inhalte werden geladen …</p></div> : error ? <div className="table-empty" role="alert"><p>{error}</p><button className="button" onClick={() => setAttempt(n => n + 1)}>Erneut versuchen</button></div> : <>
      <p className="catalog-count">{total.toLocaleString('de')} Ergebnisse</p><div className="browse-results">{hits.map(hit => <article className="browse-result" key={hit.project_id}>{hit.icon_url ? <img src={hit.icon_url} alt="" loading="lazy" /> : <div className="browse-icon"><Package size={32} /></div>}<div className="browse-result-copy"><div><h2>{hit.title}</h2><span>von {hit.author}</span></div><p>{hit.description}</p><div className="result-tags"><span>{kindLabels[kind]}</span>{loader && <span>{loader}</span>}{version && <span>{version}</span>}</div></div><div className="browse-result-action"><button className="button small light" onClick={() => setProject(hit)}><Download size={15} />Installieren</button><span>{hit.downloads.toLocaleString('de')} Downloads</span></div></article>)}</div>
      {!hits.length && <div className="table-empty"><Search size={30} /><h2>Keine passenden Inhalte gefunden.</h2><p>Ändere deine Suche oder die Filter.</p></div>}
      {!!hits.length && <div className="browse-pagination"><span>Seite {page + 1} von {Math.ceil(total / 20).toLocaleString('de')}</span><button className="button" disabled={page === 0} onClick={() => setPage(n => n - 1)}><ChevronLeft size={16} />Zurück</button><button className="button" disabled={(page + 1) * 20 >= total} onClick={() => setPage(n => n + 1)}>Weiter<ChevronRight size={16} /></button></div>}
    </>}
    {project && <InstallChooser key={project.project_id} kind={kind} project={project} profiles={profiles} onClose={() => setProject(null)} onReload={onReload} notify={notify} />}
  </div>;
}

function InstallChooser({ project, profiles, onClose, onReload, notify, kind }: { project: api.Project; profiles: api.Profile[]; onClose: () => void; onReload: () => Promise<unknown>; notify: (text: string, error?: boolean) => void; kind: CatalogKind }) {
  const [versions, setVersions] = useState<ContentVersion[]>([]), [loading, setLoading] = useState(true), [error, setError] = useState(''), [attempt, setAttempt] = useState(0), [busy, setBusy] = useState<string | null>(null), [installed, setInstalled] = useState<string[]>([]);
  useEffect(() => { const c = new AbortController(); setLoading(true); setError(''); api.getJSON<ContentVersion[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(project.project_id)}/version`, c.signal).then(data => { if (!c.signal.aborted) setVersions(data); }).catch(e => { if (!c.signal.aborted) setError(message(e)); }).finally(() => { if (!c.signal.aborted) setLoading(false); }); return () => c.abort(); }, [project.project_id, attempt]);
  async function install(profile: api.Profile, versionId: string) {
    if (busy) return;
    if (!api.desktop) { notify('Inhalte installierst du in der Desktop-App.', true); return; }
    setBusy(profile.id); setError('');
    try {
      await api.call('install_instance_content', { request: { profile_id: profile.id, project_id: project.project_id, kind, world: null, version_id: versionId } });
      setInstalled(ids => [...ids, profile.id]); await onReload(); notify(`${project.title} in ${profile.name} installiert.`);
    } catch (e) { setError(message(e)); } finally { setBusy(null); }
  }
  return <InstanceDialog title="Wo möchtest du den Inhalt installieren?" className="install-chooser" onClose={() => { if (!busy) onClose(); }}><p className="dialog-copy">{project.title} · Für jede Instanz wird die passende Veröffentlichung geprüft.</p>
    {error && <p className="inline-error" role="alert">{error} {!versions.length && <button className="text-button" onClick={() => setAttempt(n => n + 1)}>Erneut versuchen</button>}</p>}
    <div className="install-instance-list">{profiles.map(profile => {
      const match = compatibleVersion(versions, profile, kind), already = installed.includes(profile.id) || (kind === 'mod' && profile.mods.some(m => m.source.project_id === project.project_id));
      const running = ['running','starting','stopping'].includes((profile.state || '').toLowerCase());
      return <div className="install-instance" key={profile.id}><Box size={24} /><div><strong>{profile.name}</strong><small>{profile.game_version} · {profile.loader}</small><p className={match.version ? '' : 'incompatible'}>{loading ? 'Kompatibilität wird geprüft …' : !versions.length && error ? 'Kompatibilität konnte nicht geprüft werden' : match.reason || `Passende Version: ${match.version?.version_number}`}</p></div><button className="button small light" disabled={loading || !!busy || !match.version || already || running} onClick={() => match.version && install(profile, match.version.id)}>{busy === profile.id ? <LoaderCircle className="spin" size={15} /> : null}{already ? 'Installiert' : running ? 'Instanz läuft' : 'Installieren'}</button></div>;
    })}</div>{!profiles.length && <div className="table-empty"><Box size={28} /><p>Erstelle zuerst eine Instanz unter „Meine Instanzen“.</p></div>}<div className="dialog-actions"><button className="button" disabled={!!busy} onClick={onClose}>Schließen</button></div>
  </InstanceDialog>;
}
