import { ArrowRight, Box, Layers3, LoaderCircle, Play, Plus, Search, Package, Sparkles, Cpu, Clock } from 'lucide-react';
import type { Profile } from './api';
import type { Design } from './Appearance';
import type { CatalogKind } from './contentCompatibility';
export function Home({ design, profiles, selected, launching, onLaunch, onCreate, onOpen, onLibrary, onDiscover }: {
  design: Design; profiles: Profile[]; selected?: Profile; launching: boolean; onLaunch: () => void; onCreate: () => void; onOpen: (id: string) => void; onLibrary: () => void; onDiscover: (kind?: CatalogKind) => void;
}) {
  if (design === 'oled') return <div className="home home-oled">
    <section className="oled-hero">
      <Box className="oled-hero-art" strokeWidth={0.6} aria-hidden="true" />
      <span className="oled-kicker">{selected ? 'BEREIT ZUM SPIELEN' : 'LOS GEHT’S'}</span>
      <h1>{selected?.name || 'Deine erste Welt'}</h1>
      <p>{selected ? `Minecraft ${selected.game_version} · ${selected.loader === 'vanilla' ? 'Vanilla' : selected.loader} · ${selected.mods.length} Mods` : 'Erstelle eine Instanz und leg direkt los.'}</p>
      <div className="oled-hero-actions"><button className="oled-play" disabled={launching} onClick={selected ? onLaunch : onCreate}>{launching ? <LoaderCircle className="spin" size={24} /> : selected ? <Play size={24} fill="currentColor" /> : <Plus size={24} />}{launching ? 'Startet …' : selected ? 'SPIELEN' : 'INSTANZ ERSTELLEN'}</button>{selected && <button className="oled-link" onClick={() => onOpen(selected.id)}>Einstellungen &amp; Mods</button>}</div>
    </section>
    <section className="oled-stats">
      <div><Layers3 size={20} /><strong>{profiles.length}</strong><span>Instanzen</span></div>
      <div><Package size={20} /><strong>{profiles.reduce((n, p) => n + p.mods.length, 0)}</strong><span>Mods insgesamt</span></div>
      <div><Cpu size={20} /><strong>{selected ? `${selected.settings.memory.max / 1024} GB` : '–'}</strong><span>RAM der Auswahl</span></div>
      <div><Clock size={20} /><strong>{selected?.last_played ? new Date(selected.last_played).toLocaleDateString('de-DE') : 'Noch nie'}</strong><span>Zuletzt gespielt</span></div>
    </section>
    <section className="oled-row"><div className="oled-row-head"><h2>Deine Instanzen</h2><button className="oled-link" onClick={onLibrary}>Alle<ArrowRight size={14} /></button></div>
      <div className="oled-tiles">{profiles.slice(0, 6).map(p => <button key={p.id} className={`oled-tile ${selected?.id === p.id ? 'selected' : ''} ${p.loader}`} onClick={() => onOpen(p.id)}><Box size={22} /><strong>{p.name}</strong><span>{p.game_version} · {p.loader}</span></button>)}<button className="oled-tile oled-tile-new" onClick={onCreate}><Plus size={22} /><strong>Neu</strong></button></div>
    </section>
    <section className="oled-row"><div className="oled-row-head"><h2>Entdecken</h2></div><div className="oled-cards">
      <button onClick={() => onDiscover('mod')}><Package size={26} /><strong>Mods</strong><span>Tausende Mods für deinen Loader</span></button>
      <button onClick={() => onDiscover('shader')}><Sparkles size={26} /><strong>Shader</strong><span>Bessere Optik und Licht</span></button>
      <button onClick={() => onDiscover('resourcepack')}><Search size={26} /><strong>Ressourcenpakete</strong><span>Neue Texturen und Sounds</span></button>
    </div></section>
  </div>;
  const feature = <section className="home-feature"><div className="home-feature-mark" aria-hidden="true"><Box strokeWidth={1} /></div><div className="home-feature-copy"><span className="eyebrow">{selected ? 'AUSGEWÄHLTE INSTANZ' : 'DEIN ERSTER START'}</span><h2>{selected?.name || 'Eine Welt für dich.'}</h2><p>{selected ? `${selected.game_version} / ${selected.loader} / ${selected.settings.memory.max / 1024} GB RAM` : 'Version wählen, Instanz erstellen, losspielen.'}</p><div className="home-feature-actions"><button className="button light" disabled={launching} onClick={selected ? onLaunch : onCreate}>{launching ? <LoaderCircle className="spin" size={17} /> : selected ? <Play size={17} /> : <Plus size={17} />}{launching ? 'Startet …' : selected ? 'Minecraft starten' : 'Instanz erstellen'}</button>{selected && <button className="button" onClick={() => onOpen(selected.id)}>Verwalten<ArrowRight size={16} /></button>}</div></div>{selected && <div className="home-feature-index">{String(Math.max(1, profiles.findIndex(p => p.id === selected?.id) + 1)).padStart(2,'0')}<span> / {String(profiles.length).padStart(2,'0')}</span></div>}</section>;
  const library = <section className="home-library"><div className="section-heading"><div><h2>{design === 'terminal' ? 'Instanzen' : 'Deine Bibliothek'} <span className="count">{profiles.length}</span></h2></div><button className="text-button" onClick={onLibrary}>Alle ansehen<ArrowRight size={15} /></button></div><div className="home-profile-list">{profiles.slice(0, design === 'gallery' ? 8 : 5).map((p, i) => <button className={`home-profile ${selected?.id === p.id ? 'selected' : ''}`} key={p.id} onClick={() => onOpen(p.id)}><span className="home-profile-number">{String(i+1).padStart(2,'0')}</span><div className="home-profile-icon"><Box strokeWidth={1.3} /></div><div className="home-profile-copy"><strong>{p.name}</strong><span>{p.loader} · {p.game_version}</span></div><small>{p.mods.length} Mods</small><ArrowRight size={17} /></button>)}<button className="home-profile home-new" onClick={onCreate}><Plus size={20} /><strong>Neue Instanz</strong><span>Ein eigenes Setup erstellen</span></button></div></section>;
  const discover = <button className="home-discover" onClick={() => onDiscover()}><Layers3 size={24} strokeWidth={1.3} /><div><strong>Mehr für deine Welt.</strong><span>Mods entdecken und in deinen Instanzen installieren.</span></div><ArrowRight size={20} /></button>;
  return <div className={`home home-${design}`}><div className="home-heading"><div><span className="eyebrow">VERTIX / JAVA EDITION</span><h1>{design === 'paper' ? 'Deine Welten.' : design === 'terminal' ? 'Übersicht' : design === 'gallery' ? 'Deine Sammlung.' : design === 'focus' ? 'Bereit, wenn du es bist.' : 'Willkommen zurück.'}</h1></div><button className="button" onClick={onCreate}><Plus size={16} />Neue Instanz</button></div>
    {design === 'paper' ? <div className="home-paper-spread">{library}<div>{feature}{discover}</div></div> : design === 'gallery' ? <>{library}<div className="home-gallery-footer">{feature}{discover}</div></> : design === 'focus' ? <>{feature}<div className="home-focus-bottom">{library}{discover}</div></> : design === 'terminal' ? <>{feature}{library}{discover}</> : <div className="home-mono-columns"><div>{feature}{library}</div>{discover}</div>}
  </div>;
}
