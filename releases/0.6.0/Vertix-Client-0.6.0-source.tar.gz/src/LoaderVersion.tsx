import { useEffect, useState } from 'react';
import * as api from './api';
export function LoaderVersion({ loader, gameVersion, value, onChange, disabled, onValid }: {
  loader: api.Loader; gameVersion: string; value: string; onChange: (v: string) => void; disabled?: boolean; onValid: (v: boolean) => void;
}) {
  const [versions, setVersions] = useState<string[]>([]), [loading, setLoading] = useState(true), [error, setError] = useState(''), [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let active = true; setVersions([]); setError(''); setLoading(loader !== 'vanilla'); onValid(loader === 'vanilla');
    if (loader === 'vanilla' || !gameVersion) return;
    api.loaderVersions(loader, gameVersion).then(list => { if (active) { setVersions(list); onValid(list.length > 0 && (!value || list.includes(value))); } }).catch(e => { if (active) setError(e instanceof Error ? e.message : String(e)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [loader, gameVersion, attempt]);
  useEffect(() => { if (!loading) onValid(loader === 'vanilla' || (versions.length > 0 && (!value || versions.includes(value)))); }, [value, versions, loading, loader]);
  if (loader === 'vanilla') return null;
  return <label className="field">Modloader-Version<select aria-label="Modloader-Version" value={value} disabled={disabled || loading || !versions.length} onChange={e => onChange(e.target.value)}>
    <option value="">{loading ? 'Versionen werden geladen …' : versions.length ? `Neueste Version (${versions[0]})` : 'Keine kompatible Version verfügbar'}</option>
    {value && !versions.includes(value) && <option value={value}>{value} · nicht verfügbar</option>}
    {versions.map(v => <option key={v} value={v}>{v}</option>)}
  </select>{error && <span className="inline-error">{error} <button type="button" className="text-button" onClick={() => setAttempt(n => n + 1)}>Erneut versuchen</button></span>}</label>;
}
