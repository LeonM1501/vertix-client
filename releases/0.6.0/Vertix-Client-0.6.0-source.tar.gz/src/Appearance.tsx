import { useLayoutEffect, useState } from 'react';
import { Check } from 'lucide-react';
export const designs = [
  { id: 'oled', name: 'OLED', description: 'Echtes Schwarz. Knallige Farbe. Wenige, klare Buttons.', layout: 'left' },
  { id: 'mono', name: 'Mono', description: 'Seitenleiste. Klare Flächen. Alles an seinem Platz.', layout: 'left' },
  { id: 'paper', name: 'Papier', description: 'Helle Bibliothek. Große Schrift. Navigation rechts.', layout: 'right' },
  { id: 'terminal', name: 'Terminal', description: 'Navigation oben. Dichte Listen. Direkter Zugriff.', layout: 'top' },
  { id: 'gallery', name: 'Galerie', description: 'Schmale Symbolleiste. Große Karten. Raum für Instanzen.', layout: 'rail' },
  { id: 'focus', name: 'Fokus', description: 'Dein Spiel im Mittelpunkt. Navigation am unteren Rand.', layout: 'bottom' },
] as const;
export type Design = typeof designs[number]['id'];
export type Appearance = { design: Design; density: 'comfortable' | 'compact'; scale: number; corners: 'square' | 'soft'; accent: string };
export const accents = ['#8ecdf5', '#a78bfa', '#f472b6', '#fb7185', '#fbbf24', '#34d399', '#ffffff'];
const inkFor = (hex: string) => { const n = parseInt(hex.slice(1), 16); const l = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; return l > 0.55 ? '#06080c' : '#ffffff'; };
const initial: Appearance = { design: 'oled', density: 'comfortable', scale: 100, corners: 'soft', accent: accents[0] };
export function readAppearance(): Appearance {
  try {
    const v = JSON.parse(localStorage.getItem('vertix-appearance-v2') || localStorage.getItem('vertix-appearance-v1') || '{}');
    return { design: designs.some(d => d.id === v.design) ? v.design : initial.design, density: v.density === 'compact' ? 'compact' : 'comfortable', scale: [90,100,110,120].includes(v.scale) ? v.scale : 100, corners: v.corners === 'square' ? 'square' : 'soft', accent: /^#[0-9a-f]{6}$/i.test(v.accent) ? v.accent : initial.accent };
  } catch { return initial; }
}
export function useAppearance() {
  const [appearance, setAppearance] = useState(readAppearance);
  useLayoutEffect(() => {
    try { localStorage.setItem('vertix-appearance-v2', JSON.stringify(appearance)); } catch { /* Keep this session usable when browser storage is full. */ }
    const root = document.documentElement;
    root.dataset.design = appearance.design; root.dataset.density = appearance.density; root.dataset.corners = appearance.corners;
    root.style.setProperty('--accent', appearance.accent); root.style.setProperty('--accent-ink', inkFor(appearance.accent));
    root.style.setProperty('--ui-scale', String(appearance.scale / 100));
  }, [appearance]);
  return [appearance, setAppearance] as const;
}
export function AppearanceSettings({ value, onChange }: { value: Appearance; onChange: (value: Appearance) => void }) {
  return <section className="appearance-settings"><div className="section-heading"><div><h2>Deine Oberfläche</h2><p>Sechs Anordnungen. Ein Klick zum Wechseln.</p></div><span className="settings-autosave">Wird automatisch gespeichert</span></div>
    <div className="design-options">{designs.map(d => <button type="button" aria-label={`Design ${d.name}`} aria-pressed={value.design === d.id} className={`design-option ${value.design === d.id ? 'selected' : ''}`} key={d.id} onClick={() => onChange({ ...value, design: d.id })}>
      <div aria-hidden="true" className={`design-mini ${d.layout} ${d.id}`}><i className="mini-nav" /><div className="mini-main"><i className="mini-title" /><i className="mini-feature" /><div><i /><i /><i /></div></div></div>
      <div className="design-option-heading"><strong>{d.name}</strong>{value.design === d.id && <Check size={16} />}</div><p>{d.description}</p>
    </button>)}</div>
    <div className="accent-picker"><span>Akzentfarbe</span><div>{accents.map(c => <button type="button" key={c} aria-label={`Akzentfarbe ${c}`} aria-pressed={value.accent.toLowerCase() === c} className={`accent-swatch ${value.accent.toLowerCase() === c ? 'selected' : ''}`} style={{ background: c }} onClick={() => onChange({ ...value, accent: c })} />)}<label className="accent-custom" title="Eigene Farbe"><input type="color" aria-label="Eigene Akzentfarbe" value={value.accent} onChange={e => onChange({ ...value, accent: e.target.value })} /></label></div></div>
    <div className="appearance-controls"><label className="field">Abstände<select aria-label="Abstände" value={value.density} onChange={e => onChange({ ...value, density: e.target.value as Appearance['density'] })}><option value="comfortable">Entspannt</option><option value="compact">Kompakt</option></select></label>
      <label className="field">Schriftgröße<select aria-label="Schriftgröße" value={value.scale} onChange={e => onChange({ ...value, scale: Number(e.target.value) })}>{[90,100,110,120].map(n => <option key={n} value={n}>{n}%</option>)}</select></label>
      <label className="field">Ecken<select aria-label="Ecken" value={value.corners} onChange={e => onChange({ ...value, corners: e.target.value as Appearance['corners'] })}><option value="soft">Leicht gerundet</option><option value="square">Gerade</option></select></label>
    </div><button className="text-button" onClick={() => onChange(initial)}>Darstellung zurücksetzen</button>
  </section>;
}
