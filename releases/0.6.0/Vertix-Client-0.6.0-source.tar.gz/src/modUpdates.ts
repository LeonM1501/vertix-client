import { getJSON, type ContentItem, type Profile } from './api';
export type ModVersion = { id: string; version_number: string; version_type: string; date_published: string; files: unknown[] };
export type ModUpdate = { versionId: string; version: string; projectId: string; title: string };
export function newerModVersion(versions: ModVersion[], installed: ModVersion): ModVersion | undefined {
  const candidate = versions.find(v => v.version_type === 'release' && v.files.length) || versions.find(v => v.files.length);
  if (!candidate || candidate.id === installed.id) return;
  const before = Date.parse(installed.date_published), after = Date.parse(candidate.date_published);
  return Number.isFinite(before) && Number.isFinite(after) && after > before ? candidate : undefined;
}
export async function checkModUpdates(profile: Profile, items: ContentItem[], signal: AbortSignal): Promise<{ updates: Record<string, ModUpdate>; failures: number }> {
  const queue = items.filter(i => i.kind === 'mod' && i.project_id && i.version_id);
  const updates: Record<string, ModUpdate> = {}; let failures = 0, cursor = 0;
  async function worker() {
    while (cursor < queue.length && !signal.aborted) {
      const item = queue[cursor++];
      try {
        const params = new URLSearchParams({ loaders: JSON.stringify([profile.loader]), game_versions: JSON.stringify([profile.game_version]) });
        const versions = await getJSON<ModVersion[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(item.project_id!)}/version?${params}`, signal);
        const current = versions.find(v => v.id === item.version_id) || await getJSON<ModVersion>(`https://api.modrinth.com/v2/version/${encodeURIComponent(item.version_id!)}`, signal);
        const update = newerModVersion(versions, current);
        if (update) updates[item.id] = { versionId: update.id, version: update.version_number, projectId: item.project_id!, title: item.title };
      } catch { if (!signal.aborted) failures++; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(4, queue.length) }, worker));
  return { updates, failures };
}
