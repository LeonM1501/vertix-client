import type { Profile } from './api';
export type ContentVersion = { id: string; version_number: string; version_type: string; game_versions: string[]; loaders: string[]; files: unknown[] };
export type CatalogKind = 'mod' | 'shader' | 'resourcepack';
export function compatibleVersion(versions: ContentVersion[], profile: Pick<Profile, 'game_version' | 'loader'>, kind: CatalogKind = 'mod'): { version?: ContentVersion; reason?: string } {
  if (kind === 'mod' && profile.loader === 'vanilla') return { reason: 'Nicht kompatibel · Vanilla unterstützt keine Mods' };
  const loaders = kind === 'mod' ? [profile.loader] : kind === 'resourcepack' ? ['minecraft'] : ['iris', 'optifine'];
  const withLoader = versions.filter(v => loaders.some(loader => v.loaders.includes(loader)) && v.files.length > 0);
  if (!withLoader.length) return { reason: kind === 'mod' ? `Nicht kompatibel · ${profile.loader} wird nicht unterstützt` : 'Nicht kompatibel · keine Veröffentlichung für diesen Inhaltstyp' };
  const matching = withLoader.filter(v => v.game_versions.includes(profile.game_version));
  const version = matching.find(v => v.version_type === 'release') || matching[0];
  return version ? { version } : { reason: `Nicht kompatibel · keine Version für Minecraft ${profile.game_version}` };
}
