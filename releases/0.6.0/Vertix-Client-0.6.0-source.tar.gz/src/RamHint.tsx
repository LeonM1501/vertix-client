import { useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';
import * as api from './api';
export function recommendedRam(totalMb: number, mods: number): number {
  const gb = totalMb / 1024;
  let rec = gb <= 4 ? 2 : gb <= 8 ? 4 : gb <= 16 ? 6 : gb <= 32 ? 8 : 10;
  if (mods > 150) rec += 2; else if (mods > 50) rec += 1;
  return Math.max(2, Math.min(rec, Math.floor(gb / 2))) * 1024;
}
export function RamHint({ mods, current, onApply, disabled }: { mods: number; current: number; onApply: (mb: number) => void; disabled?: boolean }) {
  const [total, setTotal] = useState(0);
  useEffect(() => { (api.desktop ? api.call<number>('system_memory_mb') : Promise.resolve(((navigator as unknown as { deviceMemory?: number }).deviceMemory || 8) * 1024)).then(setTotal).catch(() => setTotal(0)); }, []);
  if (!total) return null;
  const rec = recommendedRam(total, mods), gb = (n: number) => (n / 1024).toLocaleString('de', { maximumFractionDigits: 1 });
  const note = current < rec ? 'Etwas mehr RAM sorgt für weniger Ruckler.' : current > rec * 1.5 ? 'Das ist mehr als nötig und kann sogar bremsen.' : 'Passt gut.';
  return <div className="ram-hint"><Sparkles size={16} /><span><strong>Empfohlen: {gb(rec)} GB</strong> bei {gb(total)} GB im PC{mods ? ` und ${mods} Mods` : ''}. {note}</span>{current !== rec && <button type="button" className="text-button" disabled={disabled} onClick={() => onApply(rec)}>Übernehmen</button>}</div>;
}
