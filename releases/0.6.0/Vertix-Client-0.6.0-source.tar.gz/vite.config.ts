import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins: [react()], clearScreen: false, server: { port: 1430, strictPort: true, host: '127.0.0.1', watch: { ignored: ['**/src-tauri/**', '**/upstream/**'] } } });
