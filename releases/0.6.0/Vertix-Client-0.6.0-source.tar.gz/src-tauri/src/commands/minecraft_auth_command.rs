// Microsoft/Xbox/Minecraft authentication retained from upstream; Vertix browser integration 2026-10-08.
use crate::error::{AppError, CommandError};
use crate::minecraft::minecraft_auth::Credentials;
use crate::state::State;
use tauri_plugin_opener::OpenerExt;
use uuid::Uuid;
use std::sync::atomic::{AtomicBool, Ordering};

static LOGIN_RUNNING: AtomicBool = AtomicBool::new(false);
struct LoginGuard;
impl Drop for LoginGuard { fn drop(&mut self) { LOGIN_RUNNING.store(false, Ordering::SeqCst); } }

#[tauri::command]
pub async fn begin_login(app: tauri::AppHandle) -> Result<Option<Credentials>, CommandError> {
    if LOGIN_RUNNING.swap(true, Ordering::SeqCst) { return Err(AppError::Other("Eine Anmeldung läuft bereits.".into()).into()); }
    let _guard = LoginGuard;
    let state = State::get().await?;
    let redirect_uri = "http://localhost:25585/callback";
    let flow = state.minecraft_account_manager_v2.login_begin_direct_oauth(redirect_uri).await?;
    let success = "<!doctype html><html lang='de'><meta charset='utf-8'><title>Vertix · Angemeldet</title><body style='background:#151719;color:#e8e9e5;font:16px Segoe UI;padding:10vw'><h1>Zurück zu Vertix.</h1><p>Die Microsoft-Anmeldung wird jetzt im Launcher abgeschlossen. Du kannst diesen Tab schließen.</p></body></html>".to_string();
    let failure = "<!doctype html><html lang='de'><meta charset='utf-8'><title>Vertix · Anmeldung</title><body style='background:#151719;color:#e8e9e5;font:16px Segoe UI;padding:10vw'><h1>Anmeldung nicht abgeschlossen.</h1><p>Bitte zu Vertix zurückkehren und erneut versuchen.</p></body></html>".to_string();
    let (handle, mut rx) = crate::minecraft::auth::minecraft_auth::start_oauth_callback_server(25585, success, failure, flow.state.clone()).await?;
    *state.login_server_handle.lock().await = Some(handle);
    if let Err(e) = app.opener().open_url(&flow.authorize_url, None::<&str>) {
        if let Some(h) = state.login_server_handle.lock().await.take() { h.abort(); }
        return Err(AppError::Other(format!("Browser konnte nicht geöffnet werden: {e}")).into());
    }
    let outcome = tokio::time::timeout(std::time::Duration::from_secs(600), &mut rx).await;
    if let Some(h) = state.login_server_handle.lock().await.take() { h.abort(); }
    match outcome {
        Ok(Ok(Ok(code))) => Ok(Some(state.minecraft_account_manager_v2.login_finish_direct_oauth_with_events(&code, flow, Uuid::new_v4()).await?)),
        Ok(Ok(Err(error))) => Err(error.into()),
        Ok(Err(_)) => Ok(None),
        Err(_) => Err(AppError::Other("Anmeldung nach 10 Minuten abgelaufen. Bitte erneut versuchen.".into()).into()),
    }
}
#[tauri::command]
pub async fn cancel_login() -> Result<(), CommandError> { let s = State::get().await?; if let Some(h) = s.login_server_handle.lock().await.take() { h.abort(); } Ok(()) }
#[tauri::command]
pub async fn get_accounts() -> Result<Vec<Credentials>, CommandError> { Ok(State::get().await?.minecraft_account_manager_v2.get_all_accounts().await?) }
#[tauri::command]
pub async fn get_active_account() -> Result<Option<Credentials>, CommandError> { Ok(State::get().await?.minecraft_account_manager_v2.get_active_account().await?) }
#[tauri::command]
pub async fn set_active_account(account_id: Uuid) -> Result<(), CommandError> { Ok(State::get().await?.minecraft_account_manager_v2.set_active_account(account_id).await?) }
#[tauri::command]
pub async fn remove_account(account_id: Uuid) -> Result<(), CommandError> { Ok(State::get().await?.minecraft_account_manager_v2.remove_account(account_id).await?) }
#[tauri::command]
pub fn is_flatpak() -> bool { false }
