//! Vertix authentication via the official Minecraft SISU / Xbox Live flow.
//! Uses the official Minecraft Launcher client identifier (00000000402b5328)
//! to authenticate directly with Mojang / Microsoft without 403 Forbidden errors.
use crate::config::{ProjectDirsExt, LAUNCHER_DIRECTORY};
use crate::error::{AppError, CommandError, Result};
use crate::minecraft::minecraft_auth::Credentials;
use crate::state::State;
use chrono::{Duration, Utc};
use serde::Serialize;
use tauri::{Manager, UserAttentionType, WebviewUrl, WebviewWindowBuilder};
use tokio::sync::{Mutex, Notify};

pub const CLIENT_ID: &str = "00000000402b5328";
static OPERATION: Mutex<()> = Mutex::const_new(());
static CANCEL: Notify = Notify::const_new();

#[derive(Serialize)]
pub struct AccountStatus {
    pub client_id: &'static str,
    pub signed_in: bool,
    pub username: Option<String>,
}

fn failure(message: impl Into<String>) -> AppError {
    AppError::Other(message.into())
}

#[tauri::command]
pub async fn get_vertix_account() -> std::result::Result<AccountStatus, CommandError> {
    let state = State::get().await?;
    let account = state.minecraft_account_manager_v2.get_active_account().await?;
    Ok(AccountStatus {
        client_id: CLIENT_ID,
        signed_in: account.is_some(),
        username: account.map(|a| a.username),
    })
}

#[tauri::command]
pub async fn sign_out_vertix() -> std::result::Result<(), CommandError> {
    let _guard = OPERATION
        .try_lock()
        .map_err(|_| failure("Bitte die laufende Anmeldung zuerst abschließen."))?;
    let state = State::get().await?;
    if let Some(active) = state.minecraft_account_manager_v2.get_active_account().await? {
        state.minecraft_account_manager_v2.remove_account(active.id).await?;
    }
    // Remove legacy session file if present from earlier versions
    let legacy_file = LAUNCHER_DIRECTORY.root_dir().join("microsoft-session.bin");
    let _ = tokio::fs::remove_file(legacy_file).await;
    Ok(())
}

#[tauri::command]
pub fn cancel_vertix_login(app: tauri::AppHandle) {
    if let Some(window) = app.get_webview_window("signin") {
        let _ = window.close();
    }
    CANCEL.notify_waiters();
}

#[tauri::command]
pub async fn sign_in_vertix(app: tauri::AppHandle) -> std::result::Result<AccountStatus, CommandError> {
    let _guard = OPERATION
        .try_lock()
        .map_err(|_| failure("Eine Anmeldung oder Kontoprüfung läuft bereits."))?;
    let state = State::get().await?;

    let flow = state.minecraft_account_manager_v2.login_begin(None).await?;

    if let Some(existing) = app.get_webview_window("signin") {
        let _ = existing.close();
        tokio::time::sleep(std::time::Duration::from_millis(150)).await;
    }

    let external_url = flow.redirect_uri.parse().map_err(|_| {
        failure("Ungültige Weiterleitungs-URL von Microsoft.")
    })?;

    let window = WebviewWindowBuilder::new(&app, "signin", WebviewUrl::External(external_url))
        .title("Bei Minecraft anmelden")
        .always_on_top(true)
        .center()
        .inner_size(520.0, 700.0)
        .min_inner_size(400.0, 500.0)
        .build()
        .map_err(|e| failure(format!("Anmeldefenster konnte nicht geöffnet werden: {e}")))?;

    let _ = window.request_user_attention(Some(UserAttentionType::Critical));

    let start_time = Utc::now();
    let exchange = async {
        while (Utc::now() - start_time) < Duration::minutes(10) {
            match window.url() {
                Ok(current_url) => {
                    let current_url_str = current_url.as_str();
                    if current_url_str.starts_with("https://login.live.com/oauth20_desktop.srf") {
                        if let Some((_, code)) = current_url.query_pairs().find(|(k, _)| k == "code") {
                            let _ = window.close();
                            return Ok(code.to_string());
                        }
                        if let Some((_, err)) = current_url.query_pairs().find(|(k, _)| k == "error") {
                            let _ = window.close();
                            return Err(failure(format!("Microsoft-Anmeldung abgebrochen ({err}).")));
                        }
                    }
                }
                Err(_) => {
                    return Err(failure("Anmeldung durch Schließen des Fensters abgebrochen."));
                }
            }
            tokio::time::sleep(std::time::Duration::from_millis(100)).await;
        }
        let _ = window.close();
        Err(failure("Anmeldung nach 10 Minuten abgelaufen."))
    };

    let code = tokio::select! {
        res = exchange => res?,
        _ = CANCEL.notified() => {
            let _ = window.close();
            return Err(failure("Anmeldung abgebrochen.").into());
        }
    };

    let account = state.minecraft_account_manager_v2.login_finish(&code, flow).await?;

    Ok(AccountStatus {
        client_id: CLIENT_ID,
        signed_in: true,
        username: Some(account.username),
    })
}

pub(crate) async fn credentials() -> Result<Option<Credentials>> {
    let _guard = OPERATION
        .try_lock()
        .map_err(|_| failure("Bitte die laufende Anmeldung zuerst abschließen."))?;
    let state = State::get().await?;
    state.minecraft_account_manager_v2.get_active_account().await
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn official_client_id_is_used() {
        assert_eq!(CLIENT_ID, "00000000402b5328");
    }

    #[test]
    fn account_status_serialization() {
        let status = AccountStatus {
            client_id: CLIENT_ID,
            signed_in: true,
            username: Some("TestPlayer".into()),
        };
        let json = serde_json::to_string(&status).unwrap();
        assert!(json.contains("TestPlayer"));
        assert!(json.contains("00000000402b5328"));
    }
}
