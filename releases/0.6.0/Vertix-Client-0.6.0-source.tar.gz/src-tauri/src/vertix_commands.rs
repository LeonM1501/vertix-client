// Vertix-specific application identity configuration, 2026-10-08.
use crate::config::{ProjectDirsExt, LAUNCHER_DIRECTORY};
use crate::error::{AppError, CommandError};

#[tauri::command]
pub fn get_microsoft_client_id() -> String {
    crate::minecraft::auth::minecraft_auth::vertix_microsoft_client_id().unwrap_or_default()
}

#[tauri::command]
pub fn set_microsoft_client_id(client_id: String) -> Result<(), CommandError> {
    uuid::Uuid::parse_str(client_id.trim()).map_err(|_| AppError::Other("Bitte eine gültige Microsoft Application ID eintragen.".into()))?;
    std::fs::create_dir_all(LAUNCHER_DIRECTORY.root_dir()).map_err(AppError::Io)?;
    std::fs::write(LAUNCHER_DIRECTORY.root_dir().join("microsoft-client-id.txt"), client_id.trim()).map_err(AppError::Io)?;
    Ok(())
}
