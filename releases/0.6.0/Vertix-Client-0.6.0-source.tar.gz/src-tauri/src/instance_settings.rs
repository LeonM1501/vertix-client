use crate::{error::{AppError, CommandError}, state::{State, profile_state::ModLoader}};
use serde::Deserialize;
use uuid::Uuid;

#[derive(Deserialize)]
pub struct SettingsRequest {
    pub name: String, pub memory: u32, pub game_version: String,
    pub loader: String, pub loader_version: Option<String>,
}

#[tauri::command]
pub async fn configure_vertix_instance(profile_id: Uuid, request: SettingsRequest) -> Result<(), CommandError> {
    let _guard = crate::instance_content::CONTENT_LOCK.lock().await;
    let state = State::get().await?;
    crate::instance_content::ensure_stopped(&state, profile_id).await?;
    let mut profile = state.profile_manager.get_profile(profile_id).await?;
    if request.name.trim().is_empty() || request.memory < 1024 || request.memory > 1048576 {
        return Err(AppError::Other("Name oder Arbeitsspeicher ungültig.".into()).into());
    }
    let loader = ModLoader::from_str(&request.loader)?;
    if profile.game_version != request.game_version || profile.loader != loader || profile.loader_version != request.loader_version {
        let versions = crate::minecraft::api::mc_api::MinecraftApiService::new().get_version_manifest().await?;
        if !versions.versions.iter().any(|v| v.id == request.game_version) {
            return Err(AppError::Other("Unbekannte Minecraft-Version.".into()).into());
        }
        let available = loader_versions(&request.loader, &request.game_version).await?;
        if loader != ModLoader::Vanilla && (available.is_empty() || request.loader_version.as_ref().is_some_and(|v| !available.contains(v))) {
            return Err(AppError::Other("Diese Modloader-Version ist für Minecraft nicht verfügbar.".into()).into());
        }
    }
    profile.name = request.name.trim().into();
    profile.game_version = request.game_version;
    profile.loader = loader;
    profile.loader_version = if loader == ModLoader::Vanilla { None } else { request.loader_version };
    profile.settings.use_overwrite_loader_version = false;
    profile.settings.overwrite_loader_version = None;
    profile.settings.overwrite_loader_versions.clear();
    profile.settings.memory.min = profile.settings.memory.min.min(request.memory);
    profile.settings.memory.max = request.memory;
    state.profile_manager.update_profile(profile_id, profile).await?;
    Ok(())
}

#[tauri::command]
pub async fn loader_versions(loader: &str, minecraft_version: &str) -> Result<Vec<String>, CommandError> {
    use crate::commands::minecraft_command::*;
    Ok(match loader {
        "vanilla" => vec![],
        "fabric" => get_fabric_loader_versions(minecraft_version.into()).await?.into_iter().map(|v|v.loader.version).collect(),
        "quilt" => get_quilt_loader_versions(minecraft_version.into()).await?.into_iter().map(|v|v.loader.version).collect(),
        "forge" => get_forge_versions(minecraft_version.into()).await?,
        "neoforge" => get_neoforge_versions(minecraft_version.into()).await?,
        _ => return Err(AppError::Other("Unbekannter Modloader.".into()).into()),
    })
}
