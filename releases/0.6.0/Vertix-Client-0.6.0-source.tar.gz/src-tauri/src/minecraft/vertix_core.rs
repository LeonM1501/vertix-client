use crate::error::Result;
use crate::state::profile_state::ModLoader;
use crate::utils::file_utils::write_atomic;
use log::info;
use std::path::{Path, PathBuf};
use tokio::fs;

pub const VERTIX_CORE_VERSION: &str = "1.1.0";
const CORE_26_2: &[u8] = include_bytes!("../../resources/mods/vertix-core-fabric-26.2-1.1.0.jar");
const CORE_26_3: &[u8] = include_bytes!("../../resources/mods/vertix-core-fabric-26.3-1.1.0.jar");

// Input constants changed from GLFW to SDL in 26.3. Each supported game version
// gets the artifact compiled against its own API; older mapped versions cannot load it.
fn artifact(version: &str, loader: &ModLoader) -> Option<&'static [u8]> {
    if *loader != ModLoader::Fabric { return None; }
    match version { "26.2" => Some(CORE_26_2), "26.3" => Some(CORE_26_3), _ => None }
}
pub fn is_compatible(version: &str, loader: &ModLoader) -> bool { artifact(version, loader).is_some() }
fn owned_jar(name: &str) -> bool {
    let name = name.strip_suffix(".disabled").unwrap_or(name);
    name.strip_prefix("vertix-core-fabric-").and_then(|s| s.strip_suffix(".jar"))
        .map(|v| !v.is_empty() && v.chars().all(|c| c.is_ascii_digit() || c == '.' || c == '-'))
        .unwrap_or(false)
}

pub async fn ensure_vertix_core(mods_dir: &Path, version: &str, loader: &ModLoader) -> Result<Option<PathBuf>> {
    let bytes = artifact(version, loader);
    let filename = format!("vertix-core-fabric-{version}-{VERTIX_CORE_VERSION}.jar");
    let target = mods_dir.join(&filename);
    if let Some(bytes) = bytes {
        fs::create_dir_all(mods_dir).await?;
        // Compare contents, not only file size, so same-sized stale builds are replaced.
        if fs::read(&target).await.ok().as_deref() != Some(bytes) {
            write_atomic(&target, bytes).await?;
            info!("[VertixCore] Installed Core {} for Minecraft {}", VERTIX_CORE_VERSION, version);
        }
    }
    // Remove only our precisely named artifacts, after the replacement is in place.
    // Other local mods, configurations and similarly named user files remain intact.
    if mods_dir.exists() {
        let mut entries = fs::read_dir(mods_dir).await?;
        while let Some(entry) = entries.next_entry().await? {
            if !entry.file_type().await?.is_file() { continue; }
            let name = entry.file_name().to_string_lossy().into_owned();
            if owned_jar(&name) && (bytes.is_none() || name != filename) { fs::remove_file(entry.path()).await?; }
        }
    }
    Ok(bytes.map(|_| target))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn compatibility_and_owned_files_are_exact() {
        assert!(is_compatible("26.2", &ModLoader::Fabric));
        assert!(is_compatible("26.3", &ModLoader::Fabric));
        for version in ["1.21", "1.21.11", "26.1", "26.3.1", "26.4", "26.3-pre1"] { assert!(!is_compatible(version, &ModLoader::Fabric)); }
        for loader in [ModLoader::Vanilla, ModLoader::Forge, ModLoader::NeoForge, ModLoader::Quilt] { assert!(!is_compatible("26.3", &loader)); }
        assert!(owned_jar("vertix-core-fabric-1.0.0.jar"));
        assert!(owned_jar("vertix-core-fabric-26.2-1.1.0.jar.disabled"));
        assert!(!owned_jar("vertix-core-fabric-custom.jar"));
        assert!(!owned_jar("vertix-core-settings.json"));
    }
    #[tokio::test]
    async fn installs_upgrades_repairs_and_preserves_user_files() {
        let directory = tempfile::tempdir().unwrap(); let dir = directory.path().join("mods");
        let installed = ensure_vertix_core(&dir, "26.2", &ModLoader::Fabric).await.unwrap().unwrap();
        assert_eq!(fs::read(&installed).await.unwrap(), CORE_26_2);
        fs::write(&installed, vec![0; CORE_26_2.len()]).await.unwrap();
        ensure_vertix_core(&dir, "26.2", &ModLoader::Fabric).await.unwrap();
        assert_eq!(fs::read(&installed).await.unwrap(), CORE_26_2);
        fs::write(dir.join("vertix-core-fabric-1.0.0.jar"), b"old").await.unwrap();
        fs::write(dir.join("vertix-core-fabric-custom.jar"), b"user").await.unwrap();
        fs::write(dir.join("another-mod.jar"), b"user").await.unwrap();
        let next = ensure_vertix_core(&dir, "26.3", &ModLoader::Fabric).await.unwrap().unwrap();
        assert_eq!(fs::read(&next).await.unwrap(), CORE_26_3);
        assert!(!installed.exists()); assert!(!dir.join("vertix-core-fabric-1.0.0.jar").exists());
        ensure_vertix_core(&dir, "26.3", &ModLoader::Vanilla).await.unwrap();
        assert!(!next.exists()); assert!(dir.join("vertix-core-fabric-custom.jar").exists()); assert!(dir.join("another-mod.jar").exists());
    }
}
