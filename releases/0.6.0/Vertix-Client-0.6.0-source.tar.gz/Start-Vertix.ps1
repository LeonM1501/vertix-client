$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$env:PATH = "$env:USERPROFILE\.cargo\bin;$env:PATH"
if (Test-Path -LiteralPath "$PSScriptRoot\artifacts\Vertix Client.exe") {
    & "$PSScriptRoot\artifacts\Vertix Client.exe"
} else {
    npm run desktop
}
