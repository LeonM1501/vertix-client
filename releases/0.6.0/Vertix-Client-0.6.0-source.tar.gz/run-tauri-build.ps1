$ErrorActionPreference = 'Stop'
# Keep both release entry points on the same production build path.
& "$PSScriptRoot\build-release.ps1"
