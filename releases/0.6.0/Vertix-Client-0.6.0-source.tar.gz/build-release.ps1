param([string]$ArtifactDirectory = "$PSScriptRoot\artifacts")
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$cargoBin = Join-Path $env:USERPROFILE '.cargo\bin'
if (-not ($env:PATH -split ';' -contains $cargoBin)) {
    $env:PATH = "$cargoBin;$env:PATH"
}
node node_modules/typescript/bin/tsc --noEmit
if ($LASTEXITCODE -ne 0) { throw 'TypeScript validation failed.' }
node node_modules/vite/bin/vite.js build
if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
cargo build --manifest-path src-tauri/Cargo.toml --release --locked --bin vertix-client --features custom-protocol
if ($LASTEXITCODE -ne 0) { throw 'Native release build failed; no artifact was copied.' }

$releaseExe = "$PSScriptRoot\src-tauri\target\release\vertix-client.exe"
New-Item -ItemType Directory -Path $ArtifactDirectory -Force | Out-Null
$artifactExe = Join-Path $ArtifactDirectory 'Vertix Client.exe'

if (Test-Path $releaseExe) {
    Copy-Item -Force $releaseExe $artifactExe
    # The Windows GNU LLVM executable imports this runtime DLL.
    $rustSysroot = (& rustc --print sysroot).Trim()
    if ($LASTEXITCODE -ne 0) { throw 'Could not locate the Rust runtime.' }
    $unwindDll = Join-Path $rustSysroot 'bin\libunwind.dll'
    if (-not (Test-Path -LiteralPath $unwindDll)) { throw 'Required libunwind.dll is missing from the toolchain.' }
    Copy-Item -LiteralPath $unwindDll -Destination (Join-Path $ArtifactDirectory 'libunwind.dll') -Force
    Write-Host "SUCCESS: Updated artifacts\Vertix Client.exe from $releaseExe"
} else {
    Write-Error "Release executable not found at $releaseExe"
}
