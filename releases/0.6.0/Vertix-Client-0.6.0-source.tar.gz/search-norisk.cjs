const fs = require('fs');
const path = require('path');

function search(dir) {
    for (const f of fs.readdirSync(dir)) {
        const full = path.join(dir, f);
        if (fs.statSync(full).isDirectory()) {
            if (f !== 'tests') search(full);
        } else if (f.endsWith('.rs')) {
            const c = fs.readFileSync(full, 'utf8');
            c.split('\n').forEach((l, i) => {
                if (/["'][^"']*(?:norisk|analytics-api)[^"']*["']/i.test(l)) {
                    console.log(full + ':' + (i+1) + ': ' + l.trim());
                }
            });
        }
    }
}
search('src-tauri/src');
