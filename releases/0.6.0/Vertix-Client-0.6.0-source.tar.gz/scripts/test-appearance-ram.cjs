const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
function load(file, storage = {}) {
  const output = ts.transpileModule(fs.readFileSync(file, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX } }).outputText;
  const context = { exports: {}, require: () => ({}), localStorage: { getItem: key => storage[key] || null } };
  vm.runInNewContext(output, context);
  return context.exports;
}
assert.equal(load('src/Appearance.tsx').readAppearance().design, 'oled');
const legacy = { design: 'paper', density: 'compact', scale: 120, corners: 'square' };
const migrated = load('src/Appearance.tsx', { 'vertix-appearance-v1': JSON.stringify(legacy) }).readAppearance();
for (const key of Object.keys(legacy)) assert.equal(migrated[key], legacy[key]);
assert.match(migrated.accent, /^#[0-9a-f]{6}$/i);
const current = load('src/Appearance.tsx', { 'vertix-appearance-v1': JSON.stringify(legacy), 'vertix-appearance-v2': JSON.stringify({ design: 'oled', accent: '#ffffff' }) }).readAppearance();
assert.equal(current.design, 'oled');
assert.equal(current.accent, '#ffffff');
const invalid = load('src/Appearance.tsx', { 'vertix-appearance-v2': JSON.stringify({ design: 'invalid', scale: 900, accent: 'url(example)' }) }).readAppearance();
assert.equal(invalid.design, 'oled');
assert.equal(invalid.scale, 100);
assert.match(invalid.accent, /^#[0-9a-f]{6}$/i);
assert.equal(load('src/Appearance.tsx', { 'vertix-appearance-v2': '{' }).readAppearance().design, 'oled');
const recommend = load('src/RamHint.tsx').recommendedRam;
for (const [totalGb, mods, expectedGb] of [[4, 0, 2], [8, 0, 4], [8, 200, 4], [16, 0, 6], [16, 200, 8], [32, 200, 10], [64, 200, 12]]) {
  const result = recommend(totalGb * 1024, mods);
  assert.equal(result, expectedGb * 1024);
  assert.ok(result <= totalGb * 1024 / 2, 'Leave at least half of system RAM available.');
}
console.log('Appearance migration, validation and 7 RAM recommendation cases passed.');
