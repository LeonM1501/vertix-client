import fs from 'node:fs';
function edit(path, fn) { fs.writeFileSync(path, fn(fs.readFileSync(path, 'utf8'))); }
function replaceRange(s, start, end, value) { const a=s.indexOf(start), b=s.indexOf(end,a); if(a<0||b<0) throw Error(start); return s.slice(0,a)+value+s.slice(b); }
edit('src-tauri/src/minecraft/installer.rs', s => {
 s=replaceRange(s,'    // Download NoRiskClient assets','    // Download Minecraft client','    // Vertix downloads only Minecraft assets.\n\n');
 s=replaceRange(s,'    // --- Provide managed mods via meta file','    if modloader_enum == ModLoader::Vanilla {\n        mod_resolution.mark_all_undelivered();',`    // Use each loader's standard mods directory; no upstream Forge injection.
    let profile_mods_path = state.profile_manager.get_profile_mods_path(profile)?;
    if modloader_enum != ModLoader::Vanilla {
        sync_vertix_mods(&target_mods, &profile_mods_path).await?;
    }

`);
 return s;
});
edit('src-tauri/src/minecraft/launch/launcher.rs', s => replaceRange(s,'        // Add NoRisk client specific parameters','        // Add additional JVM arguments',`        // Vertix uses the loaders' standard mods/ folder.
        if let Some(p) = &profile { command.arg(format!("-Dvertix.profile.name={}", p.name)); }

`));
edit('src-tauri/src/state/profile_state.rs', s => {
 s=replaceRange(s,'        let original = self.selected_norisk_pack_id.as_deref()?;','\n    }\n}', '        None');
 s=replaceRange(s,'        let mods_path = match profile.loader {','        log::debug!(', '        let mods_path = instance_path.join("mods");\n');
 return s;
});
edit('src/App.tsx', s => s.replace('key={item.id} className={`nav-item', 'key={item.id} aria-label={item.label} className={`nav-item').replace('className={`nav-item ${page === \'settings\'', 'aria-label="Einstellungen" className={`nav-item ${page === \'settings\'').replace('className="nav-item" onClick={() => setAboutOpen(true)}', 'className="nav-item" aria-label="Über Vertix" onClick={() => setAboutOpen(true)}'));
