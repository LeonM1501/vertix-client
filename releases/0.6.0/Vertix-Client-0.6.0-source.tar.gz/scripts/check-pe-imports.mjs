import { readFileSync } from 'node:fs';

// Inspect the import table without loading the executable or its DLLs.
for (const file of process.argv.slice(2)) {
  const b = readFileSync(file);
  const pe = b.readUInt32LE(0x3c);
  if (b.toString('ascii', pe, pe + 4) !== 'PE\0\0') throw new Error(`Invalid PE: ${file}`);
  const optional = pe + 24;
  const is64 = b.readUInt16LE(optional) === 0x20b;
  const directories = optional + (is64 ? 112 : 96);
  const sectionTable = optional + b.readUInt16LE(pe + 20);
  const sections = Array.from({ length: b.readUInt16LE(pe + 6) }, (_, i) => {
    const s = sectionTable + i * 40;
    return { rva: b.readUInt32LE(s + 12), size: Math.max(b.readUInt32LE(s + 8), b.readUInt32LE(s + 16)), offset: b.readUInt32LE(s + 20) };
  });
  const offset = rva => {
    const s = sections.find(s => rva >= s.rva && rva < s.rva + s.size);
    if (!s) throw new Error(`Invalid RVA ${rva}: ${file}`);
    return s.offset + rva - s.rva;
  };
  const imports = [];
  const importRva = b.readUInt32LE(directories + 8);
  if (importRva) for (let p = offset(importRva); b.readUInt32LE(p + 12); p += 20) {
    const name = offset(b.readUInt32LE(p + 12));
    imports.push(b.toString('ascii', name, b.indexOf(0, name)));
  }
  console.log(JSON.stringify({ file, architecture: is64 ? 'x64' : 'x86', imports }));
}
