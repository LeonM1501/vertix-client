// Vertix fork changes, 2026-10-08. Run once against the copied 0.6.28 sources.
import fs from 'node:fs';
function edit(path, fn) { const before = fs.readFileSync(path, 'utf8'); fs.writeFileSync(path, fn(before)); }
function body(source, marker, replacement) {
  const start = source.indexOf(marker); if (start < 0) throw new Error(`Missing ${marker}`);
  const open = source.indexOf('{', start); let depth = 1, end = open + 1;
  while (depth && end < source.length) { if (source[end] === '{') depth++; if (source[end] === '}') depth--; end++; }
  return source.slice(0, open + 1) + '\n' + replacement + '\n    }' + source.slice(end);
}
edit('src-tauri/Cargo.toml', s => s.replaceAll('noriskclient-launcher-v3', 'vertix-client').replaceAll('noriskclient_launcher_v3_lib', 'vertix_client_lib').replace('version = "0.6.28"', 'version = "0.1.0"').replace('description = "A Tauri App"', 'description = "Vertix Minecraft Launcher"'));
edit('src-tauri/src/config.rs', s => s.replace('ProjectDirs::from("gg", "norisk", "NoRiskClientV3")', 'ProjectDirs::from("app", "vertix", "VertixClient")').replace(' (support@norisk.gg)', ''));
edit('src-tauri/src/state/state_manager.rs', s => {
  // The empty upstream pack/version managers remain only for source compatibility.
  s = s.replace(/        ready_step\("NoriskVersionManager"[^\n]*\n/, '').replace(/        ready_step\("NoriskPackManager"[^\n]*\n/, '');
  const start = s.indexOf('        // Apply any token handbacks');
  const end = s.indexOf('        log::info!("State ready', start);
  if (start < 0 || end < 0) throw new Error('State init anchors missing');
  s = s.slice(0, start) + '        // Vertix has no in-game token handbacks, cosmetics, referrals or cloud startup.\n\n' + s.slice(end);
  return s.replace('.set_enabled(loaded_config.enable_discord_presence)', '.set_enabled(false)');
});
edit('src-tauri/src/state/profile_state.rs', s => s.replace(/        \/\/ Sync standard profiles[^]*?        trace!\("ProfileManager: Successfully loaded/, '        // Vertix starts without upstream standard profiles.\n        trace!("ProfileManager: Successfully loaded'));
edit('src-tauri/src/state/config_state.rs', s => s.replace('auto_check_updates: true', 'auto_check_updates: false').replace(/fn default_discord_presence\(\) -> bool \{[^}]*\}/, 'fn default_discord_presence() -> bool { false }').replace(/fn default_use_browser_based_login\(\) -> bool \{[^}]*\}/, 'fn default_use_browser_based_login() -> bool { true }'));
edit('src-tauri/src/minecraft/auth/minecraft_auth.rs', s => {
  s = body(s, 'pub(crate) async fn refresh_norisk_token_if_necessary(', '        // Upstream service authentication is removed from Vertix.\n        Ok((creds.clone(), false))');
  s = s.replace('const DIRECT_OAUTH_CLIENT_ID: &str = "e16699bb-2aa8-46da-b5e3-45cbcce29091";', `pub fn vertix_microsoft_client_id() -> Result<String> {
    let value = std::env::var("VERTIX_MICROSOFT_CLIENT_ID").ok().or_else(||
        std::fs::read_to_string(crate::config::LAUNCHER_DIRECTORY.root_dir().join("microsoft-client-id.txt")).ok()
    ).unwrap_or_default();
    let value = value.trim().to_string();
    uuid::Uuid::parse_str(&value).map_err(|_| AppError::Other("Für Vertix fehlt eine eigene Microsoft-App-ID. Bitte unter Einstellungen eintragen.".into()))?;
    Ok(value)
}`);
  s = s.replace('.append_pair("client_id", DIRECT_OAUTH_CLIENT_ID)', '.append_pair("client_id", &vertix_microsoft_client_id()?)');
  s = s.replaceAll('    query.insert("client_id", DIRECT_OAUTH_CLIENT_ID);', '    let client_id = vertix_microsoft_client_id()?;\n    query.insert("client_id", client_id.as_str());');
  // The OAuth state generated with PKCE must also be checked at the callback.
  s = s.replace('    error_html: String,\n) -> Result<(tokio::task::JoinHandle', '    error_html: String,\n    expected_state: String,\n) -> Result<(tokio::task::JoinHandle');
  s = s.replace('            move |Query(params): Query<HashMap<String, String>>| {', '            move |Query(params): Query<HashMap<String, String>>| {\n                let expected_state = expected_state.clone();');
  s = s.replace('                    if let Some(code) = params.get("code") {', '                    if params.get("state") != Some(&expected_state) {\n                        return Html("Ungültige Anmeldeantwort. Bitte erneut anmelden.".to_string());\n                    }\n                    if let Some(code) = params.get("code") {');
  return s;
});
edit('src-tauri/src/utils/http_client.rs', s => body(s, 'async fn send_inner(', '        Err(AppError::Other("Upstream service integrations are disabled in Vertix.".into()))'));
edit('src-tauri/src/commands/analytics_command.rs', s => {
  s = body(s, 'pub fn track_event(', '    // Vertix does not send analytics.');
  return body(s, 'async fn send_event(', '    Ok(())');
});
edit('src-tauri/src/commands/profile_command.rs', s => s.replace('selected_norisk_pack_id: params.selected_norisk_pack_id.clone()', 'selected_norisk_pack_id: None'));
edit('src-tauri/src/minecraft/launch/launcher.rs', s => s.replace('"noriskclient-launcher".to_string()', '"vertix-client".to_string()').replaceAll('"-Dnorisk.profile.name={}"', '"-Dvertix.profile.name={}"').replaceAll('"-Dnorisk.meta.dir={}"', '"-Dvertix.meta.dir={}"'));
// Archive branded packaging. It is not used for Vertix bundles.
fs.mkdirSync('upstream/packaging', { recursive: true });
for (const item of ['icons', 'dmg', 'installer-hooks.nsi']) {
  if (fs.existsSync(`src-tauri/${item}`)) fs.renameSync(`src-tauri/${item}`, `upstream/packaging/${item}`);
}
const config = JSON.parse(fs.readFileSync('src-tauri/tauri.conf.json', 'utf8'));
config.productName = 'Vertix Client'; config.version = '0.1.0'; config.identifier = 'app.vertix.client';
config.build.beforeDevCommand = 'npm run dev'; config.build.beforeBuildCommand = 'npm run build';
config.plugins = {};
config.app.windows[0] = { label: 'main', title: 'Vertix Client', width: 1280, height: 850, minWidth: 1000, minHeight: 720, decorations: false, transparent: false, visible: true, center: true };
config.app.security.csp = { 'default-src': ["'self'", 'ipc:', 'http://ipc.localhost'], 'connect-src': ["'self'", 'ipc:', 'http://ipc.localhost', 'https://api.modrinth.com', 'https://piston-meta.mojang.com'], 'img-src': ["'self'", 'data:', 'https://cdn.modrinth.com'], 'style-src': ["'self'", "'unsafe-inline'"], 'font-src': ["'self'"] };
config.bundle.targets = ['nsis']; config.bundle.createUpdaterArtifacts = false;
delete config.bundle.fileAssociations; delete config.bundle.macOS.dmg;
delete config.bundle.windows.nsis.installerHooks;
config.bundle.resources = ['../LICENSE', '../NOTICE.md'];
fs.writeFileSync('src-tauri/tauri.conf.json', JSON.stringify(config, null, 2) + '\n');
