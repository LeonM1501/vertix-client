const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
const output = ts.transpileModule(fs.readFileSync('src/modUpdates.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText;
const context = { exports: {}, require: () => ({}), URLSearchParams, Date };
vm.runInNewContext(output, context);
const newer = context.exports.newerModVersion;
const v = (id, date_published, version_type = 'release', files = [{}]) => ({ id, date_published, version_type, files });
const current = v('installed', '2026-10-01T10:00:00Z');
assert.equal(newer([current], current), undefined);
assert.equal(newer([v('new', '2026-10-02T10:00:00Z')], current).id, 'new');
assert.equal(newer([v('older', '2026-09-30T10:00:00Z')], current), undefined);
assert.equal(newer([v('same-date', current.date_published)], current), undefined);
assert.equal(newer([v('bad-date', 'invalid')], current), undefined);
assert.equal(newer([v('empty', '2026-10-02T10:00:00Z', 'release', [])], current), undefined);
assert.equal(newer([v('beta', '2026-10-03T10:00:00Z', 'beta'), v('stable', '2026-10-02T10:00:00Z')], current).id, 'stable');
assert.equal(newer([v('older-stable', '2026-09-30T10:00:00Z'), v('beta', '2026-10-03T10:00:00Z', 'beta')], current), undefined);
assert.equal(newer([], current), undefined);
console.log('9 mod update checks passed, including downgrade prevention.');
async function checkQueue() {
  const requests = [];
  const sandbox = { exports: {}, URLSearchParams, Date, require: () => ({ getJSON: async url => {
    requests.push(url);
    if (url.includes('/project/failing/')) throw Error('offline');
    if (url.includes('/project/current/')) return [current];
    if (url.includes('/project/old/')) return [v('new', '2026-10-02T10:00:00Z'), current];
    throw Error('Unexpected request: ' + url);
  } }) };
  vm.runInNewContext(output, sandbox);
  const controller = new AbortController();
  const items = [
    { id: 'mod:old', kind: 'mod', project_id: 'old', version_id: current.id, title: 'Old' },
    { id: 'mod:current', kind: 'mod', project_id: 'current', version_id: current.id, title: 'Current' },
    { id: 'mod:failing', kind: 'mod', project_id: 'failing', version_id: current.id, title: 'Failing' },
    { id: 'local', kind: 'mod', project_id: null, version_id: null },
    { id: 'pack', kind: 'resourcepack', project_id: 'not-a-mod', version_id: 'pack' },
  ];
  const result = await sandbox.exports.checkModUpdates({ loader: 'fabric', game_version: '26.3' }, items, controller.signal);
  assert.equal(Object.keys(result.updates).length, 1);
  assert.equal(result.updates['mod:old'].versionId, 'new');
  assert.equal(result.failures, 1);
  assert.equal(requests.length, 3);
  for (const request of requests) {
    const params = new URL(request).searchParams;
    assert.equal(params.get('loaders'), '["fabric"]');
    assert.equal(params.get('game_versions'), '["26.3"]');
  }
  controller.abort();
  const cancelled = await sandbox.exports.checkModUpdates({ loader: 'fabric', game_version: '26.3' }, items, controller.signal);
  assert.equal(Object.keys(cancelled.updates).length, 0);
  assert.equal(requests.length, 3);
  console.log('Update queue checks passed: partial failure, filters, unmanaged files and cancellation.');
}
checkQueue().catch(error => { console.error(error); process.exitCode = 1; });
