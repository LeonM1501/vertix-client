# Funktionsprüfung – 9. Oktober 2026

## Eigene Microsoft-App – neuer Stand

- Öffentliche Vertix-Desktop-App im eigenen Azure-Verzeichnis des Nutzers angelegt: `308cbf7a-f013-46c9-b015-8f45ef804a7f`, nur persönliche Microsoft-Konten, nativer Redirect `http://localhost:25585/callback`. Kein Client-Secret, keine Compute-/Hosting-/Speicherressourcen und kein Pay-as-you-go-Upgrade angelegt.
- Eigenes aktives OAuth-Modul mit PKCE, zufälligem State und nur lokalem Empfänger auf freiem Port. Microsoft ignoriert den Port bei localhost-Redirects; andere Nutzer verwenden denselben registrierten Pfad auf ihrem eigenen PC.
- Sichere Statusantwort an die Oberfläche enthält ausschließlich Client-ID, Anmeldestatus und Spielername. Sitzungen werden unter Windows mit benutzergebundener DPAPI gespeichert. Erneuerung nutzt ausschließlich Vertix’ eigene Microsoft-App; Minecraft-Profil und Java-Spielberechtigung werden online geprüft. Der offizielle Launcher bleibt als Alternative erhalten.
- TypeScript/Vite-Produktionsbuild, Rust-Prüfung und nativer Windows-Build erfolgreich. Aktualisierte EXE ersetzt und gestartet; native Startansicht zeigt „Bei Minecraft anmelden“, Einstellungen zeigen die neue Microsoft-Anmeldung. Bibliothek weiterhin leer; keine Testprofile angelegt.
- Drei neue Tests bestanden: registrierte Client-ID/PKCE/Weiterleitung, echte Windows-DPAPI-Ver- und Entschlüsselung mit Ablehnung beschädigter Daten sowie lokaler HTTP-Rückruf mit abgelehntem State und anschließend erfolgreichem gültigen Rückruf.
- **Noch offen:** echte Microsoft-Anmeldung, mögliche Freigabe der neuen App durch Minecraft und ein daraus gestartetes Spiel. Kein erfolgreicher Minecraft-Zugang wird aus der bloßen App-Registrierung abgeleitet.

Screenshot der erstellten App: `artifacts/Vertix-App-ID.png`.

## Aktuelle Instanzverwaltung und Launcher-Erkennung

- TypeScript/Vite-Produktionsbuild und nativer Windows-Build erfolgreich; aktualisierte EXE gestartet.
- Microsoft-Store-Launcher auf diesem Rechner erkannt. Seine Manifest-Anwendung heißt Minecraft, verwendet aber GameLaunchHelper.exe; die frühere Suche nach einem Minecraft-Executable übersah sie.
- Native Oberfläche zeigt „Launcher gefunden · Direktstart-Sitzung fehlt“ und bietet Erneut prüfen sowie Launcher öffnen an.
- Eigene Instanz im Desktop angelegt; die Instanzseite und der Modrinth-Browser sind bedienbar. Echte Mods, Ressourcenpakete und Shader für Minecraft 26.3 geladen. Browser-Vorschau zusätzlich mit 1.21.1 geprüft; zweite Ergebnisseite enthält andere Mods, Datenpaketsuche liefert Ergebnisse und sperrt den Download ohne Zielwelt.
- Über die native Oberfläche Sodium, Fresh Animations und Complementary Reimagined heruntergeladen. Dateien liegen nur in den jeweiligen mods/resourcepacks/shaderpacks-Unterordnern der Testinstanz und werden als installiert markiert.
- Ressourcenpaket deaktiviert: Datei wird .zip.disabled. Erneutes Aktualisieren erhält den deaktivierten Zustand. Sodium deaktiviert: verwaltete JAR wird aus dem aktiven Mods-Ordner entfernt. Erneutes Aktualisieren aktiviert ihn nicht automatisch.
- Zweite native Instanz angelegt: Inhaltsliste leer und eigener Ordner ohne Dateien. Kein Inhalt der ersten Instanz wird übernommen.
- App vollständig geschlossen und neu gestartet, während der Entwicklungsserver beendet war. Gespeicherte Profile werden wieder geladen; Sodium bleibt in SQLite deaktiviert und das Ressourcenpaket behält seine .disabled-Datei.
- Spielstart ohne verwendbare Sitzung öffnet den erklärenden Ausweichdialog. Die Protokollansicht einer noch nicht gestarteten Instanz zeigt den passenden Leerzustand.
- Eigene Testinstanzen und Datenbank nach Abschluss unter `artifacts/test/instance-management-2026-10-09` archiviert. Aktive Bibliothek wieder leer. Abschließender Build nach Vereinheitlichung der Sperre für Downloads/Spielstart/Export erfolgreich.
- Fünf Tests des Launcher-Moduls bestanden: aktive Kontoauswahl und Ablaufprüfung, Erhalt anderer Installationen, wiederholter Export, ungültige Pfade und getrennte Mod-Synchronisierung. Ein zusätzlicher Test für getrennte Paketordner, weltbezogene Datenpakete und Pfadbegrenzung bestanden.

**Direktstart nicht bestätigt und auf diesem Rechner derzeit blockiert:** Der installierte Store-Launcher speichert in seiner Accountdatei kein verwendbares Minecraft-Spieltoken, auch nach dem vom Nutzer ausgeführten Start bis ins Java-Hauptmenü. Der ausdrücklich dafür vorgesehene optionale Live-Sitzungstest schlägt deshalb mit „Keine gültige Minecraft-Sitzung gefunden“ fehl. Es werden keine verschlüsselten Anmeldedaten ausgelesen und keine Anmeldung umgangen. Der Direktstart-Code ist nur für Launcher-Versionen nutzbar, die eine gültige kurzlebige Minecraft-Sitzung lokal bereitstellen. Als Ausweichweg bleibt der Export einer getrennten Installation in den offiziellen Launcher verfügbar. Ein echter Minecraft-Prozess aus Vertix ist nicht als erfolgreich geprüft zu verstehen.

Screenshots: `artifacts/Vertix-Instanz.jpg`, `artifacts/Vertix-Launcher-Erkennung.jpg`.

## Frühere Prüfung: Umstellung auf den offiziellen Launcher

Die folgenden Punkte dokumentieren den vorherigen Build mit ausschließlich offiziellem Launcher-Spielstart:

- TypeScript-Prüfung und Vite-Produktionsbuild erfolgreich.
- Nativer Rust-Build mit eingebetteter Oberfläche erfolgreich. Die aktualisierte EXE unter `artifacts/Vertix Client.exe` gestartet; leere Profilbibliothek und neuer Minecraft-Launcher-Zugang sichtbar.
- Klick auf den Launcher-Zugang bei fehlender Installation öffnet die Einrichtungshilfe mit passendem Hinweis. Erneute Erkennung durchgeführt; Öffnen-Schaltfläche bleibt ohne Installation deaktiviert, Download-Schaltfläche ist verfügbar. Keine App-ID-Eingabe mehr sichtbar.
- Entwicklungsserver beendet und Desktop-Oberfläche neu geladen: eingebettete Oberfläche weiter verfügbar.
- Fünf Rust-Tests bestanden, einschließlich des Live-Tests mit Mojang-, Fabric-, Quilt- und Modrinth-Metadaten sowie echtem Sodium-JAR-Download.
- Vanilla-, Fabric- und Quilt-Profile in temporären Testordnern vorbereitet und in beide Launcher-Installationsdateiformate exportiert. Alle drei bekommen unterschiedliche Spielordner; bestehende Installationen und Einstellungen bleiben erhalten.
- Erneutes Exportieren aktualisiert nur den eigenen Profileintrag. Ungültige Installationslisten und unsichere Versionspfade werden abgelehnt.
- Verwaltete Mods werden nur ins zugehörige Profil kopiert; beim Deaktivieren entfernt. Lokale JARs und Dateien anderer Profile bleiben erhalten.
- Die aktive Desktop-Befehlsliste enthält keine direkte OAuth-Anmeldung und keinen direkten Minecraft-Prozessstart mehr.

Live-Tests erneut ausführen (Windows, Netzverbindung erforderlich):

```powershell
cargo test --manifest-path src-tauri/Cargo.toml --lib official_launcher::tests --features custom-protocol,test-manifest -- --include-ignored
```

Das Merkmal `test-manifest` aktiviert Windows Common Controls v6 für den Unit-Test-Prozess. Nicht beim App-Build einschalten: Tauri bettet dort bereits sein eigenes Windows-Manifest ein.

Noch nicht bestätigt: Anmeldung und echter Minecraft-Spielstart über den offiziellen Launcher, da dieser auf dem Testrechner noch nicht installiert ist. Forge-/NeoForge-Client-Installer sind angebunden, aber noch nicht mit einem vollständigen Installerlauf oder im Spiel geprüft. Das Verhalten des offiziellen Launchers beim tatsächlichen Laden der exportierten Installationen muss nach seiner Installation geprüft werden. Dies ist ein lokaler unsignierter Testbuild.

Aktuelle Einrichtungsansicht: `artifacts/Vertix-Launcher-Setup.jpg`.

## Frühere Prüfung – 8. Oktober 2026

Geprüft an der lokalen Windows-Testversion 0.1.0.

- TypeScript-Prüfung und Vite-Produktionsbuild erfolgreich.
- Rust-Build mit eingebetteter Oberfläche (`custom-protocol`) erfolgreich; übernommene unbenutzte Imports/Kompatibilitätsfelder erzeugen noch Compilerwarnungen.
- Native App startet, initialisiert den eigenen Datenspeicher und zeigt eine leere Bibliothek ohne NoRisk-Vorgabeprofile.
- Über die Oberfläche ein Fabric-Profil für Minecraft 1.21.1 mit 4 GB RAM erstellt. Speicherung im eigenen SQLite-Datenspeicher bestätigt.
- Live-Modrinth-Ergebnisse in der Windows-App geladen. Sodium in kompatibler Fabric-Version hinzugefügt und deaktiviert.
- App geschlossen und erneut geöffnet: Profil, Sodium und deaktivierter Status bleiben erhalten.
- Eigene Test-JAR über den nativen Windows-Dateidialog importiert. Datei erscheint als lokale JAR im Profil. Deaktivierung benennt die Datei korrekt in `.jar.disabled` um.
- Fehlende eigene Microsoft-App-ID zeigt einen verständlichen Hinweis.
- Entwicklungsserver beendet und Desktop-Oberfläche neu geladen: eingebettete Startansicht bleibt verfügbar.
- Browser-Vorschau zusätzlich geprüft: Profil anlegen, nach Neuladen wiederfinden und Modrinth-Suche.
- Selbst angelegte Desktop-Testdaten aus der aktiven Bibliothek entfernt und unter `artifacts/test/` archiviert. Kein Testprofil wird ausgeliefert oder automatisch angelegt.

Die damalige direkte Microsoft-Anmeldung wurde am 9. Oktober durch die Übergabe an den offiziellen Launcher ersetzt. Die frühere Voraussetzung einer eigenen Microsoft-App-ID entfällt. Der Moddownload ist inzwischen separat mit einer echten Sodium-JAR geprüft; ein gestarteter Minecraft-Prozess wurde weiterhin nicht beobachtet.

Screenshots: `artifacts/Vertix-Preview.jpg` und `artifacts/Vertix-Modtest.jpg`.
