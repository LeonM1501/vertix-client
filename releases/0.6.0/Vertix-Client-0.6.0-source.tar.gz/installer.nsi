!include "MUI2.nsh"
!include "FileFunc.nsh"
!include "Sections.nsh"
Var UpdateMode
Var UpdateWait

; Application Name and Output Installer
Name "Vertix Client"
!ifndef ARTIFACT_DIR
!define ARTIFACT_DIR "artifacts"
!endif
!ifndef APP_VERSION
!define APP_VERSION "0.1.0"
!endif
OutFile "${ARTIFACT_DIR}\Vertix-Client-Setup.exe"
Unicode True

; Default Installation Directory on Main SSD: AppData\Local\Programs\Vertix Client
InstallDir "$LOCALAPPDATA\Programs\Vertix Client"
InstallDirRegKey HKCU "Software\VertixClient" "InstallLocation"

; Run with user privileges so no admin prompt is required
RequestExecutionLevel user

; Installer branding and appearance
!define MUI_ICON "src-tauri\icons\icon.ico"
!define MUI_UNICON "src-tauri\icons\icon.ico"
!define MUI_ABORTWARNING

; Welcome page
!insertmacro MUI_PAGE_WELCOME

; License page
!insertmacro MUI_PAGE_LICENSE "LICENSE"

; Directory selection page (user can customize installation location)
!insertmacro MUI_PAGE_DIRECTORY

; Components page (user can toggle Start menu, Desktop, and Taskbar shortcuts)
!insertmacro MUI_PAGE_COMPONENTS

; Installation progress page
!insertmacro MUI_PAGE_INSTFILES

; Finish page with optional launch
!define MUI_FINISHPAGE_RUN "$INSTDIR\Vertix Client.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Vertix Client jetzt starten"
!insertmacro MUI_PAGE_FINISH

; Uninstaller pages
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; Language
!insertmacro MUI_LANGUAGE "German"

; Core section (Mandatory)
Section "Vertix Client (erforderlich)" SecCore
    SectionIn RO
    SetOutPath "$INSTDIR"
    
    ; Copy executable and metadata
    File "${ARTIFACT_DIR}\Vertix Client.exe"
    File "${ARTIFACT_DIR}\WebView2Loader.dll"
    File "${ARTIFACT_DIR}\libunwind.dll"
    File /nonfatal "LICENSE"
    File /nonfatal "NOTICE.md"

    ; Legacy 0.1.0 needs its update endpoint initialized by the installer.
    ; New clients query the GitHub endpoint themselves.
!if "${APP_VERSION}" == "0.1.0"
    DetailPrint "Updatequelle wird eingerichtet ..."
    SetOutPath "$APPDATA\vertix"
    SetOverwrite off
    File /oname=update_release.json "artifacts\releases\0.2.0\version.json"
    SetOverwrite on
    InitPluginsDir
    SetOutPath "$PLUGINSDIR"
    File "packaging\Initialize-Updates.ps1"
    File "artifacts\releases\0.2.0\version.json"
    System::Call 'kernel32::SetEnvironmentVariableW(w "VERTIX_UPDATE_BOOTSTRAP_SCRIPT", w "$PLUGINSDIR\Initialize-Updates.ps1") i .r0'
    nsExec::ExecToStack /TIMEOUT=20000 '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -Command "& ([scriptblock]::Create([IO.File]::ReadAllText($$env:VERTIX_UPDATE_BOOTSTRAP_SCRIPT)))"'
    Pop $0
    Pop $1
    DetailPrint "$1"
    SetOutPath "$INSTDIR"
!endif
    
    ; Create Uninstaller
    WriteUninstaller "$INSTDIR\Uninstall.exe"
    
    ; Store installation directory in registry
    WriteRegStr HKCU "Software\VertixClient" "InstallLocation" "$INSTDIR"
    
    ; Register in Windows Installed Apps / Control Panel
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "DisplayName" "Vertix Client"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "DisplayIcon" "$INSTDIR\Vertix Client.exe"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "DisplayVersion" "${APP_VERSION}"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "Publisher" "Vertix"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "UninstallString" "$\"$INSTDIR\Uninstall.exe$\""
    WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "NoModify" 1
    WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient" "NoRepair" 1
SectionEnd

; Start Menu Shortcut Section (Checked by default)
Section "Startmenü-Verknüpfung" SecStartMenu
    CreateDirectory "$SMPROGRAMS\Vertix Client"
    CreateShortcut "$SMPROGRAMS\Vertix Client\Vertix Client.lnk" "$INSTDIR\Vertix Client.exe" "" "$INSTDIR\Vertix Client.exe" 0
    CreateShortcut "$SMPROGRAMS\Vertix Client\Deinstallieren.lnk" "$INSTDIR\Uninstall.exe" "" "$INSTDIR\Uninstall.exe" 0
SectionEnd

; Desktop Shortcut Section (Checked by default)
Section "Desktop-Verknüpfung" SecDesktop
    CreateShortcut "$DESKTOP\Vertix Client.lnk" "$INSTDIR\Vertix Client.exe" "" "$INSTDIR\Vertix Client.exe" 0
SectionEnd

; Taskbar Shortcut Section (Unchecked by default, user selectable)
Section /o "An Taskleiste anheften" SecTaskbar
    CreateDirectory "$APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar"
    CreateShortcut "$APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Vertix Client.lnk" "$INSTDIR\Vertix Client.exe" "" "$INSTDIR\Vertix Client.exe" 0
SectionEnd

; Descriptions for components
Function .onInit
    StrCpy $UpdateMode 0
    ${GetParameters} $0
    ClearErrors
    ${GetOptions} $0 "/UPDATE" $1
    IfErrors 0 update_mode
    ; 0.2.0 launches its downloaded installer without flags.
    StrCmp $EXEDIR "$APPDATA\vertix\updates" update_mode done_init
update_mode:
    StrCpy $UpdateMode 1
    SetSilent silent
    SectionSetFlags ${SecStartMenu} 0
    SectionSetFlags ${SecDesktop} 0
    SectionSetFlags ${SecTaskbar} 0
    ; Wait for the previous client to release its executable.
    StrCpy $UpdateWait 0
wait_client:
    IfFileExists "$INSTDIR\Vertix Client.exe" 0 done_init
    System::Call 'kernel32::CreateFileW(w "$INSTDIR\Vertix Client.exe", i 0x40000000, i 0, p 0, i 3, i 0, p 0) p .r2'
    StrCmp $2 -1 client_locked
    System::Call 'kernel32::CloseHandle(p r2)'
    Goto done_init
client_locked:
    IntOp $UpdateWait $UpdateWait + 1
    IntCmp $UpdateWait 120 update_failed
    Sleep 500
    Goto wait_client
update_failed:
    MessageBox MB_ICONSTOP "Vertix konnte nicht beendet werden. Bitte schließe Vertix und versuche das Update erneut."
    Abort
done_init:
FunctionEnd

Function .onInstSuccess
    StrCmp $UpdateMode 1 0 done_success
    Exec '"$INSTDIR\Vertix Client.exe"'
done_success:
FunctionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
    !insertmacro MUI_DESCRIPTION_TEXT ${SecCore} "Die Programmdateien von Vertix Client."
    !insertmacro MUI_DESCRIPTION_TEXT ${SecStartMenu} "Erstellt Verknüpfungen im Startmenü (standardmäßig aktiviert)."
    !insertmacro MUI_DESCRIPTION_TEXT ${SecDesktop} "Erstellt eine Verknüpfung auf dem Desktop (standardmäßig aktiviert)."
    !insertmacro MUI_DESCRIPTION_TEXT ${SecTaskbar} "Heftet das Programm an die Windows-Taskleiste an."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

; Uninstaller Section
Section "Uninstall"
    ; Remove shortcuts
    Delete "$DESKTOP\Vertix Client.lnk"
    Delete "$SMPROGRAMS\Vertix Client\Vertix Client.lnk"
    Delete "$SMPROGRAMS\Vertix Client\Deinstallieren.lnk"
    RMDir "$SMPROGRAMS\Vertix Client"
    Delete "$APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Vertix Client.lnk"
    
    ; Remove application files
    Delete "$INSTDIR\Vertix Client.exe"
    Delete "$INSTDIR\WebView2Loader.dll"
    Delete "$INSTDIR\libunwind.dll"
    Delete "$INSTDIR\LICENSE"
    Delete "$INSTDIR\NOTICE.md"
    Delete "$INSTDIR\Uninstall.exe"
    RMDir "$INSTDIR"
    
    ; Remove registry keys
    DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VertixClient"
    DeleteRegKey HKCU "Software\VertixClient"
SectionEnd
