$ErrorActionPreference = 'Stop'
$configDirectory = Join-Path $env:APPDATA 'vertix'
$configPath = Join-Path $configDirectory 'update_release.json'
$bootstrapDirectory = Split-Path -Parent $env:VERTIX_UPDATE_BOOTSTRAP_SCRIPT

function Test-ReleaseManifest($manifest) {
    return $manifest.version -match '^\d+\.\d+\.\d+$' -and
        $manifest.installer_url -eq ('https://raw.githubusercontent.com/LeonM1501/vertix-client/main/releases/' + $manifest.version + '/Vertix-Client-Setup.exe')
}

# The installer carries a known release for installations without internet access.
$manifest = Get-Content -LiteralPath (Join-Path $bootstrapDirectory 'version.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not (Test-ReleaseManifest $manifest)) { throw 'Invalid bundled update manifest.' }
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $remote = Invoke-RestMethod -Uri 'https://raw.githubusercontent.com/LeonM1501/vertix-client/main/version.json' -TimeoutSec 8
    if (Test-ReleaseManifest $remote) { $manifest = $remote }
} catch {
    # Keep a newer previously configured release when offline.
    if (Test-Path -LiteralPath $configPath) {
        try {
            $existing = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ((Test-ReleaseManifest $existing) -and ([version]$existing.version -gt [version]$manifest.version)) { $manifest = $existing }
        } catch { }
    }
}
[IO.Directory]::CreateDirectory($configDirectory) | Out-Null
$json = $manifest | ConvertTo-Json -Depth 5
if (Test-Path -LiteralPath $configPath) {
    Copy-Item -LiteralPath $configPath -Destination ($configPath + '.before-setup') -Force
}
$temporaryPath = $configPath + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
[IO.File]::WriteAllText($temporaryPath, $json, [Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $temporaryPath -Destination $configPath -Force
Write-Output ('Updatequelle eingerichtet: ' + $manifest.version)
