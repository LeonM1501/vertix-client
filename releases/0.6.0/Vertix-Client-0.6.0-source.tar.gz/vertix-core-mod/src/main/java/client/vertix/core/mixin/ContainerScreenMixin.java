package client.vertix.core.mixin;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.modules.qol.MouseTweaksModule;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public abstract class ContainerScreenMixin {

    @Shadow protected Slot hoveredSlot;
    @Shadow protected AbstractContainerMenu menu;
    @Shadow protected abstract void slotClicked(Slot slot, int slotId, int mouseButton, ContainerInput containerInput);

    @Unique
    private Slot vertix$lastSlot = null;

    @Inject(method = "mouseDragged", at = @At("HEAD"), require = 0)
    private void vertix$onMouseDragged(MouseButtonEvent event, double dragX, double dragY, CallbackInfoReturnable<Boolean> cir) {
        VertixCoreMod mod = VertixCoreMod.getInstance();
        if (mod == null || mod.getModuleManager() == null) return;
        MouseTweaksModule mt = (MouseTweaksModule) mod.getModuleManager().getModule("mouse_tweaks");
        if (mt == null || !mt.isEnabled()) return;

        if (this.hoveredSlot == null) return;

        // Shift + LMB drag: Quick Move items across all hovered slots
        if (mt.isShiftDrag() && event.button() == InputConstants.MOUSE_BUTTON_LEFT && event.hasShiftDown()) {
            if (this.hoveredSlot != this.vertix$lastSlot && this.hoveredSlot.hasItem()) {
                this.vertix$lastSlot = this.hoveredSlot;
                this.slotClicked(this.hoveredSlot, this.hoveredSlot.index, InputConstants.MOUSE_BUTTON_LEFT, ContainerInput.QUICK_MOVE);
            }
            return;
        }

        // RMB drag: Drop 1 item per slot if holding an item on cursor
        if (mt.isRmbDrag() && event.button() == InputConstants.MOUSE_BUTTON_RIGHT) {
            if (this.hoveredSlot != this.vertix$lastSlot) {
                this.vertix$lastSlot = this.hoveredSlot;
                if (this.menu != null && !this.menu.getCarried().isEmpty()) {
                    this.slotClicked(this.hoveredSlot, this.hoveredSlot.index, InputConstants.MOUSE_BUTTON_RIGHT, ContainerInput.PICKUP);
                }
            }
        }
    }

    @Inject(method = "mouseReleased", at = @At("HEAD"), require = 0)
    private void vertix$onMouseReleased(MouseButtonEvent event, CallbackInfoReturnable<Boolean> cir) {
        this.vertix$lastSlot = null;
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"), cancellable = true, require = 0)
    private void vertix$onMouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY, CallbackInfoReturnable<Boolean> cir) {
        VertixCoreMod mod = VertixCoreMod.getInstance();
        if (mod == null || mod.getModuleManager() == null) return;
        MouseTweaksModule mt = (MouseTweaksModule) mod.getModuleManager().getModule("mouse_tweaks");
        if (mt == null || !mt.isEnabled() || !mt.isScrollTweak()) return;

        if (this.hoveredSlot != null && this.hoveredSlot.hasItem() && scrollY > 0) {
            this.slotClicked(this.hoveredSlot, this.hoveredSlot.index, InputConstants.MOUSE_BUTTON_LEFT, ContainerInput.QUICK_MOVE);
            cir.setReturnValue(true);
        }
    }
}
