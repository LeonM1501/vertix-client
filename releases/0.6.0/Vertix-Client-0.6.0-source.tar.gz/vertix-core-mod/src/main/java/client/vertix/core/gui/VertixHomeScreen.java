package client.vertix.core.gui;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.VertixCoreMod;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import static client.vertix.core.gui.RenderUtils.*;

/** R-Shift entry point. Only working features are shown here. */
public final class VertixHomeScreen extends Screen {
    public VertixHomeScreen() { super(Component.literal("Vertix")); }
    @Override public boolean isPauseScreen() { return false; }
    private MenuLayout.Rect button(int index) {
        MenuLayout.Rect p = MenuLayout.home(width, height);
        int y = p.y() + p.h() - 114;
        if (index == 0) return new MenuLayout.Rect(p.x() + 16, y, p.w() - 32, 30);
        int w = (p.w() - 40) / 2;
        return new MenuLayout.Rect(p.x() + 16 + (index - 1) * (w + 8), y + 38, w, 30);
    }
    @Override public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float delta) { drawRect(g, 0, 0, width, height, 0x99000000); }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        MenuLayout.Rect p = MenuLayout.home(width, height);
        drawCard(g, p.x(), p.y(), p.w(), p.h(), COLOR_BG_MAIN, COLOR_BORDER_DEFAULT);
        mark(g, p.x() + p.w() / 2 - 14, p.y() + 22, COLOR_ACCENT);
        drawCenteredText(g, font, "V E R T I X", p.x() + p.w() / 2, p.y() + 56, COLOR_TEXT_PRIMARY, false);
        drawCenteredText(g, font, "DEIN SPIEL. DEIN SETUP.", p.x() + p.w() / 2, p.y() + 73, COLOR_TEXT_MUTED, false);
        RenderUtils.button(g, font, button(0), "MOD MENÜ   >", true, button(0).contains(mx, my));
        RenderUtils.button(g, font, button(1), "Profile", false, button(1).contains(mx, my));
        RenderUtils.button(g, font, button(2), "HUD bearbeiten", false, button(2).contains(mx, my));
        int active = (int) VertixCoreMod.getInstance().getModuleManager().getModules().stream().filter(m -> m.isEnabled()).count();
        drawCenteredText(g, font, active + " Module aktiv", p.x() + p.w() / 2, p.bottom() - 33, COLOR_TEXT_MUTED, false);
        drawCenteredText(g, font, "R-SHIFT / ESC   Zurück zum Spiel", p.x() + p.w() / 2, p.bottom() - 16, COLOR_TEXT_SECONDARY, false);
    }
    @Override public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
        if (e.button() != InputConstants.MOUSE_BUTTON_LEFT) return super.mouseClicked(e, doubleClick);
        if (button(0).contains(e.x(), e.y())) minecraft.setScreenAndShow(new VertixMenuScreen(this, false));
        else if (button(1).contains(e.x(), e.y())) minecraft.setScreenAndShow(new VertixMenuScreen(this, true));
        else if (button(2).contains(e.x(), e.y())) minecraft.setScreenAndShow(new HudEditorScreen(this));
        else return super.mouseClicked(e, doubleClick);
        return true;
    }
    @Override public boolean keyPressed(KeyEvent e) {
        if (e.key() == InputConstants.KEY_RSHIFT || e.key() == InputConstants.KEY_ESCAPE) { onClose(); return true; } return super.keyPressed(e);
    }
    @Override public void onClose() {
        VertixCoreMod.getInstance().getConfigManager().saveConfig(VertixCoreMod.getInstance().getModuleManager().getModules());
        minecraft.setScreenAndShow(null);
    }
}
