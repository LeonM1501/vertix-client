package client.vertix.core.config;

/** Upgrade stock 1.0 visuals while retaining individually chosen colors and positions. */
public final class LegacyHudStyle {
    private LegacyHudStyle() {}

    public static int color(String module, String setting, int saved) {
        if (setting.equals("color")) {
            if ((module.equals("fps") && saved == 0xFF55FF55)
                    || (module.equals("cps") && saved == 0xFFFFC837)
                    || (module.equals("toggle_sprint") && saved == 0xFF00FF88)
                    || (module.equals("coordinates") && saved == 0xFFFFFFFF)) return 0xFFF2F0EB;
        }
        if (module.equals("keystrokes")) {
            if (setting.equals("active_color") && saved == 0xFF00D4FF) return 0xFFECE9E2;
            if (setting.equals("inactive_color") && saved == 0x801A1E24) return 0xE01C1C1C;
        }
        return saved;
    }

    public static double number(String module, String setting, double saved) {
        return setting.equals("bg_opacity") && saved == 0.5
                && (module.equals("fps") || module.equals("cps") || module.equals("coordinates")) ? 0.88 : saved;
    }

    public static int y(String module, int savedX, int savedY) {
        if (savedX != 4) return savedY;
        return switch (module) {
            case "coordinates" -> savedY == 22 ? 28 : savedY;
            case "fps" -> savedY == 50 ? 64 : savedY;
            case "armor_hud" -> savedY == 70 ? 88 : savedY;
            case "keystrokes" -> savedY == 110 ? 132 : savedY;
            case "cps" -> savedY == 185 ? 240 : savedY;
            case "potion_effects" -> savedY == 205 ? 266 : savedY;
            default -> savedY;
        };
    }
}
