package client.vertix.core.modules.qol;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public class ArmorHudModule extends Module {

    private final Setting.ModeSetting orientation;
    private final Setting.BooleanSetting showDurability;
    private final Setting.BooleanSetting showHeld;

    public ArmorHudModule() {
        super("armor_hud", "Armor HUD", "Zeigt ausgerüstete Rüstungsteile, Haltbarkeit und gehaltene Items an.",
                Category.HUD, true, true, 4, 88);

        this.orientation = new Setting.ModeSetting("orientation", "Ausrichtung", "Horizontale oder vertikale Anzeige.", "Horizontal", "Horizontal", "Vertikal");
        this.showDurability = new Setting.BooleanSetting("durability", "Haltbarkeit", "Zeigt verbleibende Haltbarkeit in Prozent.", true);
        this.showHeld = new Setting.BooleanSetting("held", "Hände einbeziehen", "Zeigt auch Haupt- und Nebenhand-Items an.", true);

        addSetting(orientation);
        addSetting(showDurability);
        addSetting(showHeld);

        this.width = 90;
        this.height = 20;
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled() || client.player == null) return;

        List<ItemStack> items = new ArrayList<>();
        if (showHeld.getValue()) {
            items.add(client.player.getMainHandItem());
        }
        items.add(client.player.getItemBySlot(EquipmentSlot.HEAD));
        items.add(client.player.getItemBySlot(EquipmentSlot.CHEST));
        items.add(client.player.getItemBySlot(EquipmentSlot.LEGS));
        items.add(client.player.getItemBySlot(EquipmentSlot.FEET));
        if (showHeld.getValue()) {
            items.add(client.player.getOffhandItem());
        }

        renderItems(extractor, client, items);
    }

    private void renderItems(GuiGraphicsExtractor extractor, Minecraft client, List<ItemStack> items) {
        boolean horizontal = "Horizontal".equalsIgnoreCase(orientation.getValue());
        int slotSize = showDurability.getValue() ? Math.max(28, client.font.width("100%") + 4) : 20;
        int count = items.size();

        if (horizontal) {
            this.width = count * slotSize + 12;
            this.height = showDurability.getValue() ? 38 : 28;
        } else {
            this.width = showDurability.getValue() ? 60 : 28;
            this.height = count * slotSize + 12;
        }

        HudStyle.panel(extractor, x, y, width, height);

        int curX = x + 6;
        int curY = y + 6;

        for (ItemStack stack : items) {
            if (!stack.isEmpty()) {
                int itemX = horizontal ? curX + (slotSize - 16) / 2 : curX;
                RenderUtils.drawItem(extractor, stack, itemX, curY);
                RenderUtils.drawItemDecorations(extractor, client.font, stack, itemX, curY);

                if (showDurability.getValue() && stack.isDamageableItem()) {
                    int max = stack.getMaxDamage();
                    int cur = max - stack.getDamageValue();
                    int pct = (int) Math.round((cur * 100.0) / max);
                    String pctStr = pct + "%";
                    int col = HudStyle.TEXT;

                    if (horizontal) {
                        RenderUtils.drawCenteredText(extractor, client.font, pctStr, curX + slotSize / 2, curY + 20, col, false);
                    } else {
                        RenderUtils.drawText(extractor, client.font, pctStr, curX + 22, curY + 4, col, false);
                    }
                }
            }

            if (horizontal) {
                curX += slotSize;
            } else {
                curY += slotSize;
            }
        }
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        List<ItemStack> sample = new ArrayList<>();
        if (showHeld.getValue()) sample.add(new ItemStack(Items.IRON_SWORD));
        sample.add(new ItemStack(Items.IRON_HELMET));
        sample.add(new ItemStack(Items.IRON_CHESTPLATE));
        sample.add(new ItemStack(Items.IRON_LEGGINGS));
        sample.add(new ItemStack(Items.IRON_BOOTS));
        if (showHeld.getValue()) sample.add(new ItemStack(Items.SHIELD));
        renderItems(extractor, client, sample);
    }
}
