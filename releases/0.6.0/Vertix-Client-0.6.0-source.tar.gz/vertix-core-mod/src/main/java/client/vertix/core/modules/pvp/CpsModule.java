package client.vertix.core.modules.pvp;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class CpsModule extends Module {

    private final Setting.BooleanSetting showBoth;
    private final Setting.ColorSetting textColor;
    private final Setting.NumberSetting bgOpacity;

    public CpsModule() {
        super("cps", "CPS Counter", "Zeigt Klicks pro Sekunde (CPS) für Links- und Rechtsklick an.",
                Category.PVP, true, true, 4, 240);

        this.showBoth = new Setting.BooleanSetting("both", "Beide Maustasten", "Zeigt sowohl LMB als auch RMB Klickraten an.", true);
        this.textColor = new Setting.ColorSetting("color", "Textfarbe", "Farbe der CPS-Anzeige.", HudStyle.TEXT);
        this.bgOpacity = new Setting.NumberSetting("bg_opacity", "Hintergrund-Transparenz", "Deckkraft des Hintergrunds.", HudStyle.DEFAULT_OPACITY, 0.0, 1.0, 0.05, false);

        addSetting(showBoth);
        addSetting(textColor);
        addSetting(bgOpacity);

        this.width = 64;
        this.height = HudStyle.COMPACT_HEIGHT;
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled()) return;

        int lCps = VertixCoreMod.getInstance().getLeftCps();
        int rCps = VertixCoreMod.getInstance().getRightCps();

        String text = showBoth.getValue() ? (lCps + " | " + rCps + " CPS") : (lCps + " CPS");
        this.width = client.font.width(text) + 12;

        HudStyle.panel(extractor, x, y, width, height, bgOpacity.getValue());
        HudStyle.centered(extractor, client.font, text, x + width / 2, y + 6, textColor.getValue());
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        this.width = client.font.width("12 | 8 CPS") + 12;
        this.height = HudStyle.COMPACT_HEIGHT;
        HudStyle.panel(extractor, x, y, width, height, bgOpacity.getValue());
        HudStyle.centered(extractor, client.font, "12 | 8 CPS", x + width / 2, y + 6, textColor.getValue());
    }
}
