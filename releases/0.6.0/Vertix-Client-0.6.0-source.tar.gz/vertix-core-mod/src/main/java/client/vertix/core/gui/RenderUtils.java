package client.vertix.core.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

public class RenderUtils {

    public static final int COLOR_BG_MAIN = 0xFA121212;
    public static final int COLOR_BG_HEADER = 0xFF171717;
    public static final int COLOR_BG_CARD = 0xFF1C1C1C;
    public static final int COLOR_BG_CARD_HOVER = 0xFF252525;
    public static final int COLOR_BORDER_DEFAULT = 0xFF333333;
    public static final int COLOR_BORDER_HOVER = 0xFF686868;
    public static final int COLOR_ACCENT = 0xFFECE9E2;
    public static final int COLOR_ACCENT_GREEN = COLOR_ACCENT;
    public static final int COLOR_ACCENT_CYAN = COLOR_ACCENT;
    public static final int COLOR_ACCENT_GOLD = COLOR_ACCENT;
    public static final int COLOR_ACCENT_RED = COLOR_ACCENT;
    public static final int COLOR_TEXT_PRIMARY = 0xFFF2F0EB;
    public static final int COLOR_TEXT_SECONDARY = 0xFFB8B8B8;
    public static final int COLOR_TEXT_MUTED = 0xFF929292;

    public static String fit(Font font, String text, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (font.width(text) <= maxWidth) return text;
        while (!text.isEmpty() && font.width(text + "...") > maxWidth)
            text = text.substring(0, text.offsetByCodePoints(text.length(), -1));
        return font.width("...") <= maxWidth ? text + "..." : "";
    }
    public static void button(GuiGraphicsExtractor g, Font font, MenuLayout.Rect r, String label, boolean primary, boolean hover) {
        drawCard(g, r.x(), r.y(), r.w(), r.h(), primary ? (hover ? 0xFFFFFFFF : COLOR_ACCENT) :
                (hover ? COLOR_BG_CARD_HOVER : COLOR_BG_CARD), primary ? COLOR_ACCENT : hover ? COLOR_BORDER_HOVER : COLOR_BORDER_DEFAULT);
        drawCenteredText(g, font, fit(font, label, r.w() - 12), r.x() + r.w() / 2, r.y() + (r.h() - 8) / 2,
                primary ? 0xFF171717 : COLOR_TEXT_PRIMARY, false);
    }
    public static void mark(GuiGraphicsExtractor g, int x, int y, int color) {
        for (int i = 0; i < 7; i++) {
            drawRect(g, x + i * 2, y + i * 3, 5, 4, color);
            drawRect(g, x + 24 - i * 2, y + i * 3, 5, 4, color);
        }
    }

    public static void drawRect(GuiGraphicsExtractor extractor, int x, int y, int width, int height, int color) {
        extractor.fill(x, y, x + width, y + height, color);
    }

    public static void drawGradient(GuiGraphicsExtractor extractor, int x, int y, int width, int height, int colorFrom, int colorTo) {
        extractor.fillGradient(x, y, x + width, y + height, colorFrom, colorTo);
    }

    public static void drawOutline(GuiGraphicsExtractor extractor, int x, int y, int width, int height, int color) {
        extractor.fill(x, y, x + width, y + 1, color); // oben
        extractor.fill(x, y + height - 1, x + width, y + height, color); // unten
        extractor.fill(x, y + 1, x + 1, y + height - 1, color); // links
        extractor.fill(x + width - 1, y + 1, x + width, y + height - 1, color); // rechts
    }

    public static void drawCard(GuiGraphicsExtractor extractor, int x, int y, int width, int height, int bgColor, int borderColor) {
        drawRect(extractor, x, y, width, height, bgColor);
        drawOutline(extractor, x, y, width, height, borderColor);
    }

    public static void drawText(GuiGraphicsExtractor extractor, Font font, String text, int x, int y, int color, boolean shadow) {
        extractor.text(font, text, x, y, color, shadow);
    }

    public static void drawCenteredText(GuiGraphicsExtractor extractor, Font font, String text, int centerX, int y, int color, boolean shadow) {
        int w = font.width(text);
        extractor.text(font, text, centerX - w / 2, y, color, shadow);
    }

    public static void drawItem(GuiGraphicsExtractor extractor, ItemStack stack, int x, int y) {
        if (!stack.isEmpty()) {
            extractor.item(stack, x, y);
        }
    }

    public static void drawItemDecorations(GuiGraphicsExtractor extractor, Font font, ItemStack stack, int x, int y) {
        if (!stack.isEmpty()) {
            extractor.itemDecorations(font, stack, x, y);
        }
    }
}
