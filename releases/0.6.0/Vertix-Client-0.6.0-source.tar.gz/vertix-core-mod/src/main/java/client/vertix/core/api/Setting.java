package client.vertix.core.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class Setting<T> {
    private final String id;
    private final String name;
    private final String description;
    protected T value;
    protected final T defaultValue;

    public Setting(String id, String name, String description, T defaultValue) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public T getValue() { return value; }
    public T getDefaultValue() { return defaultValue; }
    public void setValue(T value) { this.value = value; }

    public static class BooleanSetting extends Setting<Boolean> {
        public BooleanSetting(String id, String name, String description, boolean defaultValue) {
            super(id, name, description, defaultValue);
        }

        public void toggle() {
            this.value = !this.value;
        }
    }

    public static class NumberSetting extends Setting<Double> {
        private final double min;
        private final double max;
        private final double step;
        private final boolean isInteger;

        public NumberSetting(String id, String name, String description, double defaultValue, double min, double max, double step, boolean isInteger) {
            super(id, name, description, defaultValue);
            this.min = min;
            this.max = max;
            this.step = step;
            this.isInteger = isInteger;
        }

        public double getMin() { return min; }
        public double getMax() { return max; }
        public double getStep() { return step; }
        public boolean isInteger() { return isInteger; }

        public void setFromSlider(double ratio) {
            double raw = min + ratio * (max - min);
            double stepped = Math.round(raw / step) * step;
            this.value = Math.max(min, Math.min(max, stepped));
        }

        public double getRatio() {
            if (max <= min) return 0.0;
            return Math.max(0.0, Math.min(1.0, (value - min) / (max - min)));
        }
    }

    public static class ModeSetting extends Setting<String> {
        private final List<String> modes;
        private int index;

        public ModeSetting(String id, String name, String description, String defaultMode, String... options) {
            super(id, name, description, defaultMode);
            this.modes = new ArrayList<>(Arrays.asList(options));
            if (!this.modes.contains(defaultMode)) {
                this.modes.add(0, defaultMode);
            }
            this.index = this.modes.indexOf(defaultMode);
        }

        public List<String> getModes() { return modes; }
        public int getIndex() { return index; }

        public void cycle() {
            if (modes.isEmpty()) return;
            index = (index + 1) % modes.size();
            this.value = modes.get(index);
        }

        @Override
        public void setValue(String val) {
            int idx = modes.indexOf(val);
            if (idx >= 0) {
                this.index = idx;
                this.value = val;
            }
        }
    }

    public static class ColorSetting extends Setting<Integer> {
        public static final int[] PRESET_PALETTE = {
            0xFFFFFFFF, // Weiß
            0xFF00FF88, // Emerald / Mint
            0xFF00D4FF, // Cyan
            0xFFFFCC00, // Gold / Gelb
            0xFFFF4444, // Crimson / Rot
            0xFFAA44FF, // Lila / Violett
            0xFFFFAA00, // Orange
            0xFF888888  // Muted Grau
        };

        public ColorSetting(String id, String name, String description, int defaultColor) {
            super(id, name, description, defaultColor);
        }

        public void cyclePreset() {
            for (int i = 0; i < PRESET_PALETTE.length; i++) {
                if (PRESET_PALETTE[i] == this.value) {
                    this.value = PRESET_PALETTE[(i + 1) % PRESET_PALETTE.length];
                    return;
                }
            }
            this.value = PRESET_PALETTE[0];
        }
    }
}
