package client.vertix.core.modules.pvp;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.Collection;

public class PotionEffectsModule extends Module {

    private final Setting.BooleanSetting showDuration;
    private final Setting.BooleanSetting compact;

    public PotionEffectsModule() {
        super("potion_effects", "Potion Effects HUD", "Zeigt aktive Trank- und Statuseffekte mit Restdauer an.",
                Category.PVP, true, true, 4, 266);

        this.showDuration = new Setting.BooleanSetting("duration", "Restdauer anzeigen", "Zeigt verbleibende Minuten und Sekunden.", true);
        this.compact = new Setting.BooleanSetting("compact", "Kompaktmodus", "Schmalere Darstellung der Effekte.", false);

        addSetting(showDuration);
        addSetting(compact);

        this.width = 110;
        this.height = 20;
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled() || client.player == null) return;

        Collection<MobEffectInstance> effects = client.player.getActiveEffects();
        if (effects.isEmpty()) return;

        int rowHeight = compact.getValue() ? 12 : 16;
        int totalHeight = effects.size() * rowHeight + 12;
        int maxW = 90;

        int curY = y + 2;
        for (MobEffectInstance inst : effects) {
            String name = formatEffectName(inst.getDescriptionId());
            int amp = inst.getAmplifier();
            String ampStr = amp > 0 ? " " + (amp == 1 ? "II" : amp == 2 ? "III" : (amp + 1)) : "";
            int sec = inst.getDuration() / 20;
            String timeStr = showDuration.getValue() ? String.format(" (%02d:%02d)", sec / 60, sec % 60) : "";

            String line = name + ampStr + timeStr;
            int w = client.font.width(line) + 12;
            if (w > maxW) maxW = w;
        }

        this.width = maxW;
        this.height = totalHeight;

        HudStyle.panel(extractor, x, y, width, height);

        curY = y + 6;
        for (MobEffectInstance inst : effects) {
            String name = formatEffectName(inst.getDescriptionId());
            int amp = inst.getAmplifier();
            String ampStr = amp > 0 ? " " + (amp == 1 ? "II" : amp == 2 ? "III" : (amp + 1)) : "";
            int sec = inst.getDuration() / 20;
            String timeStr = showDuration.getValue() ? String.format(" (%02d:%02d)", sec / 60, sec % 60) : "";

            String line = name + ampStr + timeStr;
            HudStyle.text(extractor, client.font, line, x + 6, curY, HudStyle.TEXT);
            curY += rowHeight;
        }
    }

    private String formatEffectName(String id) {
        if (id == null) return "Effekt";
        String clean = id.replace("effect.minecraft.", "").replace('_', ' ');
        if (clean.isEmpty()) return "Effekt";
        return Character.toUpperCase(clean.charAt(0)) + clean.substring(1);
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        String sample = "Speed II" + (showDuration.getValue() ? " (01:45)" : "");
        this.width = Math.max(90, client.font.width(sample) + 12);
        this.height = (compact.getValue() ? 12 : 16) + 12;
        HudStyle.panel(extractor, x, y, width, height);
        HudStyle.text(extractor, client.font, sample, x + 6, y + 6, HudStyle.TEXT);
    }
}
