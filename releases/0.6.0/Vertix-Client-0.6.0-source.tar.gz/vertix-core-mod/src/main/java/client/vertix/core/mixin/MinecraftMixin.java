package client.vertix.core.mixin;

import client.vertix.core.VertixCoreMod;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void vertix$onTick(CallbackInfo ci) {
        VertixCoreMod mod = VertixCoreMod.getInstance();
        if (mod != null) {
            mod.onTick((Minecraft) (Object) this);
        }
    }
}
