package client.vertix.core.config;

import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Preset activePreset = Preset.NORMAL;

    public Preset getActivePreset() {
        return activePreset;
    }

    public void setActivePreset(Preset preset) {
        this.activePreset = preset;
    }

    public void applyPreset(Preset preset, List<Module> modules) {
        this.activePreset = preset;
        if (preset == Preset.CUSTOM) return;

        List<String> activeIds = preset.getDefaultActiveModules();
        for (Module m : modules) {
            boolean shouldEnable = activeIds.contains(m.getId());
            m.setEnabled(shouldEnable);
        }
        saveConfig(modules);
    }

    public File getGlobalConfigFile() {
        String appdata = System.getenv("APPDATA");
        if (appdata != null && !appdata.isEmpty()) {
            File dir = new File(appdata, "vertix");
            dir.mkdirs();
            return new File(dir, "vertix-client-config.json");
        }
        File homeDir = new File(System.getProperty("user.home"), ".vertix");
        homeDir.mkdirs();
        return new File(homeDir, "vertix-client-config.json");
    }

    public File getLocalConfigFile() {
        try {
            File gameDir = Minecraft.getInstance().gameDirectory;
            if (gameDir != null) {
                File dir = new File(gameDir, "config");
                dir.mkdirs();
                return new File(dir, "vertix-client.json");
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public void loadConfig(List<Module> modules) {
        File target = getGlobalConfigFile();
        if (!target.exists()) {
            File local = getLocalConfigFile();
            if (local != null && local.exists()) {
                target = local;
            }
        }

        if (!target.exists()) {
            // No saved config yet, initialize with default Preset (NORMAL)
            applyPreset(Preset.NORMAL, modules);
            return;
        }

        boolean migrated = false;
        try (FileReader reader = new FileReader(target)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            boolean legacyStyle = !root.has("version") || root.get("version").getAsInt() < 2;

            if (root.has("active_preset")) {
                try {
                    this.activePreset = Preset.valueOf(root.get("active_preset").getAsString());
                } catch (Exception e) {
                    this.activePreset = Preset.CUSTOM;
                }
            }

            if (root.has("modules") && root.get("modules").isJsonObject()) {
                JsonObject modsObj = root.getAsJsonObject("modules");
                for (Module m : modules) {
                    if (modsObj.has(m.getId())) {
                        JsonObject mObj = modsObj.getAsJsonObject(m.getId());

                        if (mObj.has("enabled")) {
                            m.setEnabled(mObj.get("enabled").getAsBoolean());
                        }
                        if (mObj.has("x")) {
                            m.setX(mObj.get("x").getAsInt());
                        }
                        if (mObj.has("y")) {
                            m.setY(mObj.get("y").getAsInt());
                        }
                        if (legacyStyle) m.setY(LegacyHudStyle.y(m.getId(), m.getX(), m.getY()));

                        if (mObj.has("settings") && mObj.get("settings").isJsonObject()) {
                            JsonObject sObj = mObj.getAsJsonObject("settings");
                            for (Setting<?> s : m.getSettings()) {
                                if (sObj.has(s.getId())) {
                                    JsonElement elem = sObj.get(s.getId());
                                    if (s instanceof Setting.BooleanSetting && elem.isJsonPrimitive()) {
                                        ((Setting.BooleanSetting) s).setValue(elem.getAsBoolean());
                                    } else if (s instanceof Setting.NumberSetting && elem.isJsonPrimitive()) {
                                        double value = elem.getAsDouble();
                                        ((Setting.NumberSetting) s).setValue(legacyStyle ? LegacyHudStyle.number(m.getId(), s.getId(), value) : value);
                                    } else if (s instanceof Setting.ModeSetting && elem.isJsonPrimitive()) {
                                        ((Setting.ModeSetting) s).setValue(elem.getAsString());
                                    } else if (s instanceof Setting.ColorSetting && elem.isJsonPrimitive()) {
                                        int value = elem.getAsInt();
                                        ((Setting.ColorSetting) s).setValue(legacyStyle ? LegacyHudStyle.color(m.getId(), s.getId(), value) : value);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            migrated = legacyStyle;
        } catch (Exception e) {
            System.err.println("[Vertix] Fehler beim Laden der Konfiguration: " + e.getMessage());
        }
        if (migrated) saveConfig(modules);
    }

    public void saveConfig(List<Module> modules) {
        JsonObject root = new JsonObject();
        root.addProperty("version", 2);
        root.addProperty("active_preset", activePreset.name());

        JsonObject modsObj = new JsonObject();
        for (Module m : modules) {
            JsonObject mObj = new JsonObject();
            mObj.addProperty("enabled", m.isEnabled());
            mObj.addProperty("x", m.getX());
            mObj.addProperty("y", m.getY());

            JsonObject sObj = new JsonObject();
            for (Setting<?> s : m.getSettings()) {
                if (s instanceof Setting.BooleanSetting) {
                    sObj.addProperty(s.getId(), ((Setting.BooleanSetting) s).getValue());
                } else if (s instanceof Setting.NumberSetting) {
                    sObj.addProperty(s.getId(), ((Setting.NumberSetting) s).getValue());
                } else if (s instanceof Setting.ModeSetting) {
                    sObj.addProperty(s.getId(), ((Setting.ModeSetting) s).getValue());
                } else if (s instanceof Setting.ColorSetting) {
                    sObj.addProperty(s.getId(), ((Setting.ColorSetting) s).getValue());
                }
            }
            mObj.add("settings", sObj);
            modsObj.add(m.getId(), mObj);
        }
        root.add("modules", modsObj);

        String jsonStr = GSON.toJson(root);

        // 1. Save to Global Config File (%APPDATA%\vertix\vertix-client-config.json)
        writeFileSafe(getGlobalConfigFile(), jsonStr);

        // 2. Save to Instance Local Config File
        File local = getLocalConfigFile();
        if (local != null) {
            writeFileSafe(local, jsonStr);
        }
    }

    private void writeFileSafe(File file, String content) {
        try {
            if (file.getParentFile() != null) {
                file.getParentFile().mkdirs();
            }
            File temp = new File(file.getAbsolutePath() + ".tmp");
            try (FileWriter writer = new FileWriter(temp)) {
                writer.write(content);
            }
            if (file.exists()) {
                file.delete();
            }
            temp.renameTo(file);
        } catch (Exception e) {
            System.err.println("[Vertix] Fehler beim Schreiben der Konfiguration: " + e.getMessage());
        }
    }
}
