package client.vertix.core;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.api.Module;
import client.vertix.core.api.ModuleManager;
import client.vertix.core.config.ConfigManager;
import client.vertix.core.gui.VertixHomeScreen;
import client.vertix.core.gui.HudEditorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class VertixCoreMod implements ClientModInitializer {

    private static VertixCoreMod instance;

    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private KeyMapping keyOpenMenu;

    // CPS Tracking
    private final List<Long> leftClicks = new ArrayList<>();
    private final List<Long> rightClicks = new ArrayList<>();
    private boolean wasLeftPressed = false;
    private boolean wasRightPressed = false;

    public static VertixCoreMod getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        this.moduleManager = new ModuleManager();
        this.configManager = new ConfigManager();

        // Register Keybind for 'Open Vertix Menu' (Default: RIGHT SHIFT = 344)
        try {
            KeyMapping.Category category = KeyMapping.Category.register(net.minecraft.resources.Identifier.fromNamespaceAndPath("vertix", "main"));
            this.keyOpenMenu = new KeyMapping("key.vertix.open_menu", InputConstants.KEY_RSHIFT, category);
            KeyMappingHelper.registerKeyMapping(this.keyOpenMenu);
        } catch (Throwable e) {
            System.err.println("[VertixCoreMod] KeyMappingHelper registration fallback: " + e.getMessage());
            try {
                this.keyOpenMenu = new KeyMapping("key.vertix.open_menu", InputConstants.KEY_RSHIFT, KeyMapping.Category.MISC);
            } catch (Throwable ignored) {}
        }

        // Load persistent universal settings across versions
        this.configManager.loadConfig(this.moduleManager.getModules());

        System.out.println("[VertixCoreMod] Ingame Mod Menu & Universal Module System initialized successfully!");
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public KeyMapping getKeyOpenMenu() {
        return keyOpenMenu;
    }

    public int getLeftCps() {
        return leftClicks.size();
    }

    public int getRightCps() {
        return rightClicks.size();
    }

    public void onTick(Minecraft client) {
        if (client == null) return;

        // 1. CPS Tracking
        if (client.mouseHandler != null) {
            long now = System.currentTimeMillis();
            boolean left = client.mouseHandler.isLeftPressed();
            boolean right = client.mouseHandler.isRightPressed();

            if (left && !wasLeftPressed) {
                leftClicks.add(now);
            }
            if (right && !wasRightPressed) {
                rightClicks.add(now);
            }
            wasLeftPressed = left;
            wasRightPressed = right;

            purgeOldClicks(leftClicks, now);
            purgeOldClicks(rightClicks, now);
        }

        // 2. Keybind to Open / Close Menu
        boolean keyPressed = false;
        if (keyOpenMenu != null && keyOpenMenu.consumeClick()) {
            keyPressed = true;
        }

        if (keyPressed) {
            if (client.gui.screen() == null) {
                client.setScreenAndShow(new VertixHomeScreen());
            }
        }

        // 3. Tick active modules
        if (moduleManager != null) {
            for (Module m : moduleManager.getModules()) {
                if (m.isEnabled()) {
                    m.onTick(client);
                }
            }
        }
    }

    private void purgeOldClicks(List<Long> clicks, long now) {
        Iterator<Long> it = clicks.iterator();
        while (it.hasNext()) {
            if (now - it.next() > 1000) {
                it.remove();
            } else {
                break;
            }
        }
    }

    public void onRenderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (client == null || moduleManager == null) return;
        // The editor draws its own matching previews; avoid drawing each HUD twice.
        if (client.gui.screen() instanceof HudEditorScreen) return;



        for (Module m : moduleManager.getModules()) {
            if (m.isHud() && m.isEnabled()) {
                try {
                    m.renderHud(extractor, deltaTracker, client);
                } catch (Throwable t) {
                    // Prevent single module render failure from breaking the HUD
                }
            }
        }
    }
}
