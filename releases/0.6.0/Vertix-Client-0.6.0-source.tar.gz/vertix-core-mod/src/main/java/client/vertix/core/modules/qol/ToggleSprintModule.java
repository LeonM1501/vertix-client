package client.vertix.core.modules.qol;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class ToggleSprintModule extends Module {

    private final Setting.BooleanSetting showHudText;
    private final Setting.ColorSetting hudColor;

    public ToggleSprintModule() {
        super("toggle_sprint", "Toggle Sprint", "Hält Sprinten automatisch aktiv, ohne die Taste gedrückt zu halten.",
                Category.QOL, true, true, 4, 4);

        this.showHudText = new Setting.BooleanSetting("show_hud", "HUD-Anzeige", "Zeigt den Sprint-Status auf dem Bildschirm an.", true);
        this.hudColor = new Setting.ColorSetting("color", "Textfarbe", "Farbe der Sprint-Statusanzeige.", HudStyle.TEXT);

        addSetting(showHudText);
        addSetting(hudColor);

        this.width = 90;
        this.height = HudStyle.COMPACT_HEIGHT;
    }

    @Override
    public void onTick(Minecraft client) {
        if (!isEnabled() || client.player == null) return;

        // Auto-sprint if moving forward and not sneaking/blind
        if (client.options.keyUp.isDown() && !client.player.isShiftKeyDown() && !client.player.horizontalCollision) {
            client.player.setSprinting(true);
        }
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled() || !showHudText.getValue() || client.player == null) return;

        boolean sprinting = client.player.isSprinting();
        String text = sprinting ? "Sprint · AN" : "Sprint · Bereit";
        this.width = client.font.width(text) + 12;
        int col = sprinting ? hudColor.getValue() : HudStyle.MUTED;

        HudStyle.panel(extractor, x, y, width, height);
        HudStyle.centered(extractor, client.font, text, x + width / 2, y + 6, col);
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        this.width = client.font.width("Sprint · Bereit") + 12;
        this.height = HudStyle.COMPACT_HEIGHT;
        HudStyle.panel(extractor, x, y, width, height);
        HudStyle.centered(extractor, client.font, "Sprint · Bereit", x + width / 2, y + 6, hudColor.getValue());
    }
}
