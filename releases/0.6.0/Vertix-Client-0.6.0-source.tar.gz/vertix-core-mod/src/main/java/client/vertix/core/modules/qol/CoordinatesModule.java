package client.vertix.core.modules.qol;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class CoordinatesModule extends Module {

    private final Setting.BooleanSetting showDirection;
    private final Setting.BooleanSetting showNether;
    private final Setting.ColorSetting textColor;
    private final Setting.NumberSetting bgOpacity;

    public CoordinatesModule() {
        super("coordinates", "Coordinates HUD", "Zeigt präzise XYZ-Koordinaten, Blickrichtung und Nether-Koordinaten an.",
                Category.HUD, true, true, 4, 28);

        this.showDirection = new Setting.BooleanSetting("direction", "Blickrichtung", "Zeigt Norden, Süden, Osten oder Westen an.", true);
        this.showNether = new Setting.BooleanSetting("nether", "Nether-Koordinaten", "Berechnet entsprechende Nether-Koordinaten.", true);
        this.textColor = new Setting.ColorSetting("color", "Textfarbe", "Farbe der Koordinatenanzeige.", HudStyle.TEXT);
        this.bgOpacity = new Setting.NumberSetting("bg_opacity", "Hintergrund-Transparenz", "Deckkraft des Hintergrunds.", HudStyle.DEFAULT_OPACITY, 0.0, 1.0, 0.05, false);

        addSetting(showDirection);
        addSetting(showNether);
        addSetting(textColor);
        addSetting(bgOpacity);

        this.width = 130;
        this.height = 24;
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled() || client.player == null) return;

        int px = (int) Math.floor(client.player.getX());
        int py = (int) Math.floor(client.player.getY());
        int pz = (int) Math.floor(client.player.getZ());

        float yaw = client.player.getYRot() % 360.0f;
        if (yaw < 0) yaw += 360.0f;
        String dir = (yaw >= 315 || yaw < 45) ? "S" : (yaw >= 45 && yaw < 135) ? "W" : (yaw >= 135 && yaw < 225) ? "N" : "E";

        String line1 = "XYZ: " + px + ", " + py + ", " + pz + (showDirection.getValue() ? " (" + dir + ")" : "");
        String line2 = "";
        if (showNether.getValue()) {
            boolean inNether = client.level != null && client.level.dimension().identifier().getPath().contains("nether");
            int nx = inNether ? px * 8 : px / 8;
            int nz = inNether ? pz * 8 : pz / 8;
            line2 = (inNether ? "OW: " : "Nether: ") + nx + ", " + nz;
        }

        int w1 = client.font.width(line1);
        int w2 = line2.isEmpty() ? 0 : client.font.width(line2);
        this.width = Math.max(110, Math.max(w1, w2) + 12);
        this.height = line2.isEmpty() ? HudStyle.COMPACT_HEIGHT : 32;

        HudStyle.panel(extractor, x, y, width, height, bgOpacity.getValue());

        HudStyle.text(extractor, client.font, line1, x + 6, y + 6, textColor.getValue());
        if (!line2.isEmpty()) {
            HudStyle.text(extractor, client.font, line2, x + 6, y + 18, HudStyle.MUTED);
        }
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        String line = "XYZ: 120, 64, -240" + (showDirection.getValue() ? " (N)" : "");
        this.width = Math.max(110, client.font.width(line) + 12);
        this.height = showNether.getValue() ? 32 : HudStyle.COMPACT_HEIGHT;
        HudStyle.panel(extractor, x, y, width, height, bgOpacity.getValue());
        HudStyle.text(extractor, client.font, line, x + 6, y + 6, textColor.getValue());
        if (showNether.getValue()) HudStyle.text(extractor, client.font, "Nether: 15, -30", x + 6, y + 18, HudStyle.MUTED);
    }
}
