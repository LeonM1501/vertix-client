package client.vertix.core.api;

public enum Category {
    ALL("Alle"),
    QOL("Quality of Life"),
    PVP("PvP"),
    HUD("HUD"),
    VISUAL("Visual"),
    PERFORMANCE("Performance"),
    UTILITY("Utility");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
