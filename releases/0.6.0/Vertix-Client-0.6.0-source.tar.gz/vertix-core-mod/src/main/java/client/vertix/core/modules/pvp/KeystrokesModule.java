package client.vertix.core.modules.pvp;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class KeystrokesModule extends Module {

    private final Setting.BooleanSetting showMouse;
    private final Setting.BooleanSetting showSpace;
    private final Setting.BooleanSetting showCps;
    private final Setting.ColorSetting activeColor;
    private final Setting.ColorSetting inactiveColor;

    public KeystrokesModule() {
        super("keystrokes", "Keystrokes", "Zeigt gedrückte Bewegungstasten (WASD), Maustasten und CPS live an.",
                Category.PVP, true, true, 4, 132);

        this.showMouse = new Setting.BooleanSetting("mouse", "Maustasten anzeigen", "Zeigt LMB und RMB unter den Tasten an.", true);
        this.showSpace = new Setting.BooleanSetting("space", "Leertaste anzeigen", "Zeigt die Leertaste als Leiste an.", true);
        this.showCps = new Setting.BooleanSetting("cps", "CPS auf Maustasten", "Zeigt Klicks pro Sekunde auf LMB und RMB.", true);
        this.activeColor = new Setting.ColorSetting("active_color", "Aktive Farbe", "Hintergrundfarbe, wenn Taste gedrückt ist.", RenderUtils.COLOR_ACCENT);
        this.inactiveColor = new Setting.ColorSetting("inactive_color", "Inaktive Farbe", "Hintergrundfarbe im Ruhezustand.", HudStyle.SURFACE);

        addSetting(showMouse);
        addSetting(showSpace);
        addSetting(showCps);
        addSetting(activeColor);
        addSetting(inactiveColor);

        this.width = 68;
        this.height = 70;
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled()) return;

        boolean up = client.options.keyUp.isDown();
        boolean left = client.options.keyLeft.isDown();
        boolean down = client.options.keyDown.isDown();
        boolean right = client.options.keyRight.isDown();
        boolean jump = client.options.keyJump.isDown();
        boolean lmb = client.mouseHandler.isLeftPressed();
        boolean rmb = client.mouseHandler.isRightPressed();

        int actCol = activeColor.getValue();
        int inactCol = inactiveColor.getValue();

        int curY = y;

        // W key
        drawKey(extractor, client, "W", x + 24, curY, 20, 20, up, actCol, inactCol);
        curY += 22;

        // A, S, D keys
        drawKey(extractor, client, "A", x + 2, curY, 20, 20, left, actCol, inactCol);
        drawKey(extractor, client, "S", x + 24, curY, 20, 20, down, actCol, inactCol);
        drawKey(extractor, client, "D", x + 46, curY, 20, 20, right, actCol, inactCol);
        curY += 22;

        // Mouse buttons
        if (showMouse.getValue()) {
            int lCps = VertixCoreMod.getInstance().getLeftCps();
            int rCps = VertixCoreMod.getInstance().getRightCps();
            String lmbText = showCps.getValue() ? "L " + lCps : "LMB";
            String rmbText = showCps.getValue() ? "R " + rCps : "RMB";

            drawKey(extractor, client, lmbText, x + 2, curY, 31, 16, lmb, actCol, inactCol);
            drawKey(extractor, client, rmbText, x + 35, curY, 31, 16, rmb, actCol, inactCol);
            curY += 18;
        }

        // Space bar
        if (showSpace.getValue()) {
            drawKey(extractor, client, "—", x + 2, curY, 64, 10, jump, actCol, inactCol);
            curY += 12;
        }

        this.width = 68;
        this.height = curY - y;
    }

    private void drawKey(GuiGraphicsExtractor extractor, Minecraft client, String text, int kx, int ky, int kw, int kh, boolean pressed, int actCol, int inactCol) {
        int bg = pressed ? actCol : inactCol;
        int textCol = HudStyle.contrastingText(bg);
        RenderUtils.drawCard(extractor, kx, ky, kw, kh, bg, pressed ? RenderUtils.COLOR_ACCENT : HudStyle.BORDER);
        HudStyle.centered(extractor, client.font, RenderUtils.fit(client.font, text, kw - 4), kx + kw / 2, ky + (kh - 8) / 2, textCol);
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        drawKey(extractor, client, "W", x + 24, y, 20, 20, false, 0, inactiveColor.getValue());
        drawKey(extractor, client, "A", x + 2, y + 22, 20, 20, false, 0, inactiveColor.getValue());
        drawKey(extractor, client, "S", x + 24, y + 22, 20, 20, true, activeColor.getValue(), inactiveColor.getValue());
        drawKey(extractor, client, "D", x + 46, y + 22, 20, 20, false, 0, inactiveColor.getValue());
        this.width = 68;
        int curY = y + 44;
        if (showMouse.getValue()) {
            drawKey(extractor, client, showCps.getValue() ? "L 12" : "LMB", x + 2, curY, 31, 16, false, activeColor.getValue(), inactiveColor.getValue());
            drawKey(extractor, client, showCps.getValue() ? "R 8" : "RMB", x + 35, curY, 31, 16, false, activeColor.getValue(), inactiveColor.getValue());
            curY += 18;
        }
        if (showSpace.getValue()) {
            drawKey(extractor, client, "—", x + 2, curY, 64, 10, false, activeColor.getValue(), inactiveColor.getValue());
            curY += 12;
        }
        this.height = curY - y;
    }
}
