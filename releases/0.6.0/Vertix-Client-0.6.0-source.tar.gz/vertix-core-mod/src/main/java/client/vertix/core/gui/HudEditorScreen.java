package client.vertix.core.gui;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class HudEditorScreen extends Screen {

    private final Screen parent;
    private Module draggingModule = null;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("Vertix HUD Editor"));
        this.parent = parent;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float delta) {
        // Semi-transparent overlay so world is visible
        RenderUtils.drawRect(extractor, 0, 0, width, height, 0x55000000);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float delta) {
        super.extractRenderState(extractor, mouseX, mouseY, delta);

        // Top info bar
        int barW = Math.min(360, width - 20);
        int barH = 34;
        int barX = (width - barW) / 2;
        int barY = 8;
        RenderUtils.drawCard(extractor, barX, barY, barW, barH, RenderUtils.COLOR_BG_MAIN, RenderUtils.COLOR_BORDER_DEFAULT);
        RenderUtils.drawCenteredText(extractor, font, "HUD BEARBEITEN", barX + barW / 2, barY + 7, RenderUtils.COLOR_TEXT_PRIMARY, false);
        RenderUtils.drawCenteredText(extractor, font, "Element ziehen · ESC zum Speichern", barX + barW / 2, barY + 21, RenderUtils.COLOR_TEXT_SECONDARY, false);

        // Render each active HUD module with an interactive outline
        for (Module m : VertixCoreMod.getInstance().getModuleManager().getModules()) {
            if (!m.isHud() || !m.isEnabled()) continue;

            m.renderHudPlaceholder(extractor, minecraft);

            boolean hovered = mouseX >= m.getX() && mouseX < m.getX() + m.getWidth()
                    && mouseY >= m.getY() && mouseY < m.getY() + m.getHeight();
            int outlineCol = (m == draggingModule) ? RenderUtils.COLOR_ACCENT
                    : hovered ? RenderUtils.COLOR_BORDER_HOVER : RenderUtils.COLOR_BORDER_DEFAULT;
            RenderUtils.drawOutline(extractor, m.getX() - 1, m.getY() - 1, m.getWidth() + 2, m.getHeight() + 2, outlineCol);

            // Label only the element being edited; keep badges on screen.
            if (hovered || m == draggingModule) {
                String label = RenderUtils.fit(font, m.getName(), Math.max(0, width - 12));
                int badgeW = font.width(label) + 8;
                int badgeX = Math.max(2, Math.min(width - badgeW - 2, m.getX()));
                int badgeY = m.getY() >= 16 ? m.getY() - 15 : m.getY() + m.getHeight() + 3;
                badgeY = Math.max(2, Math.min(height - 14, badgeY));
                RenderUtils.drawRect(extractor, badgeX, badgeY, badgeW, 12, RenderUtils.COLOR_BG_MAIN);
                RenderUtils.drawText(extractor, font, label, badgeX + 4, badgeY + 2, RenderUtils.COLOR_TEXT_PRIMARY, false);
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != InputConstants.MOUSE_BUTTON_LEFT) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();

        // Top info bar clicked -> close editor
        int barW = Math.min(360, width - 20);
        int barX = (width - barW) / 2;
        if (mx >= barX && mx <= barX + barW && my >= 8 && my <= 42) {
            onClose();
            return true;
        }

        // Check if any HUD module was clicked
        for (Module m : VertixCoreMod.getInstance().getModuleManager().getModules()) {
            if (!m.isHud() || !m.isEnabled()) continue;

            if (mx >= m.getX() && mx <= m.getX() + m.getWidth() && my >= m.getY() && my <= m.getY() + m.getHeight()) {
                draggingModule = m;
                dragOffsetX = (int) (mx - m.getX());
                dragOffsetY = (int) (my - m.getY());
                return true;
            }
        }

        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (draggingModule != null) {
            int newX = (int) (event.x() - dragOffsetX);
            int newY = (int) (event.y() - dragOffsetY);

            // Clamp to screen bounds
            newX = Math.max(2, Math.min(width - draggingModule.getWidth() - 2, newX));
            newY = Math.max(2, Math.min(height - draggingModule.getHeight() - 2, newY));

            draggingModule.setX(newX);
            draggingModule.setY(newY);
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (draggingModule != null) {
            draggingModule = null;
            // Persist new layout
            VertixCoreMod.getInstance().getConfigManager().saveConfig(VertixCoreMod.getInstance().getModuleManager().getModules());
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == InputConstants.KEY_ESCAPE /* ESC */ || event.key() == InputConstants.KEY_RSHIFT /* R-SHIFT */) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        VertixCoreMod.getInstance().getConfigManager().saveConfig(VertixCoreMod.getInstance().getModuleManager().getModules());
        if (minecraft != null) {
            minecraft.setScreenAndShow(parent);
        }
    }
}
