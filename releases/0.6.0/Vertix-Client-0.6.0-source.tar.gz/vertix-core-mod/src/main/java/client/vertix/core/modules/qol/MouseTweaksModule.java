package client.vertix.core.modules.qol;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;

public class MouseTweaksModule extends Module {

    private final Setting.BooleanSetting shiftDrag;
    private final Setting.BooleanSetting rmbDrag;
    private final Setting.BooleanSetting scrollTweak;

    public MouseTweaksModule() {
        super("mouse_tweaks", "Mouse Tweaks", "Erleichtert das Sortieren & Shiften im Inventar per Drag & Drop.",
                Category.QOL, false, true, 0, 0);

        this.shiftDrag = new Setting.BooleanSetting("shift_drag", "Shift + Drag",
                "Items beim Drüberziehen mit gedrücktem Shift sofort verschieben.", true);
        this.rmbDrag = new Setting.BooleanSetting("rmb_drag", "Rechtsklick-Drop",
                "Mit rechter Maustaste 1 Item pro Slot beim Ziehen ablegen.", true);
        this.scrollTweak = new Setting.BooleanSetting("scroll_tweak", "Mausrad-Tweak",
                "Mausrad über Slots verschiebt Items (z. B. in Kisten).", true);

        addSetting(shiftDrag);
        addSetting(rmbDrag);
        addSetting(scrollTweak);
    }

    public boolean isShiftDrag() {
        return shiftDrag.getValue();
    }

    public boolean isRmbDrag() {
        return rmbDrag.getValue();
    }

    public boolean isScrollTweak() {
        return scrollTweak.getValue();
    }
}
