package client.vertix.core.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum Preset {
    NORMAL("Normal", "Ausgewogenes Setup für normales Spielen mit grundlegendem HUD.",
            Arrays.asList("toggle_sprint", "coordinates", "fps", "mouse_tweaks")),

    PVP("PvP", "Vollständiges Kampflayout mit Keystrokes, CPS, Armor und Target HUD.",
            Arrays.asList("toggle_sprint", "coordinates", "fps", "armor_hud", "keystrokes", "cps", "potion_effects", "target_hud", "crosshair", "mouse_tweaks")),

    PERFORMANCE("Performance", "Minimale Belastung, nur die wichtigsten Leistungsanzeigen aktiv.",
            Collections.singletonList("fps")),

    CUSTOM("Benutzerdefiniert", "Dein individuelles Setup.",
            Collections.emptyList());

    private final String displayName;
    private final String description;
    private final List<String> defaultActiveModules;

    Preset(String displayName, String description, List<String> defaultActiveModules) {
        this.displayName = displayName;
        this.description = description;
        this.defaultActiveModules = defaultActiveModules;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getDefaultActiveModules() {
        return defaultActiveModules;
    }
}
