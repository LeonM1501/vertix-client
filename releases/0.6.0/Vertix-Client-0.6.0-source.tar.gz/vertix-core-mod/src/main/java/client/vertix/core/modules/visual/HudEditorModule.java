package client.vertix.core.modules.visual;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.gui.HudEditorScreen;
import net.minecraft.client.Minecraft;

public class HudEditorModule extends Module {

    public HudEditorModule() {
        super("hud_editor", "HUD Editor", "Ermöglicht das freie Verschieben aller aktiven HUD-Elemente per Drag-and-Drop.",
                Category.HUD, false, false, 0, 0);
    }

    @Override
    public void onEnable() {
        // Automatically open HUD Editor screen when enabled
        Minecraft mc = Minecraft.getInstance();
        if (mc != null) {
            mc.execute(() -> {
                mc.setScreenAndShow(new HudEditorScreen(mc.gui.screen()));
                setEnabled(false); // Reset toggle state once screen opened
            });
        }
    }
}
