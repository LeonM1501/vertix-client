package client.vertix.core.api;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    private final String id;
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private final boolean defaultEnabled;
    private final boolean hud;

    // HUD element position and dimensions
    protected int x;
    protected int y;
    protected int width = 60;
    protected int height = 18;

    private final List<Setting<?>> settings = new ArrayList<>();

    public Module(String id, String name, String description, Category category, boolean defaultEnabled, boolean isHud, int defaultX, int defaultY) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.defaultEnabled = defaultEnabled;
        this.enabled = defaultEnabled;
        this.hud = isHud;
        this.x = defaultX;
        this.y = defaultY;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public boolean isDefaultEnabled() { return defaultEnabled; }
    public boolean isHud() { return hud; }

    public int getX() { return x; }
    public void setX(int x) { this.x = x; }
    public int getY() { return y; }
    public void setY(int y) { this.y = y; }
    public int getWidth() { return width; }
    public void setWidth(int width) { this.width = width; }
    public int getHeight() { return height; }
    public void setHeight(int height) { this.height = height; }

    public void setEnabled(boolean enabled) {
        if (this.enabled != enabled) {
            this.enabled = enabled;
            if (enabled) {
                onEnable();
            } else {
                onDisable();
            }
        }
    }

    public void toggle() {
        setEnabled(!this.enabled);
    }

    public void addSetting(Setting<?> setting) {
        settings.add(setting);
    }

    public List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    @SuppressWarnings("unchecked")
    public <T extends Setting<?>> T getSetting(String id, Class<T> clazz) {
        for (Setting<?> s : settings) {
            if (s.getId().equals(id) && clazz.isInstance(s)) {
                return (T) s;
            }
        }
        return null;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(Minecraft client) {}

    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {}
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        renderHud(extractor, null, client);
    }
}
