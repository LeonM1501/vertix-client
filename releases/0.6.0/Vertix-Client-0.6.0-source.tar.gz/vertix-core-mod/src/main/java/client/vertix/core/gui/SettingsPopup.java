package client.vertix.core.gui;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import java.util.Locale;
import static client.vertix.core.gui.RenderUtils.*;

/** Centered, scrollable settings sheet. The same rectangles render and handle inputs. */
public class SettingsPopup {
    private final Module module;
    private final MenuLayout.Rect panel, body, close;
    private Setting.NumberSetting dragging;
    private int scroll;
    public SettingsPopup(Module module, int targetX, int targetY, int screenWidth, int screenHeight) {
        this.module = module;
        int w = Math.min(270, screenWidth - 24);
        int h = Math.min(Math.max(116, 84 + module.getSettings().size() * 40), screenHeight - 24);
        panel = new MenuLayout.Rect((screenWidth - w) / 2, (screenHeight - h) / 2, w, h);
        body = new MenuLayout.Rect(panel.x() + 12, panel.y() + 46, w - 24, h - 72);
        close = new MenuLayout.Rect(panel.right() - 34, panel.y() + 8, 26, 26);
    }
    public Module getModule() { return module; }
    public boolean isMouseInside(double mx, double my) { return panel.contains(mx, my); }
    private int row(int i) { return body.y() + i * 40 - scroll; }
    private MenuLayout.Rect control(int i) { return new MenuLayout.Rect(body.right() - 96, row(i) + 13, 96, 20); }
    private MenuLayout.Rect track(int i) { return new MenuLayout.Rect(body.x(), row(i) + 16, body.w(), 16); }
    private int maxScroll() { return Math.max(0, module.getSettings().size() * 40 - body.h()); }
    public void render(GuiGraphicsExtractor g, int mx, int my, Minecraft client) {
        drawCard(g, panel.x(), panel.y(), panel.w(), panel.h(), COLOR_BG_MAIN, COLOR_BORDER_HOVER);
        drawText(g, client.font, fit(client.font, module.getName(), panel.w() - 60), panel.x() + 12, panel.y() + 12, COLOR_TEXT_PRIMARY, false);
        drawText(g, client.font, "Einstellungen", panel.x() + 12, panel.y() + 27, COLOR_TEXT_MUTED, false);
        button(g, client.font, close, "x", false, close.contains(mx, my));
        g.enableScissor(body.x(), body.y(), body.right(), body.bottom());
        for (int i = 0; i < module.getSettings().size(); i++) {
            Setting<?> s = module.getSettings().get(i); int y = row(i);
            if (y + 40 <= body.y() || y >= body.bottom()) continue;
            String value = s instanceof Setting.NumberSetting n ? (n.isInteger() ? String.valueOf(n.getValue().intValue()) : String.format(Locale.ROOT, "%.1f", n.getValue())) : "";
            drawText(g, client.font, fit(client.font, s.getName(), body.w() - client.font.width(value) - 8), body.x(), y + 1, COLOR_TEXT_SECONDARY, false);
            if (s instanceof Setting.NumberSetting n) {
                drawText(g, client.font, value, body.right() - client.font.width(value), y + 1, COLOR_TEXT_PRIMARY, false);
                MenuLayout.Rect t = track(i);
                drawRect(g, t.x(), t.y() + 7, t.w(), 2, COLOR_BORDER_HOVER);
                int fill = (int) Math.round(t.w() * n.getRatio());
                drawRect(g, t.x(), t.y() + 7, fill, 2, COLOR_ACCENT);
                drawRect(g, Math.clamp(t.x() + fill - 2, t.x(), t.right() - 4), t.y() + 3, 4, 10, COLOR_ACCENT);
            } else {
                MenuLayout.Rect c = control(i);
                if (s instanceof Setting.BooleanSetting b) button(g, client.font, c, b.getValue() ? "AN" : "AUS", b.getValue(), c.contains(mx, my));
                else if (s instanceof Setting.ModeSetting m) button(g, client.font, c, m.getValue() + "  >", false, c.contains(mx, my));
                else if (s instanceof Setting.ColorSetting color) {
                    button(g, client.font, c, "Farbe  >", false, c.contains(mx, my));
                    drawRect(g, body.x(), y + 17, 14, 14, color.getValue());
                }
            }
        }
        g.disableScissor();
        drawText(g, client.font, maxScroll() > 0 ? "Scrollen für weitere Einstellungen" : "Änderungen werden gespeichert.", panel.x() + 12, panel.bottom() - 16, COLOR_TEXT_MUTED, false);
        if (maxScroll() > 0) {
            int thumb = Math.max(12, body.h() * body.h() / (body.h() + maxScroll()));
            drawRect(g, panel.right() - 6, body.y() + scroll * (body.h() - thumb) / maxScroll(), 2, thumb, COLOR_TEXT_MUTED);
        }
    }
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != InputConstants.MOUSE_BUTTON_LEFT) return false;
        if (close.contains(mx, my)) return true;
        if (!body.contains(mx, my)) return false;
        for (int i = 0; i < module.getSettings().size(); i++) {
            Setting<?> s = module.getSettings().get(i);
            if (s instanceof Setting.NumberSetting n && track(i).contains(mx, my)) {
                dragging = n; n.setFromSlider((mx - body.x()) / body.w()); save(); return false;
            }
            if (!control(i).contains(mx, my)) continue;
            if (s instanceof Setting.BooleanSetting b) b.toggle();
            else if (s instanceof Setting.ModeSetting m) m.cycle();
            else if (s instanceof Setting.ColorSetting c) c.cyclePreset();
            save(); return false;
        }
        return false;
    }
    public void mouseScrolled(double amount) { mouseReleased(); scroll = Math.clamp(scroll - (int) (amount * 22), 0, maxScroll()); }
    public void mouseDragged(double mx, double my) { if (dragging != null) dragging.setFromSlider((mx - body.x()) / body.w()); }
    public void mouseReleased() { if (dragging != null) { dragging = null; save(); } }
    private void save() { VertixCoreMod.getInstance().getConfigManager().saveConfig(VertixCoreMod.getInstance().getModuleManager().getModules()); }
}
