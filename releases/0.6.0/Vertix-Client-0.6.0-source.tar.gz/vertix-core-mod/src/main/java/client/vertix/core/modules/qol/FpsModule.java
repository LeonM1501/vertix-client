package client.vertix.core.modules.qol;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class FpsModule extends Module {

    private final Setting.BooleanSetting showLabel;
    private final Setting.ColorSetting textColor;
    private final Setting.NumberSetting bgOpacity;

    public FpsModule() {
        super("fps", "FPS Display", "Zeigt die aktuellen Frames pro Sekunde (FPS) an.",
                Category.HUD, true, true, 4, 64);

        this.showLabel = new Setting.BooleanSetting("label", "FPS-Label", "Zeigt den Text 'FPS' hinter der Zahl an.", true);
        this.textColor = new Setting.ColorSetting("color", "Textfarbe", "Farbe der FPS-Anzeige.", HudStyle.TEXT);
        this.bgOpacity = new Setting.NumberSetting("bg_opacity", "Hintergrund-Transparenz", "Deckkraft des Hintergrunds.", HudStyle.DEFAULT_OPACITY, 0.0, 1.0, 0.05, false);

        addSetting(showLabel);
        addSetting(textColor);
        addSetting(bgOpacity);

        this.width = 54;
        this.height = HudStyle.COMPACT_HEIGHT;
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled()) return;

        int fps = client.getFps();
        String text = fps + (showLabel.getValue() ? " FPS" : "");
        this.width = client.font.width(text) + 12;

        HudStyle.panel(extractor, x, y, width, height, bgOpacity.getValue());
        HudStyle.centered(extractor, client.font, text, x + width / 2, y + 6, textColor.getValue());
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        this.width = client.font.width("144 FPS") + 12;
        this.height = HudStyle.COMPACT_HEIGHT;
        HudStyle.panel(extractor, x, y, width, height, bgOpacity.getValue());
        HudStyle.centered(extractor, client.font, "144 FPS", x + width / 2, y + 6, textColor.getValue());
    }
}
