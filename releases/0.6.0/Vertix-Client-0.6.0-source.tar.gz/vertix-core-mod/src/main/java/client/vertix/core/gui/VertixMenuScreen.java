package client.vertix.core.gui;

import com.mojang.blaze3d.platform.InputConstants;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.config.Preset;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.List;
import java.util.Locale;
import static client.vertix.core.gui.RenderUtils.*;

public class VertixMenuScreen extends Screen {
    private final Screen parent;
    private boolean presets;
    private Category category = Category.ALL;
    private String query = "";
    private boolean searchFocused;
    private int scroll;
    private SettingsPopup popup;
    private static final Category[] CATEGORIES = Category.values();
    private static final Preset[] PRESETS = { Preset.NORMAL, Preset.PVP, Preset.PERFORMANCE };
    public VertixMenuScreen() { this(new VertixHomeScreen(), false); }
    public VertixMenuScreen(Screen parent, boolean presets) {
        super(Component.literal("Vertix Mod Menü")); this.parent = parent; this.presets = presets;
    }
    @Override public boolean isPauseScreen() { return false; }
    private void focusSearch(boolean focused) {
        if (searchFocused != focused) { searchFocused = focused; minecraft.onTextInputFocusChange(this, focused); }
    }
    @Override public void removed() { focusSearch(false); super.removed(); }
    private MenuLayout layout() { return new MenuLayout(width, height); }
    private List<Module> modules() { return VertixCoreMod.getInstance().getModuleManager().getModules(); }
    private void save() { VertixCoreMod.getInstance().getConfigManager().saveConfig(modules()); }
    private List<Module> filtered() {
        String q = query.strip().toLowerCase(Locale.ROOT);
        return modules().stream().filter(m -> (category == Category.ALL || m.getCategory() == category)
                && (m.getName() + " " + m.getDescription()).toLowerCase(Locale.ROOT).contains(q)).toList();
    }
    private MenuLayout.Rect nav(MenuLayout l, int index) {
        return l.nav(index);
    }
    private MenuLayout.Rect settings(MenuLayout.Rect r) { return new MenuLayout.Rect(r.x() + 9, r.bottom() - 23, r.w() - 63, 17); }
    private MenuLayout.Rect toggle(MenuLayout.Rect r) { return new MenuLayout.Rect(r.right() - 45, r.bottom() - 23, 36, 17); }
    @Override public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float delta) { drawRect(g, 0, 0, width, height, 0xA6000000); }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        MenuLayout l = layout();
        drawCard(g, l.panel.x(), l.panel.y(), l.panel.w(), l.panel.h(), COLOR_BG_MAIN, COLOR_BORDER_DEFAULT);
        drawRect(g, l.panel.x() + 1, l.panel.y() + 1, l.panel.w() - 2, 42, COLOR_BG_HEADER);
        button(g, font, l.back, "<", false, l.back.contains(mx, my));
        drawText(g, font, "VERTIX  /  " + (presets ? "PROFILE" : "MOD MENÜ"), l.panel.x() + 44, l.panel.y() + 17, COLOR_TEXT_PRIMARY, false);
        button(g, font, l.close, "x", false, l.close.contains(mx, my));
        drawRect(g, l.rail.right(), l.rail.y(), 1, l.rail.h(), COLOR_BORDER_DEFAULT);
        for (int i = 0; i < CATEGORIES.length; i++) {
            MenuLayout.Rect r = nav(l, i); boolean active = !presets && category == CATEGORIES[i];
            if (active || r.contains(mx, my)) drawRect(g, r.x(), r.y(), r.w(), r.h(), active ? 0xFF303030 : COLOR_BG_CARD);
            if (active) drawRect(g, r.x(), r.y() + 3, 2, r.h() - 6, COLOR_ACCENT);
            String label = CATEGORIES[i] == Category.QOL ? "Komfort" : CATEGORIES[i].getDisplayName();
            drawText(g, font, fit(font, label, r.w() - 14), r.x() + 8, r.y() + (r.h() - 8) / 2, active ? COLOR_TEXT_PRIMARY : COLOR_TEXT_MUTED, false);
        }
        MenuLayout.Rect profiles = nav(l, 7), hud = nav(l, 8);
        if (presets) drawRect(g, profiles.x(), profiles.y(), profiles.w(), profiles.h(), 0xFF303030);
        drawText(g, font, "Profile", profiles.x() + 8, profiles.y() + (profiles.h() - 8) / 2, presets ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY, false);
        drawText(g, font, fit(font, "HUD Editor", hud.w() - 12), hud.x() + 8, hud.y() + (hud.h() - 8) / 2, COLOR_TEXT_SECONDARY, false);
        if (presets) renderPresets(g, l, mx, my); else renderMods(g, l, mx, my);
        drawRect(g, l.panel.x() + 1, l.panel.bottom() - 25, l.panel.w() - 2, 1, COLOR_BORDER_DEFAULT);
        String footer = presets ? "Ein Klick aktiviert das Profil." : filtered().size() + " Module   /   " + modules().stream().filter(Module::isEnabled).count() + " aktiv";
        drawText(g, font, fit(font, footer, l.panel.w() - 130), l.panel.x() + 12, l.panel.bottom() - 16, COLOR_TEXT_MUTED, false);
        drawText(g, font, "ESC  Zurück", l.panel.right() - 82, l.panel.bottom() - 16, COLOR_TEXT_SECONDARY, false);
        if (popup != null) { drawRect(g, 0, 0, width, height, 0x80000000); popup.render(g, mx, my, minecraft); }
    }
    private void renderMods(GuiGraphicsExtractor g, MenuLayout l, int mx, int my) {
        drawCard(g, l.search.x(), l.search.y(), l.search.w(), l.search.h(), COLOR_BG_CARD, searchFocused ? COLOR_ACCENT : COLOR_BORDER_DEFAULT);
        String text = query.isEmpty() && !searchFocused ? "Module suchen ..." : query + (searchFocused ? "_" : "");
        drawText(g, font, fit(font, text, l.search.w() - 36), l.search.x() + 8, l.search.y() + 7,
                query.isEmpty() && !searchFocused ? COLOR_TEXT_MUTED : COLOR_TEXT_PRIMARY, false);
        if (!query.isEmpty()) drawText(g, font, "x", l.search.right() - 14, l.search.y() + 7, COLOR_TEXT_SECONDARY, false);
        List<Module> list = filtered(); scroll = Math.clamp(scroll, 0, l.maxScroll(list.size()));
        g.enableScissor(l.content.x(), l.content.y(), l.content.right(), l.content.bottom());
        for (int i = 0; i < list.size(); i++) {
            MenuLayout.Rect r = l.card(i, scroll); if (r.bottom() <= l.content.y() || r.y() >= l.content.bottom()) continue;
            Module m = list.get(i); boolean hover = r.contains(mx, my) && l.content.contains(mx, my);
            drawCard(g, r.x(), r.y(), r.w(), r.h(), hover ? COLOR_BG_CARD_HOVER : COLOR_BG_CARD,
                    m.isEnabled() ? 0xFF77746E : hover ? COLOR_BORDER_HOVER : COLOR_BORDER_DEFAULT);
            drawText(g, font, fit(font, m.getName(), r.w() - 28), r.x() + 10, r.y() + 10, COLOR_TEXT_PRIMARY, false);
            drawDescription(g, m.getDescription(), r.x() + 10, r.y() + 26, r.w() - 20, 2);
            MenuLayout.Rect s = settings(r), t = toggle(r);
            if (!m.getSettings().isEmpty()) drawText(g, font, fit(font, "Einstellungen", s.w() - 4), s.x(), s.y() + 4,
                    s.contains(mx, my) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_MUTED, false);
            button(g, font, t, m.getId().equals("hud_editor") ? ">" : m.isEnabled() ? "AN" : "AUS", m.isEnabled(), hover && t.contains(mx, my));
        }
        if (list.isEmpty()) {
            drawCenteredText(g, font, "Keine Module gefunden", l.content.x() + l.content.w() / 2, l.content.y() + 22, COLOR_TEXT_SECONDARY, false);
            drawCenteredText(g, font, "Suche oder Kategorie ändern.", l.content.x() + l.content.w() / 2, l.content.y() + 39, COLOR_TEXT_MUTED, false);
        }
        g.disableScissor(); scrollbar(g, l, l.maxScroll(list.size()));
    }
    private void drawDescription(GuiGraphicsExtractor g, String text, int x, int y, int w, int lines) {
        for (int line = 0; line < lines && !text.isEmpty(); line++) {
            String part = text;
            if (font.width(part) > w) {
                if (line == lines - 1) { part = fit(font, part, w); text = ""; }
                else { while (font.width(part) > w) part = part.substring(0, part.length() - 1);
                    int space = part.lastIndexOf(' '); if (space > 0) part = part.substring(0, space); text = text.substring(part.length()).stripLeading(); }
            } else text = "";
            drawText(g, font, part, x, y + line * 11, COLOR_TEXT_MUTED, false);
        }
    }
    private void renderPresets(GuiGraphicsExtractor g, MenuLayout l, int mx, int my) {
        drawText(g, font, "Deine Spielweise", l.search.x(), l.search.y() + 3, COLOR_TEXT_PRIMARY, false);
        drawText(g, font, fit(font, "Module mit einem Klick abstimmen.", l.search.w()), l.search.x(), l.search.y() + 16, COLOR_TEXT_MUTED, false);
        int max = Math.max(0, PRESETS.length * 80 - 8 - l.content.h()); scroll = Math.clamp(scroll, 0, max);
        g.enableScissor(l.content.x(), l.content.y(), l.content.right(), l.content.bottom());
        for (int i = 0; i < PRESETS.length; i++) {
            Preset p = PRESETS[i]; boolean active = VertixCoreMod.getInstance().getConfigManager().getActivePreset() == p;
            MenuLayout.Rect r = new MenuLayout.Rect(l.content.x(), l.content.y() + i * 80 - scroll, l.content.w(), 72);
            drawCard(g, r.x(), r.y(), r.w(), r.h(), r.contains(mx, my) ? COLOR_BG_CARD_HOVER : COLOR_BG_CARD, active ? COLOR_ACCENT : COLOR_BORDER_DEFAULT);
            drawText(g, font, p.getDisplayName(), r.x() + 12, r.y() + 11, COLOR_TEXT_PRIMARY, false);
            drawDescription(g, p.getDescription(), r.x() + 12, r.y() + 29, r.w() - 24, 2);
            drawText(g, font, active ? "AKTIV" : "Aktivieren", r.right() - 72, r.y() + 11, active ? COLOR_ACCENT : COLOR_TEXT_MUTED, false);
        }
        g.disableScissor(); scrollbar(g, l, max);
    }
    private void scrollbar(GuiGraphicsExtractor g, MenuLayout l, int max) {
        if (max <= 0) return;
        int thumb = Math.max(18, l.content.h() * l.content.h() / (l.content.h() + max));
        drawRect(g, l.content.right() + 5, l.content.y(), 2, l.content.h(), COLOR_BORDER_DEFAULT);
        drawRect(g, l.content.right() + 5, l.content.y() + scroll * (l.content.h() - thumb) / max, 2, thumb, COLOR_TEXT_SECONDARY);
    }
    @Override public boolean mouseClicked(MouseButtonEvent e, boolean twice) {
        double mx = e.x(), my = e.y(); int button = e.button();
        if (popup != null) { popup.mouseReleased(); if (!popup.isMouseInside(mx, my) || popup.mouseClicked(mx, my, button)) popup = null; return true; }
        MenuLayout l = layout();
        if (button == InputConstants.MOUSE_BUTTON_LEFT) {
            if (l.close.contains(mx, my)) { save(); minecraft.setScreenAndShow(null); return true; }
            if (l.back.contains(mx, my)) { onClose(); return true; }
            for (int i = 0; i < CATEGORIES.length; i++) if (nav(l, i).contains(mx, my)) {
                presets = false; category = CATEGORIES[i]; scroll = 0; focusSearch(false); return true;
            }
            if (nav(l, 7).contains(mx, my)) { presets = true; scroll = 0; focusSearch(false); return true; }
            if (nav(l, 8).contains(mx, my)) { minecraft.setScreenAndShow(new HudEditorScreen(this)); return true; }
            focusSearch(!presets && l.search.contains(mx, my));
            if (searchFocused) { if (mx >= l.search.right() - 24) { query = ""; scroll = 0; } return true; }
        }
        if (!l.content.contains(mx, my)) return super.mouseClicked(e, twice);
        if (presets && button == InputConstants.MOUSE_BUTTON_LEFT) {
            for (int i = 0; i < PRESETS.length; i++) if (new MenuLayout.Rect(l.content.x(), l.content.y() + i * 80 - scroll, l.content.w(), 72).contains(mx, my)) {
                VertixCoreMod.getInstance().getConfigManager().applyPreset(PRESETS[i], modules()); return true;
            }
        } else if (!presets) {
            List<Module> list = filtered();
            for (int i = 0; i < list.size(); i++) {
                MenuLayout.Rect r = l.card(i, scroll); if (!r.contains(mx, my)) continue; Module m = list.get(i);
                if ((button == InputConstants.MOUSE_BUTTON_RIGHT || settings(r).contains(mx, my)) && !m.getSettings().isEmpty()) {
                    focusSearch(false); popup = new SettingsPopup(m, r.x(), r.y(), width, height); return true;
                }
                if (button == InputConstants.MOUSE_BUTTON_LEFT) {
                    if (m.getId().equals("hud_editor")) minecraft.setScreenAndShow(new HudEditorScreen(this));
                    else { m.toggle(); VertixCoreMod.getInstance().getConfigManager().setActivePreset(Preset.CUSTOM); save(); }
                    return true;
                }
            }
        }
        return super.mouseClicked(e, twice);
    }
    @Override public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (popup != null) { popup.mouseScrolled(vertical); return true; }
        MenuLayout l = layout(); if (!l.content.contains(mx, my)) return super.mouseScrolled(mx, my, horizontal, vertical);
        int max = presets ? Math.max(0, 232 - l.content.h()) : l.maxScroll(filtered().size());
        scroll = Math.clamp(scroll - (int) (vertical * 24), 0, max); return true;
    }
    @Override public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (popup != null) { popup.mouseDragged(e.x(), e.y()); return true; } return super.mouseDragged(e, dx, dy);
    }
    @Override public boolean mouseReleased(MouseButtonEvent e) {
        if (popup != null) { popup.mouseReleased(); return true; } return super.mouseReleased(e);
    }
    @Override public boolean charTyped(CharacterEvent e) {
        if (searchFocused && query.codePointCount(0, query.length()) < 64) { query += e.codepointAsString(); scroll = 0; return true; }
        return super.charTyped(e);
    }
    @Override public boolean keyPressed(KeyEvent e) {
        if (e.key() == InputConstants.KEY_RSHIFT) { if (popup != null) popup.mouseReleased(); save(); minecraft.setScreenAndShow(null); return true; }
        if (e.key() == InputConstants.KEY_ESCAPE) { if (popup != null) { popup.mouseReleased(); popup = null; } else if (searchFocused) focusSearch(false); else onClose(); return true; }
        if (searchFocused) {
            if (e.key() == InputConstants.KEY_BACKSPACE && !query.isEmpty()) { query = query.substring(0, query.offsetByCodePoints(query.length(), -1)); scroll = 0; return true; }
            if (e.key() == InputConstants.KEY_RETURN) { focusSearch(false); return true; }
        }
        return super.keyPressed(e);
    }
    @Override public void onClose() { if (popup != null) { popup.mouseReleased(); popup = null; return; } save(); minecraft.setScreenAndShow(parent); }
}
