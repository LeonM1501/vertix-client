package client.vertix.core.modules.pvp;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class TargetHudModule extends Module {

    private final Setting.BooleanSetting showHealthBar;
    private final Setting.BooleanSetting showDistance;

    public TargetHudModule() {
        super("target_hud", "Target HUD", "Zeigt Informationen über das aktuell anvisierte Ziel (HP-Bar, Distanz).",
                Category.PVP, true, true, 200, 150);

        this.showHealthBar = new Setting.BooleanSetting("health_bar", "Lebensleiste", "Zeigt einen visuellen Lebensbalken an.", true);
        this.showDistance = new Setting.BooleanSetting("distance", "Distanz anzeigen", "Zeigt die Entfernung zum Ziel in Metern an.", true);

        addSetting(showHealthBar);
        addSetting(showDistance);

        this.width = 120;
        this.height = 34;
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled()) return;

        Entity entity = client.crosshairPickEntity;
        if (!(entity instanceof LivingEntity target)) return;

        String name = target.getName().getString();
        float hp = Math.max(0.0f, target.getHealth());
        float maxHp = Math.max(1.0f, target.getMaxHealth());
        float ratio = Math.min(1.0f, hp / maxHp);

        String distStr = showDistance.getValue() && client.player != null
                ? String.format(" · %.1fm", client.player.distanceTo(target))
                : "";
        String hpText = String.format("%.1f / %.1f HP%s", hp, maxHp, distStr);

        this.width = Math.max(120, Math.max(client.font.width(name), client.font.width(hpText)) + 16);
        this.height = showHealthBar.getValue() ? 34 : 26;

        RenderUtils.drawCard(extractor, x, y, width, height, HudStyle.SURFACE, HudStyle.BORDER);

        // Name
        RenderUtils.drawText(extractor, client.font, name, x + 6, y + 4, HudStyle.TEXT, false);

        // HP Text
        RenderUtils.drawText(extractor, client.font, hpText, x + 6, y + 14, HudStyle.MUTED, false);

        // Health bar
        if (showHealthBar.getValue()) {
            int barX = x + 6;
            int barY = y + 25;
            int barW = width - 12;
            int barH = 4;

            RenderUtils.drawRect(extractor, barX, barY, barW, barH, RenderUtils.COLOR_BORDER_DEFAULT);
            int fillW = (int) (barW * ratio);
            int col = HudStyle.TEXT;
            if (fillW > 0) {
                RenderUtils.drawRect(extractor, barX, barY, fillW, barH, col);
            }
        }
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        String sampleHealth = "18.0 / 20.0 HP" + (showDistance.getValue() ? " · 3.5m" : "");
        this.width = Math.max(120, Math.max(client.font.width("Spieler (Beispiel)"), client.font.width(sampleHealth)) + 16);
        this.height = showHealthBar.getValue() ? 34 : 26;
        RenderUtils.drawCard(extractor, x, y, width, height, HudStyle.SURFACE, HudStyle.BORDER);
        RenderUtils.drawText(extractor, client.font, "Spieler (Beispiel)", x + 6, y + 4, HudStyle.TEXT, false);
        RenderUtils.drawText(extractor, client.font, sampleHealth, x + 6, y + 14, HudStyle.MUTED, false);
        if (showHealthBar.getValue()) {
            RenderUtils.drawRect(extractor, x + 6, y + 25, width - 12, 4, RenderUtils.COLOR_BORDER_DEFAULT);
            RenderUtils.drawRect(extractor, x + 6, y + 25, (int) ((width - 12) * 0.9f), 4, HudStyle.TEXT);
        }
    }
}
