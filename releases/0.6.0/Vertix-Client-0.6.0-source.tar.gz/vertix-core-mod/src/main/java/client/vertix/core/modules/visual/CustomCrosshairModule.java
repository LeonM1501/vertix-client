package client.vertix.core.modules.visual;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.RenderUtils;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.LivingEntity;

public class CustomCrosshairModule extends Module {

    private final Setting.ModeSetting style;
    private final Setting.NumberSetting size;
    private final Setting.NumberSetting gap;
    private final Setting.NumberSetting thickness;
    private final Setting.ColorSetting color;
    private final Setting.BooleanSetting dynamicTarget;
    private final Setting.BooleanSetting centerDot;

    public CustomCrosshairModule() {
        super("crosshair", "Custom Crosshair", "Ersetzt das Standard-Fadenkreuz durch ein vollständig anpassbares Crosshair.",
                Category.VISUAL, false, true, 0, 0);

        this.style = new Setting.ModeSetting("style", "Design", "Aussehen des Fadenkreuzes.", "Kreuz", "Kreuz", "Punkt", "T-Form", "Kreis");
        this.size = new Setting.NumberSetting("size", "Größe", "Länge der Linien.", 6.0, 2.0, 16.0, 1.0, true);
        this.gap = new Setting.NumberSetting("gap", "Abstand", "Abstand vom Mittelpunkt.", 3.0, 0.0, 12.0, 1.0, true);
        this.thickness = new Setting.NumberSetting("thickness", "Dicke", "Linienstärke.", 2.0, 1.0, 4.0, 1.0, true);
        this.color = new Setting.ColorSetting("color", "Farbe", "Standardfarbe des Fadenkreuzes.", 0xFFFFFFFF);
        this.dynamicTarget = new Setting.BooleanSetting("dynamic", "Ziel-Highlight", "Färbt sich rot, wenn ein Ziel anvisiert wird.", true);
        this.centerDot = new Setting.BooleanSetting("dot", "Mittelpunkt", "Zeigt einen Punkt in der Mitte an.", true);

        addSetting(style);
        addSetting(size);
        addSetting(gap);
        addSetting(thickness);
        addSetting(color);
        addSetting(dynamicTarget);
        addSetting(centerDot);
    }

    @Override
    public void renderHud(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, Minecraft client) {
        if (!isEnabled()) return;

        int cx = client.getWindow().getGuiScaledWidth() / 2;
        int cy = client.getWindow().getGuiScaledHeight() / 2;

        int col = color.getValue();
        if (dynamicTarget.getValue() && client.crosshairPickEntity instanceof LivingEntity) {
            col = 0xFFFF2222; // Rot bei Ziel
        }

        int s = (int) size.getValue().doubleValue();
        int g = (int) gap.getValue().doubleValue();
        int t = (int) thickness.getValue().doubleValue();
        int halfT = t / 2;

        String st = style.getValue();

        if ("Punkt".equalsIgnoreCase(st)) {
            RenderUtils.drawRect(extractor, cx - halfT - 1, cy - halfT - 1, t + 2, t + 2, 0xFF000000);
            RenderUtils.drawRect(extractor, cx - halfT, cy - halfT, t, t, col);
            return;
        }

        // Center dot
        if (centerDot.getValue()) {
            RenderUtils.drawRect(extractor, cx - 1, cy - 1, 2, 2, col);
        }

        if ("Kreuz".equalsIgnoreCase(st) || "T-Form".equalsIgnoreCase(st)) {
            // Oben
            RenderUtils.drawRect(extractor, cx - halfT, cy - g - s, t, s, col);
            // Links
            RenderUtils.drawRect(extractor, cx - g - s, cy - halfT, s, t, col);
            // Rechts
            RenderUtils.drawRect(extractor, cx + g, cy - halfT, s, t, col);
            // Unten (nur bei Kreuz)
            if ("Kreuz".equalsIgnoreCase(st)) {
                RenderUtils.drawRect(extractor, cx - halfT, cy + g, t, s, col);
            }
        } else if ("Kreis".equalsIgnoreCase(st)) {
            // Stylized box/circle
            int r = s + g;
            RenderUtils.drawRect(extractor, cx - r, cy - r, r * 2, t, col);
            RenderUtils.drawRect(extractor, cx - r, cy + r - t, r * 2, t, col);
            RenderUtils.drawRect(extractor, cx - r, cy - r, t, r * 2, col);
            RenderUtils.drawRect(extractor, cx + r - t, cy - r, t, r * 2, col);
        }
    }

    @Override
    public void renderHudPlaceholder(GuiGraphicsExtractor extractor, Minecraft client) {
        int cx = x + 30;
        int cy = y + 10;
        RenderUtils.drawRect(extractor, cx - 1, cy - 6, 2, 5, 0xFFFFFFFF);
        RenderUtils.drawRect(extractor, cx - 1, cy + 2, 2, 5, 0xFFFFFFFF);
        RenderUtils.drawRect(extractor, cx - 6, cy - 1, 5, 2, 0xFFFFFFFF);
        RenderUtils.drawRect(extractor, cx + 2, cy - 1, 5, 2, 0xFFFFFFFF);
    }
}
