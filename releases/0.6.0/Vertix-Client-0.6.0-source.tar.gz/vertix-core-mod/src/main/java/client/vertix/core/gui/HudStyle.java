package client.vertix.core.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Shared HUD surfaces and spacing, matching the in-game menu. */
public final class HudStyle {
    public static final int TEXT = RenderUtils.COLOR_TEXT_PRIMARY;
    public static final int MUTED = RenderUtils.COLOR_TEXT_SECONDARY;
    public static final int SURFACE = 0xE01C1C1C;
    public static final int BORDER = 0xB0444444;
    public static final int PADDING = 6;
    public static final int LINE_HEIGHT = 12;
    public static final int COMPACT_HEIGHT = 20;
    public static final double DEFAULT_OPACITY = 0.88;

    private HudStyle() {}

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        panel(g, x, y, w, h, DEFAULT_OPACITY);
    }

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, double opacity) {
        int alpha = (int) Math.round(Math.max(0, Math.min(1, opacity)) * 255);
        RenderUtils.drawCard(g, x, y, w, h, (alpha << 24) | 0x001C1C1C,
                ((int) Math.round(alpha * 0.78) << 24) | 0x00444444);
    }

    public static void text(GuiGraphicsExtractor g, Font font, String value, int x, int y, int color) {
        RenderUtils.drawText(g, font, value, x, y, color, false);
    }

    public static void centered(GuiGraphicsExtractor g, Font font, String value, int x, int y, int color) {
        RenderUtils.drawCenteredText(g, font, value, x, y, color, false);
    }

    /** Keep user-selected colors legible for both light and dark key backgrounds. */
    public static int contrastingText(int background) {
        int r = (background >> 16) & 255, g = (background >> 8) & 255, b = background & 255;
        return (r * 299 + g * 587 + b * 114) / 1000 >= 145 ? 0xFF171717 : TEXT;
    }
}
