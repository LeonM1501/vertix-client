package client.vertix.core.gui;

/** One geometry model for rendering, clipping and pointer hit testing. GUI-scaled pixels. */
public final class MenuLayout {
    public record Rect(int x, int y, int w, int h) {
        public int right() { return x + w; }
        public int bottom() { return y + h; }
        public boolean contains(double mx, double my) {
            return mx >= x && mx < right() && my >= y && my < bottom();
        }
    }
    public final Rect panel, rail, content, search, close, back;
    public final int columns, cardWidth;
    public static final int CARD_HEIGHT = 76, GAP = 8;
    public MenuLayout(int width, int height) {
        int w = Math.min(620, width - 16), h = Math.min(366, height - 16);
        panel = new Rect((width - w) / 2, (height - h) / 2, w, h);
        int railWidth = w < 420 ? 76 : 104;
        rail = new Rect(panel.x(), panel.y() + 44, railWidth, h - 68);
        content = new Rect(rail.right() + 12, panel.y() + 80, w - railWidth - 28, h - 116);
        columns = content.w() >= 350 ? 2 : 1;
        cardWidth = (content.w() - (columns - 1) * GAP) / columns;
        search = new Rect(content.x(), panel.y() + 48, content.w(), 22);
        close = new Rect(panel.right() - 34, panel.y() + 8, 26, 26);
        back = new Rect(panel.x() + 12, panel.y() + 10, 22, 22);
    }
    public Rect card(int index, int scroll) {
        return new Rect(content.x() + index % columns * (cardWidth + GAP),
                content.y() + index / columns * (CARD_HEIGHT + GAP) - scroll, cardWidth, CARD_HEIGHT);
    }
    public Rect nav(int index) {
        int step = Math.min(24, Math.max(12, (rail.h() - 16) / 9));
        return new Rect(rail.x() + 8, rail.y() + 8 + index * step, rail.w() - 16, step - 2);
    }
    public int maxScroll(int count) {
        int rows = (count + columns - 1) / columns;
        return Math.max(0, rows * (CARD_HEIGHT + GAP) - (rows > 0 ? GAP : 0) - content.h());
    }
    public static Rect home(int width, int height) {
        int w = Math.min(264, width - 20), h = Math.min(226, height - 16);
        return new Rect((width - w) / 2, (height - h) / 2, w, h);
    }
}
