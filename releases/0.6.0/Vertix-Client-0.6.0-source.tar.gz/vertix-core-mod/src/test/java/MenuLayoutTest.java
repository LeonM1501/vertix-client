import client.vertix.core.gui.MenuLayout;

public class MenuLayoutTest {
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        int cases = 0;
        for (int[] size : new int[][]{{320,240},{426,240},{480,270},{640,360},{960,540},{1280,720}}) {
            MenuLayout l = new MenuLayout(size[0], size[1]);
            check(l.panel.x() >= 0 && l.panel.right() <= size[0], "panel exceeds width");
            check(l.panel.y() >= 0 && l.panel.bottom() <= size[1], "panel exceeds height");
            check(l.nav(8).bottom() <= l.rail.bottom(), "HUD action overlaps footer at " + size[0]);
            check(l.content.w() >= 180 && l.cardWidth >= 160, "cards too narrow");
            check(l.search.bottom() < l.content.y(), "search overlaps cards");
            for (int count : new int[]{0,1,2,11,40}) {
                int max = l.maxScroll(count);
                check(max >= 0, "negative scroll");
                if (count > 0) {
                    var last = l.card(count - 1, max);
                    check(last.bottom() <= l.content.bottom(), "last row cannot be reached");
                    check(last.right() <= l.content.right(), "card exceeds clipped width");
                    check(last.contains(last.x(), last.y()), "top-left is clickable");
                    check(!last.contains(last.right(), last.bottom()), "gap belongs to no card");
                }
                cases++;
            }
        }
        check(new MenuLayout(640,360).columns == 2, "wide UI should have two columns");
        check(new MenuLayout(320,240).columns == 1, "narrow UI should have one column");
        System.out.println("Passed " + cases + " responsive layout cases.");
    }
}
