package client.vertix.core.config;

public final class LegacyHudStyleTest {
    private static void check(boolean value) {
        if (!value) throw new AssertionError("HUD migration regression");
    }
    public static void main(String[] args) {
        check(LegacyHudStyle.color("fps", "color", 0xFF55FF55) == 0xFFF2F0EB);
        check(LegacyHudStyle.color("cps", "color", 0xFFFFC837) == 0xFFF2F0EB);
        check(LegacyHudStyle.color("toggle_sprint", "color", 0xFF00FF88) == 0xFFF2F0EB);
        check(LegacyHudStyle.color("keystrokes", "active_color", 0xFF00D4FF) == 0xFFECE9E2);
        check(LegacyHudStyle.color("keystrokes", "inactive_color", 0x801A1E24) == 0xE01C1C1C);
        check(LegacyHudStyle.color("fps", "color", 0xFFAA44FF) == 0xFFAA44FF);
        check(LegacyHudStyle.color("crosshair", "color", 0xFF55FF55) == 0xFF55FF55);
        check(LegacyHudStyle.number("fps", "bg_opacity", 0.5) == 0.88);
        check(LegacyHudStyle.number("fps", "bg_opacity", 0.3) == 0.3);
        check(LegacyHudStyle.y("fps", 4, 50) == 64);
        check(LegacyHudStyle.y("fps", 124, 98) == 98);
        check(LegacyHudStyle.y("coordinates", 4, 22) == 28);
        check(LegacyHudStyle.y("keystrokes", 4, 110) == 132);
        System.out.println("HUD style migration: defaults updated, custom colors/positions preserved.");
    }
}
