param(
    [string]$MinecraftMetadataRoot = "$env:APPDATA\vertix\VertixClient\meta",
    [string]$JdkHome = "$env:ProgramFiles\Java\jdk-24"
)
$ErrorActionPreference = 'Stop'
$sourceRoot = $PSScriptRoot
$projectRoot = Split-Path -Parent $sourceRoot
$javac = Join-Path $JdkHome 'bin\javac.exe'
$jar = Join-Path $JdkHome 'bin\jar.exe'
if (!(Test-Path -LiteralPath $javac) -or !(Test-Path -LiteralPath $jar)) { throw 'Pass -JdkHome with a full JDK (24 or newer; 25 recommended).' }
$sources = @(Get-ChildItem -LiteralPath (Join-Path $sourceRoot 'src\main\java') -Recurse -Filter '*.java' | ForEach-Object { $_.FullName })
$libraryJars = @(Get-ChildItem -LiteralPath (Join-Path $MinecraftMetadataRoot 'libraries') -Recurse -Filter '*.jar' | ForEach-Object { $_.FullName })
$dependencies = Get-Content -Raw -LiteralPath (Join-Path $sourceRoot 'dependencies\manifest.json') | ConvertFrom-Json
foreach ($version in @('26.2', '26.3')) {
    $minecraft = Join-Path $MinecraftMetadataRoot "versions\$version\$version.jar"
    if (!(Test-Path -LiteralPath $minecraft)) { throw "Missing Minecraft $version client JAR. Prepare that version in Vertix first." }
    $dependency = Join-Path $sourceRoot "dependencies\$version\fabric-key-mapping-api-v1.jar"
    $expectedHash = ($dependencies | Where-Object minecraft -eq $version).sha256
    if ((Get-FileHash -LiteralPath $dependency -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { throw 'Fabric key mapping dependency checksum mismatch.' }
    # A fresh staging directory prevents removed classes from leaking into a release.
    $stage = Join-Path $sourceRoot ("build\$version-" + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    $classpath = (@($minecraft, $dependency) + $libraryJars) -join ';'
    $argsFile = Join-Path $stage 'compile.args'
    $compileArgs = @('-encoding', 'UTF-8', '-proc:none', '--release', '21', '-cp', ('"' + $classpath.Replace('\', '/') + '"'), '-d', ('"' + $stage.Replace('\', '/') + '"'))
    $compileArgs += $sources | ForEach-Object { '"' + $_.Replace('\', '/') + '"' }
    Set-Content -LiteralPath $argsFile -Value $compileArgs -Encoding utf8
    & $javac "@$argsFile"
    if ($LASTEXITCODE -ne 0) { throw "Core compilation for $version failed." }
    # compile.args is outside the package entries below and is never distributed.
    Copy-Item -LiteralPath (Join-Path $sourceRoot 'src\main\resources\vertix.mixins.json') -Destination $stage
    Copy-Item -LiteralPath (Join-Path $projectRoot 'LICENSE') -Destination $stage
    $metadata = Get-Content -Raw -LiteralPath (Join-Path $sourceRoot 'src\main\resources\fabric.mod.json') | ConvertFrom-Json
    $metadata.depends.minecraft = $version
    $metadata | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $stage 'fabric.mod.json') -Encoding utf8
    New-Item -ItemType Directory -Path (Join-Path $stage 'META-INF\jars') -Force | Out-Null
    Copy-Item -LiteralPath $dependency -Destination (Join-Path $stage 'META-INF\jars\fabric-key-mapping-api-v1.jar')
    Copy-Item -LiteralPath (Join-Path $sourceRoot 'src\main\resources\assets') -Destination $stage -Recurse
    $output = Join-Path $projectRoot "src-tauri\resources\mods\vertix-core-fabric-$version-1.1.0.jar"
    & $jar --create --file $output --date=2026-10-10T00:00:00Z -C $stage client -C $stage assets -C $stage META-INF -C $stage fabric.mod.json -C $stage vertix.mixins.json -C $stage LICENSE
    if ($LASTEXITCODE -ne 0) { throw "Packaging for $version failed." }
    Write-Host "Built $output"
}
