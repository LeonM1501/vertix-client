# Vertix Core 1.1.0

Clientseitige Fabric-Mod des Vertix-Launchers, GPL-3.0-only. R-Shift öffnet das Hauptmenü. „Mod Menü“ öffnet Module, Suche und Kategorien; Profile und HUD-Editor sind separat erreichbar. ESC geht eine Ebene zurück, R-Shift schließt das Menü. Einstellungen und HUD-Positionen werden über den bestehenden ConfigManager gespeichert.

## Unterstützte Versionen

Fabric, Minecraft **26.2** und **26.3**, Java 25+, Fabric Loader 0.19.3+. Für jede Minecraft-Version wird eine eigene JAR kompiliert. 26.3 verwendet SDL-Eingabecodes; `InputConstants` wird beim jeweiligen Build aufgelöst. Die Mod behauptet keine Kompatibilität zu 1.21, Forge, NeoForge oder Quilt.

Die kleine Fabric Key Mapping API ist versionsgenau als unveränderte verschachtelte JAR enthalten. Eine zusätzlich installierte vollständige Fabric API ist für Vertix Core nicht nötig. Herkunft und Prüfsummen: `dependencies/manifest.json`; Lizenz und Fabric-Metadaten sind in den jeweiligen JARs enthalten. Quellen: https://github.com/FabricMC/fabric (Apache-2.0).

## Build

Zuerst die beiden Minecraft-Versionen in Vertix vorbereiten, damit die offiziellen Spiel-JARs und Bibliotheken vorhanden sind. Dann im Projektstamm:

```powershell
./vertix-core-mod/build.ps1 -JdkHome 'C:/Program Files/Java/jdk-25'
# Optional: -MinecraftMetadataRoot '<Vertix-Metadatenordner>'
```

Ein vollständiges JDK ab 24 wird akzeptiert; JDK 25 vermeidet die Klassenversionswarnungen beim Lesen der Minecraft-JARs. Der Build verwendet nur den eigenen Java-Source und die offiziellen vorhandenen Bibliotheken. Frische Staging-Verzeichnisse verhindern alte Klassen im Paket. Ergebnisse liegen unter `src-tauri/resources/mods/vertix-core-fabric-<minecraft>-1.1.0.jar`; der Rust-Build bindet beide ein.

Layoutprüfung ohne Spielstart:

```powershell
javac -d artifacts/core-layout-test vertix-core-mod/src/main/java/client/vertix/core/gui/MenuLayout.java vertix-core-mod/src/test/java/MenuLayoutTest.java
java -cp artifacts/core-layout-test MenuLayoutTest
```

Die Launcher-Integration aktualisiert Core beim Profilstart und beim Vorbereiten für den offiziellen Launcher. Sie vergleicht den Dateiinhalt, schreibt atomar und bereinigt ausschließlich genau benannte ältere Core-Artefakte. Config-Dateien und andere lokale Mods bleiben erhalten.
