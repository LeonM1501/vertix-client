# Minecraft fallback skin

`steve.png` is the unmodified wide Steve player texture from Minecraft 26.2
(`assets/minecraft/textures/entity/player/wide/steve.png`).
Minecraft artwork © Mojang AB / Microsoft. Used to identify the game and display
a standard player when no account skin is available. This artwork is not covered
by Vertix's source-code licence. Vertix is not an official Minecraft product.
