# Core 1.7.3 – Visual-Module, Totem und Welt-Feuer

Ancient Debris Notifier markiert Funde in geladenen Chunks; Clear Water und Clear Lava reduzieren Flüssigkeitsnebel. Totem Counter zeigt den eigenen Bestand, Low Totem steuert zusätzlich die Pop-Größe. Das Welt-Feuer-Paket wurde verkleinert und migriert ältere Paketversionen. FreeCam, Modul-Hotkeys, Profile mit Videooptionen und Performance-Profile bleiben enthalten.

Bedienung und Release-Prüfung: [Client 0.14.2](../changelogs/0.14.2.md). Herkunft und Lizenzen: [THIRD_PARTY.md](THIRD_PARTY.md). Core 1.7.3 ist im Launcher-Update 0.14.2 für Fabric 26.2/26.3 und Forge 1.20.1 enthalten.

# Core 1.6.1 — Discord Streaming ohne eigenes FPS-Limit

Der Streaming-Modus verwendet Minecrafts eigenes FPS-Limit und behält seine
randlose Vollbildfunktion. Ältere `stream_fps`-Einstellungen werden nicht
mehr verwendet; das separate Hintergrund-FPS-Modul bleibt unverändert.
Unterstützt werden Fabric 26.2/26.3 und Forge 1.20.1. Details und Prüfungen:
[Discord-Streaming-FPS](../changelogs/discord-streaming-fps.md).

# Historie: Core 1.5.0 für Client 0.10.0

Neue Module: FPS Modus, Hintergrund-Ruhe, Zoom und Session HUD. Das FPS-HUD unterstützt Kompakt, Details und Framezeit-Graph. R-Shift → Profile → Performance aktiviert Grafikprofil, Graph und Hintergrundlimit. Neue Module sind einzeln wählbar und standardmäßig aus.

Die drei Grafikstufen begrenzen Sichtweite auf maximal 12/8/5 Chunks und reduzieren Entity-Reichweite sowie Partikel. Schnell/Maximum reduzieren Ambient Occlusion und Biome Blend. Schon niedrigere Werte werden nicht erhöht. Wolken und Entity-Schatten separat einstellbar. FPS-Limit und VSync bleiben erhalten. Beim Ausschalten/Weltverlassen/Beenden kommen unverändert verwaltete Originalwerte zurück; manuelle Änderungen behalten bei der Rücknahme Vorrang. OptionsMixin verhindert die Speicherung temporärer Werte in options.txt.

Zoom: aktivieren, C halten (umlegbar). F6 kopiert eigene Koordinaten ohne Chat-Übertragung. Favoriten auf Modkarten markieren und links filtern. Zurücksetzen im Einstellungsfenster betrifft nur Moduloptionen, keine Positionen oder Aktivzustände. Session-Zeit beginnt beim Welt-/Dimensionswechsel neu.

Java-25-Tests mit Temurin und normalem JIT sowie mit Sodium/Lithium/FerriteCore bestanden unter Minecraft 26.2 und 26.3. Drittmods werden nicht gebündelt. Es wird kein bestimmter FPS-Gewinn zugesagt. Details: [Prüfstand 0.10.0](../changelogs/verification-0.10.0.md).

# Historie: Core 1.4.0 — Armor HUD für Client 0.9.0

Das bestehende Modul `armor_hud` verwendet adaptierte MIT-Regeln aus uku’s Armor HUD, ergänzt um eigene Vertix-Darstellung. Herkunft, Commit und Lizenz: [UPSTREAM.md](../third_party/uku-armor-hud/UPSTREAM.md).

Unter **R-Shift → HUD → Armor HUD → Einstellungen** beziehungsweise per Rechtsklick im HUD-Editor:

- Anzeige: horizontal/vertikal, alle/belegte/kritische Slots, Reihenfolge, beide Hände einzeln und Zuschauermodus.
- Haltbarkeit: Prozent, Restwert, Rest/Gesamt, Balken oder Prozent mit Balken; vollständig abschaltbar.
- Warnungen: Prozent- und Restwertgrenze (eine genügt), Warnfarbe, optionales bewegtes Symbol und Warnton beim Eintritt in den kritischen Bereich (maximal alle vier Sekunden, standardmäßig aus).
- Darstellung: Vertix-Panel, einzelne Slots oder minimal; Deckkraft, Größe, Abstände, leere Slot-Symbole und Textfarben. Das HUD bleibt auf dem Bildschirm und skaliert bei Platzmangel herunter.

Die bisherige Modul-ID und die IDs `orientation`, `held`, `durability` bleiben erhalten; neue Optionen verwenden Standardwerte. Warnfarben sind unabhängig von optionalen Haltbarkeitsfarben. Vor dem Weltladen verwendet die Editor-Vorschau sichere eigene Slot-Symbole, danach echte Minecraft-Items.

Für die Veröffentlichung von Client 0.9.0 am 22. Oktober werden EXE, Setup und Source-Archiv mit Core 1.4.0 neu gebaut. Ältere lokale 0.9.0-Artefakte mit Core 1.3.1 dürfen nicht verwendet werden. Änderungen am Desktop-Setup oder an einer persönlichen Installation sind ein gesonderter Auftrag.

Prüfungen und Befehle: [verification-core-1.4.0.md](../changelogs/verification-core-1.4.0.md).

# Änderungen in Core 1.3.0

## Core 1.3.1

Direkter R-Shift-Modbrowser, transparente Oberflächen und gruppierte Einstellungsfenster im Vertix-Stil. Modulwerte und HUD-Konfiguration bleiben kompatibel mit 1.3.0.

Modkarten besitzen klare Symbole und unterscheidbare Aktivzustände. Der HUD-Editor bietet Raster, abschaltbares Einrasten an Bildschirmmitte und anderen Anzeigen, Ausrichtungslinien, Rechtsklick-Einstellungen sowie das Zurücksetzen der Positionen auf den Stand beim Öffnen. Graphit/Offwhite, keine übernommenen NoRisk-Assets.

# Vertix Core 1.3.0

Clientseitige Fabric-Mod des Vertix-Launchers, GPL-3.0-only. R-Shift öffnet das Hauptmenü. „Mod Menü“ öffnet Module, Suche und Kategorien; Profile und HUD-Editor sind separat erreichbar. ESC geht eine Ebene zurück, R-Shift schließt das Menü. Einstellungen und HUD-Positionen werden über den bestehenden ConfigManager gespeichert.

## Unterstützte Versionen

Fabric, Minecraft **26.2** und **26.3**, Java 25+, Fabric Loader 0.19.3+. Für jede Minecraft-Version wird eine eigene JAR kompiliert. 26.3 verwendet SDL-Eingabecodes; `InputConstants` wird beim jeweiligen Build aufgelöst. Die Mod behauptet keine Kompatibilität zu 1.21, Forge, NeoForge oder Quilt.

Die kleine Fabric Key Mapping API ist versionsgenau als unveränderte verschachtelte JAR enthalten. Eine zusätzlich installierte vollständige Fabric API ist für Vertix Core nicht nötig. Herkunft und Prüfsummen: `dependencies/manifest.json`; Lizenz und Fabric-Metadaten sind in den jeweiligen JARs enthalten. Quellen: https://github.com/FabricMC/fabric (Apache-2.0).

## Discord Streaming

R-Shift → Mod Menü → Performance → **Discord Streaming** aktivieren. Das optionale Modul begrenzt Minecraft standardmäßig auf 60 FPS (30–240 einstellbar), damit GPU-Leistung für Discord übrig bleibt. Ein niedrigeres Spiel-/AFK-Limit bleibt erhalten. Unter Windows wird Vollbild randlos; beim Ausschalten werden das zusätzliche Limit und der Fensterwechsel zurückgenommen. Es gibt keine automatische Discord-Erkennung. Das Modul ist standardmäßig aus und wird über die vorhandene Modulkonfiguration gespeichert.

Die beiden `src/26.2/java`- und `src/26.3/java`-Window-Mixins sind getrennte Implementierungen: GLFW für 26.2, Minecrafts vorhandene SDL-Funktion für 26.3. Der Build nimmt genau die zur Version gehörenden Quellen auf.

Ein isolierter Offline-Lauf prüft Mod-Laden, FPS-Begrenzung und Rücknahme, wiederholte Vollbildwechsel und Wiederherstellung der Fenstergröße:

```powershell
./scripts/test-streaming.ps1 -Version 26.2 -MetadataRoot '<Metadaten mit beiden Spiel-JARs und Bibliotheken>' -JdkHome '<JDK>'
./scripts/test-streaming.ps1 -Version 26.3 -MetadataRoot '<Metadaten mit beiden Spiel-JARs und Bibliotheken>' -JdkHome '<JDK>'
```

Der Test verwendet ein eigenes Spiel- und Konfigurationsverzeichnis unter `artifacts/verification/0.7.0`, keine echten Anmeldedaten, und beendet seine eigene Spielinstanz nach den Prüfungen. Der Test-Mixin wird nie in die produktiven Core-JARs aufgenommen. Das prüft keinen echten Discord-Stream und keinen GPU-Leistungsgewinn.

Mit `-JavaHome '<Java-25-Runtime>'` kann die Laufzeit unabhängig vom Compiler gewählt werden, beispielsweise die vom Launcher verwaltete Java-25-Runtime. `-AssetsRoot` wählt einen vorbereiteten offiziellen Assets-Ordner; 26.3 benötigt den Index 34 einschließlich der zugehörigen Dateien.

Core gehört zur Laufzeit ausschließlich in den Mod-Ordner, nicht zusätzlich in den JVM-Classpath. Der Test nimmt Core nur zum Kompilieren in den Classpath auf. Die abschließenden 26.3-Prüfungen bestanden mit der normalen Java-25-Runtime und JIT; ein früherer Interpreterlauf ist zusätzlich als Diagnoseartefakt erhalten. Die tatsächliche Streamleistung wurde nicht vermessen.

## Build ausführen

Zuerst die beiden Minecraft-Versionen in Vertix vorbereiten, damit die offiziellen Spiel-JARs und Bibliotheken vorhanden sind. Dann im Projektstamm:

```powershell
./vertix-core-mod/build.ps1 -JdkHome 'C:/Program Files/Java/jdk-25'
# Optional: -MinecraftMetadataRoot '<Vertix-Metadatenordner>'
```

Ein vollständiges JDK ab 24 wird akzeptiert; JDK 25 vermeidet die Klassenversionswarnungen beim Lesen der Minecraft-JARs. Der Build verwendet nur den eigenen Java-Source und die offiziellen vorhandenen Bibliotheken. Frische Staging-Verzeichnisse verhindern alte Klassen im Paket. Ergebnisse liegen unter `src-tauri/resources/mods/vertix-core-fabric-<minecraft>-<Version-aus-fabric.mod.json>.jar`; der Rust-Build bindet beide ein.

Layoutprüfung ohne Spielstart:

```powershell
javac -d artifacts/core-layout-test vertix-core-mod/src/main/java/client/vertix/core/gui/MenuLayout.java vertix-core-mod/src/test/java/MenuLayoutTest.java
java -cp artifacts/core-layout-test MenuLayoutTest
```

Die Launcher-Integration aktualisiert Core beim Profilstart und beim Vorbereiten für den offiziellen Launcher. Sie vergleicht den Dateiinhalt, schreibt atomar und bereinigt ausschließlich genau benannte ältere Core-Artefakte. Config-Dateien und andere lokale Mods bleiben erhalten.
