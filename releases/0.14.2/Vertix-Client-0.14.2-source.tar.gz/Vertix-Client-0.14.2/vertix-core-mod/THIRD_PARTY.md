# Integrierte Originalprojekte

Die unveränderten Original-JARs liegen unter `dependencies/integrations/` und werden mit ihren eigenen Metadaten und Lizenzdateien verschachtelt ausgeliefert. `manifest.json` hält Versionsnummer, Original-Download und SHA-512 fest. Fabric Loader löst Mod-IDs auf, sodass eine bereits installierte neuere kompatible Ausgabe derselben Mod nicht doppelt initialisiert wird.

- AppleSkin, squeek502: https://github.com/squeek502/AppleSkin — Unlicense. Fabric 26.2/26.3 und Forge 1.20.1. Originale HUD-, Tooltip- und Netzwerkfunktionen; Steuerung im Vertix-Core-Menü. Exakte Sättigungswerte auf Multiplayer-Servern hängen weiterhin von der Unterstützung des Servers ab.
- Gamma Utils, Sjouwer: https://github.com/Sjouwer/gamma-utils — LGPL-3.0-only. Unveränderte Fabric-Versionen; Core steuert deren öffentliche Laufzeiteinstellungen und setzt dynamische Gamma-Anpassungen nur vorübergehend aus. Forge 1.20.1 verwendet eine eigene Lichtmap-Anbindung, weil die aktuelle Gamma-Utils-Integration für diese Plattform nicht verfügbar ist.
- TotemCounter, uku: https://github.com/uku3lig/totemcounter — MIT. Unveränderte Fabric-Versionen mit ukulib; Vertix steuert Nametag-/Tab-Optionen und stellt die Zähler im eigenen gestaltbaren HUD dar. Forge 1.20.1 verwendet einen eigenen Inventar-/Paket-Zähler.
- Fabric API: https://github.com/FabricMC/fabric — Apache-2.0. Originale versionsgebundene API-JARs mit verschachtelten Teilmodulen.
- Cloth Config: https://github.com/shedaniel/cloth-config — LGPL-3.0-only. Originalabhängigkeit von Gamma Utils.
- ukulib: https://github.com/uku3lig/ukulib — MPL-2.0. Originalabhängigkeit von TotemCounter. Weitere verschachtelte Bibliotheken behalten ihre Originalhinweise.

Enchantment Outlines / Glowing Glints von Tixul: https://modrinth.com/resourcepack/glowing-glints — All Rights Reserved. Die Grafiken werden **nicht** in Vertix weiterverteilt. Das Modul lädt die unveränderte Originaldatei beim Aktivieren vom Modrinth-CDN, prüft SHA-512 und aktiviert ausschließlich sein eigenes Pack. Für Minecraft 1.20.1 benötigt das Pack eine passende CIT-Unterstützung (etwa OptiFine); diese wird nicht automatisch installiert. Das Originalpack kann Warnungen zu optionalen Mod-Items protokollieren, wenn die betreffenden Mods fehlen.

Marvins PvP Enhancements wurde ausschließlich lokal als Funktionsreferenz untersucht. Es wird weder eingebettet noch dessen Code kopiert. Item-Physik und Schwertanimationen werden nicht verändert.
