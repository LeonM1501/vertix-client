package client.vertix.core.mixin;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.modules.visual.AncientDebrisModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public class AncientDebrisRenderMixin {
    @Inject(method="finalizeGizmoCollection",at=@At("HEAD"),require=0)
    private void vertix$debris(CallbackInfo ci){
        var core=VertixCoreMod.getInstance();var mc=Minecraft.getInstance();
        if(core==null||mc.player==null)return;
        var module=(AncientDebrisModule)core.getModuleManager().getModule("ancient_debris_notifier");
        if(!module.isEnabled()||module.visible().isEmpty())return;
        var camera=mc.gameRenderer.mainCamera();var forward=camera.forwardVector();
        var start=camera.position().add(forward.x()*.5,forward.y()*.5,forward.z()*.5);
        try(var collection=((LevelRenderer)(Object)this).collectPerFrameRenderThreadGizmos()){
            for(var pos:module.visible()){
                Gizmos.cuboid(pos,GizmoStyle.stroke(0xFFFFAA33,2)).setAlwaysOnTop();
                Gizmos.line(start,Vec3.atCenterOf(pos),0xFFFFAA33,2).setAlwaysOnTop();
            }
        }
    }
}
