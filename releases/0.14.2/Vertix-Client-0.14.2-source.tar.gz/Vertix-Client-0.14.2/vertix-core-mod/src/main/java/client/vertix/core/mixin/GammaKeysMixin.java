package client.vertix.core.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets="io.github.sjouwer.gammautils.KeyBindings",remap=false)
public class GammaKeysMixin {
    @Inject(method="registerBindings",at=@At("HEAD"),cancellable=true,remap=false)
    private static void vertix$disableKeys(CallbackInfo ci){ci.cancel();}
}
