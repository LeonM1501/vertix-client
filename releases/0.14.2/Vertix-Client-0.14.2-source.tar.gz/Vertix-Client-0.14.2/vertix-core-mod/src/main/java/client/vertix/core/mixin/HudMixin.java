package client.vertix.core.mixin;

import client.vertix.core.VertixCoreMod;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Hud.class)
public class HudMixin {

    @Inject(method = "extractRenderState", at = @At("TAIL"), require = 0)
    private void vertix$onExtractRenderState(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, CallbackInfo ci) {
        VertixCoreMod mod = VertixCoreMod.getInstance();
        if (mod != null) {
            mod.onRenderHud(extractor, deltaTracker);
        }
    }

    @Inject(method="extractEffects",at=@At("HEAD"),cancellable=true)
    private void effects(GuiGraphicsExtractor g,DeltaTracker d,CallbackInfo ci){var c=VertixCoreMod.getInstance();if(c!=null&&c.getModuleManager()!=null&&c.getModuleManager().isModuleEnabled("potion_effects"))ci.cancel();}

    @Inject(method = "extractCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void vertix$onExtractCrosshair(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, CallbackInfo ci) {
        VertixCoreMod mod = VertixCoreMod.getInstance();
        if (mod != null && mod.getModuleManager() != null && mod.getModuleManager().isModuleEnabled("crosshair")) {
            ci.cancel();
        }
    }
}
