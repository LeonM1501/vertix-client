package client.vertix.core.mixin;
import client.vertix.core.modules.visual.ClearFluidModule;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.FogRenderer;
import net.minecraft.world.level.material.FogType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(FogRenderer.class)
public class ClearFluidFogMixin {
    @Inject(method="setupFog",at=@At("RETURN"),require=0)
    private void vertix$clear(Camera camera,int renderDistance,DeltaTracker delta,float darken,ClientLevel level,CallbackInfoReturnable<FogData> ci){
        var type=camera.getFluidInCamera();
        if((type==FogType.WATER&&ClearFluidModule.active("clear_water"))||(type==FogType.LAVA&&ClearFluidModule.active("clear_lava"))){
            var fog=ci.getReturnValue();float distance=renderDistance*16f;fog.environmentalStart=distance*.75f;fog.environmentalEnd=distance;
        }
    }
}
