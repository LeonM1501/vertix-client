package client.vertix.core.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Shared HUD surfaces and spacing, matching the in-game menu. */
public final class HudStyle {
    public static final int TEXT = RenderUtils.COLOR_TEXT_PRIMARY;
    public static final int MUTED = RenderUtils.COLOR_TEXT_SECONDARY;
    public static final int SURFACE = 0xE01C1C1C;
    public static final int BORDER = 0xB0444444;
    public static final int PADDING = 6;
    public static final int LINE_HEIGHT = 12;
    public static final int COMPACT_HEIGHT = 20;
    public static final double DEFAULT_OPACITY = 0.88;

    private static client.vertix.core.api.Module current;
    public static void begin(client.vertix.core.api.Module module){current=module;}
    public static void end(){current=null;}
    public static String style(){
        if(current!=null){var s=current.getSetting("style",client.vertix.core.api.Setting.ModeSetting.class);if(s!=null&&!s.getValue().equals("Global"))return s.getValue();}
        var core=client.vertix.core.VertixCoreMod.getInstance();
        var theme=core==null||core.getModuleManager()==null?null:core.getModuleManager().getModule("theme");
        if(theme==null||!theme.isEnabled())return "Vertix";
        return theme.getSetting("style",client.vertix.core.api.Setting.ModeSetting.class).getValue();
    }
    private HudStyle() {}

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        panel(g, x, y, w, h, DEFAULT_OPACITY);
    }

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, double opacity) {
        int alpha = (int) Math.round(Math.max(0, Math.min(1, opacity)) * 255);
        RenderUtils.drawCard(g, x, y, w, h, (alpha << 24) | 0x0020252B,
                ((int) Math.round(alpha * 0.58) << 24) | 0x00515B66);
    }

    public static void text(GuiGraphicsExtractor g, Font font, String value, int x, int y, int color) {
        RenderUtils.drawText(g, font, value, x, y, color, false);
    }

    public static void centered(GuiGraphicsExtractor g, Font font, String value, int x, int y, int color) {
        RenderUtils.drawCenteredText(g, font, value, x, y, color, false);
    }

    /** Keep user-selected colors legible for both light and dark key backgrounds. */
    public static int contrastingText(int background) {
        int r = (background >> 16) & 255, g = (background >> 8) & 255, b = background & 255;
        return (r * 299 + g * 587 + b * 114) / 1000 >= 145 ? 0xFF171717 : TEXT;
    }
}
