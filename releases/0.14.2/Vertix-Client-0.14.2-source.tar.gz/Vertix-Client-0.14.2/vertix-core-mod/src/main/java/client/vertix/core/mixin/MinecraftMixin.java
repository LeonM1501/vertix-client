package client.vertix.core.mixin;

import client.vertix.core.VertixCoreMod;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void vertix$onTick(CallbackInfo ci) {
        VertixCoreMod mod = VertixCoreMod.getInstance();
        if (mod != null) {
            mod.onTick((Minecraft) (Object) this);
        }
    }
    @Inject(method="startAttack",at=@At("HEAD"),cancellable=true)
    private void vertix$noAttack(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> ci){if(client.vertix.core.modules.qol.FreeCamModule.active())ci.setReturnValue(false);}
    @Inject(method="startUseItem",at=@At("HEAD"),cancellable=true)
    private void vertix$noUse(CallbackInfo ci){if(client.vertix.core.modules.qol.FreeCamModule.active())ci.cancel();}
    @Inject(method="continueAttack",at=@At("HEAD"),cancellable=true)
    private void vertix$noContinue(boolean attacking,CallbackInfo ci){if(client.vertix.core.modules.qol.FreeCamModule.active())ci.cancel();}
    @Inject(method="renderFrame",at=@At("HEAD"))
    private void vertix$sampleFrame(boolean renderLevel,CallbackInfo ci){var core=VertixCoreMod.getInstance();if(core!=null)core.onFrame((Minecraft)(Object)this);}
    @Inject(method="close",at=@At("HEAD"))
    private void vertix$restoreOptions(CallbackInfo ci){var mode=client.vertix.core.modules.qol.PerformanceModeModule.instance();if(mode!=null)mode.shutdown();var zoom=client.vertix.core.modules.qol.ZoomModule.instance();if(zoom!=null)zoom.restore();}
}
