package client.vertix.core.mixin;
import net.minecraft.client.Camera;
import client.vertix.core.modules.qol.ZoomModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import client.vertix.core.modules.qol.FreeCamModule;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPosition(net.minecraft.world.phys.Vec3 position);
    @Shadow protected abstract void setRotation(float yaw,float pitch);
    @Inject(method="update",at=@At(value="INVOKE",target="Lnet/minecraft/client/Camera;alignWithEntity(F)V",shift=At.Shift.AFTER))
    private void vertix$freecam(net.minecraft.client.DeltaTracker delta,CallbackInfo ci){var f=FreeCamModule.instance();if(FreeCamModule.active()){setPosition(f.position());setRotation(f.yaw(),f.pitch());}}
    @Inject(method="calculateFov",at=@At("RETURN"),cancellable=true)
    private void zoom(float partial,CallbackInfoReturnable<Float> ci){var z=ZoomModule.instance();if(z!=null)ci.setReturnValue((float)(ci.getReturnValue()*z.multiplier()));}
}
