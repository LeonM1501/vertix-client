package client.vertix.core.mixin;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.particle.Particle;
import net.minecraft.core.particles.ParticleOptions;
import client.vertix.core.performance.RenderOptimizer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ParticleEngine.class)
public class ParticleBudgetMixin {
    @Inject(method="createParticle",at=@At("HEAD"),cancellable=true)
    private void budget(ParticleOptions options,double x,double y,double z,double dx,double dy,double dz,CallbackInfoReturnable<Particle> ci){if(RenderOptimizer.rejectParticle(options,x,y,z))ci.setReturnValue(null);}
}
