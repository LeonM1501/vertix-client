package client.vertix.core.mixin;
import client.vertix.core.modules.visual.GammaModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Pause dynamic adjustments without altering the user's Gamma Utils settings. */
@Pseudo
@Mixin(targets="io.github.sjouwer.gammautils.GammaManager",remap=false)
public class GammaDynamicMixin {
    @Inject(method="setDynamicGamma",at=@At("HEAD"),cancellable=true,remap=false)
    private static void holdCoreBrightness(CallbackInfo ci){if(GammaModule.active())ci.cancel();}
}
