package client.vertix.core.config;

import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private JsonObject profiles=new JsonObject();
    private String activeProfile="";
    public java.util.List<String> getProfiles(){return java.util.List.copyOf(profiles.keySet());}
    public String getActiveProfile(){return activeProfile;}
    public void saveProfile(String name,List<Module> modules){
        name=name.strip();if(name.isEmpty()||name.length()>48)throw new IllegalArgumentException("Profilname: 1 bis 48 Zeichen");
        var mode=client.vertix.core.modules.qol.PerformanceModeModule.instance();
        if(mode!=null)mode.beforeOptionsSave();
        JsonObject video;
        try{video=VideoSettings.capture(Minecraft.getInstance().options);}finally{if(mode!=null)mode.afterOptionsSave();}
        JsonObject snapshot=snapshot(modules),keys=new JsonObject();
        snapshot.add("video",video);
        for(var key:Minecraft.getInstance().options.keyMappings)keys.addProperty(key.getName(),key.saveString());
        JsonElement old=profiles.get(name);String oldActive=activeProfile;Preset oldPreset=activePreset;
        snapshot.add("controls",keys);profiles.add(name,snapshot);activeProfile=name;activePreset=Preset.CUSTOM;
        if(!saveConfig(modules)){
            if(old==null)profiles.remove(name);else profiles.add(name,old);
            activeProfile=oldActive;activePreset=oldPreset;
            throw new IllegalStateException("Profil konnte nicht gespeichert werden. Datei ist eventuell gesperrt.");
        }
    }
    public void deleteProfile(String name,List<Module> modules){
        JsonElement old=profiles.remove(name);if(old==null)return;
        String oldActive=activeProfile;if(activeProfile.equals(name))activeProfile="";
        if(!saveConfig(modules)){profiles.add(name,old);activeProfile=oldActive;throw new IllegalStateException("Profil konnte nicht gelöscht werden. Datei ist eventuell gesperrt.");}
    }
    public void loadProfile(String name,List<Module> modules){
        if(!profiles.has(name))return;
        JsonObject snapshot=profiles.getAsJsonObject(name);
        var mode=client.vertix.core.modules.qol.PerformanceModeModule.instance();
        if(mode!=null)mode.beforeOptionsSave();
        try{if(snapshot.has("video")&&snapshot.get("video").isJsonObject())VideoSettings.apply(Minecraft.getInstance().options,snapshot.getAsJsonObject("video"));}
        finally{if(mode!=null)mode.afterOptionsSave();}
        applyModules(snapshot,modules,false);
        if(snapshot.has("controls")){
            var keys=snapshot.getAsJsonObject("controls");
            for(var key:Minecraft.getInstance().options.keyMappings)if(keys.has(key.getName())){
                try{key.setKey(com.mojang.blaze3d.platform.InputConstants.getKey(keys.get(key.getName()).getAsString()));}catch(IllegalArgumentException ignored){}
            }
            net.minecraft.client.KeyMapping.resetMapping();
        }
        Minecraft.getInstance().options.save();
        activeProfile=name;activePreset=Preset.CUSTOM;
        if(!saveConfig(modules))throw new IllegalStateException("Profil geladen, aber aktiver Zustand konnte nicht gespeichert werden.");
    }

    private Preset activePreset = Preset.NORMAL;

    public Preset getActivePreset() {
        return activePreset;
    }

    public void setActivePreset(Preset preset) {
        this.activePreset = preset;
        this.activeProfile="";
    }

    public void applyPreset(Preset preset, List<Module> modules) {
        this.activePreset = preset;
        this.activeProfile="";
        if (preset == Preset.CUSTOM) return;

        List<String> activeIds = preset.getDefaultActiveModules();
        for (Module m : modules) {
            boolean shouldEnable = activeIds.contains(m.getId()) || m.getId().equals("appleskin") || m.getId().equals("theme");
            m.setEnabled(shouldEnable);
        }
        for(Module m:modules)if(m.getId().equals("fps")){var view=m.getSetting("view",Setting.ModeSetting.class);if(view!=null)view.setValue(preset==Preset.PERFORMANCE?"Graph":"Kompakt");}
        saveConfig(modules);
    }

    public File getGlobalConfigFile() {
        String appdata = System.getenv("APPDATA");
        if (appdata != null && !appdata.isEmpty()) {
            File dir = new File(appdata, "vertix");
            dir.mkdirs();
            return new File(dir, "vertix-client-config.json");
        }
        File homeDir = new File(System.getProperty("user.home"), ".vertix");
        homeDir.mkdirs();
        return new File(homeDir, "vertix-client-config.json");
    }

    public File getLocalConfigFile() {
        try {
            File gameDir = Minecraft.getInstance().gameDirectory;
            if (gameDir != null) {
                File dir = new File(gameDir, "config");
                dir.mkdirs();
                return new File(dir, "vertix-client.json");
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public void loadConfig(List<Module> modules) {
        File target = getGlobalConfigFile();
        if (!target.exists()) {
            File local = getLocalConfigFile();
            if (local != null && local.exists()) {
                target = local;
            }
        }

        if (!target.exists()) {
            // No saved config yet, initialize with default Preset (NORMAL)
            applyPreset(Preset.NORMAL, modules);
            return;
        }

        boolean migrated = false;
        try (FileReader reader = new FileReader(target,java.nio.charset.StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            boolean legacyStyle = !root.has("version") || root.get("version").getAsInt() < 2;

            if (root.has("active_preset")) {
                try {
                    this.activePreset = Preset.valueOf(root.get("active_preset").getAsString());
                } catch (Exception e) {
                    this.activePreset = Preset.CUSTOM;
                }
            }

            if(root.has("profiles")&&root.get("profiles").isJsonObject())profiles=root.getAsJsonObject("profiles").deepCopy();
            if(root.has("active_profile"))activeProfile=root.get("active_profile").getAsString();
            applyModules(root,modules,legacyStyle);
            if(!root.has("version")||root.get("version").getAsInt()<3)for(Module m:modules)if(m.getId().equals("potion_effects")&&m.getX()==4&&m.getY()==266){m.setX(200);m.setY(4);}
            migrated = legacyStyle;
        } catch (Exception e) {
            System.err.println("[Vertix] Fehler beim Laden der Konfiguration: " + e.getMessage());
        }
        if (migrated) saveConfig(modules);
    }

    private void applyModules(JsonObject root,List<Module> modules,boolean legacyStyle){
            if (root.has("modules") && root.get("modules").isJsonObject()) {
                JsonObject modsObj = root.getAsJsonObject("modules");
                for (Module m : modules) {
                    if (modsObj.has(m.getId())) {
                        JsonObject mObj = modsObj.getAsJsonObject(m.getId());

                        if(mObj.has("favorite"))m.setFavorite(mObj.get("favorite").getAsBoolean());
                        if(mObj.has("hotkey"))m.setHotkey(mObj.get("hotkey").getAsString());
                        if (mObj.has("enabled")) {
                            m.setEnabled(mObj.get("enabled").getAsBoolean());
                        }
                        if (mObj.has("x")) {
                            m.setX(mObj.get("x").getAsInt());
                        }
                        if (mObj.has("y")) {
                            m.setY(mObj.get("y").getAsInt());
                        }
                        if (legacyStyle) m.setY(LegacyHudStyle.y(m.getId(), m.getX(), m.getY()));

                        if (mObj.has("settings") && mObj.get("settings").isJsonObject()) {
                            JsonObject sObj = mObj.getAsJsonObject("settings");
                            if(m.getId().equals("low_totem")&&!sObj.has("pop_size")&&sObj.has("amount"))
                                m.getSetting("pop_size",Setting.NumberSetting.class).setValue(1-sObj.get("amount").getAsDouble()*.9);
                            for (Setting<?> s : m.getSettings()) {
                                if (sObj.has(s.getId())) {
                                    JsonElement elem = sObj.get(s.getId());
                                    if (s instanceof Setting.BooleanSetting && elem.isJsonPrimitive()) {
                                        ((Setting.BooleanSetting) s).setValue(elem.getAsBoolean());
                                    } else if (s instanceof Setting.NumberSetting && elem.isJsonPrimitive()) {
                                        double value = elem.getAsDouble();
                                        ((Setting.NumberSetting) s).setValue(legacyStyle ? LegacyHudStyle.number(m.getId(), s.getId(), value) : value);
                                    } else if (s instanceof Setting.ModeSetting && elem.isJsonPrimitive()) {
                                        ((Setting.ModeSetting) s).setValue(elem.getAsString());
                                    } else if (s instanceof Setting.ColorSetting && elem.isJsonPrimitive()) {
                                        int value = elem.getAsInt();
                                        ((Setting.ColorSetting) s).setValue(legacyStyle ? LegacyHudStyle.color(m.getId(), s.getId(), value) : value);
                                    }
                                }
                            }
                        }
                    }
                }
            }
    }

    private JsonObject snapshot(List<Module> modules) {
        JsonObject root = new JsonObject();
        root.addProperty("version", 3);
        root.addProperty("active_preset", activePreset.name());

        JsonObject modsObj = new JsonObject();
        for (Module m : modules) {
            JsonObject mObj = new JsonObject();
            mObj.addProperty("enabled", m.isEnabled());
            mObj.addProperty("favorite",m.isFavorite());
            mObj.addProperty("hotkey",m.getHotkey());
            mObj.addProperty("x", m.getX());
            mObj.addProperty("y", m.getY());

            JsonObject sObj = new JsonObject();
            for (Setting<?> s : m.getSettings()) {
                if (s instanceof Setting.BooleanSetting) {
                    sObj.addProperty(s.getId(), ((Setting.BooleanSetting) s).getValue());
                } else if (s instanceof Setting.NumberSetting) {
                    sObj.addProperty(s.getId(), ((Setting.NumberSetting) s).getValue());
                } else if (s instanceof Setting.ModeSetting) {
                    sObj.addProperty(s.getId(), ((Setting.ModeSetting) s).getValue());
                } else if (s instanceof Setting.ColorSetting) {
                    sObj.addProperty(s.getId(), ((Setting.ColorSetting) s).getValue());
                }
            }
            mObj.add("settings", sObj);
            modsObj.add(m.getId(), mObj);
        }
        root.add("modules", modsObj);

        return root;
    }
    public boolean saveConfig(List<Module> modules) {
        JsonObject root=snapshot(modules);
        root.add("profiles",profiles.deepCopy());root.addProperty("active_profile",activeProfile);
        String jsonStr = GSON.toJson(root);

        // 1. Save to Global Config File (%APPDATA%\vertix\vertix-client-config.json)
        boolean saved=writeFileSafe(getGlobalConfigFile(), jsonStr);

        // 2. Save to Instance Local Config File
        File local = getLocalConfigFile();
        if (saved && local != null) {
            writeFileSafe(local, jsonStr);
        }
        return saved;
    }

    private boolean writeFileSafe(File file, String content) {
        File temp = null;
        try {
            if (file.getParentFile() != null) {
                file.getParentFile().mkdirs();
            }
            temp = File.createTempFile(file.getName() + ".", ".tmp", file.getParentFile());
            try (FileWriter writer = new FileWriter(temp,java.nio.charset.StandardCharsets.UTF_8)) {
                writer.write(content);
            }
            try{java.nio.file.Files.move(temp.toPath(),file.toPath(),java.nio.file.StandardCopyOption.ATOMIC_MOVE,java.nio.file.StandardCopyOption.REPLACE_EXISTING);}
            catch(java.nio.file.AtomicMoveNotSupportedException e){java.nio.file.Files.move(temp.toPath(),file.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);}
            return true;
        } catch (Exception e) {
            System.err.println("[Vertix] Fehler beim Schreiben der Konfiguration: " + e.getMessage()
                    + (temp == null ? "" : "; Entwurf: " + temp));
            return false;
        }
    }
}
