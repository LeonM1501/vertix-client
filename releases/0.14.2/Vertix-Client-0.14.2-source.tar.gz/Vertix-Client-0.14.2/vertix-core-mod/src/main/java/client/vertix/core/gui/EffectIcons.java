package client.vertix.core.gui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;
public final class EffectIcons {
    public static void draw(GuiGraphicsExtractor g,Minecraft mc,MobEffectInstance effect,int x,int y){g.blitSprite(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,net.minecraft.client.gui.Hud.getMobEffectSprite(effect.getEffect()),x,y,18,18);}
}
