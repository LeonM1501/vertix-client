package client.vertix.core.modules.pvp;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
public final class CrystalOptimizerModule extends Module {
    public CrystalOptimizerModule(){super("crystal_optimizer","Crystal Optimizer","Kristall-Effekte begrenzen; Kristalle bleiben sichtbar.",Category.PERFORMANCE,false,false,0,0);
        addSetting(new Setting.BooleanSetting("beams","Beams ausblenden","Kosmetische Drachen-Heilstrahlen ausblenden.",true));
        addSetting(new Setting.BooleanSetting("base","Sockel ausblenden","Kosmetische Kristall-Sockel ausblenden.",false));
        addSetting(new Setting.BooleanSetting("explosions","Explosionen optimieren","Begrenzt Explosionspartikel, auch bei TNT; Schaden bleibt unverändert.",true));
        addSetting(new Setting.NumberSetting("explosion_budget","Explosionspartikel pro Tick","Begrenzt die Erstellung für Kristalle und TNT.",8,1,128,1,true));
    }
}
