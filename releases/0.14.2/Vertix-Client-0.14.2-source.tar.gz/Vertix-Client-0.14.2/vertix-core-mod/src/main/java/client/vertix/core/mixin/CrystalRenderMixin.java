package client.vertix.core.mixin;
import net.minecraft.client.renderer.entity.EndCrystalRenderer;
import net.minecraft.client.renderer.entity.state.EndCrystalRenderState;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import client.vertix.core.performance.RenderOptimizer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(EndCrystalRenderer.class)
public class CrystalRenderMixin {
    @Inject(method="extractRenderState(Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;Lnet/minecraft/client/renderer/entity/state/EndCrystalRenderState;F)V",at=@At("TAIL"))
    private void optimize(EndCrystal crystal,EndCrystalRenderState state,float partial,CallbackInfo ci){var m=RenderOptimizer.module("crystal_optimizer");if(RenderOptimizer.enabled(m)){if(RenderOptimizer.flag(m,"beams"))state.beamOffset=null;if(RenderOptimizer.flag(m,"base"))state.showsBottom=false;}}
}
