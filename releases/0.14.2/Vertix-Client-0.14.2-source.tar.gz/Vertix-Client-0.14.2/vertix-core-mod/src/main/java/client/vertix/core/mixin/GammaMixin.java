package client.vertix.core.mixin;
import net.minecraft.client.renderer.Lightmap;
import net.minecraft.client.renderer.state.LightmapRenderState;
import client.vertix.core.modules.visual.GammaModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Lightmap.class)
public class GammaMixin {
    @Inject(method="render",at=@At("HEAD"))
    private void gamma(LightmapRenderState state,CallbackInfo ci){float b=GammaModule.brightness();if(b>0){state.brightness=Math.max(state.brightness,b*15);state.needsUpdate=true;}}
}
