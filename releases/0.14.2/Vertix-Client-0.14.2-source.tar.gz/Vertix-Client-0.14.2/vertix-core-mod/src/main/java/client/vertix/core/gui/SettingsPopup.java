package client.vertix.core.gui;

import com.mojang.blaze3d.platform.InputConstants;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import java.util.*;
import static client.vertix.core.gui.RenderUtils.*;

/** Floating inspector: grouped rows share geometry for rendering and pointer input. */
public class SettingsPopup {
    private final Module module;
    private final MenuLayout.Rect panel, body, close;
    private final Set<String> collapsed = new HashSet<>();
    private Setting.NumberSetting dragging;
    private MenuLayout.Rect dragTrack;
    private int scroll;
    private boolean waitingForKey;
    private record Row(String group, Setting<?> setting, int offset) {}
    public SettingsPopup(Module module, int targetX, int targetY, int screenWidth, int screenHeight) {
        this.module = module;
        int w = Math.min(420, screenWidth - 24);
        int groups = (int)module.getSettings().stream().map(module::getSettingGroup).distinct().count();
        int h = Math.min(104 + groups * 24 + module.getSettings().size() * 28 + (module.getId().equals("low_totem")?78:0), screenHeight - 24);
        panel = new MenuLayout.Rect((screenWidth-w)/2, (screenHeight-h)/2, w, h);
        body = new MenuLayout.Rect(panel.x()+16, panel.y()+45, w-32, h-75);
        close = new MenuLayout.Rect(panel.right()-28, panel.y()+10, 16, 16);
    }
    private List<Row> rows() {
        List<Row> rows = new ArrayList<>(); int y = module.getId().equals("low_totem")?78:0;
        for (String group : module.getSettings().stream().map(module::getSettingGroup).distinct().toList()) {
            List<Setting<?>> settings = module.getSettings().stream().filter(s -> module.getSettingGroup(s).equals(group)).toList();
            if(settings.isEmpty())continue;
            rows.add(new Row(group,null,y)); y+=24;
            if(!collapsed.contains(group))for(Setting<?> s:settings){rows.add(new Row(group,s,y));y+=28;}
        }
        return rows;
    }
    private MenuLayout.Rect keyButton(){return new MenuLayout.Rect(panel.x()+14,panel.bottom()-23,Math.max(70,panel.w()-130),17);}
    private MenuLayout.Rect resetButton(){return new MenuLayout.Rect(panel.right()-106,panel.bottom()-23,90,17);}
    private static <T> void resetValue(Setting<T> setting){setting.setValue(setting.getDefaultValue());}
    private int maxScroll() {var list=rows();return Math.max(0,list.isEmpty()?0:list.getLast().offset()+(list.getLast().setting()==null?24:28)-body.h());}
    private int y(Row row) {return body.y()+row.offset()-scroll;}
    private MenuLayout.Rect control(Row row) {return new MenuLayout.Rect(body.right()-Math.min(146,body.w()/2),y(row)+3,Math.min(146,body.w()/2),20);}
    private MenuLayout.Rect track(Row row) {var c=control(row);return new MenuLayout.Rect(c.x()+43,c.y(),c.w()-43,c.h());}
    public Module getModule(){return module;}
    public boolean isMouseInside(double x,double y){return panel.contains(x,y);}
    public void render(GuiGraphicsExtractor g,int mx,int my,Minecraft client){
        scroll=Math.clamp(scroll,0,maxScroll());
        drawCard(g,panel.x(),panel.y(),panel.w(),panel.h(),0xF020252B,0xFF515B66);
        drawText(g,client.font,fit(client.font,module.getName(),panel.w()-60),panel.x()+16,panel.y()+15,COLOR_TEXT_PRIMARY,false);
        drawOutline(g,close.x(),close.y(),close.w(),close.h(),close.contains(mx,my)?COLOR_ACCENT:COLOR_BORDER_HOVER);
        drawCenteredText(g,client.font,"x",close.x()+8,close.y()+4,COLOR_TEXT_PRIMARY,false);
        drawRect(g,panel.x()+16,panel.y()+35,panel.w()-32,1,0x708F9298);
        g.enableScissor(body.x(),body.y(),body.right(),body.bottom());
        if(module.getId().equals("low_totem")){
            int top=body.y()-scroll;float size=(float)(4*module.getSetting("pop_size",Setting.NumberSetting.class).getValue());
            drawText(g,client.font,"Pop-Größe · Vorschau",body.x()+8,top+8,COLOR_TEXT_SECONDARY,false);
            int x=body.right()-56-(int)(8*size),y=top+37-(int)(8*size);
            g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(size,size);
            try{drawItem(g,net.minecraft.world.item.Items.TOTEM_OF_UNDYING.getDefaultInstance(),0,0);}finally{g.pose().popMatrix();}
        }
        for(Row row:rows()){
            int y=y(row);if(y+28<=body.y()||y>=body.bottom())continue;
            if(row.setting()==null){drawText(g,client.font,row.group()+"  "+(collapsed.contains(row.group())?">":"v"),body.x()+4,y+7,COLOR_TEXT_PRIMARY,false);continue;}
            Setting<?> s=row.setting();var c=control(row);
            drawRect(g,body.x()+5,y,1,28,0x70989A9E);
            drawText(g,client.font,fit(client.font,s.getName(),c.x()-body.x()-22),body.x()+17,y+9,COLOR_TEXT_SECONDARY,false);
            if(s instanceof Setting.NumberSetting n){
                String value=n.isInteger()?String.valueOf(n.getValue().intValue()):String.format(Locale.ROOT,"%.2f",n.getValue());
                drawCard(g,c.x(),c.y(),37,20,0x40303030,0x80989A9E);
                drawCenteredText(g,client.font,value,c.x()+18,c.y()+6,COLOR_TEXT_PRIMARY,false);
                var t=track(row);drawRect(g,t.x(),t.y()+9,t.w(),2,0x80989A9E);
                int filled=(int)Math.round((t.w()-5)*n.getRatio());
                drawRect(g,t.x(),t.y()+9,filled,2,0xC0ECE9E2);
                drawRect(g,t.x()+filled,t.y()+6,5,8,COLOR_ACCENT);
            }else if(s instanceof Setting.BooleanSetting b){
                int x=c.right()-16;drawCard(g,x,c.y()+2,16,16,0x30303030,0xB0B8B8B8);
                if(b.getValue()){drawRect(g,x+3,c.y()+10,3,2,COLOR_ACCENT);drawRect(g,x+6,c.y()+7,2,5,COLOR_ACCENT);drawRect(g,x+8,c.y()+5,2,4,COLOR_ACCENT);}
            }else if(s instanceof Setting.ModeSetting m){
                drawCard(g,c.x(),c.y(),c.w(),20,0x30303030,0x80989A9E);
                drawText(g,client.font,"<",c.x()+5,c.y()+6,COLOR_TEXT_SECONDARY,false);
                drawCenteredText(g,client.font,fit(client.font,m.getValue(),c.w()-36),c.x()+c.w()/2,c.y()+6,COLOR_TEXT_PRIMARY,false);
                drawText(g,client.font,">",c.right()-10,c.y()+6,COLOR_TEXT_SECONDARY,false);
            }else if(s instanceof Setting.ColorSetting color){
                drawCard(g,c.x(),c.y(),c.w(),20,0x30303030,0x80989A9E);
                drawRect(g,c.x()+5,c.y()+5,10,10,color.getValue());
                drawText(g,client.font,String.format("#%06X",color.getValue()&0xFFFFFF),c.x()+22,c.y()+6,COLOR_TEXT_PRIMARY,false);
                drawText(g,client.font,">",c.right()-10,c.y()+6,COLOR_TEXT_SECONDARY,false);
            }
        }
        g.disableScissor();
        var key=keyButton();
        String keyName=module.getHotkey().isEmpty()?"Keine":InputConstants.getKey(module.getHotkey()).getDisplayName().getString();
        drawText(g,client.font,fit(client.font,waitingForKey?"Taste drücken · Backspace löscht":"Hotkey: "+keyName,key.w()),key.x()+2,key.y()+4,COLOR_TEXT_SECONDARY,false);
        var reset=resetButton();drawText(g,client.font,"Zurücksetzen",reset.x()+8,reset.y()+4,reset.contains(mx,my)?COLOR_TEXT_PRIMARY:COLOR_TEXT_MUTED,false);
        if(maxScroll()>0){int thumb=Math.max(12,body.h()*body.h()/(body.h()+maxScroll()));drawRect(g,panel.right()-6,body.y()+scroll*(body.h()-thumb)/maxScroll(),2,thumb,COLOR_TEXT_SECONDARY);}
    }
    public boolean mouseClicked(double mx,double my,int button){
        if(button!=InputConstants.MOUSE_BUTTON_LEFT)return false;
        if(close.contains(mx,my))return true;
        if(keyButton().contains(mx,my)){waitingForKey=true;return false;}
        if(resetButton().contains(mx,my)){for(var setting:module.getSettings())resetValue(setting);save();return false;}
        if(!body.contains(mx,my))return false;
        for(Row row:rows()){
            if(row.setting()==null){if(new MenuLayout.Rect(body.x(),y(row),body.w(),24).contains(mx,my)){mouseReleased();if(!collapsed.remove(row.group()))collapsed.add(row.group());scroll=Math.min(scroll,maxScroll());return false;}continue;}
            var c=control(row);Setting<?> s=row.setting();
            if(!c.contains(mx,my))continue;
            if(s instanceof Setting.NumberSetting n){var t=track(row);if(t.contains(mx,my)){dragging=n;dragTrack=t;n.setFromSlider((mx-t.x())/Math.max(1,t.w()-5));}return false;}
            if(s instanceof Setting.BooleanSetting b){if(mx>=c.right()-20)b.toggle();}
            else if(s instanceof Setting.ModeSetting m){int next=(m.getIndex()+(mx<c.x()+20?-1:1)+m.getModes().size())%m.getModes().size();m.setValue(m.getModes().get(next));}
            else if(s instanceof Setting.ColorSetting color)color.cyclePreset();
            save();return false;
        }
        return false;
    }
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event){
        if(!waitingForKey)return false;
        waitingForKey=false;
        if(event.key()!=InputConstants.KEY_ESCAPE){module.setHotkey(event.key()==InputConstants.KEY_BACKSPACE?"":InputConstants.getKey(event).getName());save();}
        return true;
    }
    public void mouseScrolled(double amount){mouseReleased();scroll=Math.clamp(scroll-(int)(amount*22),0,maxScroll());}
    public void mouseDragged(double mx,double my){if(dragging!=null)dragging.setFromSlider((mx-dragTrack.x())/Math.max(1,dragTrack.w()-5));}
    public void mouseReleased(){if(dragging!=null){dragging=null;dragTrack=null;save();}}
    private void save(){VertixCoreMod.getInstance().getConfigManager().saveConfig(VertixCoreMod.getInstance().getModuleManager().getModules());}
}
