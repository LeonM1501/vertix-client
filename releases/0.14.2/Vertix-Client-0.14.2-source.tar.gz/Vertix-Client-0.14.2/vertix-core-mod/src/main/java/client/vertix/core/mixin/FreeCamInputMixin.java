package client.vertix.core.mixin;
import client.vertix.core.modules.qol.FreeCamModule;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardInput.class)
public class FreeCamInputMixin extends ClientInput {
    @Inject(method="tick",at=@At("RETURN"))
    private void vertix$stopPlayer(CallbackInfo ci){if(FreeCamModule.active()){keyPresses=Input.EMPTY;moveVector=Vec2.ZERO;}}
}
