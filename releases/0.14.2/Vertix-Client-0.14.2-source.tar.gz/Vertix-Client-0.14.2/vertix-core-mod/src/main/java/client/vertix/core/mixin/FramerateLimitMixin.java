package client.vertix.core.mixin;

import com.mojang.blaze3d.platform.FramerateLimitTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FramerateLimitTracker.class)
public class FramerateLimitMixin {
    @Inject(method = "getFramerateLimit", at = @At("RETURN"), cancellable = true)
    private void vertix$backgroundLimit(CallbackInfoReturnable<Integer> cir) {
        int limit=cir.getReturnValue();
        var core=client.vertix.core.VertixCoreMod.getInstance();
        if(core!=null&&core.getModuleManager()!=null){var module=core.getModuleManager().getModule("background_fps");if(module instanceof client.vertix.core.modules.qol.BackgroundFpsModule saver&&saver.isEnabled())limit=saver.limit(limit,net.minecraft.client.Minecraft.getInstance().isWindowActive());}
        cir.setReturnValue(limit);
    }
}
