package client.vertix.core.gui;

/** GUI-independent placement rules shared by dragging and regression tests. */
public final class HudPlacement {
    public record Position(int x, int y, int guideX, int guideY) {}
    public static Position place(int x, int y, int w, int h, int screenW, int screenH, boolean snap, int[][] others) {
        int gx = -1, gy = -1, bestX = 5, bestY = 5;
        if (snap) {
            int[][] targets = new int[others.length + 1][];
            targets[0] = new int[]{screenW / 2, screenH / 2, 0, 0};
            System.arraycopy(others, 0, targets, 1, others.length);
            int originalX=x, originalY=y;
            for (int[] r : targets) {
                for (int target : new int[]{r[0],r[0]+r[2]/2,r[0]+r[2]}) {
                    for (int offset : new int[]{0,w/2,w}) {
                        int distance=Math.abs(originalX+offset-target);
                        if (distance < bestX) {bestX=distance;x=target-offset;gx=target;}
                    }
                }
                for (int target : new int[]{r[1],r[1]+r[3]/2,r[1]+r[3]}) {
                    for (int offset : new int[]{0,h/2,h}) {
                        int distance=Math.abs(originalY+offset-target);
                        if (distance < bestY) {bestY=distance;y=target-offset;gy=target;}
                    }
                }
            }
        }
        int cx=Math.max(2,Math.min(Math.max(2,screenW-w-2),x));
        int cy=Math.max(2,Math.min(Math.max(2,screenH-h-2),y));
        return new Position(cx,cy,cx==x?gx:-1,cy==y?gy:-1);
    }
}
