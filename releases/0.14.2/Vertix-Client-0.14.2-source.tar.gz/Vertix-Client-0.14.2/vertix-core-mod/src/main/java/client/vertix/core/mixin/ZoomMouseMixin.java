package client.vertix.core.mixin;
import net.minecraft.client.MouseHandler;
import client.vertix.core.modules.qol.ZoomModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public class ZoomMouseMixin {
    @Inject(method="onScroll",at=@At("HEAD"),cancellable=true)
    private void scroll(long window,double horizontal,double vertical,CallbackInfo ci){var z=ZoomModule.instance();if(z!=null&&z.scroll(vertical))ci.cancel();}
    @ModifyArgs(method="turnPlayer",at=@At(value="INVOKE",target="Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"),require=0)
    private void vertix$turn(org.spongepowered.asm.mixin.injection.invoke.arg.Args args){
        double x=args.get(0),y=args.get(1);
        var f=client.vertix.core.modules.qol.FreeCamModule.instance();
        if(client.vertix.core.modules.qol.FreeCamModule.active()){f.turn(x,y);args.set(0,0d);args.set(1,0d);}
        else {var z=ZoomModule.instance();double scale=z==null?1:z.mouseScale();args.set(0,x*scale);args.set(1,y*scale);}
    }
}
