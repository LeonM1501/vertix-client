package client.vertix.core.mixin;
import client.vertix.core.VertixCoreMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardHandler.class)
public class ModuleKeyMixin {
    @Inject(method="keyPress",at=@At("HEAD"))
    private void vertix$key(long window,int action,KeyEvent event,CallbackInfo ci){
        var core=VertixCoreMod.getInstance();if(core!=null&&action==1)core.onModuleKey(InputConstants.getKey(event).getName());
    }
}
