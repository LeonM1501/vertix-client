package client.vertix.core.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import java.util.LinkedHashMap;
import java.util.Map;

/** Video settings shared by the supported Minecraft versions. */
public final class VideoSettings {
    private VideoSettings() {}
    private static Map<String,OptionInstance<?>> options(Options o) {
        Map<String,OptionInstance<?>> values=new LinkedHashMap<>();
        for(String name:new String[]{"graphicsPreset","graphicsMode"}){
            try{Object option=Options.class.getMethod(name).invoke(o);if(option instanceof OptionInstance<?> instance)values.put(name,instance);}
            catch(NoSuchMethodException ignored){}catch(ReflectiveOperationException e){throw new IllegalStateException("Video option unavailable: "+name,e);}
        }
        values.put("renderDistance",o.renderDistance()); values.put("simulationDistance",o.simulationDistance());
        values.put("entityDistanceScaling",o.entityDistanceScaling()); values.put("maxFps",o.framerateLimit());
        values.put("clouds",o.cloudStatus()); values.put("ao",o.ambientOcclusion());
        values.put("mipmapLevels",o.mipmapLevels()); values.put("biomeBlendRadius",o.biomeBlendRadius());
        values.put("vsync",o.enableVsync()); values.put("entityShadows",o.entityShadows());
        values.put("bobView",o.bobView()); values.put("fov",o.fov());
        values.put("screenEffectScale",o.screenEffectScale()); values.put("fovEffectScale",o.fovEffectScale());
        values.put("darknessEffectScale",o.darknessEffectScale()); values.put("gamma",o.gamma());
        values.put("guiScale",o.guiScale()); values.put("particles",o.particles());
        // Some video options exist only on particular supported game versions.
        for(String name:new String[]{"cloudRange","weatherRadius","cutoutLeaves","vignette","improvedTransparency","chunkSectionFadeInTime","prioritizeChunkUpdates","textureFiltering","maxAnisotropyBit","glintSpeed","glintStrength","damageTiltStrength"}){
            try{Object option=Options.class.getMethod(name).invoke(o);if(option instanceof OptionInstance<?> instance)values.put(name,instance);}
            catch(NoSuchMethodException ignored){}catch(ReflectiveOperationException e){throw new IllegalStateException("Video option unavailable: "+name,e);}
        }
        return values;
    }
    private static <T> void save(JsonObject result,String name,OptionInstance<T> option) {
        option.codec().encodeStart(JsonOps.INSTANCE,option.get()).result().ifPresent(value->result.add(name,value));
    }
    private static <T> void load(JsonElement value,OptionInstance<T> option) {
        option.codec().parse(JsonOps.INSTANCE,value).result().ifPresent(option::set);
    }
    public static JsonObject capture(Options options) {
        JsonObject result=new JsonObject();options(options).forEach((name,option)->save(result,name,option));return result;
    }
    public static void apply(Options options,JsonObject values) {
        options(options).forEach((name,option)->{if(values.has(name))load(values.get(name),option);});
    }
}
