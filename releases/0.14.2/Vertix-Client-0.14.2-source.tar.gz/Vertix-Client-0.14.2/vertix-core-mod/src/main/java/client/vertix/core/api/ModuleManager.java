package client.vertix.core.api;

import client.vertix.core.modules.pvp.*;
import client.vertix.core.modules.qol.*;
import client.vertix.core.modules.visual.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        registerDefaultModules();
    }

    private void registerDefaultModules() {
        // Quality of Life & HUD
        register(new ToggleSprintModule());
        register(new CoordinatesModule());
        register(new FpsModule());
        register(new ArmorHudModule());
        register(new MouseTweaksModule());
        register(new DiscordStreamingModule());
        register(new PerformanceModeModule());
        register(new BackgroundFpsModule());
        register(new ZoomModule());
        register(new FreeCamModule());
        register(new AppleSkinModule());
        register(new SessionModule());

        // PvP & Combat
        register(new KeystrokesModule());
        register(new CpsModule());
        register(new PotionEffectsModule());
        register(new TargetHudModule());
        register(new CrystalOptimizerModule());
        register(new TotemCounterModule());

        // Visual & Customization
        register(new CustomCrosshairModule());
        register(new HudEditorModule());
        register(new ThemeModule());
        register(new GammaModule());
        register(new ClearFluidModule("clear_water","Clear Water"));
        register(new ClearFluidModule("clear_lava","Clear Lava"));
        register(new AncientDebrisModule());
        register(new GlowingGlintsModule());
        register(new LowOverlayModule("low_fire","Low Fire",.4));
        register(new LowOverlayModule("low_totem","Low Totem",.6));
        register(new LowOverlayModule("low_shield","Low Shield",.35));
    }

    public void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public Module getModule(String id) {
        for (Module m : modules) {
            if (m.getId().equalsIgnoreCase(id)) {
                return m;
            }
        }
        return null;
    }

    public boolean isModuleEnabled(String id) {
        Module m = getModule(id);
        return m != null && m.isEnabled();
    }
}
