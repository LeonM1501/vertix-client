package client.vertix.core.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.*;
import client.vertix.core.modules.visual.LowOverlayModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(FirstPersonHandsAndItemsRenderer.class)
public class LowHeldItemMixin {
    @Inject(method="submitArmWithItem",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V",ordinal=0,shift=At.Shift.AFTER))
    private void start(net.minecraft.client.renderer.state.level.PlayerRenderState player,net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState hands,float delta,float pitch,InteractionHand hand,float swing,ItemStack stack,float equip,PoseStack pose,SubmitNodeCollector nodes,int light,CallbackInfo ci){if(stack.is(Items.SHIELD))pose.translate(0,-LowOverlayModule.amount("low_shield"),0);}
}
