# Vertix Core – Forge 1.20.1

This is a Forge build of the same 16 modules, settings and menu as the Fabric
26.2/26.3 builds. `generate_sources.py` adapts shared rendering/input calls to the
Minecraft 1.20.1 API. The generated Java files stay in `build/`; behavior changes
belong in the shared source rather than a second copy of the modules.

Validated development runtime: Minecraft 1.20.1, Forge 47.4.20, Java 17. Other
Minecraft versions and loaders are not declared compatible by changing metadata.

## Build

Use a full Java 17 JDK and Python 3:

```powershell
./build-port.ps1 -JdkHome 'C:/path/to/jdk-17' -PythonExe 'C:/path/to/python.exe'
```

The script builds a reobfuscated distributable and copies it into the launcher's
embedded resources. The ordinary build excludes `src/smoke/java` test code.

## Isolated smoke test

```powershell
$env:JAVA_HOME = 'C:/path/to/jdk-17'
./gradlew.bat runClient -Psmoke '-PpythonExe=C:/path/to/python.exe'
```

This opens and automatically closes a development client. Its game files are
under `run/`; APPDATA is redirected to `run/smoke-appdata`. No personal profile,
account session or world is used. Check `run/smoke-result.txt`, not only Gradle's
exit code: the test checks bootstrap, 16 modules, the keybinding's no-screen
condition, menu/HUD-preview rendering and saving configuration/keybindings.

The smoke test does not replace gameplay testing of each module in a real world.
The distributable must be rebuilt without `-Psmoke` afterwards.

The Gradle wrapper comes from the official Forge MDK and is distributed under
the Apache License 2.0. Vertix code retains the project's GPLv3 license; the
Armor HUD notices and MIT license remain in the shared resources.
