package client.vertix.core.forge;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.StreamingWindow;
import client.vertix.core.gui.*;
import net.minecraft.client.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.nio.file.*;

/** Compiled only with -Psmoke. Test preferences and options live in run/. */
@Mod.EventBusSubscriber(modid="vertix_core",value=Dist.CLIENT)
public final class ForgeSmoke {
    private static int ticks,renders;
    private static boolean opened;
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END)return;
        var mc=Minecraft.getInstance();if(mc.getOverlay()!=null||mc.screen==null)return;
        try{
            var core=VertixCoreMod.getInstance();if(core==null)throw new AssertionError("Core bootstrap missing");
            if(!((Object)mc.getWindow() instanceof StreamingWindow))throw new AssertionError("Window mixin missing");
            for(String id:new String[]{"zoom","fps_mode","crystal_optimizer","low_fire","low_totem","low_shield","gamma","glowing_glints","totem_counter","appleskin","theme"})if(core.getModuleManager().getModule(id)==null)throw new AssertionError("Module missing: "+id);
            if(!opened){
                // The real binding is intentionally inactive over other screens.
                // Exercise its no-screen condition without creating a user world.
                opened=true;mc.screen=null;
                var streaming=core.getModuleManager().getModule("discord_streaming");
                var frameLimit=Minecraft.class.getDeclaredMethod("getFramerateLimit");frameLimit.setAccessible(true);
                mc.options.framerateLimit().set(120);int initial=(int)frameLimit.invoke(mc);
                if(initial!=120)throw new AssertionError("Minecraft FPS setting not applied: "+initial);
                streaming.setEnabled(true);
                if((int)frameLimit.invoke(mc)!=120)throw new AssertionError("Streaming changed FPS limit");
                mc.options.framerateLimit().set(200);
                if((int)frameLimit.invoke(mc)!=200)throw new AssertionError("Streaming ignored changed FPS limit");
                streaming.setEnabled(false);
                if((int)frameLimit.invoke(mc)!=200)throw new AssertionError("Disabling streaming changed FPS limit");
                var apple=(client.vertix.core.modules.qol.AppleSkinModule)core.getModuleManager().getModule("appleskin");
                var appleValue=Class.forName("squeek.appleskin.ModConfig").getField("SHOW_FOOD_VALUES_OVERLAY").get(null);
                apple.setEnabled(false);apple.sync();
                if((boolean)appleValue.getClass().getMethod("get").invoke(appleValue))throw new AssertionError("AppleSkin did not turn off");
                apple.setEnabled(true);apple.sync();
                if(!(boolean)appleValue.getClass().getMethod("get").invoke(appleValue))throw new AssertionError("AppleSkin did not turn on");
                var forward=mc.options.keyUp;var previous=forward.saveString();
                forward.setKey(com.mojang.blaze3d.platform.InputConstants.getKey("key.keyboard.i"));
                core.getConfigManager().saveProfile("Forge Test",core.getModuleManager().getModules());
                forward.setKey(com.mojang.blaze3d.platform.InputConstants.getKey("key.keyboard.k"));
                core.getConfigManager().loadProfile("Forge Test",core.getModuleManager().getModules());
                if(!forward.saveString().equals("key.keyboard.i"))throw new AssertionError("Profile did not restore controls");
                forward.setKey(com.mojang.blaze3d.platform.InputConstants.getKey(previous));KeyMapping.resetMapping();
                var openKey=core.getKeyOpenMenu();String previousOpen=openKey.saveString();
                var y=com.mojang.blaze3d.platform.InputConstants.getKey("key.keyboard.y");openKey.setKey(y);KeyMapping.resetMapping();
                KeyMapping.click(y);core.onTick(mc);
                if(!(mc.screen instanceof VertixMenuScreen))throw new AssertionError("Remapped key did not open menu");
                mc.screen.keyPressed(y.getValue(),0,0);
                if(mc.screen instanceof VertixMenuScreen)throw new AssertionError("Remapped key did not close menu");
                openKey.setKey(com.mojang.blaze3d.platform.InputConstants.getKey(previousOpen));KeyMapping.resetMapping();mc.screen=null;
                KeyMapping.click(core.getKeyOpenMenu().getDefaultKey());core.onTick(mc);
                if(!(mc.screen instanceof VertixMenuScreen))throw new AssertionError("RSHIFT binding did not open menu");return;
            }
            if(++ticks==2&&!(mc.screen instanceof VertixMenuScreen))throw new AssertionError("RSHIFT key did not open Vertix menu");
            if(ticks==10)mc.setScreen(new HudEditorScreen(mc.screen));
            if(ticks>=30){
                if(renders<5)throw new AssertionError("HUD/menu not rendered");
                core.getConfigManager().saveConfig(core.getModuleManager().getModules());mc.options.save();
                if(!Files.isRegularFile(core.getConfigManager().getGlobalConfigFile().toPath()))throw new AssertionError("Config save failed");
                String options=Files.readString(mc.gameDirectory.toPath().resolve("options.txt"));
                if(!options.contains("key_key.vertix.open_menu:"))throw new AssertionError("Keybind not persisted");
                Files.writeString(Path.of("smoke-result.txt"),"PASS: Forge 1.20.1; 25 modules; AppleSkin toggle; profile controls; remapped menu key; HUD placeholders; mixins; settings save");mc.stop();
            }
        }catch(Throwable failure){try{Files.writeString(Path.of("smoke-result.txt"),"FAIL: "+failure);}catch(Exception ignored){}failure.printStackTrace();mc.stop();}
    }
    @SubscribeEvent public static void render(ScreenEvent.Render.Post e){if(e.getScreen() instanceof VertixMenuScreen||e.getScreen() instanceof HudEditorScreen)renders++;}
}
