package client.vertix.core.forge.mixin;
import client.vertix.core.modules.qol.PerformanceModeModule;
import net.minecraft.client.Options;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Options.class)
public class OptionsMixin {
    @Inject(method="save",at=@At("HEAD")) private void vertix$original(CallbackInfo ci){var mode=PerformanceModeModule.instance();if(mode!=null)mode.beforeOptionsSave();}
    @Inject(method="save",at=@At("RETURN")) private void vertix$resume(CallbackInfo ci){var mode=PerformanceModeModule.instance();if(mode!=null)mode.afterOptionsSave();}
}
