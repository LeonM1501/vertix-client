package client.vertix.core.forge.mixin;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.modules.qol.*;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method="startAttack",at=@At("HEAD"),cancellable=true)
    private void vertix$noAttack(CallbackInfoReturnable<Boolean> ci){if(FreeCamModule.active())ci.setReturnValue(false);}
    @Inject(method="startUseItem",at=@At("HEAD"),cancellable=true)
    private void vertix$noUse(CallbackInfo ci){if(FreeCamModule.active())ci.cancel();}
    @Inject(method="continueAttack",at=@At("HEAD"),cancellable=true)
    private void vertix$noContinue(boolean attacking,CallbackInfo ci){if(FreeCamModule.active())ci.cancel();}
    @Inject(method="runTick",at=@At("HEAD"))
    private void vertix$frame(boolean tick,CallbackInfo ci){var core=VertixCoreMod.getInstance();if(core!=null)core.onFrame((Minecraft)(Object)this);}
    @Inject(method="close",at=@At("HEAD"))
    private void vertix$close(CallbackInfo ci){var mode=PerformanceModeModule.instance();if(mode!=null)mode.shutdown();var zoom=ZoomModule.instance();if(zoom!=null)zoom.restore();}
    @Inject(method="getFramerateLimit",at=@At("RETURN"),cancellable=true)
    private void vertix$limit(CallbackInfoReturnable<Integer> cir){
        int limit=cir.getReturnValue();
        var core=VertixCoreMod.getInstance();if(core!=null){var module=core.getModuleManager().getModule("background_fps");if(module instanceof BackgroundFpsModule saver&&saver.isEnabled())limit=saver.limit(limit,Minecraft.getInstance().isWindowActive());}
        cir.setReturnValue(limit);
    }
}
