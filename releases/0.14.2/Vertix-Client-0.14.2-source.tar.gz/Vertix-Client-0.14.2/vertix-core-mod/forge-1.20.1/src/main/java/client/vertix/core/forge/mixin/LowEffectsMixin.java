package client.vertix.core.forge.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import client.vertix.core.modules.visual.LowOverlayModule;
import client.vertix.core.modules.visual.ClearFluidModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ScreenEffectRenderer.class)
public class LowEffectsMixin {
    @Inject(method="renderWater",at=@At("HEAD"),cancellable=true,require=0)
    private static void vertix$clearWater(Minecraft mc,PoseStack pose,CallbackInfo ci){if(ClearFluidModule.active("clear_water"))ci.cancel();}
    @Inject(method="renderFire",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V",shift=At.Shift.AFTER))
    private static void start(Minecraft mc,PoseStack pose,CallbackInfo ci){pose.translate(0,-LowOverlayModule.amount("low_fire"),0);}
}
