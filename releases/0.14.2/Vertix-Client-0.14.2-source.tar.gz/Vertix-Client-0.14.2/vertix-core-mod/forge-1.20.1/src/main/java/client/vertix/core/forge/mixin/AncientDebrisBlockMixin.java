package client.vertix.core.forge.mixin;
import client.vertix.core.modules.visual.AncientDebrisModule;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientLevel.class)
public class AncientDebrisBlockMixin {
    @Inject(method="setBlock",at=@At("RETURN"),require=0)
    private void vertix$blockChanged(BlockPos pos,BlockState state,int flags,int recursion,CallbackInfoReturnable<Boolean> ci){if(ci.getReturnValue())AncientDebrisModule.blockChanged(pos,state);}
    @Inject(method="setServerVerifiedBlockState",at=@At("RETURN"),require=0)
    private void vertix$serverBlockChanged(BlockPos pos,BlockState state,int flags,CallbackInfo ci){AncientDebrisModule.blockChanged(pos,((ClientLevel)(Object)this).getBlockState(pos));}
}
