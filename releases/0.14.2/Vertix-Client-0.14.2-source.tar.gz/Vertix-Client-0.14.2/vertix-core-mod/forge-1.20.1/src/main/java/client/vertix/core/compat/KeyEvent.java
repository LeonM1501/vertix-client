package client.vertix.core.compat;
public record KeyEvent(int key,int scancode,int modifiers) {}
