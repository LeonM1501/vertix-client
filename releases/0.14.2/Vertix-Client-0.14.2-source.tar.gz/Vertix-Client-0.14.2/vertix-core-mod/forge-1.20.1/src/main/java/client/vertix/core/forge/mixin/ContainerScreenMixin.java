package client.vertix.core.forge.mixin;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.modules.qol.MouseTweaksModule;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(AbstractContainerScreen.class)
public abstract class ContainerScreenMixin {
    @Shadow protected Slot hoveredSlot;
    @Shadow @Final protected AbstractContainerMenu menu;
    @Shadow protected abstract void slotClicked(Slot slot,int index,int button,ClickType action);
    @Unique private Slot vertix$lastSlot;
    @Unique private MouseTweaksModule vertix$module(){var core=VertixCoreMod.getInstance();if(core==null)return null;var module=(MouseTweaksModule)core.getModuleManager().getModule("mouse_tweaks");return module!=null&&module.isEnabled()?module:null;}
    @Inject(method="mouseDragged",at=@At("HEAD"))
    private void vertix$drag(double x,double y,int button,double dx,double dy,CallbackInfoReturnable<Boolean> cir){
        var module=vertix$module();if(module==null||hoveredSlot==null||hoveredSlot==vertix$lastSlot)return;
        if(module.isShiftDrag()&&button==0&&Screen.hasShiftDown()&&hoveredSlot.hasItem()){vertix$lastSlot=hoveredSlot;slotClicked(hoveredSlot,hoveredSlot.index,0,ClickType.QUICK_MOVE);}
        else if(module.isRmbDrag()&&button==1&&!menu.getCarried().isEmpty()){vertix$lastSlot=hoveredSlot;slotClicked(hoveredSlot,hoveredSlot.index,1,ClickType.PICKUP);}
    }
    @Inject(method="mouseReleased",at=@At("HEAD")) private void vertix$release(double x,double y,int button,CallbackInfoReturnable<Boolean> cir){vertix$lastSlot=null;}
}
