package client.vertix.core.forge.mixin;
import client.vertix.core.modules.visual.ClearFluidModule;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.world.level.material.FogType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(FogRenderer.class)
public class ClearFluidFogMixin {
    @Inject(method="setupFog",at=@At("RETURN"),require=0)
    private static void vertix$clear(Camera camera,FogRenderer.FogMode mode,float distance,boolean thick,float partial,CallbackInfo ci){
        var type=camera.getFluidInCamera();
        if((type==FogType.WATER&&ClearFluidModule.active("clear_water"))||(type==FogType.LAVA&&ClearFluidModule.active("clear_lava"))){RenderSystem.setShaderFogStart(distance*.75f);RenderSystem.setShaderFogEnd(distance);}
    }
}
