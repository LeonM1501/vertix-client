package client.vertix.core.compat;
public record DeltaTracker(float partialTick) {}
