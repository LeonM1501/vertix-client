package client.vertix.core.forge.mixin;
import client.vertix.core.modules.qol.FreeCamModule;
import net.minecraft.client.Camera;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Camera.class)
public abstract class FreeCamCameraMixin {
    @Shadow protected abstract void setPosition(Vec3 position);
    @Shadow protected abstract void setRotation(float yaw,float pitch);
    @Inject(method="setup",at=@At("RETURN"))
    private void vertix$camera(BlockGetter level,Entity entity,boolean detached,boolean reversed,float partial,CallbackInfo ci){var f=FreeCamModule.instance();if(FreeCamModule.active()){setPosition(f.position());setRotation(f.yaw(),f.pitch());}}
}
