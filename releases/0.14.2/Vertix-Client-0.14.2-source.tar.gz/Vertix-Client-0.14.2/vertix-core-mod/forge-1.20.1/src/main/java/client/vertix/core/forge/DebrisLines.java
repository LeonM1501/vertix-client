package client.vertix.core.forge;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;

public final class DebrisLines extends RenderType {
    private DebrisLines(){super("vertix_unused",DefaultVertexFormat.POSITION_COLOR_NORMAL,VertexFormat.Mode.LINES,256,false,false,()->{},()->{});}
    public static final RenderType TYPE=RenderType.create("vertix_debris_lines",DefaultVertexFormat.POSITION_COLOR_NORMAL,VertexFormat.Mode.LINES,256,false,false,
        CompositeState.builder().setShaderState(RENDERTYPE_LINES_SHADER).setDepthTestState(NO_DEPTH_TEST).setTransparencyState(TRANSLUCENT_TRANSPARENCY).setWriteMaskState(COLOR_WRITE).setLineState(DEFAULT_LINE).createCompositeState(false));
}
