package client.vertix.core.forge.mixin;
import client.vertix.core.modules.qol.FreeCamModule;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(KeyboardInput.class)
public class FreeCamInputMixin extends Input {
    @Inject(method="tick",at=@At("RETURN"))
    private void vertix$stopPlayer(boolean slowdown,float scale,CallbackInfo ci){if(FreeCamModule.active()){leftImpulse=0;forwardImpulse=0;jumping=false;shiftKeyDown=false;}}
}
