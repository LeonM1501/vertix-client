package client.vertix.core.compat;
public final class Numbers {
    public static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    public static long clamp(long v,long min,long max){return Math.max(min,Math.min(max,v));}
    public static double clamp(double v,double min,double max){return Math.max(min,Math.min(max,v));}
}
