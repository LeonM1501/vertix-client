package client.vertix.core.compat;
public record CharacterEvent(char character,int modifiers) {public String codepointAsString(){return String.valueOf(character);}}
