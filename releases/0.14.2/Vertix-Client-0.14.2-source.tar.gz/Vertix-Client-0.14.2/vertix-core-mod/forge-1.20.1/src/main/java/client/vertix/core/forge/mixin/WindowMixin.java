package client.vertix.core.forge.mixin;

import client.vertix.core.api.StreamingWindow;
import com.mojang.blaze3d.platform.Monitor;
import com.mojang.blaze3d.platform.ScreenManager;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.platform.WindowEventHandler;
import net.minecraft.Util;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Window.class)
public abstract class WindowMixin implements StreamingWindow {
    @Shadow @Final private long window;
    @Shadow @Final private ScreenManager screenManager;
    @Shadow @Final private WindowEventHandler eventHandler;
    @Shadow private boolean fullscreen;
    @Shadow private int x;
    @Shadow private int y;
    @Shadow private int width;
    @Shadow private int height;
    @Shadow private int windowedX;
    @Shadow private int windowedY;
    @Shadow private int windowedWidth;
    @Shadow private int windowedHeight;
    @Shadow protected abstract void setMode();
    @Shadow protected abstract void refreshFramebufferSize();
    @Unique private boolean vertix$streaming;
    @Unique private boolean vertix$borderless;

    @Override
    public void vertix$setStreaming(boolean enabled) {
        if (Util.getPlatform() != Util.OS.WINDOWS || enabled == vertix$streaming) return;
        vertix$streaming = enabled;
        if (fullscreen) {
            setMode();
            refreshFramebufferSize();
            eventHandler.resizeDisplay();
        }
    }

    @Inject(method = "setMode", at = @At("HEAD"), cancellable = true)
    private void vertix$borderless(CallbackInfo ci) {
        if (vertix$streaming && fullscreen) {
            Monitor monitor = screenManager.findBestMonitor((Window) (Object) this);
            GLFWVidMode mode = monitor == null ? null : GLFW.glfwGetVideoMode(monitor.getMonitor());
            if (mode != null) {
                if (!vertix$borderless && GLFW.glfwGetWindowMonitor(window) == 0) {
                    windowedX = x;
                    windowedY = y;
                    windowedWidth = width;
                    windowedHeight = height;
                }
                vertix$borderless = true;
                x = monitor.getX();
                y = monitor.getY();
                width = mode.width();
                height = mode.height();
                GLFW.glfwSetWindowAttrib(window, GLFW.GLFW_DECORATED, GLFW.GLFW_FALSE);
                // One extra row prevents Windows treating this as exclusive fullscreen.
                GLFW.glfwSetWindowMonitor(window, 0, x, y, width, height + 1, GLFW.GLFW_DONT_CARE);
                ci.cancel();
                return;
            }
        }
        if (vertix$borderless) {
            vertix$borderless = false;
            GLFW.glfwSetWindowAttrib(window, GLFW.GLFW_DECORATED, GLFW.GLFW_TRUE);
            // Vanilla only saves window bounds when leaving a monitor-attached window.
            if (fullscreen) {
                boolean requested = fullscreen;
                fullscreen = false;
                setMode();
                fullscreen = requested;
            }
        }
    }

    @Inject(method = "isFullscreen", at = @At("HEAD"), cancellable = true)
    private void vertix$softScreen(CallbackInfoReturnable<Boolean> cir) {
        if (vertix$borderless) cir.setReturnValue(true);
    }
}
