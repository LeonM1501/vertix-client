package client.vertix.core.forge;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.compat.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod("vertix_core")
public final class VertixForge {
    @Mod.EventBusSubscriber(modid="vertix_core",value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        @SubscribeEvent public static void registerKeys(RegisterKeyMappingsEvent e){
            var core=new VertixCoreMod();core.onInitializeClient();
            e.register(core.getKeyOpenMenu());e.register(core.getKeyZoom());e.register(core.getKeyCopy());
        }
    }
    @Mod.EventBusSubscriber(modid="vertix_core",value=Dist.CLIENT)
    public static final class Events {
        @SubscribeEvent public static void debris(net.minecraftforge.client.event.RenderLevelStageEvent e){
            if(e.getStage()!=net.minecraftforge.client.event.RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
            var core=VertixCoreMod.getInstance();var mc=Minecraft.getInstance();if(core==null||mc.player==null)return;
            var module=(client.vertix.core.modules.visual.AncientDebrisModule)core.getModuleManager().getModule("ancient_debris_notifier");
            if(!module.isEnabled()||module.visible().isEmpty())return;
            var camera=e.getCamera().getPosition();var pose=e.getPoseStack();var buffers=mc.renderBuffers().bufferSource();var lines=buffers.getBuffer(DebrisLines.TYPE);
            var forward=e.getCamera().getLookVector();var start=camera.add(forward.x()*.5,forward.y()*.5,forward.z()*.5);pose.pushPose();pose.translate(-camera.x,-camera.y,-camera.z);
            for(var pos:module.visible()){
                net.minecraft.client.renderer.LevelRenderer.renderLineBox(pose,lines,pos.getX(),pos.getY(),pos.getZ(),pos.getX()+1,pos.getY()+1,pos.getZ()+1,1f,.67f,.2f,1f);
                var end=net.minecraft.world.phys.Vec3.atCenterOf(pos);var direction=end.subtract(start).normalize();var matrix=pose.last();
                lines.vertex(matrix.pose(),(float)start.x,(float)start.y,(float)start.z).color(1f,.67f,.2f,1f).normal(matrix.normal(),(float)direction.x,(float)direction.y,(float)direction.z).endVertex();
                lines.vertex(matrix.pose(),(float)end.x,(float)end.y,(float)end.z).color(1f,.67f,.2f,1f).normal(matrix.normal(),(float)direction.x,(float)direction.y,(float)direction.z).endVertex();
            }
            buffers.endBatch(DebrisLines.TYPE);pose.popPose();
        }
        @SubscribeEvent public static void keys(net.minecraftforge.client.event.InputEvent.Key e){
            var core=VertixCoreMod.getInstance();
            if(core!=null&&e.getAction()==1)core.onModuleKey(com.mojang.blaze3d.platform.InputConstants.getKey(e.getKey(),e.getScanCode()).getName());
        }
        @SubscribeEvent public static void scroll(ScreenEvent.MouseScrolled.Pre e){
            var core=VertixCoreMod.getInstance();var mc=Minecraft.getInstance();
            if(core==null||mc.player==null||mc.gameMode==null||!(e.getScreen() instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?> screen))return;
            var module=(client.vertix.core.modules.qol.MouseTweaksModule)core.getModuleManager().getModule("mouse_tweaks");var slot=screen.getSlotUnderMouse();
            if(module!=null&&module.isEnabled()&&module.isScrollTweak()&&e.getScrollDelta()>0&&slot!=null&&slot.hasItem()){
                mc.gameMode.handleInventoryMouseClick(screen.getMenu().containerId,slot.index,0,net.minecraft.world.inventory.ClickType.QUICK_MOVE,mc.player);e.setCanceled(true);
            }
        }
        @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e){var core=VertixCoreMod.getInstance();if(e.phase==TickEvent.Phase.END&&core!=null)core.onTick(Minecraft.getInstance());}
        @SubscribeEvent public static void hud(RenderGuiEvent.Post e){var core=VertixCoreMod.getInstance();if(core!=null)core.onRenderHud(e.getGuiGraphics(),new DeltaTracker(e.getPartialTick()));}
        @SubscribeEvent public static void effects(RenderGuiOverlayEvent.Pre e){var core=VertixCoreMod.getInstance();if(core!=null&&e.getOverlay().id().equals(VanillaGuiOverlay.POTION_ICONS.id())&&core.getModuleManager().isModuleEnabled("potion_effects"))e.setCanceled(true);}
        @SubscribeEvent public static void crosshair(RenderGuiOverlayEvent.Pre e){var core=VertixCoreMod.getInstance();if(core!=null&&e.getOverlay().id().equals(VanillaGuiOverlay.CROSSHAIR.id())&&core.getModuleManager().isModuleEnabled("crosshair"))e.setCanceled(true);}
    }
}
