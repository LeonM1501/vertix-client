package client.vertix.core.forge.mixin;
import client.vertix.core.modules.visual.AncientDebrisModule;
import net.minecraft.client.multiplayer.ClientChunkCache;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ClientChunkCache.class)
public class AncientDebrisChunkMixin {
    @Inject(method="replaceWithPacketData",at=@At("RETURN"),require=0)
    private void vertix$chunkLoaded(CallbackInfoReturnable<LevelChunk> ci){AncientDebrisModule.chunkLoaded(ci.getReturnValue());}
}
