package client.vertix.core.forge.mixin;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.world.level.dimension.DimensionType;
import client.vertix.core.modules.visual.GammaModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(LightTexture.class)
public class GammaMixin {
    @Inject(method="getBrightness",at=@At("RETURN"),cancellable=true)
    private static void brightness(DimensionType dimension,int light,CallbackInfoReturnable<Float> ci){ci.setReturnValue(Math.max(ci.getReturnValue(),GammaModule.brightness()));}
}
