package client.vertix.core.forge.mixin;
import net.minecraft.client.renderer.entity.EndCrystalRenderer;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.core.BlockPos;
import client.vertix.core.performance.RenderOptimizer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(EndCrystalRenderer.class)
public class CrystalRenderMixin {
    @Redirect(method="render(Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;getBeamTarget()Lnet/minecraft/core/BlockPos;"))
    private BlockPos beam(EndCrystal crystal){var m=RenderOptimizer.module("crystal_optimizer");return RenderOptimizer.enabled(m)&&RenderOptimizer.flag(m,"beams")?null:crystal.getBeamTarget();}
    @Redirect(method="render(Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;showsBottom()Z"))
    private boolean base(EndCrystal crystal){var m=RenderOptimizer.module("crystal_optimizer");return !(RenderOptimizer.enabled(m)&&RenderOptimizer.flag(m,"base"))&&crystal.showsBottom();}
}
