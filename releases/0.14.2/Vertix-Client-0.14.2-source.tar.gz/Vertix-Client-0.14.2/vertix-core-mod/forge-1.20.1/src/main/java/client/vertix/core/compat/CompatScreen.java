package client.vertix.core.compat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Bridges old GLFW callbacks to the shared menu's value-based input handlers. */
public abstract class CompatScreen extends Screen {
    protected CompatScreen(Component title){super(title);}
    @Override public final void render(GuiGraphics g,int x,int y,float partial){extractRenderState(g,x,y,partial);}
    public void extractRenderState(GuiGraphics g,int x,int y,float partial){extractBackground(g,x,y,partial);super.render(g,x,y,partial);}
    public void extractBackground(GuiGraphics g,int x,int y,float partial){super.renderBackground(g);}
    @Override public final boolean mouseClicked(double x,double y,int button){return mouseClicked(new MouseButtonEvent(x,y,button),false);}
    public boolean mouseClicked(MouseButtonEvent e,boolean twice){return super.mouseClicked(e.x(),e.y(),e.button());}
    @Override public final boolean mouseDragged(double x,double y,int button,double dx,double dy){return mouseDragged(new MouseButtonEvent(x,y,button),dx,dy);}
    public boolean mouseDragged(MouseButtonEvent e,double dx,double dy){return super.mouseDragged(e.x(),e.y(),e.button(),dx,dy);}
    @Override public final boolean mouseReleased(double x,double y,int button){return mouseReleased(new MouseButtonEvent(x,y,button));}
    public boolean mouseReleased(MouseButtonEvent e){return super.mouseReleased(e.x(),e.y(),e.button());}
    @Override public final boolean mouseScrolled(double x,double y,double amount){return mouseScrolled(x,y,0,amount);}
    public boolean mouseScrolled(double x,double y,double horizontal,double vertical){return super.mouseScrolled(x,y,vertical);}
    @Override public final boolean keyPressed(int key,int scancode,int modifiers){return keyPressed(new KeyEvent(key,scancode,modifiers));}
    public boolean keyPressed(KeyEvent e){return super.keyPressed(e.key(),e.scancode(),e.modifiers());}
    @Override public final boolean charTyped(char c,int modifiers){return charTyped(new CharacterEvent(c,modifiers));}
    public boolean charTyped(CharacterEvent e){return super.charTyped(e.character(),e.modifiers());}
}
