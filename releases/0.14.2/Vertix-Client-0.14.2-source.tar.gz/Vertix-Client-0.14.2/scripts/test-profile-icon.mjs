import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import {pathToFileURL} from 'node:url';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
fs.mkdirSync('artifacts',{recursive:true});
const output=ts.transpileModule(fs.readFileSync('src/ProfileIcon.tsx','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}}).outputText;
fs.writeFileSync('artifacts/profile-icon-test.mjs',output);
const {profileIcon,ProfileIcon}=await import(pathToFileURL(process.cwd()+'/artifacts/profile-icon-test.mjs'));
const icon={symbol:'pickaxe',background:'#343b49',image:null};
// Rust serializes Profile.extra with serde(flatten), so persisted icons are root fields.
const profile={id:'test',name:'Survival',vertix_icon:icon};
assert.deepEqual(profileIcon(profile),icon);
assert.match(renderToStaticMarkup(React.createElement(ProfileIcon,{profile})),/lucide-pickaxe/);
assert.deepEqual(profileIcon({extra:{vertix_icon:icon}}),icon);
assert.equal(profileIcon({}).symbol,'box');
console.log('Instance icons: flattened persistence shape, legacy shape, SVG rendering and fallback passed.');

const portraits=JSON.parse(fs.readFileSync('src/ProfileIcon.tsx','utf8').match(/const blockPortraits = (\[.*\]);/)[1]);
assert.equal(portraits.length,24);assert.equal(new Set(portraits.map(p=>p.id)).size,24);
for(const block of portraits){const bytes=Buffer.from(block.image.split(',')[1],'base64');assert.equal(bytes.subarray(1,4).toString(),'PNG');assert.equal(bytes.readUInt32BE(16),256);assert.equal(bytes.readUInt32BE(20),256);assert.equal(bytes[25],6);assert.ok(block.image.length<700000);const config={symbol:'box',background:'#e5ac42',image:block.image};assert.deepEqual(profileIcon(JSON.parse(JSON.stringify({vertix_icon:config}))),config);assert.match(renderToStaticMarkup(React.createElement(ProfileIcon,{value:config})),/data:image\/png;base64/);}
console.log('24 portable RGBA block portraits: dimensions, validated payload size, persisted profile shape and rendered PNG passed.');
