"""Regenerate the embedded portraits from a locally installed Minecraft client JAR.

Usage: python render-block-portraits.py path/to/26.3.jar
Requires Pillow and numpy. Minecraft textures belong to Mojang / Microsoft.
Only composed block portraits are included; the client JAR is never distributed.
"""
import base64
import io
import json
import pathlib
import re
import sys
import zipfile

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter

path = pathlib.Path(__file__).resolve().parents[1] / "src/ProfileIcon.tsx"
source = path.read_text(encoding="utf-8")
match = re.search(r"const blockPortraits = (\[.*\]);", source)
portraits = json.loads(match.group(1))
textures = [
    ("grass_block_top", "grass_block_side"),
    ("crafting_table_top", "crafting_table_front"),
    ("furnace_top", "furnace_front"), ("oak_planks", "bookshelf"),
    ("tnt_top", "tnt_side"), ("stone", "stone"),
    ("diamond_block", "diamond_block"), ("emerald_block", "emerald_block"),
    ("gold_block", "gold_block"), ("redstone_block", "redstone_block"),
    ("oak_log_top", "oak_log"), ("birch_log_top", "birch_log"),
    ("hay_block_top", "hay_block_side"), ("pumpkin_top", "carved_pumpkin"),
    ("obsidian", "obsidian"), ("bricks", "bricks"),
    ("packed_ice", "packed_ice"), ("slime_block", "slime_block"),
    ("sea_lantern", "sea_lantern"), ("amethyst_block", "amethyst_block"),
    ("soul_sand", "soul_sand"), ("moss_block", "moss_block"),
    ("end_stone", "end_stone"), ("copper_block", "copper_block"),
]
assert len(portraits) == len(textures)
with zipfile.ZipFile(sys.argv[1]) as jar:
    def texture(name):
        data = jar.read(f"assets/minecraft/textures/block/{name}.png")
        return Image.open(io.BytesIO(data)).convert("RGBA").crop((0, 0, 16, 16)).resize((128, 128), Image.Resampling.NEAREST)

    for portrait, (top_name, side_name) in zip(portraits, textures):
        top, side = texture(top_name), texture(side_name)
        if portrait["id"] == "grass":
            top = Image.blend(ImageEnhance.Color(top).enhance(0), Image.new("RGBA", top.size, (100, 155, 58, 255)), .7)
            overlay = texture("grass_block_side_overlay")
            green = Image.new("RGBA", overlay.size, (100, 155, 58, 0))
            green.putalpha(overlay.getchannel("A"))
            side.alpha_composite(green)
        canvas = Image.new("RGBA", (256, 256))
        shadow = Image.new("RGBA", canvas.size)
        ImageDraw.Draw(shadow).ellipse((35, 192, 230, 235), fill=(0, 0, 0, 95))
        canvas.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(9)))

        def face(image, points, brightness):
            p0, p1, p2 = points
            matrix = np.array([[(p1[0]-p0[0])/128, (p2[0]-p0[0])/128], [(p1[1]-p0[1])/128, (p2[1]-p0[1])/128]])
            inverse = np.linalg.inv(matrix)
            offset = -inverse @ np.array(p0)
            coefficients = (inverse[0, 0], inverse[0, 1], offset[0], inverse[1, 0], inverse[1, 1], offset[1])
            canvas.alpha_composite(ImageEnhance.Brightness(image).enhance(brightness).transform((256, 256), Image.Transform.AFFINE, coefficients, Image.Resampling.NEAREST))

        face(top, [(128, 25), (224, 73), (32, 73)], 1.12)
        face(side, [(32, 73), (128, 121), (32, 183)], .86)
        face(side, [(128, 121), (224, 73), (128, 231)], .65)
        output = io.BytesIO()
        canvas.save(output, format="PNG", optimize=True)
        portrait["image"] = "data:image/png;base64," + base64.b64encode(output.getvalue()).decode()
replacement = json.dumps(portraits, ensure_ascii=False, separators=(",", ":"))
source = source[:match.start(1)] + replacement + source[match.end(1):]
path.write_text(source, encoding="utf-8", newline="\n")
print(f"Regenerated {len(portraits)} block portraits.")
