//! Manual preflight against saved public API responses; no credentials or network access.
//! cargo run --example catalog_live -- <path to catalog-fixture.json>
use serde_json::{Value,json};
use vertix_content_regressions::{catalog_identity,catalog_versions};
fn main() {
    let path=std::env::args().nth(1).expect("path to saved live API fixture");
    let text=std::fs::read_to_string(path).unwrap();
    let data:Value=serde_json::from_str(text.trim_start_matches('\u{feff}')).unwrap();
    let mr=&data["modrinth"];let cf=&data["curseforge"];
    assert!(catalog_identity::same_repository(mr,cf),"live source identities differ");
    let mut hit=mr.clone();hit["project_id"]=mr["id"].clone();
    let mut hits=vec![hit];
    catalog_identity::merge(&mut hits,cf,Some(mr["id"].as_str().unwrap().into()));
    assert_eq!(hits.len(),1);assert_eq!(hits[0]["provider"],"both");
    let mut versions=data["mrVersions"].as_array().unwrap().clone();
    for v in &mut versions {v["_provider"]="modrinth".into();}
    // Feed the comparator the public catalog contract using actual API filenames.
    for file in data["cfFiles"].as_array().unwrap() {
        versions.push(json!({"id":file["id"].to_string(),"version_number":file["fileName"],"game_versions":["1.21.1"],
            "version_type":if file["releaseType"]==1 {"release"} else if file["releaseType"]==2 {"beta"} else {"alpha"},
            "date_published":file["fileDate"],"_provider":"curseforge"}));
    }
    versions.sort_by(catalog_versions::compare);
    let first=&versions[0];
    let matching_cf=data["cfFiles"].as_array().unwrap().iter().any(|f| f["hashes"].as_array().unwrap().iter().any(|h|
        h["algo"]==1 && first["files"].as_array().is_some_and(|files| files.iter().any(|mf| mf["hashes"]["sha1"]==h["value"]))));
    assert!(matching_cf,"expected a shared top release in the validation fixture");
    assert_eq!(first["_provider"],"modrinth","equal top release must prefer Modrinth");
    println!("Live fixture: Sodium merged once; {} versions ranked; top {} from Modrinth with matching CurseForge SHA1.",versions.len(),first["version_number"]);
}
