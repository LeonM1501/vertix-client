param(
    [string]$JdkHome = 'C:/Program Files/Java/jdk-26.0.2',
    [string]$MetadataRoot = "$PSScriptRoot/../artifacts/core-meta",
    [string]$Version = '26.2',
    [string]$AssetsRoot = "$env:APPDATA/vertix/VertixClient/meta/assets",
    [string]$JavaHome = $JdkHome,
    [string]$TestClass = 'StreamingRuntimeTest',
    [string]$ReuseTestRoot = '',
    [switch]$VanillaOnly,
    [switch]$WithExistingDependencies,
    [string[]]$ExtraJavaArgs = @(),
    [int]$TimeoutMinutes = 4
)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
$runTag = [guid]::NewGuid().ToString('N')
$testRoot = Join-Path $root "artifacts/verification/0.8.0/streaming-$Version-$runTag"
if($ReuseTestRoot){
    $allowed=[IO.Path]::GetFullPath((Join-Path $root 'artifacts/verification'))+[IO.Path]::DirectorySeparatorChar
    $resolved=[IO.Path]::GetFullPath($ReuseTestRoot)
    if(!$resolved.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)){throw 'ReuseTestRoot must be inside artifacts/verification'}
    $testRoot=$resolved
}
New-Item "$testRoot/classes","$testRoot/game/mods","$testRoot/appdata","$testRoot/natives" -ItemType Directory -Force | Out-Null
$metadataFile = Join-Path $MetadataRoot "versions/$Version/version.json"
if (Test-Path $metadataFile) {
    $meta = Get-Content $metadataFile -Raw | ConvertFrom-Json
} else {
    $manifest = Invoke-RestMethod https://piston-meta.mojang.com/mc/game/version_manifest_v2.json -TimeoutSec 30
    $meta = Invoke-RestMethod ($manifest.versions | Where-Object id -eq $Version).url -TimeoutSec 30
    New-Item (Split-Path $metadataFile) -ItemType Directory -Force | Out-Null
    $meta | ConvertTo-Json -Depth 30 | Set-Content $metadataFile
}
$libraries = @()
foreach ($lib in $meta.libraries) {
    $a = $lib.downloads.artifact
    if (!$a -or $lib.name -match 'natives-(linux|macos|windows-arm64)') { continue }
    $path = Join-Path "$MetadataRoot/libraries" $a.path
    if (!(Test-Path $path)) {
        New-Item (Split-Path $path) -ItemType Directory -Force | Out-Null
        Invoke-WebRequest $a.url -OutFile $path -TimeoutSec 60
    }
    if ((Get-FileHash $path -Algorithm SHA1).Hash.ToLowerInvariant() -ne $a.sha1) { throw "Invalid library: $($lib.name)" }
    $libraries += $path
    if ($lib.name -match 'natives-windows$') {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [IO.Compression.ZipFile]::OpenRead($path)
        try {
            foreach ($entry in $zip.Entries | Where-Object Name -Like '*.dll') {
                [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path "$testRoot/natives" $entry.Name), $true)
            }
        } finally { $zip.Dispose() }
    }
}
$libraries += Get-ChildItem "$MetadataRoot/libraries/net/fabricmc","$MetadataRoot/libraries/org/ow2/asm" -Recurse -Filter '*.jar' -ErrorAction SilentlyContinue |
    Group-Object { $_.Directory.Parent.FullName } | ForEach-Object {
        $_.Group | Sort-Object { try { [version]($_.Directory.Name -replace '[^0-9.].*$','') } catch { [version]'0.0' } } | Select-Object -Last 1 -ExpandProperty FullName
    }
$minecraft = Join-Path $MetadataRoot "versions/$Version/$Version.jar"
$testLibraries = Join-Path $testRoot 'libraries'
New-Item $testLibraries -ItemType Directory -Force | Out-Null
$copiedLibraries = @()
for ($i = 0; $i -lt $libraries.Count; $i++) {
    $copy = Join-Path $testLibraries "$i.jar"
    if(!$ReuseTestRoot -or !(Test-Path $copy)){Copy-Item -LiteralPath $libraries[$i] -Destination $copy}
    $copiedLibraries += $copy
}
$libraries = $copiedLibraries
$testMinecraft = Join-Path $testRoot 'minecraft.jar'
if(!$ReuseTestRoot -or !(Test-Path $testMinecraft)){Copy-Item -LiteralPath $minecraft -Destination $testMinecraft}
$minecraft = $testMinecraft
$coreVersion=(Get-Content "$root/vertix-core-mod/src/main/resources/fabric.mod.json" -Raw | ConvertFrom-Json).version
$core = Join-Path $root "src-tauri/resources/mods/vertix-core-fabric-$Version-$coreVersion.jar"
$classpath = (@($minecraft, $core) + $libraries) -join ';'
& "$JdkHome/bin/javac.exe" --release 21 -proc:none -encoding UTF-8 -sourcepath "$root/vertix-core-mod/src/test/java" -cp $classpath -d "$testRoot/classes" "$root/vertix-core-mod/src/test/java/client/vertix/test/$TestClass.java"
if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed' }
@{schemaVersion=1;id='vertix_streaming_test';version='1';environment='client';mixins=@('streaming-test.mixins.json')} | ConvertTo-Json | Set-Content "$testRoot/classes/fabric.mod.json"
@{required=$true;package='client.vertix.test';compatibilityLevel='JAVA_21';client=@($TestClass);injectors=@{defaultRequire=1}} | ConvertTo-Json -Depth 4 | Set-Content "$testRoot/classes/streaming-test.mixins.json"
& "$JdkHome/bin/jar.exe" --create --file "$testRoot/game/mods/streaming-test.jar" -C "$testRoot/classes" .
foreach ($old in Get-ChildItem "$testRoot/game/mods" -File | Where-Object { $_.Name -match '^vertix-core-(fabric|forge)-[0-9.]+-[0-9.]+\.jar$' -and ($VanillaOnly -or $_.Name -ne (Split-Path $core -Leaf)) }) {
    Move-Item -LiteralPath $old.FullName -Destination (Join-Path $testRoot ("previous-" + [guid]::NewGuid().ToString('N') + '-' + $old.Name))
}
if (!$VanillaOnly) { Copy-Item $core "$testRoot/game/mods/" -Force }
foreach($project in @('appleskin','fabric-api')) {
    $destination=Join-Path "$testRoot/game/mods" "external-$project-test.jar"
    if($VanillaOnly -or !$WithExistingDependencies) {
        if(Test-Path -LiteralPath $destination){Move-Item -LiteralPath $destination -Destination (Join-Path $testRoot ("previous-"+[guid]::NewGuid().ToString('N')+"-$project.jar"))}
    } else {
        $entry=Get-Content "$root/vertix-core-mod/dependencies/integrations/manifest.json" -Raw | ConvertFrom-Json | Where-Object { $_.minecraft -eq $Version -and $_.project -eq $project }
        if(!$entry){throw "No pinned $project dependency for $Version"}
        $source=Join-Path "$root/vertix-core-mod/dependencies/integrations" $entry.file
        if((Get-FileHash -LiteralPath $source -Algorithm SHA512).Hash.ToLowerInvariant() -ne $entry.sha512){throw "Invalid test dependency: $project"}
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }
}
$classpath = (@($minecraft) + $libraries) -join ';'
'fullscreen:false' | Set-Content "$testRoot/game/options.txt"
# Separate config and offline identity; never use or mutate the user's instances/account.
$configDir = Join-Path $testRoot 'appdata/vertix'
New-Item $configDir -ItemType Directory -Force | Out-Null
'{"version":2,"modules":{"discord_streaming":{"enabled":true,"settings":{"stream_fps":30}}}}' | Set-Content -LiteralPath (Join-Path $configDir 'vertix-client-config.json') -Encoding utf8
$env:APPDATA = "$testRoot/appdata"
$argsFile = "$testRoot/launch.args"
(@('--enable-native-access=ALL-UNNAMED') + $ExtraJavaArgs + @('-Xmx2G', "-Djava.library.path=$testRoot/natives", "-Dorg.lwjgl.librarypath=$testRoot/natives", "-Dfabric.gameJarPath=$minecraft", '-cp', $classpath, 'net.fabricmc.loader.impl.launch.knot.KnotClient', '--username', 'VertixTest', '--uuid', '00000000000000000000000000000000', '--accessToken', '0', '--version', $Version, '--gameDir', "$testRoot/game", '--assetsDir', $AssetsRoot, '--assetIndex', $meta.assetIndex.id, '--width', '960', '--height', '540')) | ForEach-Object { '"' + $_.Replace('\','/') + '"' } | Set-Content $argsFile
$process = Start-Process cmd.exe -ArgumentList "/d /c `"`"$JavaHome/bin/java.exe`" @`"$argsFile`" > `"$testRoot/stdout.log`" 2>&1`"" -WorkingDirectory "$testRoot/game" -WindowStyle Hidden -PassThru
$process.Id | Set-Content "$testRoot/process-id.txt"
Write-Host "Started isolated Minecraft $Version test, PID $($process.Id). Evidence: $testRoot"
$deadline = (Get-Date).AddMinutes($TimeoutMinutes)
while (!$process.WaitForExit(1000)) {
    if ((Get-Date) -gt $deadline) {
        & taskkill.exe /PID $process.Id /T /F | Out-Null
        throw "Minecraft $Version test timed out; see $testRoot/stdout.log"
    }
}
if (!(Select-String -Path "$testRoot/stdout.log" -Pattern $(if($TestClass -eq 'StreamingRuntimeTest'){'VERTIX_STREAMING_TEST_PASSED'}elseif($TestClass -in @('UpgradeRuntimeTest','VideoProfileRuntimeTest')){'VERTIX_UI_TEST_PASSED'}else{'VERTIX_EXPANSION_TEST_PASSED'}) -Quiet)) {
    throw "Minecraft $Version streaming test failed (exit $($process.ExitCode)); see $testRoot/stdout.log"
}
Write-Host "Minecraft $Version $TestClass assertions passed."
