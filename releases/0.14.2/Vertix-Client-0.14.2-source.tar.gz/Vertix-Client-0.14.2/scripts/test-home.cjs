const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),ts=require('typescript'),React=require('react'),{renderToStaticMarkup}=require('react-dom/server');
function load(file,dependencies={}){
  const context={exports:{},require:n=>dependencies[n]??require(n)};
  vm.runInNewContext(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}}).outputText,context);
  return context.exports;
}
const geometry=load('src/skinGeometry.ts');
for(const slim of [false,true])for(const legacy of [false,true]){
  const parts=geometry.skinParts(slim,legacy);
  assert.equal(parts.length,6);
  assert.equal(parts.find(p=>p.name==='left-arm').w,slim&&!legacy?3:4);
  for(const part of parts){
    assert.ok(part.y+part.h<=32);
    for(const uv of [part.uv,...(part.overlay?[part.overlay]:[])]){
      const faces=geometry.skinFaces(part,uv);assert.equal(faces.length,6);
      for(const face of faces){assert.ok(face.u>=0&&face.v>=0&&face.u+face.w<=64&&face.v+face.h<=(legacy?32:64),`${part.name}/${face.name} stays in the texture`);}
    }
  }
  if(legacy){assert.ok(parts.find(p=>p.name==='left-arm').mirrored);assert.ok(parts.find(p=>p.name==='left-leg').mirrored);assert.equal(parts.filter(p=>p.overlay).length,1);}
}
const front=geometry.skinFaces(geometry.skinParts(false,false)[0])[0];
assert.deepEqual([front.u,front.v,front.w,front.h],[8,8,8,8]);
const png=fs.readFileSync('public/skins/steve.png');assert.equal(png.subarray(1,4).toString(),'PNG');assert.equal(png.readUInt32BE(16),64);assert.equal(png.readUInt32BE(20),64);
const {SkinPreview}=load('src/SkinPreview.tsx',{'./api':{desktop:false},'./skinGeometry':geometry});
const {Home}=load('src/Home.tsx',{'./SkinPreview':{SkinPreview},'./ProfileIcon':{ProfileIcon:()=>null}});
const profile={id:'one',name:'Survival',game_version:'26.2',loader:'fabric',settings:{memory:{max:8192}}};
const props={design:'slate',account:null,profiles:[profile],selected:profile,launching:false,progress:'',onSelect(){},onLaunch(){},onCreate(){},onOpen(){},onLibrary(){},onDiscover(){}};
const html=renderToStaticMarkup(React.createElement(Home,props));
assert.match(html,/Instanz auswählen/);assert.match(html,/Survival/);assert.match(html,/8 GB RAM/);assert.match(html,/Skin drehen/);assert.ok(!html.includes('Dein Skin wird geladen'));
const empty=renderToStaticMarkup(React.createElement(Home,{...props,profiles:[],selected:undefined}));
assert.ok(!empty.includes('Instanz auswählen'));assert.match(empty,/Instanz erstellen/);
const busy=renderToStaticMarkup(React.createElement(Home,{...props,launching:true,progress:'Minecraft wird vorbereitet'}));
assert.match(busy,/class="home-play" disabled/);assert.match(busy,/Minecraft wird vorbereitet/);
console.log('Home: classic/slim/legacy skin UVs, overlays, bundled fallback, instance picker, empty state and launch progress passed.');
