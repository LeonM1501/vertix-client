//! Duplicate handling is based on embedded mod IDs, not filenames or display titles.
use crate::error::{AppError,Result};
use serde::{Deserialize,Serialize};
use std::{collections::{BTreeMap,BTreeSet},io::Read,path::{Path,PathBuf}};

#[derive(Clone,Debug)]struct Candidate{path:PathBuf,ids:BTreeSet<String>,version:Option<semver::Version>,hash:String}
#[derive(Default,Serialize,Deserialize,Debug)]pub struct Report{pub preserved:Vec<String>,pub warnings:Vec<String>}
fn version(value:&str)->Option<semver::Version>{
    let value=value.strip_prefix('v').unwrap_or(value);
    if value.contains("${"){return None;}
    let split=value.find(['-','+']).unwrap_or(value.len());let (numbers,suffix)=value.split_at(split);
    let value=match numbers.split('.').count(){1=>format!("{numbers}.0.0{suffix}"),2=>format!("{numbers}.0{suffix}"),_=>value.into()};
    semver::Version::parse(&value).ok()
}
fn text(zip:&mut zip::ZipArchive<std::fs::File>,name:&str)->Option<String>{let mut entry=zip.by_name(name).ok()?;if entry.size()>2*1024*1024{return None;}let mut s=String::new();entry.read_to_string(&mut s).ok()?;Some(s)}
fn inspect(path:PathBuf,loader:&str)->Option<Candidate>{
    let mut zip=zip::ZipArchive::new(std::fs::File::open(&path).ok()?).ok()?;
    let mut ids=BTreeSet::new();let v;
    match loader{
        "fabric"|"quilt"=>{
            let (body,quilt)=if loader=="quilt"{text(&mut zip,"quilt.mod.json").map(|s|(s,true)).or_else(||text(&mut zip,"fabric.mod.json").map(|s|(s,false)))?}else{(text(&mut zip,"fabric.mod.json")?,false)};
            let doc:serde_json::Value=serde_json::from_str(&body).ok()?;let doc=if quilt{&doc["quilt_loader"]}else{&doc};
            ids.insert(doc["id"].as_str()?.to_owned());v=doc["version"].as_str().and_then(version);
        },
        "forge"|"neoforge"=>{
            let body=if loader=="neoforge"{text(&mut zip,"META-INF/neoforge.mods.toml").or_else(||text(&mut zip,"META-INF/mods.toml"))?}else{text(&mut zip,"META-INF/mods.toml")?};
            let doc:toml::Value=toml::from_str(&body).ok()?;let mods=doc.get("mods")?.as_array()?;let mut versions=BTreeSet::new();
            for item in mods{ids.insert(item.get("modId")?.as_str()?.to_owned());let declared=item.get("version").and_then(toml::Value::as_str).unwrap_or("");
                let declared=if declared=="${file.jarVersion}"{text(&mut zip,"META-INF/MANIFEST.MF").and_then(|manifest|manifest.lines().find_map(|l|l.strip_prefix("Implementation-Version: ")).map(str::to_owned)).unwrap_or_default()}else{declared.to_owned()};
                versions.insert(version(&declared));
            }
            // Multi-mod jars can only be replaced by the exact same ID set and shared version.
            v=if versions.len()==1{versions.into_iter().next().flatten()}else{None};
        },_=>return None,
    }
    if ids.is_empty(){return None;}
    Some(Candidate{path,ids,version:v,hash:String::new()})
}

pub fn resolve(directory:&Path,loader:&str)->Result<Report>{
    let mut report=Report::default();if !directory.exists(){return Ok(report);}
    let mut groups:BTreeMap<BTreeSet<String>,Vec<Candidate>>=BTreeMap::new();
    for entry in std::fs::read_dir(directory)?{let entry=entry?;if !entry.file_type()?.is_file(){continue;}let path=entry.path();if !path.extension().and_then(|s|s.to_str()).is_some_and(|s|s.eq_ignore_ascii_case("jar")){continue;}
        if let Some(candidate)=inspect(path,loader){groups.entry(candidate.ids.clone()).or_default().push(candidate);}
    }
    let keys=groups.keys().cloned().collect::<Vec<_>>();
    for (ids,mut candidates) in groups{
        if keys.iter().any(|other|other!=&ids&&!ids.is_disjoint(other)){report.warnings.push(format!("Überlappende Mod-IDs: {}. Bitte manuell prüfen.",ids.iter().cloned().collect::<Vec<_>>().join(", ")));continue;}
        if candidates.len()<2{continue;}
        if candidates.iter().any(|c|c.version.is_none()){report.warnings.push(format!("Versionsnummern für {} sind nicht eindeutig vergleichbar. Bitte eine Version auswählen.",ids.iter().cloned().collect::<Vec<_>>().join(", ")));continue;}
        for candidate in &mut candidates {use sha2::{Digest,Sha256};let mut file=std::fs::File::open(&candidate.path)?;let mut digest=Sha256::new();std::io::copy(&mut file,&mut digest)?;candidate.hash=format!("{:x}",digest.finalize());}
        candidates.sort_by(|a,b|b.version.as_ref().unwrap().cmp_precedence(a.version.as_ref().unwrap()).then(a.path.cmp(&b.path)));
        let newest=&candidates[0];
        if candidates.iter().skip(1).any(|c|c.version.as_ref().unwrap().cmp_precedence(newest.version.as_ref().unwrap())==std::cmp::Ordering::Equal&&c.hash!=newest.hash){report.warnings.push(format!("Unterschiedliche Dateien mit gleicher Mod-Version: {}",ids.iter().cloned().collect::<Vec<_>>().join(", ")));continue;}
        for old in candidates.iter().skip(1){
            let backup=directory.join(".vertix-duplicates").join(&old.hash);std::fs::create_dir_all(&backup)?;
            let filename=old.path.file_name().ok_or_else(||AppError::Other("Ungültiger Mod-Dateiname.".into()))?;
            let target=backup.join(filename);
            if target.is_file(){
                use sha2::{Digest,Sha256};let mut previous=std::fs::File::open(&target)?;let mut digest=Sha256::new();std::io::copy(&mut previous,&mut digest)?;
                if format!("{:x}",digest.finalize())==old.hash{
                    // A pinned managed version can be downloaded again. Its identical
                    // preserved copy already exists, so do not accumulate extra copies.
                    std::fs::remove_file(&old.path)?;
                    report.preserved.push(format!("{} → {}",filename.to_string_lossy(),target.display()));continue;
                }
            }
            // Never overwrite an earlier backup, even if its contents were modified by the user.
            let target=if target.exists(){backup.join(format!("{}-{}",uuid::Uuid::new_v4(),filename.to_string_lossy()))}else{target};
            let record=serde_json::json!({"original":filename.to_string_lossy(),"sha256":old.hash,"version":old.version.as_ref().unwrap().to_string(),"selected":newest.path.file_name().unwrap().to_string_lossy(),"selected_version":newest.version.as_ref().unwrap().to_string(),"mod_ids":ids});
            std::fs::write(target.with_extension("jar.json"),serde_json::to_vec_pretty(&record)?)?;
            std::fs::rename(&old.path,&target)?;
            report.preserved.push(format!("{} → {}",filename.to_string_lossy(),target.display()));
        }
    }
    if !report.preserved.is_empty()||!report.warnings.is_empty()||directory.join(".vertix-duplicate-report.json").exists(){std::fs::write(directory.join(".vertix-duplicate-report.json"),serde_json::to_vec_pretty(&report)?)?;}
    // Ambiguous duplicates remain intact and prevent a misleading successful launch.
    if !report.warnings.is_empty(){return Err(AppError::Other(format!("Mod-Konflikt: {}. Details: {}",report.warnings.join("; "),directory.join(".vertix-duplicate-report.json").display())));}
    Ok(report)
}
pub async fn before_launch(directory:&Path,loader:&str)->Result<Report>{let directory=directory.to_owned();let loader=loader.to_owned();tokio::task::spawn_blocking(move||resolve(&directory,&loader)).await.map_err(|e|AppError::Other(e.to_string()))?}

/// A managed entry may still pin an older version. Hide it only when the actual
/// active file is absent and a preserved copy exists, never merely on a stale report.
pub async fn is_preserved(directory:&Path,filename:&str)->bool{
    if filename.contains(['/', '\\'])||directory.join(filename).exists(){return false;}
    let Ok(mut entries)=tokio::fs::read_dir(directory.join(".vertix-duplicates")).await else{return false;};
    while let Ok(Some(entry))=entries.next_entry().await{if entry.file_type().await.is_ok_and(|t|t.is_dir())&&entry.path().join(filename).is_file(){return true;}}
    false
}

#[cfg(test)]mod tests{
    use super::*;use std::io::Write;
    fn jar(path:&Path,id:&str,v:&str){let mut z=zip::ZipWriter::new(std::fs::File::create(path).unwrap());z.start_file("fabric.mod.json",zip::write::SimpleFileOptions::default()).unwrap();write!(z,"{}",serde_json::json!({"id":id,"version":v})).unwrap();z.finish().unwrap();}
    #[test]fn newest_wins_but_older_and_disabled_files_survive(){let t=tempfile::tempdir().unwrap();jar(&t.path().join("new.jar"),"same","2.0.0");jar(&t.path().join("old.jar"),"same","1.9.9");jar(&t.path().join("off.jar.disabled"),"same","3.0.0");jar(&t.path().join("different.jar"),"other","1.0.0");let r=resolve(t.path(),"fabric").unwrap();assert_eq!(r.preserved.len(),1);assert!(t.path().join("new.jar").exists());assert!(!t.path().join("old.jar").exists());assert!(t.path().join("off.jar.disabled").exists());assert!(t.path().join("different.jar").exists());assert!(resolve(t.path(),"fabric").unwrap().preserved.is_empty());}
    #[test]fn filename_is_never_identity(){let t=tempfile::tempdir().unwrap();jar(&t.path().join("mod-99.jar"),"a","1.0.0");jar(&t.path().join("mod-1.jar"),"b","2.0.0");assert!(resolve(t.path(),"fabric").unwrap().preserved.is_empty());}
    #[test]fn stable_beats_prerelease(){assert!(version("2.0.0").unwrap()>version("2.0.0-rc.1").unwrap());assert!(version("${version}").is_none());}
    #[test]fn unorderable_duplicates_stop_without_moving_files(){let t=tempfile::tempdir().unwrap();jar(&t.path().join("a.jar"),"same","release-final");jar(&t.path().join("b.jar"),"same","2.0");assert!(resolve(t.path(),"fabric").is_err());assert!(t.path().join("a.jar").is_file());assert!(t.path().join("b.jar").is_file());}
    #[test]fn forge_manifest_versions_are_resolved_and_overlapping_bundles_are_kept(){
        fn forge(path:&Path,ids:&[&str],v:&str){let mut z=zip::ZipWriter::new(std::fs::File::create(path).unwrap());z.start_file("META-INF/mods.toml",zip::write::SimpleFileOptions::default()).unwrap();for id in ids{writeln!(z,"[[mods]]\nmodId=\"{id}\"\nversion=\"${{file.jarVersion}}\"").unwrap();}z.start_file("META-INF/MANIFEST.MF",zip::write::SimpleFileOptions::default()).unwrap();writeln!(z,"Implementation-Version: {v}").unwrap();z.finish().unwrap();}
        let t=tempfile::tempdir().unwrap();forge(&t.path().join("old.jar"),&["armor"],"1.0.0");forge(&t.path().join("new.jar"),&["armor"],"1.1.0");assert_eq!(resolve(t.path(),"forge").unwrap().preserved.len(),1);assert!(t.path().join("new.jar").exists());
        forge(&t.path().join("bundle.jar"),&["armor","extra"],"2.0.0");assert!(resolve(t.path(),"forge").is_err());assert!(t.path().join("bundle.jar").exists());assert!(t.path().join("new.jar").exists());
    }
    #[test]fn a_downloaded_pin_does_not_accumulate_backups(){let t=tempfile::tempdir().unwrap();jar(&t.path().join("old.jar"),"same","1.0.0");jar(&t.path().join("new.jar"),"same","2.0.0");resolve(t.path(),"fabric").unwrap();jar(&t.path().join("old.jar"),"same","1.0.0");resolve(t.path(),"fabric").unwrap();let backups=std::fs::read_dir(t.path().join(".vertix-duplicates")).unwrap().flat_map(|d|std::fs::read_dir(d.unwrap().path()).unwrap()).count();assert_eq!(backups,2);}
}
