use crate::{error::{AppError, CommandError}, state::{State, profile_state::ModLoader}};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Deserialize)]
pub struct SettingsRequest {
    pub name: String, pub memory: u32, pub game_version: String,
    pub loader: String, pub loader_version: Option<String>,
    pub icon: Option<ProfileIcon>,
}

#[derive(Deserialize, Serialize)]
pub struct ProfileIcon { pub symbol: String, pub background: String, pub image: Option<String> }
fn validated_icon(icon: ProfileIcon) -> Result<serde_json::Value, AppError> {
    if !["box","pickaxe","trees","sword","castle","globe","compass","leaf","gem","shield","cpu","rocket"].contains(&icon.symbol.as_str()) || icon.background.len()!=7 || !icon.background.starts_with('#') || !icon.background[1..].bytes().all(|c|c.is_ascii_hexdigit()) { return Err(AppError::Other("Ungültiges Instanzbild.".into())); }
    if let Some(data)=&icon.image {
        use base64::Engine; use image::ImageDecoder;
        let encoded=data.strip_prefix("data:image/png;base64,").ok_or_else(||AppError::Other("Das Bild muss als PNG gespeichert werden.".into()))?;
        if encoded.len()>700_000 {return Err(AppError::Other("Das Instanzbild ist zu groß.".into()));}
        let bytes=base64::engine::general_purpose::STANDARD.decode(encoded).map_err(|e|AppError::Other(e.to_string()))?;
        let decoder=image::codecs::png::PngDecoder::new(std::io::Cursor::new(&bytes)).map_err(|e|AppError::Other(e.to_string()))?;
        let (w,h)=decoder.dimensions();if w==0 || h==0 || w>512 || h>512 {return Err(AppError::Other("Instanzbilder dürfen höchstens 512 × 512 Pixel haben.".into()));}
    }
    serde_json::to_value(icon).map_err(Into::into)
}

#[tauri::command]
pub async fn configure_vertix_instance(profile_id: Uuid, request: SettingsRequest) -> Result<(), CommandError> {
    let _guard = crate::instance_content::CONTENT_LOCK.lock().await;
    let state = State::get().await?;
    crate::instance_content::ensure_stopped(&state, profile_id).await?;
    let mut profile = state.profile_manager.get_profile(profile_id).await?;
    if request.name.trim().is_empty() || request.memory < 1024 || request.memory > 1048576 {
        return Err(AppError::Other("Name oder Arbeitsspeicher ungültig.".into()).into());
    }
    let loader = ModLoader::from_str(&request.loader)?;
    if profile.game_version != request.game_version || profile.loader != loader || profile.loader_version != request.loader_version {
        let versions = crate::minecraft::api::mc_api::MinecraftApiService::new().get_version_manifest().await?;
        if !versions.versions.iter().any(|v| v.id == request.game_version) {
            return Err(AppError::Other("Unbekannte Minecraft-Version.".into()).into());
        }
        let available = loader_versions(&request.loader, &request.game_version).await?;
        if loader != ModLoader::Vanilla && (available.is_empty() || request.loader_version.as_ref().is_some_and(|v| !available.contains(v))) {
            return Err(AppError::Other("Diese Modloader-Version ist für Minecraft nicht verfügbar.".into()).into());
        }
    }
    if let Some(icon)=request.icon {profile.extra.insert("vertix_icon".into(),validated_icon(icon)?);}
    profile.name = request.name.trim().into();
    profile.game_version = request.game_version;
    profile.loader = loader;
    profile.loader_version = if loader == ModLoader::Vanilla { None } else { request.loader_version };
    profile.settings.use_overwrite_loader_version = false;
    profile.settings.overwrite_loader_version = None;
    profile.settings.overwrite_loader_versions.clear();
    profile.settings.memory.min = profile.settings.memory.min.min(request.memory);
    profile.settings.memory.max = request.memory;
    state.profile_manager.update_profile(profile_id, profile).await?;
    Ok(())
}

#[tauri::command]
pub async fn instance_duplicate_report(profile_id:Uuid)->Result<crate::duplicate_mods::Report,CommandError>{
    let state=State::get().await?;let profile=state.profile_manager.get_profile(profile_id).await?;
    let root=crate::instance_content::isolated_root(&state,&profile).await?;
    match tokio::fs::read(root.join("mods/.vertix-duplicate-report.json")).await{
        Ok(bytes)=>Ok(serde_json::from_slice(&bytes).map_err(AppError::from)?),
        Err(e)if e.kind()==std::io::ErrorKind::NotFound=>Ok(Default::default()),Err(e)=>Err(AppError::from(e).into())
    }
}

#[tauri::command]
pub async fn loader_versions(loader: &str, minecraft_version: &str) -> Result<Vec<String>, CommandError> {
    use crate::commands::minecraft_command::*;
    Ok(match loader {
        "vanilla" => vec![],
        "fabric" => get_fabric_loader_versions(minecraft_version.into()).await?.into_iter().map(|v|v.loader.version).collect(),
        "quilt" => get_quilt_loader_versions(minecraft_version.into()).await?.into_iter().map(|v|v.loader.version).collect(),
        "forge" => get_forge_versions(minecraft_version.into()).await?,
        "neoforge" => get_neoforge_versions(minecraft_version.into()).await?,
        _ => return Err(AppError::Other("Unbekannter Modloader.".into()).into()),
    })
}
