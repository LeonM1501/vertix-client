//! Only a remote file with recorded content ownership may be retired automatically.
use crate::{error::{AppError, Result}, minecraft::downloads::mod_resolver::TargetMod};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::path::Path;
use tokio::fs;

#[derive(Default, Serialize, Deserialize)]
struct Manifest { version: u32, files: Vec<OwnedFile> }
#[derive(Serialize, Deserialize)]
struct OwnedFile { name: String, sha256: String, source: String }
#[derive(Serialize, Deserialize)]
struct RetiredFile { name: String, sha1: String }
fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn valid(name: &str) -> bool {
    !name.is_empty() && !name.contains(['/', '\\', ':', '\0']) && name != "." && name != ".."
}

// Explicitly replacing a legacy remote version is different from guessing
// ownership from a transferred list of filenames. Bind retirement to its hash.
pub async fn retire_after_restart(root: &Path, name: &str, sha1: &str) -> Result<()> {
    if !valid(name) { return Err(AppError::Other("Ungültiger Mod-Dateiname.".into())); }
    let path=root.join(".vertix-retire-mods.json");
    let mut files: Vec<RetiredFile> = if path.exists() {serde_json::from_slice(&fs::read(&path).await?)?} else {Vec::new()};
    if !files.iter().any(|f|f.name==name) {files.push(RetiredFile{name:name.into(),sha1:sha1.into()});}
    crate::utils::file_utils::write_atomic(path,serde_json::to_vec(&files)?).await
}
pub async fn apply_retirements(root: &Path) -> Result<()> {
    let manifest=root.join(".vertix-retire-mods.json");
    if !manifest.exists() {return Ok(());}
    let files: Vec<RetiredFile>=serde_json::from_slice(&fs::read(&manifest).await?)?;
    for file in files {
        if !valid(&file.name) {return Err(AppError::Other("Ungültiger vorgemerkter Dateiname.".into()));}
        let path=root.join("mods").join(&file.name);
        match fs::read(&path).await {
            Ok(bytes) => {
                use sha1::Digest;
                if format!("{:x}",sha1::Sha1::digest(&bytes))!=file.sha1 {return Err(AppError::Other(format!("{} wurde lokal verändert und bleibt erhalten. Löse den Versionskonflikt vor dem nächsten Spielstart.",file.name)));}
                crate::utils::trash_utils::move_path_to_trash(&path,Some("replaced_mod_versions")).await?;
            },
            Err(e) if e.kind()==std::io::ErrorKind::NotFound => {},
            Err(e)=>return Err(e.into()),
        }
    }
    fs::remove_file(manifest).await?;Ok(())
}

pub async fn sync(mods: &[TargetMod], directory: &Path) -> Result<()> {
    sync_protected(mods,directory,&[]).await
}
pub async fn claim_remote(directory: &Path, name: &str, expected: &str, source: &str) -> Result<()> {
    if !valid(name) {return Err(AppError::Other("Ungültiger Mod-Dateiname.".into()));}
    let bytes=match fs::read(directory.join(name)).await {Ok(b)=>b,Err(e) if e.kind()==std::io::ErrorKind::NotFound=>return Ok(()),Err(e)=>return Err(e.into())};
    use sha1::Digest;
    if format!("{:x}",sha1::Sha1::digest(&bytes))!=expected {return Err(AppError::Other(format!("{name} wurde lokal verändert und bleibt erhalten.")));}
    let path=directory.join(".vertix-managed-mods.json");
    let mut manifest=fs::read(&path).await.ok().and_then(|b|serde_json::from_slice::<Manifest>(&b).ok()).filter(|m|m.version==2).unwrap_or_default();
    manifest.version=2;manifest.files.retain(|f|f.name!=name);
    manifest.files.push(OwnedFile{name:name.into(),sha256:digest(&bytes),source:source.into()});
    crate::utils::file_utils::write_atomic(path,serde_json::to_vec(&manifest)?).await
}
pub async fn sync_protected(mods: &[TargetMod], directory: &Path, keep: &[String]) -> Result<()> {
    fs::create_dir_all(directory).await?;
    let path = directory.join(".vertix-managed-mods.json");
    // Old name-only manifests cannot prove ownership. Adopt matching downloads,
    // but never remove a file solely because its name occurred in such a list.
    let previous = match fs::read(&path).await {
        Ok(bytes) => serde_json::from_slice::<Manifest>(&bytes).ok().filter(|m|m.version == 2).unwrap_or_default(),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Manifest::default(),
        Err(e) => return Err(e.into()),
    };
    let mut prepared = Vec::new();
    let mut owned = Vec::new();
    for m in mods {
        if !valid(&m.filename) { return Err(AppError::Other("Ungültiger Mod-Dateiname.".into())); }
        let target = directory.join(&m.filename);
        // Local jars already live in this directory. Never register them as
        // remotely managed; a subsequent cache-only sync must leave them intact.
        if m.mod_id.starts_with("local:") || m.cache_path == target {
            if m.cache_path != target {
                let bytes=fs::read(&m.cache_path).await?;
                if let Ok(existing)=fs::read(&target).await {if existing!=bytes {return Err(AppError::Other(format!("Lokaler Namenskonflikt: {}",m.filename)));}}
                prepared.push((target,bytes));
            }
            continue;
        }
        let bytes = fs::read(&m.cache_path).await?;
        let hash = digest(&bytes);
        if let Ok(existing) = fs::read(&target).await {
            if existing != bytes && !previous.files.iter().any(|p|p.name == m.filename && p.sha256 == digest(&existing)) {
                return Err(AppError::Other(format!("{} ist eine lokale oder veränderte Datei. Sie bleibt erhalten; löse den Namenskonflikt vor der Installation.", m.filename)));
            }
        }
        owned.push(OwnedFile { name: m.filename.clone(), sha256: hash, source: m.mod_id.clone() });
        prepared.push((target, bytes));
    }
    // Validate every input before changing any existing file.
    for (target, bytes) in prepared { crate::utils::file_utils::write_atomic(&target, bytes).await?; }
    for old in previous.files {
        if !valid(&old.name) || old.source.starts_with("local:") || mods.iter().any(|m|m.filename == old.name) { continue; }
        if keep.contains(&old.name) {owned.push(old);continue;}
        let target = directory.join(&old.name);
        if let Ok(bytes) = fs::read(&target).await {
            if digest(&bytes) == old.sha256 {
                crate::utils::trash_utils::move_path_to_trash(&target, Some("managed_mods")).await?;
            }
        }
    }
    crate::utils::file_utils::write_atomic(&path, serde_json::to_vec(&Manifest { version: 2, files: owned })?).await
}

#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    async fn legacy_transfer_and_local_resync_never_delete_user_jars() {
        let temp = tempfile::tempdir().unwrap(); let root = temp.path().join("mods"); fs::create_dir_all(&root).await.unwrap();
        fs::write(root.join("mine.jar"), b"own code").await.unwrap();
        fs::write(root.join(".vertix-managed-mods.json"), br#"["mine.jar"]"#).await.unwrap();
        sync(&[], &root).await.unwrap(); assert!(root.join("mine.jar").exists());
        let local = TargetMod { mod_id:"local:mine.jar".into(), filename:"mine.jar".into(), cache_path:root.join("mine.jar"), sha1:None };
        sync(&[local], &root).await.unwrap(); sync(&[], &root).await.unwrap();
        assert_eq!(fs::read(root.join("mine.jar")).await.unwrap(), b"own code");
    }
    #[tokio::test]
    async fn modified_remote_and_conflicts_are_preserved() {
        let temp = tempfile::tempdir().unwrap(); let root = temp.path().join("mods"); let cache = temp.path().join("cache.jar");
        fs::write(&cache,b"download").await.unwrap();
        let remote = TargetMod { mod_id:"modrinth:abc".into(),filename:"download.jar".into(),cache_path:cache,sha1:None };
        sync(&[remote.clone()],&root).await.unwrap();
        fs::write(root.join("download.jar"),b"my replacement").await.unwrap();
        assert!(sync(&[remote],&root).await.is_err()); sync(&[],&root).await.unwrap();
        assert_eq!(fs::read(root.join("download.jar")).await.unwrap(),b"my replacement");
    }
    #[tokio::test]
    async fn explicit_legacy_version_replacement_is_hash_bound_and_deferred() {
        let temp=tempfile::tempdir().unwrap();let root=temp.path();fs::create_dir(root.join("mods")).await.unwrap();
        let path=root.join("mods/old.jar");fs::write(&path,b"old").await.unwrap();
        let hash=format!("{:x}",sha1::Sha1::digest(b"old"));
        retire_after_restart(root,"old.jar",&hash).await.unwrap();assert!(path.exists());
        fs::write(&path,b"local").await.unwrap();assert!(apply_retirements(root).await.is_err());assert!(path.exists());
        fs::write(&path,b"old").await.unwrap();apply_retirements(root).await.unwrap();assert!(!path.exists());
    }
    #[tokio::test]
    async fn unresolved_enabled_remote_is_kept_and_same_name_legacy_update_is_allowed() {
        let temp=tempfile::tempdir().unwrap();let root=temp.path().join("mods");fs::create_dir(&root).await.unwrap();
        let path=root.join("remote.jar");fs::write(&path,b"old").await.unwrap();
        claim_remote(&root,"remote.jar",&format!("{:x}",sha1::Sha1::digest(b"old")),"modrinth:remote").await.unwrap();
        sync_protected(&[],&root,&["remote.jar".into()]).await.unwrap();assert!(path.exists());
        let cache=temp.path().join("new.jar");fs::write(&cache,b"new").await.unwrap();
        let m=TargetMod{mod_id:"modrinth:remote".into(),filename:"remote.jar".into(),cache_path:cache,sha1:None};
        sync(&[m],&root).await.unwrap();assert_eq!(fs::read(&path).await.unwrap(),b"new");
    }
}
