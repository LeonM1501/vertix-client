//! Provider credentials never enter profiles, URLs, logs or distributed artifacts.
use crate::error::{AppError, CommandError, Result};
use reqwest::{header::HeaderValue, Client, RequestBuilder};
use std::path::PathBuf;

fn failure(message: &str) -> AppError { AppError::Other(message.into()) }
fn path() -> Result<PathBuf> {
    Ok(PathBuf::from(std::env::var_os("APPDATA").ok_or_else(||failure("APPDATA fehlt."))?).join("vertix/providers/curseforge.bin"))
}
#[cfg(windows)]
fn crypt(bytes: &[u8], encrypt: bool) -> Result<Vec<u8>> {
    use windows::Win32::{Security::Cryptography::{CryptProtectData, CryptUnprotectData, CRYPT_INTEGER_BLOB}, Foundation::{LocalFree, HLOCAL}};
    let input=CRYPT_INTEGER_BLOB {cbData:bytes.len() as u32,pbData:bytes.as_ptr() as *mut u8};
    let mut output=CRYPT_INTEGER_BLOB::default();
    unsafe {
        let result=if encrypt {CryptProtectData(&input,None,None,None,None,1,&mut output)} else {CryptUnprotectData(&input,None,None,None,None,1,&mut output)};
        result.map_err(|_|failure("Der CurseForge-Key konnte nicht mit diesem Windows-Konto gelesen oder gespeichert werden."))?;
        let data=std::slice::from_raw_parts(output.pbData,output.cbData as usize).to_vec();
        let _=LocalFree(HLOCAL(output.pbData as *mut _));
        Ok(data)
    }
}
#[cfg(not(windows))]
fn crypt(_: &[u8], _: bool) -> Result<Vec<u8>> {Err(failure("Auf diesem System den Key über VERTIX_CURSEFORGE_API_KEY bereitstellen."))}
pub fn key() -> Result<String> {
    if let Ok(key)=std::env::var("VERTIX_CURSEFORGE_API_KEY") {if !key.trim().is_empty(){return Ok(key.trim().into());}}
    let data=std::fs::read(path()?).map_err(|_|failure("CurseForge-Key fehlt. Hinterlege ihn unter Einstellungen → Inhaltsquellen."))?;
    String::from_utf8(crypt(&data,false)?).map_err(|_|failure("Der gespeicherte CurseForge-Key ist ungültig."))
}
pub fn header() -> Result<HeaderValue> {
    let mut value=HeaderValue::from_str(&key()?).map_err(|_|failure("Ungültiger CurseForge-Key."))?;
    value.set_sensitive(true);Ok(value)
}
pub fn forge_cdn(url: &reqwest::Url) -> bool {
    url.scheme()=="https" && url.port_or_known_default()==Some(443) && url.host_str().is_some_and(|h|h=="forgecdn.net" || h.ends_with(".forgecdn.net"))
}
pub fn api_client() -> Result<Client> {
    Client::builder().timeout(std::time::Duration::from_secs(25)).redirect(reqwest::redirect::Policy::none()).build().map_err(Into::into)
}
pub fn download_request(url: &str) -> Result<RequestBuilder> {
    let parsed=reqwest::Url::parse(url).map_err(|_|failure("Ungültige Downloadadresse."))?;
    if !forge_cdn(&parsed) {return Ok(crate::config::HTTP_CLIENT.get(url));}
    let client=Client::builder().redirect(reqwest::redirect::Policy::custom(|a|{
        if a.previous().len()>=5 {a.error("Zu viele Downloadweiterleitungen")} else if forge_cdn(a.url()){a.follow()}else{a.error("Unzulässige CurseForge-Downloadweiterleitung")}
    })).build()?;
    Ok(client.get(url).header("x-api-key",header()?))
}
#[tauri::command]
pub fn curseforge_key_configured() -> bool {key().is_ok()}
#[tauri::command]
pub async fn save_curseforge_key(api_key: String) -> std::result::Result<(),CommandError> {
    let key=api_key.trim();
    if key.is_empty(){if let Ok(p)=path(){let _=std::fs::remove_file(p);}return Ok(());}
    let mut h=HeaderValue::from_str(key).map_err(|_|failure("Ungültiger API-Key."))?;h.set_sensitive(true);
    let response=api_client()?.get("https://api.curseforge.com/v1/games/432").header("x-api-key",h).send().await.map_err(|_|failure("CurseForge ist nicht erreichbar. Der bisherige Key bleibt erhalten."))?;
    if !response.status().is_success(){return Err(failure("CurseForge lehnt den Key ab. Prüfe ihn und seine Freischaltung im Entwicklerportal.").into());}
    let destination=path()?;std::fs::create_dir_all(destination.parent().unwrap()).map_err(AppError::Io)?;
    crate::utils::file_utils::write_atomic(destination,crypt(key.as_bytes(),true)?).await?;Ok(())
}
