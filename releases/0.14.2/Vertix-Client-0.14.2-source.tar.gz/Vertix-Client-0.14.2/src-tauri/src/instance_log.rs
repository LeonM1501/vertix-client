use crate::error::Result;
use std::path::Path;
pub async fn read_latest(path: &Path) -> Result<String> {
    let bytes = tokio::fs::read(path).await?;
    let text = String::from_utf8_lossy(&bytes);
    let secret = regex::Regex::new(r"(?i)(--accessToken\s+|Bearer\s+)[^\s]+").unwrap();
    Ok(secret.replace_all(&text,"$1[geschützt]").into_owned())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    async fn reads_beyond_old_limit_without_losing_start_or_end() {
        let temp=tempfile::tempdir().unwrap();let path=temp.path().join("latest.log");
        let text=format!("FIRST LINE\n{}\n--accessToken top-secret\nBearer another-secret\nLAST LINE", "Minecraft log entry\n".repeat(100_000));
        tokio::fs::write(&path,&text).await.unwrap();let output=read_latest(&path).await.unwrap();
        assert!(output.len()>1_000_000);assert!(output.starts_with("FIRST LINE"));assert!(output.ends_with("LAST LINE"));
        assert!(!output.contains("top-secret"));assert!(!output.contains("another-secret"));assert!(output.contains("[geschützt]"));
    }
}
