//! Unified read model. Cross-provider identities require a shared file or source repository.
use crate::{config::HTTP_CLIENT,error::{AppError,CommandError,Result}};
use serde::{Serialize,Deserialize};use serde_json::{Value,json};
use std::collections::HashMap;
type Cached = (std::time::Instant,Option<String>);
fn identity_path()->Option<std::path::PathBuf>{std::env::var_os("APPDATA").map(|p|std::path::PathBuf::from(p).join("vertix/providers/catalog-identities.json"))}
static IDENTITIES: std::sync::LazyLock<tokio::sync::Mutex<HashMap<String,Cached>>>=std::sync::LazyLock::new(||{
    let entries=identity_path().and_then(|p|std::fs::read(p).ok()).and_then(|b|serde_json::from_slice::<HashMap<String,String>>(&b).ok()).unwrap_or_default();
    tokio::sync::Mutex::new(entries.into_iter().map(|(c,m)|(c,(std::time::Instant::now(),Some(m)))).collect())
});
#[derive(Clone,Serialize,Deserialize,Default)]
pub struct Sources {pub modrinth:Option<String>,pub curseforge:Option<String>}
fn fail(s:&str)->AppError {AppError::Other(s.into())}
pub async fn mr(path:&str)->Result<Value>{Ok(HTTP_CLIENT.get(format!("https://api.modrinth.com/v2/{path}")).send().await?.error_for_status()?.json().await?)}
pub async fn cf(path:&str)->Result<Value>{
    let r=crate::provider_keys::api_client()?.get(format!("https://api.curseforge.com/v1/{path}")).header("x-api-key",crate::provider_keys::header()?).send().await?;
    if matches!(r.status().as_u16(),401|403){return Err(fail("CurseForge lehnt den API-Key ab. Prüfe ihn unter Einstellungen → Inhaltsquellen."));}
    if !r.status().is_success(){return Err(fail(&format!("CurseForge antwortet mit HTTP {}.",r.status().as_u16())));}
    Ok(r.json::<Value>().await?["data"].clone())
}
fn cf_id(id:&str)->Result<&str>{let id=id.strip_prefix("cf:").unwrap_or(id);if id.is_empty()||!id.chars().all(|c|c.is_ascii_digit()){return Err(fail("Ungültige CurseForge-Projekt-ID."));}Ok(id)}
async fn identify(c:&Value)->Option<String>{
    let id=c["id"].to_string();
    if let Some((at,result))=IDENTITIES.lock().await.get(&id){if at.elapsed().as_secs()<3600{return result.clone();}}
    let mut result=None;
    if let Some(slug)=c["slug"].as_str(){if let Ok(m)=mr(&format!("project/{}",urlencoding::encode(slug))).await {if crate::catalog_identity::same_repository(&m,c){result=m["id"].as_str().map(str::to_owned);}}}
    if result.is_none(){if let Some(files)=c["latestFiles"].as_array(){for file in files.iter().take(2){
        if let Some(hash)=file["hashes"].as_array().and_then(|h|h.iter().find(|h|h["algo"]==1)).and_then(|h|h["value"].as_str()){
            if hash.len()==40&&hash.chars().all(|c|c.is_ascii_hexdigit()){
                if let Ok(v)=mr(&format!("version_file/{hash}?algorithm=sha1")).await {result=v["project_id"].as_str().map(str::to_owned);if result.is_some(){break;}}
            }
        }
    }}}
    let mut cache=IDENTITIES.lock().await;
    cache.insert(id,(std::time::Instant::now(),result.clone()));
    if result.is_some(){if let Some(path)=identity_path(){
        let positive=cache.iter().filter_map(|(c,(_,m))|m.as_ref().map(|m|(c,m))).collect::<HashMap<_,_>>();
        if let Ok(bytes)=serde_json::to_vec(&positive){let _=crate::utils::file_utils::write_atomic(path,bytes).await;}
    }}result
}
pub async fn sources(id:&str)->Result<Sources>{
    if id.starts_with("cf:"){
        let c=cf(&format!("mods/{}",cf_id(id)?)).await?;return Ok(Sources{modrinth:identify(&c).await,curseforge:Some(cf_id(id)?.into())});
    }
    let m=mr(&format!("project/{}",urlencoding::encode(id))).await?;let mid=m["id"].as_str().unwrap_or(id).to_owned();
    let mut source=Sources{modrinth:Some(mid.clone()),curseforge:None};
    if crate::provider_keys::key().is_ok(){
        if let Some((cid,_))=IDENTITIES.lock().await.iter().find(|(_,(_,id))|id.as_deref()==Some(&mid)){source.curseforge=Some(cid.clone());return Ok(source);}
        let slug=m["slug"].as_str().unwrap_or(id);
        if let Ok(list)=cf(&format!("mods/search?gameId=432&classId=6&slug={}",urlencoding::encode(slug))).await{
            if let Some(list)=list.as_array(){for c in list {if crate::catalog_identity::same_repository(&m,c)||identify(c).await.as_deref()==Some(&mid){source.curseforge=c["id"].as_u64().map(|n|n.to_string());break;}}}
        }
    }
    Ok(source)
}
pub async fn project(id:&str)->Result<Value>{
    if !id.starts_with("cf:"){let mut p=mr(&format!("project/{}",urlencoding::encode(id))).await?;p["provider"]="modrinth".into();p["website_url"]=format!("https://modrinth.com/mod/{}",p["slug"].as_str().unwrap_or(id)).into();return Ok(p);}
    let c=cf(&format!("mods/{}",cf_id(id)?)).await?;
    if c["classId"]!=6{return Err(fail("Dieses CurseForge-Projekt ist keine Minecraft-Mod."));}
    let body=cf(&format!("mods/{}/description",cf_id(id)?)).await?.as_str().unwrap_or("").to_owned();
    Ok(json!({"id":id,"slug":c["slug"],"title":c["name"],"description":c["summary"],"body":body,"icon_url":c["logo"]["url"],"downloads":c["downloadCount"],"followers":c["thumbsUpCount"],"categories":c["categories"].as_array().map(|a|a.iter().filter_map(|c|c["name"].as_str()).collect::<Vec<_>>()).unwrap_or_default(),"project_type":"mod","provider":"curseforge","website_url":format!("https://www.curseforge.com/minecraft/mc-mods/{}",urlencoding::encode(c["slug"].as_str().unwrap_or("")))}))
}
pub async fn versions(id:&str, game:Option<&str>, loader:Option<&str>)->Result<Vec<Value>> {
    let sources=sources(id).await?;let mut out=Vec::new();let mut errors=Vec::new();
    if let Some(mid)=&sources.modrinth {
        let mut params=reqwest::Url::parse(&format!("https://api.modrinth.com/v2/project/{}/version",urlencoding::encode(mid))).unwrap();
        if let Some(game)=game{params.query_pairs_mut().append_pair("game_versions",&json!([game]).to_string());}
        if let Some(loader)=loader{params.query_pairs_mut().append_pair("loaders",&json!([loader]).to_string());}
        match async {HTTP_CLIENT.get(params).send().await?.error_for_status()?.json::<Vec<Value>>().await}.await {
            Ok(list)=>for mut v in list {v["_provider"]="modrinth".into();v["_project_id"]=mid.clone().into();out.push(v)},Err(e)=>errors.push(e.to_string())
        }
    }
    if let Some(cid)=&sources.curseforge {
        let query_game=game.map(|g|format!("&gameVersion={}",urlencoding::encode(g))).unwrap_or_default();
        let query_loader=loader.and_then(loader_id).map(|n|format!("&modLoaderType={n}")).unwrap_or_default();
        let mut offset=0;
        loop {
            let list=match cf(&format!("mods/{cid}/files?pageSize=50&index={offset}{query_game}{query_loader}")).await{Ok(v)=>v,Err(e)=>{errors.push(e.to_string());break;}};
            let Some(list)=list.as_array()else{break;};
            for file in list {out.push(normalize_file(cid,file));}
            if list.len()<50||offset>=9950{break;}offset+=50;
        }
    }
    if out.is_empty()&&!errors.is_empty(){return Err(fail(&errors.join(" ")));}
    out.retain(|v|game.map_or(true,|g|v["game_versions"].as_array().is_some_and(|a|a.iter().any(|v|v==g)))&&loader.map_or(true,|l|v["loaders"].as_array().is_some_and(|a|a.iter().any(|v|v==l))));
    out.sort_by(crate::catalog_versions::compare);Ok(out)
}
fn loader_id(loader:&str)->Option<u8>{match loader {"forge"=>Some(1),"fabric"=>Some(4),"quilt"=>Some(5),"neoforge"=>Some(6),_=>None}}
fn normalize_file(cid:&str,f:&Value)->Value{
    let tags=f["gameVersions"].as_array().cloned().unwrap_or_default();
    let loaders=tags.iter().filter_map(|v|v.as_str()).map(str::to_lowercase).filter(|s|loader_id(s).is_some()).collect::<Vec<_>>();
    let games=tags.iter().filter_map(|v|v.as_str()).filter(|s|s.chars().next().is_some_and(|c|c.is_ascii_digit())).collect::<Vec<_>>();
    let sha=f["hashes"].as_array().and_then(|a|a.iter().find(|h|h["algo"]==1)).map(|h|h["value"].clone()).unwrap_or(Value::Null);
    let files=if f["downloadUrl"].as_str().is_some()&&sha.is_string()&&f["isAvailable"]!=false{json!([{"filename":f["fileName"],"url":f["downloadUrl"],"hashes":{"sha1":sha},"size":f["fileLength"],"primary":true}])}else{json!([])};
    json!({"id":format!("cf:{cid}:{}",f["id"]),"version_number":f["fileName"].as_str().unwrap_or("").trim_end_matches(".jar"),"version_type":match f["releaseType"].as_u64(){Some(1)=>"release",Some(2)=>"beta",_=>"alpha"},"date_published":f["fileDate"],"game_versions":games,"loaders":loaders,"files":files,"_provider":"curseforge","_project_id":format!("cf:{cid}"),"_fingerprint":f["fileFingerprint"]})
}
#[derive(Deserialize)]
pub struct Search {pub query:String,pub game_version:Option<String>,pub loader:Option<String>,pub sort:String,pub offset:usize,pub limit:usize,pub category:Option<String>}
#[tauri::command]
pub async fn search_mod_catalog(request:Search)->std::result::Result<Value,CommandError>{search(request).await.map_err(Into::into)}
async fn search(r:Search)->Result<Value>{
    let count=r.offset.saturating_add(r.limit.clamp(1,100)).min(1000);let mut hits=Vec::<Value>::new();let mut warning=None;
    let mut facets=vec![json!(["project_type:mod"])];if let Some(g)=&r.game_version{facets.push(json!([format!("versions:{g}")]));}if let Some(l)=&r.loader{facets.push(json!([format!("categories:{l}")]));}
    if let Some(c)=r.category.as_ref().filter(|c|!c.is_empty()){facets.push(json!([format!("categories:{c}")]));}
    let mut mr_total=0;
    let popular=r.sort=="downloads";
    let windows=if popular {vec![r.offset]}else{(0..count).step_by(100).collect::<Vec<_>>()};
    for offset in windows {
        let mut url=reqwest::Url::parse("https://api.modrinth.com/v2/search").unwrap();url.query_pairs_mut().append_pair("query",&r.query).append_pair("index",&r.sort).append_pair("facets",&json!(facets).to_string()).append_pair("limit",&(if popular {r.limit.clamp(1,100)}else{count.saturating_sub(offset).min(100)}).to_string()).append_pair("offset",&offset.to_string());
        match async {HTTP_CLIENT.get(url).send().await?.error_for_status()?.json::<Value>().await}.await {Ok(data)=>{mr_total=data["total_hits"].as_u64().unwrap_or(0)as usize;if let Some(list)=data["hits"].as_array(){for mut hit in list.clone(){hit["provider"]="modrinth".into();hits.push(hit)}}},Err(e)=>{warning=Some(format!("Modrinth: {e}"));break;}}
    }
    // Popularity is Modrinth's own rank. Version resolution still checks both providers.
    if r.sort=="downloads" {
        let selected=hits.into_iter().take(r.limit.clamp(1,100)).collect::<Vec<_>>();
        return Ok(json!({"hits":selected,"total_hits":mr_total,"total_is_estimate":false,"offset":r.offset,"limit":r.limit,
            "warning":warning,"ranking_source":"modrinth"}));
    }
    let mut cf_total=0;let mut raw_cf=Vec::new();
    let game=r.game_version.as_ref().map(|g|format!("&gameVersion={}",urlencoding::encode(g))).unwrap_or_default();let loader=r.loader.as_deref().and_then(loader_id).map(|l|format!("&modLoaderType={l}")).unwrap_or_default();
    let sort=match r.sort.as_str(){"updated"=>3,"newest"=>11,"relevance"=>1,_=>6};
    if crate::provider_keys::key().is_ok()&&r.category.as_ref().map_or(true,|c|c.is_empty()){for offset in (0..count).step_by(50){
        let response=crate::provider_keys::api_client()?.get(format!("https://api.curseforge.com/v1/mods/search?gameId=432&classId=6&searchFilter={}&sortField={sort}&sortOrder=desc&pageSize={}&index={offset}{game}{loader}",urlencoding::encode(&r.query),count.saturating_sub(offset).min(50))).header("x-api-key",crate::provider_keys::header()?).send().await;
        match response {Ok(res) if res.status().is_success()=>{let data=res.json::<Value>().await?;cf_total=data["pagination"]["totalCount"].as_u64().unwrap_or(0)as usize;if let Some(list)=data["data"].as_array(){raw_cf.extend(list.clone())}},_=>{warning=Some("CurseForge ist nicht verfügbar oder lehnt den Key ab. Modrinth-Ergebnisse bleiben verfügbar.".into());break;}}
    }}else{warning=Some(if r.category.as_ref().is_some_and(|c|!c.is_empty()) {"Der gewählte Kategoriefilter gilt nur für Modrinth. Für die gemeinsame Suche alle Kategorien wählen."}else{"Modrinth ist aktiv. Für CurseForge unter Einstellungen → Inhaltsquellen einen API-Key hinterlegen."}.into());}
    let work=raw_cf.into_iter().map(|c|async move {let mid=identify(&c).await;(c,mid)});
    use futures::StreamExt;
    let identified=futures::stream::iter(work).buffered(4).collect::<Vec<_>>().await;
    for(c,mid)in identified{crate::catalog_identity::merge(&mut hits,&c,mid);}
    let total=mr_total+cf_total-hits.iter().filter(|h|h["provider"]=="both").count();let selected=hits.into_iter().skip(r.offset).take(r.limit.clamp(1,100)).collect::<Vec<_>>();
    Ok(json!({"hits":selected,"total_hits":total.min(1000),"total_is_estimate":cf_total>0,"offset":r.offset,"limit":r.limit,"warning":warning}))
}
#[tauri::command]
pub async fn catalog_project(project_id:String)->std::result::Result<Value,CommandError>{project(&project_id).await.map_err(Into::into)}
#[tauri::command]
pub async fn catalog_versions(project_id:String,game_version:Option<String>,loader:Option<String>)->std::result::Result<Vec<Value>,CommandError>{versions(&project_id,game_version.as_deref(),loader.as_deref()).await.map_err(Into::into)}

#[tauri::command]
pub async fn catalog_version(version_id:String)->std::result::Result<Value,CommandError>{
    if let Some(rest)=version_id.strip_prefix("cf:"){
        let (cid,fid)=rest.split_once(':').ok_or_else(||fail("Ungültige CurseForge-Version."))?;
        cf_id(cid)?;cf_id(fid)?;
        let data=cf(&format!("mods/{cid}/files/{fid}")).await?;
        Ok(normalize_file(cid,&data))
    }else{mr(&format!("version/{}",urlencoding::encode(&version_id))).await.map_err(Into::into)}
}

#[cfg(test)]
mod live_popularity_tests {
    use super::*;
    #[tokio::test]
    #[ignore = "explicit live API validation only"]
    async fn popularity_matches_modrinth_first_and_deep_page() {
        for offset in [0,1020] {
            let actual=search(Search{query:String::new(),game_version:None,loader:None,sort:"downloads".into(),offset,limit:20,category:None}).await.unwrap();
            let mut url=reqwest::Url::parse("https://api.modrinth.com/v2/search").unwrap();
            url.query_pairs_mut().append_pair("index","downloads").append_pair("query","").append_pair("facets",r#"[["project_type:mod"]]"#).append_pair("offset",&offset.to_string()).append_pair("limit","20");
            let expected:Value=HTTP_CLIENT.get(url).send().await.unwrap().error_for_status().unwrap().json().await.unwrap();
            let ids=|v:&Value|v["hits"].as_array().unwrap().iter().map(|h|h["project_id"].clone()).collect::<Vec<_>>();
            assert_eq!(ids(&actual),ids(&expected));assert_eq!(actual["ranking_source"],"modrinth");assert_eq!(actual["offset"],offset);assert!(actual["total_hits"].as_u64().unwrap()>1000);
        }
    }
}
