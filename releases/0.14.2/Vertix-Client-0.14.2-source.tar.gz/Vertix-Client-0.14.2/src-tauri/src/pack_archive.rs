//! Modpack manifests and archive extraction. No network or user-profile state.
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::{collections::HashSet, fs, io::{Read, Write}, path::Path};
use zip::ZipArchive;
type Result<T> = std::result::Result<T, String>;
pub const MAX_FILE: u64 = 2 * 1024 * 1024 * 1024;
const MAX_TOTAL: u64 = 32 * 1024 * 1024 * 1024;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PackFile {
    pub path: String, pub downloads: Vec<String>, pub sha1: Option<String>,
    pub sha512: Option<String>, pub size: Option<u64>, pub optional: bool,
    pub curseforge: Option<(u64, u64)>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PackPlan {
    pub format: String, pub name: String, pub game_version: String, pub loader: String,
    pub loader_version: Option<String>, pub files: Vec<PackFile>, pub overrides: Vec<String>,
    pub skipped_server: usize,
}
pub fn safe_path(name: &str) -> bool {
    if name.is_empty() || name.starts_with('/') || name.contains(['\\', ':', '\0']) {return false;}
    name.trim_end_matches('/').split('/').all(|part| {
        let device=part.split('.').next().unwrap_or("").to_ascii_uppercase();
        !part.is_empty() && part!="." && part!=".." && !part.ends_with(['.',' ']) &&
        !part.chars().any(|c|c.is_control() || "<>\"|?*".contains(c)) &&
        !matches!(device.as_str(),"CON"|"PRN"|"AUX"|"NUL"|"COM1"|"COM2"|"COM3"|"COM4"|"COM5"|"COM6"|"COM7"|"COM8"|"COM9"|"LPT1"|"LPT2"|"LPT3"|"LPT4"|"LPT5"|"LPT6"|"LPT7"|"LPT8"|"LPT9") &&
        !part.to_ascii_lowercase().starts_with(".vertix")
    })
}
fn text(v:&Value,key:&str)->Result<String>{v[key].as_str().filter(|s|!s.trim().is_empty()).map(str::to_owned).ok_or_else(||format!("Modpack: {key} fehlt."))}
fn hash(v:&Value,key:&str,len:usize)->Result<String>{let value=text(v,key)?;if value.len()!=len||!value.bytes().all(|c|c.is_ascii_hexdigit()){return Err(format!("Ungültige {key}-Prüfsumme."));}Ok(value.to_ascii_lowercase())}
pub fn inspect(path:&Path)->Result<PackPlan>{
    let mut zip=ZipArchive::new(fs::File::open(path).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    if zip.len()>100_000 {return Err("Das Modpack enthält zu viele Dateien.".into());}
    let mut names=HashSet::new();let mut bytes=0u64;
    for i in 0..zip.len(){let entry=zip.by_index(i).map_err(|e|e.to_string())?;
        if !safe_path(entry.name()) || entry.unix_mode().is_some_and(|m|m&0o170000==0o120000){return Err(format!("Unsicherer Archivpfad: {}",entry.name()));}
        if !names.insert(entry.name().to_ascii_lowercase()){return Err("Das Archiv enthält doppelte Dateipfade.".into());}
        bytes=bytes.saturating_add(entry.size());if bytes>MAX_TOTAL||entry.size()>MAX_FILE{return Err("Das Modpack überschreitet die Importgrößenbegrenzung.".into());}
    }
    let mr=names.contains("modrinth.index.json");let cf=names.contains("manifest.json");
    if mr==cf {return Err("Erwartet wird eine Modrinth-.mrpack oder CurseForge-Modpack-ZIP mit genau einem Manifest im Hauptordner. Welt-/Ressourcen-ZIPs über Inhalte importieren.".into());}
    let mut entry=zip.by_name(if mr{"modrinth.index.json"}else{"manifest.json"}).map_err(|e|e.to_string())?;
    if entry.size()>8*1024*1024{return Err("Das Modpack-Manifest ist zu groß.".into());}
    let mut manifest=String::new();entry.read_to_string(&mut manifest).map_err(|e|e.to_string())?;
    parse(&serde_json::from_str(&manifest).map_err(|e|format!("Ungültiges Modpack-Manifest: {e}"))?,mr)
}
pub fn parse(v:&Value,mr:bool)->Result<PackPlan>{
    let mut plan=PackPlan{format:if mr{"Modrinth"}else{"CurseForge"}.into(),name:text(v,"name")?,game_version:String::new(),loader:"vanilla".into(),loader_version:None,files:Vec::new(),overrides:Vec::new(),skipped_server:0};
    if plan.name.len()>256{return Err("Der Modpack-Name ist zu lang.".into());}
    if mr {
        if v["formatVersion"]!=1||v["game"]!="minecraft"{return Err("Diese Modrinth-Formatversion oder dieses Spiel wird nicht unterstützt.".into());}
        let deps=v["dependencies"].as_object().ok_or("Minecraft-Abhängigkeiten fehlen.")?;
        plan.game_version=text(&v["dependencies"],"minecraft")?;
        for (id,version) in deps {if id=="minecraft"{continue;}let loader=match id.as_str(){"fabric-loader"=>"fabric","quilt-loader"=>"quilt","forge"=>"forge","neoforge"=>"neoforge",_=>return Err(format!("Nicht unterstützte Modpack-Abhängigkeit: {id}"))};
            if plan.loader!="vanilla"{return Err("Mehrere Modloader in einem Modpack sind nicht unterstützt.".into());}plan.loader=loader.into();plan.loader_version=Some(version.as_str().filter(|s|!s.is_empty()).ok_or("Loader-Version fehlt.")?.into());}
        plan.overrides=vec!["overrides/".into(),"client-overrides/".into()];
        let files=v["files"].as_array().ok_or("Die Modpack-Dateiliste fehlt.")?;let mut paths=HashSet::new();let mut size=0u64;
        for f in files {let path=text(f,"path")?;if !safe_path(&path)||path.ends_with('/')||!paths.insert(path.to_ascii_lowercase()){return Err(format!("Ungültiger oder doppelter Dateipfad: {path}"));}
            let client=f["env"]["client"].as_str().unwrap_or("required");if !matches!(client,"required"|"optional"|"unsupported"){return Err("Unbekannte Client-Umgebung im Modpack.".into());}
            if client=="unsupported"{plan.skipped_server+=1;continue;}
            let length=f["fileSize"].as_u64().ok_or("Dateigröße fehlt.")?;size=size.saturating_add(length);if length>MAX_FILE||size>MAX_TOTAL{return Err("Die Modpack-Downloads sind zu groß.".into());}
            let downloads=f["downloads"].as_array().ok_or("Downloadadressen fehlen.")?.iter().map(|u|u.as_str().map(str::to_owned).ok_or("Ungültige Downloadadresse.")).collect::<std::result::Result<Vec<_>,_>>()?;
            if downloads.is_empty(){return Err(format!("Keine Downloadadresse für {path}."));}
            plan.files.push(PackFile{path,downloads,sha1:Some(hash(&f["hashes"],"sha1",40)?),sha512:Some(hash(&f["hashes"],"sha512",128)?),size:Some(length),optional:client=="optional",curseforge:None});
        }
    } else {
        if v["manifestType"]!="minecraftModpack"||v["manifestVersion"]!=1{return Err("Diese ZIP ist kein unterstützter CurseForge-Modpack-Export.".into());}
        plan.game_version=text(&v["minecraft"],"version")?;
        let loaders=v["minecraft"]["modLoaders"].as_array().ok_or("Modloader-Angaben fehlen.")?;
        let primary=loaders.iter().filter(|l|l["primary"]==true).collect::<Vec<_>>();
        let chosen=if primary.len()==1{Some(primary[0])}else if primary.is_empty()&&loaders.len()<=1{loaders.first()}else{return Err("Der primäre Modloader ist nicht eindeutig.".into());};
        if let Some(loader)=chosen {let id=text(loader,"id")?;let (kind,version)=id.split_once('-').ok_or("Unbekanntes Modloaderformat.")?;
            if !matches!(kind,"fabric"|"forge"|"neoforge"|"quilt")||version.is_empty(){return Err(format!("Nicht unterstützter Modloader: {id}"));}plan.loader=kind.into();plan.loader_version=Some(version.into());}
        let overrides=v["overrides"].as_str().unwrap_or("overrides");if !safe_path(overrides){return Err("Ungültiger Overrides-Ordner.".into());}plan.overrides.push(format!("{}/",overrides.trim_end_matches('/')));
        let files=v["files"].as_array().ok_or("Dateiliste fehlt.")?;let mut ids=HashSet::new();
        for f in files {let project=f["projectID"].as_u64().filter(|n|*n>0).ok_or("CurseForge-Projekt-ID fehlt.")?;let file=f["fileID"].as_u64().filter(|n|*n>0).ok_or("CurseForge-Datei-ID fehlt.")?;
            if !ids.insert((project,file)){return Err("Doppelte CurseForge-Datei im Manifest.".into());}
            plan.files.push(PackFile{path:String::new(),downloads:Vec::new(),sha1:None,sha512:None,size:None,optional:f["required"]==false,curseforge:Some((project,file))});}
    }
    if plan.files.len()>10_000||!safe_path(&plan.game_version)||plan.game_version.contains('/')||plan.loader_version.as_ref().is_some_and(|v|!safe_path(v)||v.contains('/')){return Err("Ungültige Versionsangaben oder zu viele Dateien im Modpack.".into());}
    Ok(plan)
}
pub fn extract(path:&Path,target:&Path,plan:&PackPlan)->Result<()> {
    // inspect() validates every path, including unused server-only entries.
    inspect(path)?;
    let mut zip=ZipArchive::new(fs::File::open(path).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    for prefix in &plan.overrides {for i in 0..zip.len(){let mut entry=zip.by_index(i).map_err(|e|e.to_string())?;
        let Some(relative)=entry.name().strip_prefix(prefix).map(str::to_owned)else{continue;};if relative.is_empty()||entry.is_dir(){continue;}
        if !safe_path(&relative){return Err("Unsicherer Overrides-Pfad.".into());}
        let dest=target.join(&relative);fs::create_dir_all(dest.parent().unwrap()).map_err(|e|e.to_string())?;
        let mut output=fs::File::create(dest).map_err(|e|e.to_string())?;
        std::io::copy(&mut entry,&mut output).map_err(|e|e.to_string())?;output.flush().map_err(|e|e.to_string())?;
    }}Ok(())
}

#[cfg(test)] mod tests {
    use super::*;use serde_json::json;use zip::{ZipWriter,write::SimpleFileOptions};
    fn mr()->Value{json!({"formatVersion":1,"game":"minecraft","name":"Pack","dependencies":{"minecraft":"26.2","fabric-loader":"0.19.5"},"files":[]})}
    #[test] fn rejects_paths_and_unknown_dependencies(){for s in ["../evil","C:/a","a\\b","/a","mods/CON.jar","mods/a.jar.","mods/.vertix-managed-mods.json"]{assert!(!safe_path(s),"{s}");}let mut v=mr();v["dependencies"]["future-loader"]="1".into();assert!(parse(&v,true).is_err());}
    #[test] fn correct_client_environment_and_exact_loader(){let mut v=mr();v["files"]=json!([{"path":"mods/server.jar","env":{"client":"unsupported"}}]);let p=parse(&v,true).unwrap();assert_eq!(p.skipped_server,1);assert_eq!(p.loader_version.as_deref(),Some("0.19.5"));assert!(p.files.is_empty());}
    #[test] fn curseforge_preserves_ids_and_primary_loader(){let p=parse(&json!({"name":"CF","manifestType":"minecraftModpack","manifestVersion":1,"minecraft":{"version":"1.20.1","modLoaders":[{"id":"forge-47.4.0","primary":true}]},"files":[{"projectID":123,"fileID":456,"required":true}],"overrides":"custom"}),false).unwrap();assert_eq!(p.files[0].curseforge,Some((123,456)));assert_eq!(p.loader,"forge");assert_eq!(p.overrides,vec!["custom/"]);}
    #[test] fn client_overrides_win_and_server_overrides_are_excluded(){let t=tempfile::tempdir().unwrap();let path=t.path().join("pack.mrpack");let mut z=ZipWriter::new(fs::File::create(&path).unwrap());for (n,b) in [("modrinth.index.json",mr().to_string()),("overrides/config/a.txt","common".into()),("client-overrides/config/a.txt","client".into()),("server-overrides/config/b.txt","server".into())]{z.start_file(n,SimpleFileOptions::default()).unwrap();z.write_all(b.as_bytes()).unwrap();}z.finish().unwrap();let p=inspect(&path).unwrap();let dest=t.path().join("new");extract(&path,&dest,&p).unwrap();assert_eq!(fs::read_to_string(dest.join("config/a.txt")).unwrap(),"client");assert!(!dest.join("config/b.txt").exists());}
    #[test] fn rejects_archive_escape_even_when_not_selected(){let t=tempfile::tempdir().unwrap();let path=t.path().join("pack.zip");let mut z=ZipWriter::new(fs::File::create(&path).unwrap());z.start_file("../outside",SimpleFileOptions::default()).unwrap();z.write_all(b"bad").unwrap();z.finish().unwrap();assert!(inspect(&path).is_err());assert!(!t.path().join("outside").exists());}
}
