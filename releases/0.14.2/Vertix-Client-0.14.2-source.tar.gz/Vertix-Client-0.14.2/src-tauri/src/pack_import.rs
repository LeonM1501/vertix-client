//! User-selected archives are copied, validated and staged before profile registration.
use crate::{error::{AppError,CommandError,Result},pack_archive::{PackPlan,PackFile},state::{State,profile_state::Profile}};
use serde::Serialize;
use std::{collections::HashMap,path::{Path,PathBuf},sync::LazyLock,time::{Duration,Instant}};
use tokio::{fs,io::AsyncWriteExt};use tauri::{Emitter};use tauri_plugin_dialog::DialogExt;use uuid::Uuid;
struct Pending { directory:tempfile::TempDir, plan:PackPlan, created:Instant }
static PENDING:LazyLock<tokio::sync::Mutex<HashMap<String,Pending>>>=LazyLock::new(||tokio::sync::Mutex::new(HashMap::new()));
#[derive(Serialize)] pub struct PackPreview {pub ticket:String,pub format:String,pub name:String,pub game_version:String,pub loader:String,pub loader_version:Option<String>,pub files:usize,pub optional:usize,pub skipped_server:usize,pub curseforge_key_required:bool}
fn fail(s:impl Into<String>)->AppError{AppError::Other(s.into())}
#[tauri::command]
pub async fn choose_modpack(app:tauri::AppHandle)->std::result::Result<Option<PackPreview>,CommandError>{
    let (tx,rx)=tokio::sync::oneshot::channel();app.dialog().file().set_title("Modrinth- oder CurseForge-Modpack importieren").add_filter("Modpacks",&["mrpack","zip"]).pick_file(move|f|{let _=tx.send(f);});
    let Some(file)=rx.await.map_err(|_|fail("Dateiauswahl geschlossen."))?else{return Ok(None);};
    let source=file.into_path().map_err(|e|fail(e.to_string()))?;
    Ok(Some(preview_source(source).await?))
}
#[tauri::command]
pub async fn inspect_modpack_path(path:String)->std::result::Result<PackPreview,CommandError>{
    let path=PathBuf::from(path);
    if !path.extension().and_then(|e|e.to_str()).is_some_and(|e|e.eq_ignore_ascii_case("zip")||e.eq_ignore_ascii_case("mrpack")){return Err(fail("Wähle eine .mrpack- oder .zip-Datei.").into());}
    preview_source(path).await.map_err(Into::into)
}
async fn preview_source(source:PathBuf)->Result<PackPreview>{
    let pending=tokio::task::spawn_blocking(move||->Result<Pending>{
        if std::fs::metadata(&source)?.len()>4*1024*1024*1024{return Err(fail("Das Archiv ist größer als 4 GB."));}
        let directory=tempfile::tempdir()?;let path=directory.path().join("pack.zip");std::fs::copy(source,&path)?;
        let plan=crate::pack_archive::inspect(&path).map_err(fail)?;Ok(Pending{directory,plan,created:Instant::now()})
    }).await.map_err(|e|fail(e.to_string()))??;
    let p=&pending.plan;let ticket=Uuid::new_v4().to_string();
    let preview=PackPreview{ticket:ticket.clone(),format:p.format.clone(),name:p.name.clone(),game_version:p.game_version.clone(),loader:p.loader.clone(),loader_version:p.loader_version.clone(),files:p.files.len(),optional:p.files.iter().filter(|f|f.optional).count(),skipped_server:p.skipped_server,curseforge_key_required:p.format=="CurseForge"&&crate::provider_keys::key().is_err()};
    let mut cache=PENDING.lock().await;cache.retain(|_,p|p.created.elapsed()<Duration::from_secs(1800));if cache.len()>=4{cache.clear();}cache.insert(ticket,pending);Ok(preview)
}
#[tauri::command] pub async fn discard_modpack(ticket:String){PENDING.lock().await.remove(&ticket);}
#[tauri::command]
pub async fn add_modpack_files(app:tauri::AppHandle,ticket:String)->std::result::Result<usize,CommandError>{
    let (tx,rx)=tokio::sync::oneshot::channel();app.dialog().file().set_title("Zusätzliche Modpack-Dateien auswählen").add_filter("Minecraft-Dateien",&["jar","zip"]).pick_files(move|files|{let _=tx.send(files);});
    let Some(files)=rx.await.map_err(|_|fail("Dateiauswahl geschlossen."))?else{return Ok(0);};
    if files.len()>512{return Err(fail("Wähle höchstens 512 Dateien gleichzeitig.").into());}
    let cache=PENDING.lock().await;let pending=cache.get(&ticket).ok_or_else(||fail("Wähle das Modpack erneut."))?;let folder=pending.directory.path().join("provided");fs::create_dir_all(&folder).await.map_err(AppError::Io)?;
    let mut count=0;for file in files {let source=file.into_path().map_err(|e|fail(e.to_string()))?;let meta=fs::metadata(&source).await.map_err(AppError::Io)?;if !meta.is_file()||meta.len()>crate::pack_archive::MAX_FILE{return Err(fail("Eine zusätzliche Datei ist zu groß oder keine reguläre Datei.").into());}
        let copy=folder.join(Uuid::new_v4().to_string());fs::copy(source,&copy).await.map_err(AppError::Io)?;
        let hash=crate::utils::hash_utils::calculate_sha1(&copy).await.map_err(AppError::Io)?;let target=folder.join(hash);if target.exists(){fs::remove_file(copy).await.map_err(AppError::Io)?;}else{fs::rename(copy,target).await.map_err(AppError::Io)?;}count+=1;
    }Ok(count)
}
fn allowed(url:&reqwest::Url)->bool{
    url.scheme()=="https"&&url.port_or_known_default()==Some(443)&&url.username().is_empty()&&url.password().is_none()&&url.host_str().is_some_and(|h|matches!(h,"cdn.modrinth.com"|"github.com"|"raw.githubusercontent.com"|"gitlab.com"|"release-assets.githubusercontent.com"|"objects.githubusercontent.com")||h=="forgecdn.net"||h.ends_with(".forgecdn.net"))
}
pub(crate) fn verify_file(bytes:&[u8],file:&PackFile)->Result<()>{
    use sha1::Digest;use sha2::Sha512;
    if file.size.is_some_and(|n|n!=bytes.len() as u64)||file.sha1.as_ref().is_some_and(|s|format!("{:x}",sha1::Sha1::digest(bytes))!=*s)||file.sha512.as_ref().is_some_and(|s|format!("{:x}",Sha512::digest(bytes))!=*s){return Err(fail(format!("Prüfsumme oder Größe stimmt nicht: {}",file.path)));}Ok(())
}
async fn download(file:&PackFile,root:&Path,provided:&Path)->Result<()> {
    if let Some(hash)=&file.sha1 {let local=provided.join(hash);if local.is_file(){
        use tokio::io::AsyncReadExt;use sha1::Digest;let mut input=fs::File::open(&local).await?;let mut sha1=sha1::Sha1::new();let mut sha512=sha2::Sha512::new();let mut size=0u64;let mut buffer=vec![0u8;65536];
        loop{let n=input.read(&mut buffer).await?;if n==0{break;}size+=n as u64;sha1.update(&buffer[..n]);sha512.update(&buffer[..n]);}
        if format!("{:x}",sha1.finalize())!=*hash||file.size.is_some_and(|n|n!=size)||file.sha512.as_ref().is_some_and(|h|format!("{:x}",sha512.finalize())!=*h){return Err(fail(format!("Die zusätzliche Datei passt nicht: {}",file.path)));}
        let target=root.join(&file.path);fs::create_dir_all(target.parent().unwrap()).await?;fs::copy(local,target).await?;return Ok(());
    }}
    if file.downloads.is_empty(){let (project,id)=file.curseforge.unwrap_or_default();return Err(fail(format!("Keine API-Downloadfreigabe für {} (CurseForge {project}/{id}). Lade genau diese Datei auf CurseForge herunter und füge sie über Zusätzliche Dateien hinzu. Danach den Import erneut starten.",file.path)));}

    let target=root.join(&file.path);fs::create_dir_all(target.parent().unwrap()).await?;
    let client=reqwest::Client::builder().timeout(Duration::from_secs(180)).redirect(reqwest::redirect::Policy::custom(|a|if a.previous().len()<5&&allowed(a.url()){a.follow()}else{a.error("Unzulässige Modpack-Downloadweiterleitung")})).build()?;
    let mut last="Download nicht verfügbar.".to_string();
    for address in &file.downloads {
        let result=async {
            let url=reqwest::Url::parse(address).map_err(|_|fail("Ungültige Downloadadresse."))?;if !allowed(&url){return Err(fail("Diese Downloadquelle wird für Modpacks nicht unterstützt."));}
            let request=if crate::provider_keys::forge_cdn(&url){crate::provider_keys::download_request(address)?}else{client.get(url)};
            let mut response=request.timeout(Duration::from_secs(180)).send().await?.error_for_status()?;
            if response.content_length().is_some_and(|n|n>crate::pack_archive::MAX_FILE){return Err(fail("Modpack-Datei zu groß."));}
            // Hash while streaming; never buffer a large modpack file in RAM.
            use sha1::Digest;let mut sha1=sha1::Sha1::new();let mut sha512=sha2::Sha512::new();let mut length=0u64;
            let temp=target.with_extension(format!("vertix-download-{}",Uuid::new_v4()));let mut output=fs::File::create(&temp).await?;
            let transfer=async {while let Some(chunk)=response.chunk().await?{length+=chunk.len() as u64;if length>crate::pack_archive::MAX_FILE||file.size.is_some_and(|n|length>n){return Err(fail("Modpack-Datei überschreitet die erwartete Größe."));}sha1.update(&chunk);sha512.update(&chunk);output.write_all(&chunk).await?;}output.flush().await?;Ok::<_,AppError>(())}.await;
            drop(output);if let Err(e)=transfer{let _=fs::remove_file(&temp).await;return Err(e);}
            if file.size.is_some_and(|n|n!=length)||file.sha1.as_ref().is_some_and(|s|format!("{:x}",sha1.finalize())!=*s)||file.sha512.as_ref().is_some_and(|s|format!("{:x}",sha512.finalize())!=*s){let _=fs::remove_file(&temp).await;return Err(fail(format!("Prüfsumme oder Größe stimmt nicht: {}",file.path)));}
            fs::rename(temp,&target).await?;Ok(())
        }.await;
        match result{Ok(())=>return Ok(()),Err(e)=>last=e.to_string()}
    }Err(fail(format!("{}: {last}",file.path)))
}
async fn resolve_cf(file:&PackFile)->Result<PackFile>{
    let Some((project,id))=file.curseforge else{return Ok(file.clone());};
    let f=crate::catalog::cf(&format!("mods/{project}/files/{id}")).await?;
    if f["id"].as_u64()!=Some(id)||f["modId"].as_u64()!=Some(project)||f["isAvailable"]==false{return Err(fail(format!("CurseForge-Datei {project}/{id} ist nicht verfügbar.")));}
    let url=f["downloadUrl"].as_str().filter(|s|!s.is_empty());
    let project_info=crate::catalog::cf(&format!("mods/{project}")).await?;
    if project_info["gameId"]!=432{return Err(fail("Die CurseForge-Datei gehört nicht zu Minecraft."));}
    let folder=match project_info["classId"].as_u64(){Some(6)=>"mods",Some(12)=>"resourcepacks",Some(6552)=>"shaderpacks",_=>return Err(fail(format!("Nicht unterstützter CurseForge-Inhaltstyp in Projekt {project}.")))};
    let name=f["fileName"].as_str().filter(|n|crate::pack_archive::safe_path(n)&&!n.contains('/')).ok_or_else(||fail("Ungültiger CurseForge-Dateiname."))?;
    let sha=f["hashes"].as_array().and_then(|a|a.iter().find(|h|h["algo"]==1)).and_then(|h|h["value"].as_str()).filter(|s|s.len()==40&&s.bytes().all(|c|c.is_ascii_hexdigit())).ok_or_else(||fail("CurseForge-SHA1 fehlt."))?;
    Ok(PackFile{path:format!("{folder}/{name}"),downloads:url.map(|u|vec![u.into()]).unwrap_or_default(),sha1:Some(sha.to_ascii_lowercase()),sha512:None,size:f["fileLength"].as_u64(),optional:file.optional,curseforge:file.curseforge})
}
#[tauri::command]
pub async fn import_modpack(app:tauri::AppHandle,ticket:String,name:String,include_optional:bool)->std::result::Result<String,CommandError>{
    let pending=PENDING.lock().await.remove(&ticket).ok_or_else(||fail("Importvorschau abgelaufen. Wähle das Modpack erneut."))?;
    let result=import_pending(app,&pending,name,include_optional).await;
    if result.is_err(){PENDING.lock().await.insert(ticket,Pending{created:Instant::now(),..pending});}
    result
}
async fn import_pending(app:tauri::AppHandle,pending:&Pending,name:String,include_optional:bool)->std::result::Result<String,CommandError>{
    if name.trim().is_empty()||name.trim().len()>256{return Err(fail("Gib einen Namen mit höchstens 256 Zeichen ein.").into());}
    let _guard=crate::instance_content::CONTENT_LOCK.lock().await;let state=State::get().await?;
    let plan=pending.plan.clone();let archive=pending.directory.path().join("pack.zip");
    let files=plan.files.iter().filter(|f|!f.optional||include_optional).collect::<Vec<_>>();
    let base=crate::state::profile_state::default_profile_path();fs::create_dir_all(&base).await.map_err(AppError::Io)?;
    let stage=tempfile::Builder::new().prefix(".vertix-pack-").tempdir_in(&base).map_err(AppError::Io)?;
    let total=files.len();let mut paths=std::collections::HashSet::new();let mut download_size=0u64;
    for (index,file) in files.into_iter().enumerate(){
        let _=app.emit("vertix-pack-progress",serde_json::json!({"message":format!("Datei {} von {} herunterladen und prüfen",index+1,total),"completed":index,"total":total}));
        let file=resolve_cf(file).await?;download_size=download_size.saturating_add(file.size.unwrap_or(crate::pack_archive::MAX_FILE));if download_size>32*1024*1024*1024{return Err(fail("Modpack-Downloads überschreiten 32 GB.").into());}if !paths.insert(file.path.to_ascii_lowercase()){return Err(fail("Mehrere Modpack-Dateien haben denselben Zielpfad.").into());}download(&file,stage.path(),&pending.directory.path().join("provided")).await?;
    }
    let _=app.emit("vertix-pack-progress",serde_json::json!({"message":"Konfigurationen und Client-Dateien übernehmen","completed":total,"total":total}));
    let path=stage.path().to_path_buf();let copy_plan=plan.clone();tokio::task::spawn_blocking(move||crate::pack_archive::extract(&archive,&path,&copy_plan)).await.map_err(|e|fail(e.to_string()))?.map_err(fail)?;
    // Use a fresh UUID directory; pack names never select or overwrite an existing instance.
    let id=Uuid::new_v4();let segment=format!("{}-{}",sanitize_filename::sanitize(name.trim()).chars().take(70).collect::<String>(),id.simple());
    let mut profile:Profile=serde_json::from_value(serde_json::json!({"id":id,"name":name.trim(),"path":segment,"game_version":plan.game_version,"loader":plan.loader,"loader_version":plan.loader_version,"created":chrono::Utc::now(),"use_shared_minecraft_folder":false})).map_err(AppError::Json)?;
    profile.extra.insert("vertix_import".into(),serde_json::json!({"format":plan.format,"original_name":plan.name}));
    let destination=state.profile_manager.calculate_instance_path_for_profile(&profile)?;if destination.exists(){return Err(fail("Der neue Instanzordner existiert bereits.").into());}
    fs::rename(stage.path(),&destination).await.map_err(AppError::Io)?;
    // Register only after every required file and override has succeeded.
    state.profile_manager.create_profile(profile).await?;
    Ok(id.to_string())
}

#[cfg(test)]mod tests{use super::*;
    #[test]fn downloads_reject_local_and_credential_urls(){for s in ["http://cdn.modrinth.com/a","https://127.0.0.1/a","https://cdn.modrinth.com.evil.test/a","https://user:pass@cdn.modrinth.com/a"]{assert!(!allowed(&reqwest::Url::parse(s).unwrap()));}assert!(allowed(&reqwest::Url::parse("https://cdn.modrinth.com/data/a.jar").unwrap()));}
    #[test]fn bad_hashes_do_not_pass(){use sha1::Digest;let mut f=PackFile{path:"mods/a.jar".into(),downloads:vec![],sha1:Some(format!("{:x}",sha1::Sha1::digest(b"original"))),sha512:None,size:Some(8),optional:false,curseforge:None};assert!(verify_file(b"original",&f).is_ok());assert!(verify_file(b"modified",&f).is_err());f.size=Some(7);assert!(verify_file(b"original",&f).is_err());}
    #[tokio::test]async fn provided_files_require_exact_bytes_and_work_without_download_url(){
        use sha1::Digest;let temp=tempfile::tempdir().unwrap();let provided=temp.path().join("provided");fs::create_dir(&provided).await.unwrap();let hash=format!("{:x}",sha1::Sha1::digest(b"trusted"));
        fs::write(provided.join(&hash),b"wrong").await.unwrap();let f=PackFile{path:"mods/a.jar".into(),downloads:vec![],sha1:Some(hash.clone()),sha512:None,size:Some(7),optional:false,curseforge:Some((1,2))};
        let root=temp.path().join("instance");assert!(download(&f,&root,&provided).await.is_err());assert!(!root.join("mods/a.jar").exists());fs::write(provided.join(&hash),b"trusted").await.unwrap();download(&f,&root,&provided).await.unwrap();assert_eq!(fs::read(root.join("mods/a.jar")).await.unwrap(),b"trusted");
    }
    #[tokio::test]
    #[ignore="explicit official-provider network verification; uses only isolated temporary files"]
    async fn live_pack_download_recognition_and_curseforge(){
        use crate::instance_content::{ContentItem,InstanceSnapshot};use std::io::Write;
        let params=urlencoding::encode(r#"["26.2"]"#);let versions=crate::catalog::mr(&format!("project/sodium/version?game_versions={params}&loaders=%5B%22fabric%22%5D")).await.unwrap();
        let v=versions.as_array().unwrap().iter().find(|v|v["version_type"]=="release").unwrap();let file=v["files"].as_array().unwrap().iter().find(|f|f["primary"]==true).unwrap();
        let temp=tempfile::tempdir().unwrap();let root=temp.path().join("instance");let provided=temp.path().join("provided");
        let f=PackFile{path:"mods/my-renamed-file.jar".into(),downloads:vec![file["url"].as_str().unwrap().into()],sha1:Some(file["hashes"]["sha1"].as_str().unwrap().into()),sha512:Some(file["hashes"]["sha512"].as_str().unwrap().into()),size:file["size"].as_u64(),optional:false,curseforge:None};
        download(&f,&root,&provided).await.unwrap();let bytes=fs::read(root.join(&f.path)).await.unwrap();verify_file(&bytes,&f).unwrap();
        let mut broken=f.clone();broken.path="mods/bad.jar".into();broken.sha1=Some("0".repeat(40));assert!(download(&broken,&root,&provided).await.is_err());assert!(!root.join("mods/bad.jar").exists());
        let pack=temp.path().join("fixture.mrpack");let mut archive=zip::ZipWriter::new(std::fs::File::create(&pack).unwrap());let manifest=serde_json::json!({"formatVersion":1,"game":"minecraft","name":"Isolated pack","dependencies":{"minecraft":"26.2","fabric-loader":"0.19.5"},"files":[{"path":f.path,"downloads":f.downloads,"hashes":{"sha1":f.sha1,"sha512":f.sha512},"fileSize":f.size}]});
        for (name,data) in [("modrinth.index.json",manifest.to_string()),("overrides/config/test.cfg","common".into()),("client-overrides/config/test.cfg","client".into())]{archive.start_file(name,zip::write::SimpleFileOptions::default()).unwrap();archive.write_all(data.as_bytes()).unwrap();}archive.finish().unwrap();
        let plan=crate::pack_archive::inspect(&pack).unwrap();crate::pack_archive::extract(&pack,&root,&plan).unwrap();assert_eq!(fs::read_to_string(root.join("config/test.cfg")).await.unwrap(),"client");
        let item=ContentItem{id:"file:mods/my-renamed-file.jar".into(),kind:"mod".into(),title:"my-renamed-file.jar".into(),filename:"my-renamed-file.jar".into(),version:None,project_id:None,version_id:None,author:None,icon_url:None,enabled:true,relative_path:Some(f.path.clone()),world:None,size:bytes.len() as u64};
        let mut snapshot=InstanceSnapshot{items:vec![item],worlds:vec![],files:vec![],directory:root.to_string_lossy().into_owned(),running:false,pending_restart:false,pending_content:vec![]};
        crate::mod_identity::recognize(&root,&mut snapshot).await.unwrap();assert_eq!(snapshot.items[0].project_id.as_deref(),v["project_id"].as_str());assert_eq!(snapshot.items[0].version_id.as_deref(),v["id"].as_str());assert!(snapshot.items[0].title.to_ascii_lowercase().contains("sodium"));
        assert_eq!(fs::read(root.join(&f.path)).await.unwrap(),bytes);assert!(!root.join("mods/.vertix-managed-mods.json").exists());
        if crate::provider_keys::key().is_ok(){
            let mods=crate::catalog::cf("mods/search?gameId=432&classId=6&slug=sodium").await.unwrap();let id=mods.as_array().unwrap().iter().find(|m|m["slug"]=="sodium").unwrap()["id"].as_u64().unwrap();
            let files=crate::catalog::cf(&format!("mods/{id}/files?pageSize=50&modLoaderType=4&gameVersion=26.2")).await.unwrap();let file=files.as_array().unwrap().iter().find(|f|f["downloadUrl"].is_string()).unwrap();
            let cf=PackFile{path:String::new(),downloads:vec![],sha1:None,sha512:None,size:None,optional:false,curseforge:Some((id,file["id"].as_u64().unwrap()))};let cf=resolve_cf(&cf).await.unwrap();let cf_root=temp.path().join("cf");download(&cf,&cf_root,&provided).await.unwrap();let path=cf_root.join(&cf.path);assert_eq!(crate::utils::hash_utils::calculate_sha1(&path).await.unwrap(),cf.sha1.clone().unwrap());
            let fp=crate::utils::hash_utils::calculate_curseforge_fingerprint(&path).await.unwrap();let result=crate::provider_keys::api_client().unwrap().post("https://api.curseforge.com/v1/fingerprints/432").header("x-api-key",crate::provider_keys::header().unwrap()).json(&serde_json::json!({"fingerprints":[fp]})).send().await.unwrap().error_for_status().unwrap().json::<serde_json::Value>().await.unwrap();
            assert!(result["data"]["exactMatches"].as_array().unwrap().iter().any(|m|m["file"]["modId"]==id&&m["file"]["hashes"].as_array().unwrap().iter().any(|h|h["algo"]==1&&h["value"].as_str()==cf.sha1.as_deref())));
            println!("Live CurseForge exact-file download, SHA1 and fingerprint endpoint passed.");
        }else{println!("CurseForge live check skipped: no local key configured.");}
        println!("Pinned Modrinth download, rejected tampered hash, overrides and renamed-file recognition passed without modifying a user instance.");
    }
}
