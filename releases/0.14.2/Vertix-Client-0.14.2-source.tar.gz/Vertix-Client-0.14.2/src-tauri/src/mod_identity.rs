//! Local file recognition enriches display metadata; it never claims file ownership.
use crate::{error::{AppError,Result},instance_content::{ContentItem,InstanceSnapshot}};
use serde::{Serialize,Deserialize};use serde_json::{Value,json};use std::{collections::HashMap,path::{Path,PathBuf},time::{SystemTime,UNIX_EPOCH}};
const CACHE:&str=".vertix-mod-identities.json";
static LOCK:tokio::sync::Mutex<()>=tokio::sync::Mutex::const_new(());
#[derive(Clone,Default,Serialize,Deserialize)]struct Identity{title:Option<String>,version:Option<String>,author:Option<String>,icon:Option<String>,project:Option<String>,version_id:Option<String>}
#[derive(Clone,Serialize,Deserialize)]struct Record{size:u64,modified:u128,sha1:String,identity:Identity,checked:u64,cf_checked:bool}
type Cache=HashMap<String,Record>;
fn now()->u64{SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs()}
async fn cache(root:&Path)->Cache{tokio::fs::read(root.join(CACHE)).await.ok().and_then(|b|serde_json::from_slice(&b).ok()).unwrap_or_default()}
fn relative(item:&ContentItem)->String{item.relative_path.clone().unwrap_or_else(||format!("mods/{}{}",item.filename,if item.enabled{""}else{".disabled"}))}
async fn stamp(path:&Path)->Option<(u64,u128)>{let m=tokio::fs::symlink_metadata(path).await.ok()?;if !m.is_file()||m.file_type().is_symlink(){return None;}Some((m.len(),m.modified().ok()?.duration_since(UNIX_EPOCH).ok()?.as_nanos()))}
fn apply(item:&mut ContentItem,i:&Identity){if let Some(title)=&i.title{item.title=title.clone();}if i.version.is_some(){item.version=i.version.clone();}item.author=i.author.clone();item.icon_url=i.icon.clone();item.project_id=i.project.clone();item.version_id=i.version_id.clone();}
pub async fn apply_cached(root:&Path,snapshot:&mut InstanceSnapshot){let cache=cache(root).await;for item in &mut snapshot.items{if item.kind!="mod"||item.project_id.is_some(){continue;}let relative=relative(item);if let Some(record)=cache.get(&relative){if stamp(&root.join(&relative)).await==Some((record.size,record.modified)){apply(item,&record.identity);}}}}
/// Called only by an explicit install/update, never by recognition itself.
pub async fn local_replacement(root:&Path,aliases:&[String])->Result<Option<(String,String,bool)>>{
    let cache=cache(root).await;let mut matches=Vec::new();
    for (relative,record) in cache {if !record.identity.project.as_ref().is_some_and(|p|aliases.contains(p)){continue;}
        let Some(name)=relative.strip_prefix("mods/").filter(|n|!n.contains('/')&&!n.contains('\\'))else{continue;};
        let path=root.join(&relative);if stamp(&path).await!=Some((record.size,record.modified)){continue;}
        if crate::utils::hash_utils::calculate_sha1(&path).await?!=record.sha1{return Err(AppError::Other(format!("{name} wurde lokal verändert und bleibt erhalten.")));}
        matches.push((name.to_owned(),record.sha1,!name.ends_with(".disabled")));
    }
    if matches.len()>1{return Err(AppError::Other("Mehrere lokale Versionen derselben Mod gefunden. Entferne den Versionskonflikt vor dem Aktualisieren.".into()));}
    Ok(matches.pop())
}
fn authors(v:&Value)->Option<String>{let array=v.as_array()?;let names=array.iter().filter_map(|v|v.as_str().or_else(||v["name"].as_str())).collect::<Vec<_>>();if names.is_empty(){None}else{Some(names.join(", "))}}
pub(crate) fn embedded(path:&Path)->Identity {
    use std::io::Read;let mut result=Identity::default();
    let Ok(file)=std::fs::File::open(path)else{return result;};let Ok(mut zip)=zip::ZipArchive::new(file)else{return result;};
    for name in ["fabric.mod.json","quilt.mod.json","META-INF/neoforge.mods.toml","META-INF/mods.toml"]{
        let Ok(mut entry)=zip.by_name(name)else{continue;};if entry.size()>2*1024*1024{continue;}let mut body=String::new();if entry.read_to_string(&mut body).is_err(){continue;}
        if name.ends_with(".json"){if let Ok(v)=serde_json::from_str::<Value>(&body){let loader=if name.starts_with("quilt"){&v["quilt_loader"]}else{&v};let meta=if name.starts_with("quilt"){&loader["metadata"]}else{loader};result.title=meta["name"].as_str().map(str::to_owned);result.version=loader["version"].as_str().map(str::to_owned);result.author=authors(&meta["authors"]).or_else(||meta["contributors"].as_object().map(|m|m.keys().cloned().collect::<Vec<_>>().join(", ")));}}
        else{let read=|key:&str|regex::Regex::new(&format!(r#"(?m)^\s*{}\s*=\s*["']([^"'\r\n]+)["']"#,key)).ok().and_then(|r|r.captures(&body).map(|c|c[1].to_owned()));result.title=read("displayName");result.version=read("version").filter(|v|!v.contains("${"));result.author=read("authors");}
        if result.title.is_some(){break;}
    }result
}
pub async fn recognize(root:&Path,snapshot:&mut InstanceSnapshot)->Result<()> {
    let _guard=LOCK.lock().await;let mut cache=cache(root).await;let cf_available=crate::provider_keys::key().is_ok();
    let mut pending:Vec<(String,PathBuf,Record)>=Vec::new();
    for item in &snapshot.items {if item.kind!="mod"||item.project_id.is_some(){continue;}let relative=relative(item);let path=root.join(&relative);
        // Every caller supplies a freshly scanned, instance-local file path.
        let Some((size,modified))=stamp(&path).await else{continue;};if size>crate::pack_archive::MAX_FILE{continue;}
        if cache.get(&relative).is_some_and(|r|r.size==size&&r.modified==modified&&(r.identity.project.is_some()||now().saturating_sub(r.checked)<6*60*60&&(!cf_available||r.cf_checked))){continue;}
        let sha1=crate::utils::hash_utils::calculate_sha1(&path).await?;
        if let Some(known)=cache.values().find(|r|r.sha1==sha1&&r.identity.project.is_some()).cloned(){cache.insert(relative,Record{size,modified,..known});continue;}
        let copy=path.clone();let identity=tokio::task::spawn_blocking(move||embedded(&copy)).await.map_err(|e|AppError::Other(e.to_string()))?;
        pending.push((relative,path,Record{size,modified,sha1,identity,checked:0,cf_checked:false}));
    }
    // Batch exact SHA1 lookup: renamed files still resolve, equal titles never imply identity.
    for chunk in pending.chunks_mut(100){
        let hashes=chunk.iter().map(|(_,_,r)|r.sha1.clone()).collect::<Vec<_>>();
        let response=crate::config::HTTP_CLIENT.post("https://api.modrinth.com/v2/version_files").timeout(std::time::Duration::from_secs(25)).json(&json!({"hashes":hashes,"algorithm":"sha1"})).send().await;
        let versions=match response{Ok(r) if r.status().is_success()=>r.json::<Value>().await.ok(),_=>None};
        if let Some(versions)=versions {for (_,_,record) in chunk {record.checked=now();if let Some(v)=versions.get(&record.sha1){if let Some(id)=v["project_id"].as_str(){
            // The endpoint is indexed by exact file hash; verify the returned file too.
            if !v["files"].as_array().is_some_and(|a|a.iter().any(|f|f["hashes"]["sha1"].as_str()==Some(&record.sha1))){continue;}
            record.identity.project=Some(id.into());record.identity.version_id=v["id"].as_str().map(str::to_owned);record.identity.version=v["version_number"].as_str().map(str::to_owned);
            if let Ok(p)=crate::catalog::mr(&format!("project/{}",urlencoding::encode(id))).await{record.identity.title=p["title"].as_str().map(str::to_owned);record.identity.icon=p["icon_url"].as_str().map(str::to_owned);}
        }}}}
    }
    if cf_available {
        let mut fingerprints=HashMap::new();for (index,(_,path,record)) in pending.iter().enumerate(){if record.identity.project.is_none(){if let Ok(fp)=crate::utils::hash_utils::calculate_curseforge_fingerprint(path).await{fingerprints.entry(fp).or_insert_with(Vec::new).push(index);}}}
        for keys in fingerprints.keys().copied().collect::<Vec<_>>().chunks(100){
            let response=crate::provider_keys::api_client()?.post("https://api.curseforge.com/v1/fingerprints/432").header("x-api-key",crate::provider_keys::header()?).json(&json!({"fingerprints":keys})).send().await;
            let matches=match response{Ok(r) if r.status().is_success()=>r.json::<Value>().await.ok(),_=>None};
            if let Some(matches)=matches {for key in keys{for index in &fingerprints[key]{pending[*index].2.cf_checked=true;}}
                if let Some(exact)=matches["data"]["exactMatches"].as_array(){for matched in exact {let file=&matched["file"];let Some(fp)=file["fileFingerprint"].as_u64()else{continue;};let Some(indices)=fingerprints.get(&fp)else{continue;};let Some(project)=file["modId"].as_u64()else{continue;};let Some(id)=file["id"].as_u64()else{continue;};
                    // Murmur2 alone is not enough: a shared SHA1 must confirm the exact bytes.
                    let sha=file["hashes"].as_array().and_then(|a|a.iter().find(|h|h["algo"]==1)).and_then(|h|h["value"].as_str());
                    let info=crate::catalog::cf(&format!("mods/{project}")).await.ok();
                    for index in indices {let record=&mut pending[*index].2;if sha.map(str::to_ascii_lowercase).as_deref()!=Some(&record.sha1){continue;}record.checked=now();record.identity.project=Some(format!("cf:{project}"));record.identity.version_id=Some(format!("cf:{project}:{id}"));
                        if record.identity.version.is_none(){record.identity.version=file["displayName"].as_str().or_else(||file["fileName"].as_str()).map(str::to_owned);}
                        if let Some(p)=&info{record.identity.title=p["name"].as_str().map(str::to_owned);record.identity.icon=p["logo"]["url"].as_str().map(str::to_owned);record.identity.author=authors(&p["authors"]);}
                    }
                }}
            }
        }
    }
    for (relative,path,record) in pending {if stamp(&path).await==Some((record.size,record.modified)){cache.insert(relative,record);}}
    // Keep metadata only for files currently present. No game files are moved or removed.
    let present=snapshot.items.iter().filter(|i|i.kind=="mod").map(relative).collect::<std::collections::HashSet<_>>();cache.retain(|p,_|present.contains(p));
    crate::utils::file_utils::write_atomic(root.join(CACHE),serde_json::to_vec(&cache)?).await?;
    for item in &mut snapshot.items{if item.kind=="mod"&&item.project_id.is_none(){if let Some(record)=cache.get(&relative(item)){apply(item,&record.identity);}}}Ok(())
}

#[cfg(test)]mod tests{use super::*;use std::io::Write;
    #[test]fn local_metadata_never_guesses_remote_project(){let temp=tempfile::tempdir().unwrap();let path=temp.path().join("renamed.jar");let mut z=zip::ZipWriter::new(std::fs::File::create(&path).unwrap());z.start_file("fabric.mod.json",zip::write::SimpleFileOptions::default()).unwrap();z.write_all(br#"{"id":"sodium","name":"My Private Sodium","version":"1.2.3","authors":["Someone"]}"#).unwrap();z.finish().unwrap();let i=embedded(&path);assert_eq!(i.title.as_deref(),Some("My Private Sodium"));assert_eq!(i.author.as_deref(),Some("Someone"));assert!(i.project.is_none());}
    #[tokio::test]async fn explicit_replacement_is_hash_bound_and_multiple_versions_are_rejected(){
        let temp=tempfile::tempdir().unwrap();let root=temp.path();tokio::fs::create_dir(root.join("mods")).await.unwrap();let path=root.join("mods/old.jar");tokio::fs::write(&path,b"old").await.unwrap();let (size,modified)=stamp(&path).await.unwrap();let hash=crate::utils::hash_utils::calculate_sha1(&path).await.unwrap();let record=Record{size,modified,sha1:hash.clone(),identity:Identity{project:Some("project".into()),..Default::default()},checked:now(),cf_checked:false};let mut records=Cache::new();records.insert("mods/old.jar".into(),record.clone());tokio::fs::write(root.join(CACHE),serde_json::to_vec(&records).unwrap()).await.unwrap();
        assert_eq!(local_replacement(root,&["project".into()]).await.unwrap(),Some(("old.jar".into(),hash,true)));assert!(path.exists());assert!(!root.join("mods/.vertix-managed-mods.json").exists());
        tokio::fs::write(root.join("mods/second.jar"),b"old").await.unwrap();let (size,modified)=stamp(&root.join("mods/second.jar")).await.unwrap();records.insert("mods/second.jar".into(),Record{size,modified,..record});tokio::fs::write(root.join(CACHE),serde_json::to_vec(&records).unwrap()).await.unwrap();assert!(local_replacement(root,&["project".into()]).await.is_err());
        records.remove("mods/second.jar");tokio::fs::write(root.join(CACHE),serde_json::to_vec(&records).unwrap()).await.unwrap();tokio::fs::write(&path,b"private replacement").await.unwrap();assert!(local_replacement(root,&["project".into()]).await.unwrap().is_none());assert_eq!(tokio::fs::read(path).await.unwrap(),b"private replacement");
    }
}
