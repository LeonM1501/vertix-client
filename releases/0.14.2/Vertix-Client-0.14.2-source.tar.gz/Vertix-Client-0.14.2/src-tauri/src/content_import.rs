use std::{fs, path::Path};
use zip::{ZipArchive, ZipWriter, write::SimpleFileOptions};
type Result<T> = std::result::Result<T, String>;
pub const PENDING: &str = ".vertix-pending";
pub fn pending_entries(root: &Path) -> Vec<String> {
    let staged=root.join(PENDING);let mut names=Vec::new();
    for folder in ["mods","resourcepacks","shaderpacks"] {
        if let Ok(entries)=fs::read_dir(staged.join(folder)) {for entry in entries.flatten(){if entry.path().is_file(){names.push(entry.file_name().to_string_lossy().into_owned());}}}
    }
    if let Ok(worlds)=fs::read_dir(staged.join("saves")) {for world in worlds.flatten(){
        if world.path().join("level.dat").is_file(){names.push(format!("Welt: {}",world.file_name().to_string_lossy()));}
        else if let Ok(packs)=fs::read_dir(world.path().join("datapacks")){for pack in packs.flatten(){names.push(format!("{} → {}",world.file_name().to_string_lossy(),pack.file_name().to_string_lossy()));}}
    }}
    names.sort();names
}
#[derive(Debug, PartialEq, Eq)]
pub struct Plan { pub kind: &'static str, pub prefix: String }
fn failure(e: impl std::fmt::Display) -> String { e.to_string() }
fn safe(name: &str) -> bool {
    !name.is_empty() && !name.contains(['\\', ':', '\0']) && !name.starts_with('/') &&
        name.trim_end_matches('/').split('/').all(|s| !s.is_empty() && s != "." && s != ".." && !s.ends_with(['.', ' ']))
}
pub fn inspect(source: &Path, hint: &str) -> Result<Plan> {
    let mut zip = ZipArchive::new(fs::File::open(source).map_err(failure)?).map_err(failure)?;
    if zip.len() > 100_000 { return Err("Das Archiv enthält zu viele Dateien.".into()); }
    let mut names = Vec::new(); let mut bytes = 0u64;
    for i in 0..zip.len() {
        let entry = zip.by_index(i).map_err(failure)?;
        if !safe(entry.name()) || entry.unix_mode().is_some_and(|m|m & 0o170000 == 0o120000) { return Err("Das Archiv enthält einen unsicheren Pfad oder eine Verknüpfung.".into()); }
        bytes = bytes.saturating_add(entry.size());
        if bytes > 16 * 1024 * 1024 * 1024 { return Err("Das entpackte Archiv ist größer als 16 GB.".into()); }
        if !entry.name().starts_with("__MACOSX/") { names.push(entry.name().to_owned()); }
    }
    let worlds: Vec<_> = names.iter().filter_map(|n| n.strip_suffix("level.dat").filter(|p|p.is_empty() || p.ends_with('/'))).collect();
    if worlds.len() > 1 { return Err("Das Archiv enthält mehrere Welten. Importiere sie einzeln.".into()); }
    if let Some(prefix) = worlds.first() { return Ok(Plan {kind:"world",prefix:prefix.to_string()}); }
    for marker in ["fabric.mod.json","quilt.mod.json","META-INF/mods.toml","META-INF/neoforge.mods.toml"] {
        if names.iter().any(|n|n == marker) { return Ok(Plan {kind:"mod",prefix:String::new()}); }
    }
    let prefixes: Vec<_> = names.iter().filter_map(|n|n.strip_suffix("pack.mcmeta").filter(|p|p.is_empty() || p.ends_with('/'))).collect();
    if prefixes.len()>1 {return Err("Das Archiv enthält mehrere Pakete. Importiere sie einzeln.".into());}
    for prefix in prefixes {
        let assets = names.iter().any(|n|n.starts_with(&format!("{prefix}assets/")));
        let data = names.iter().any(|n|n.starts_with(&format!("{prefix}data/")));
        if assets && data && !matches!(hint,"resourcepack"|"datapack") { return Err("Dieses Paket enthält Ressourcen und Daten. Wähle den Inhaltstyp ausdrücklich.".into()); }
        if assets || data { return Ok(Plan {kind:if assets && (!data || hint=="resourcepack") {"resourcepack"} else {"datapack"},prefix:prefix.into()}); }
    }
    if let Some(n) = names.iter().find(|n|n.starts_with("shaders/") || n.contains("/shaders/")) {
        let position = n.find("shaders/").unwrap(); return Ok(Plan {kind:"shader",prefix:n[..position].into()});
    }
    Err("Inhalt nicht erkannt. Erwartet werden eine Mod-JAR, eine Welt mit level.dat, ein Ressourcen-/Datenpaket mit pack.mcmeta oder ein Shaderpaket.".into())
}
fn ensure_plain(path: &Path) -> Result<()> {
    for ancestor in path.ancestors() {
        if fs::symlink_metadata(ancestor).is_ok_and(|m|m.file_type().is_symlink()) { return Err("Verknüpfte Zielordner werden nicht verwendet.".into()); }
    }
    Ok(())
}
pub fn import(source: &Path, root: &Path, hint: &str, world: Option<&str>, running: bool, modded: bool) -> Result<String> {
    let plan = inspect(source,hint)?;
    if plan.kind=="mod" && !modded { return Err("Diese Datei ist eine Mod und benötigt einen Modloader.".into()); }
    let name = source.file_name().and_then(|n|n.to_str()).ok_or("Dateiname fehlt")?;
    if !safe(name) { return Err("Ungültiger Dateiname.".into()); }
    let folder = match plan.kind {
        "mod" => "mods".into(), "resourcepack"=>"resourcepacks".into(), "shader"=>"shaderpacks".into(),
        "world"=>"saves".into(),
        "datapack" => {
            let w=world.filter(|w|safe(w) && !w.contains('/')).ok_or("Datenpaket erkannt: Wähle eine vorhandene Zielwelt und importiere erneut.")?;
            if !root.join("saves").join(w).join("level.dat").is_file() { return Err("Die Zielwelt existiert nicht.".into()); }
            format!("saves/{w}/datapacks")
        }, _ => unreachable!()
    };
    let filename = if plan.kind=="world" {
        plan.prefix.trim_end_matches('/').rsplit('/').next().filter(|s|!s.is_empty()).unwrap_or_else(||source.file_stem().and_then(|n|n.to_str()).unwrap_or("Welt")).to_string()
    } else if plan.kind=="mod" { format!("{}.jar",source.file_stem().unwrap().to_string_lossy()) }
    else { format!("{}.zip",source.file_stem().unwrap().to_string_lossy()) };
    if !safe(&filename) { return Err("Ungültiger Zielname.".into()); }
    let relative=format!("{folder}/{filename}");
    let staged=root.join(PENDING).join(&relative); let active=root.join(&relative);
    if active.exists() || active.with_file_name(format!("{filename}.disabled")).exists() || staged.exists() { return Err(format!("{filename} ist bereits vorhanden. Vorhandene Inhalte bleiben erhalten.")); }
    let target=if running {staged} else {active}; ensure_plain(&target)?;
    fs::create_dir_all(target.parent().unwrap()).map_err(failure)?;
    let temp=target.parent().unwrap().join(format!(".import-{}",uuid::Uuid::new_v4()));
    let result=(|| -> Result<()> {
        if plan.kind=="world" {
            fs::create_dir(&temp).map_err(failure)?;
            let mut zip=ZipArchive::new(fs::File::open(source).map_err(failure)?).map_err(failure)?;
            for i in 0..zip.len() {
                let mut entry=zip.by_index(i).map_err(failure)?;
                let Some(relative)=entry.name().strip_prefix(&plan.prefix) else {continue;};
                if relative.is_empty() {continue;}
                let path=temp.join(relative); if entry.is_dir() {fs::create_dir_all(path).map_err(failure)?;continue;}
                fs::create_dir_all(path.parent().unwrap()).map_err(failure)?;
                let mut output=fs::File::create(path).map_err(failure)?; std::io::copy(&mut entry,&mut output).map_err(failure)?;
            }
        } else if plan.prefix.is_empty() { fs::copy(source,&temp).map_err(failure)?; }
        else {
            let mut zip=ZipArchive::new(fs::File::open(source).map_err(failure)?).map_err(failure)?;
            let mut output=ZipWriter::new(fs::File::create(&temp).map_err(failure)?);
            for i in 0..zip.len() {
                let mut entry=zip.by_index(i).map_err(failure)?;
                let Some(relative)=entry.name().strip_prefix(&plan.prefix).map(str::to_owned) else {continue;};
                if relative.is_empty() || entry.is_dir() {continue;}
                output.start_file(relative,SimpleFileOptions::default()).map_err(failure)?;
                std::io::copy(&mut entry,&mut output).map_err(failure)?;
            }
            output.finish().map_err(failure)?;
        }
        fs::rename(&temp,&target).map_err(failure)?;
        Ok(())
    })();
    if result.is_err() {
        // Only our fresh staging path is eligible for cleanup.
        if temp.is_dir() { let _=fs::remove_dir_all(&temp); } else { let _=fs::remove_file(&temp); }
    }
    result?; Ok(plan.kind.into())
}
pub fn apply_pending(root: &Path) -> Result<()> {
    let staged=root.join(PENDING);
    if !staged.exists() { return Ok(()); }
    fn merge(source:&Path,target:&Path) -> Result<()> {
        ensure_plain(source)?; ensure_plain(target)?;
        fs::create_dir_all(target).map_err(failure)?;
        for entry in fs::read_dir(source).map_err(failure)? {
            let entry=entry.map_err(failure)?;let dest=target.join(entry.file_name());
            if entry.file_type().map_err(failure)?.is_dir() { merge(&entry.path(),&dest)?; }
            else {
                ensure_plain(&entry.path())?; ensure_plain(&dest)?;
                if dest.exists() {
                    // Never overwrite a file created outside Vertix while the game ran.
                    if fs::read(&dest).map_err(failure)? != fs::read(entry.path()).map_err(failure)? { return Err(format!("Neustart-Inhalt kollidiert mit {}. Beide Dateien bleiben erhalten.",dest.display())); }
                    fs::remove_file(entry.path()).map_err(failure)?;
                } else { fs::rename(entry.path(),dest).map_err(failure)?; }
            }
        }
        fs::remove_dir(source).map_err(failure)?;Ok(())
    }
    merge(&staged,root)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    fn archive(path:&Path,entries:&[(&str,&[u8])]) {
        let mut z=ZipWriter::new(fs::File::create(path).unwrap());
        for (name,data) in entries {z.start_file(*name,SimpleFileOptions::default()).unwrap();z.write_all(data).unwrap();}z.finish().unwrap();
    }
    #[test]
    fn recognizes_nested_world_packs_and_defers_until_restart() {
        let t=tempfile::tempdir().unwrap();let root=t.path().join("instance");fs::create_dir_all(&root).unwrap();
        let world=t.path().join("world.zip");archive(&world,&[("My World/level.dat",b"level"),("My World/region/r.mca",b"region")]);
        assert_eq!(inspect(&world,"auto").unwrap().kind,"world");
        import(&world,&root,"auto",None,true,true).unwrap(); assert!(!root.join("saves/My World/level.dat").exists());
        apply_pending(&root).unwrap(); assert!(root.join("saves/My World/level.dat").exists());
        let pack=t.path().join("pack.zip");archive(&pack,&[("wrapper/pack.mcmeta",b"{}"),("wrapper/assets/a/test",b"a")]);
        assert_eq!(import(&pack,&root,"auto",None,false,true).unwrap(),"resourcepack");
        let mut normalized=ZipArchive::new(fs::File::open(root.join("resourcepacks/pack.zip")).unwrap()).unwrap();assert!(normalized.by_name("pack.mcmeta").is_ok());
        let data=t.path().join("data.zip");archive(&data,&[("pack.mcmeta",b"{}"),("data/a/function/a.mcfunction",b"say hello")]);
        assert!(import(&data,&root,"auto",None,false,true).is_err());
        assert_eq!(import(&data,&root,"auto",Some("My World"),false,true).unwrap(),"datapack");
    }
    #[test]
    fn rejects_traversal_duplicates_and_ambiguous_packs() {
        let t=tempfile::tempdir().unwrap();let a=t.path().join("bad.zip");archive(&a,&[("../outside",b"x")]);assert!(inspect(&a,"auto").is_err());
        archive(&a,&[("pack.mcmeta",b"{}"),("assets/a/x",b"x"),("data/a/x",b"x")]);assert!(inspect(&a,"auto").is_err());assert_eq!(inspect(&a,"datapack").unwrap().kind,"datapack");
    }
}
