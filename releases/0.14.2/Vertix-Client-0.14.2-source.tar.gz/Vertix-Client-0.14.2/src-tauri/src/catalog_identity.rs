use serde_json::{Value,json};
pub fn repository(value:&str)->Option<String>{
    let lower=value.to_lowercase();
    let path=lower.strip_prefix("https://github.com/")?.split(['?','#']).next()?;
    let parts=path.trim_matches('/').split('/').collect::<Vec<_>>();
    if parts.len()<2{return None;}
    let owner=parts[0];let repo=parts[1].trim_end_matches(".git");
    if owner.is_empty()||repo.is_empty()||[owner,repo].iter().any(|s|!s.chars().all(|c|c.is_ascii_alphanumeric()||"._-".contains(c))){return None;}
    Some(format!("{owner}/{repo}"))
}
pub fn same_repository(a:&Value,b:&Value)->bool{
    let source=a["source_url"].as_str().and_then(repository);
    source.is_some()&&source==b["links"]["sourceUrl"].as_str().and_then(repository)
}
/// A canonical ID is supplied only after a matching published hash/source was verified.
pub fn merge(hits:&mut Vec<Value>,c:&Value,canonical:Option<String>){
    if let Some(existing)=canonical.as_ref().and_then(|id|hits.iter_mut().find(|h|h["project_id"].as_str()==Some(id))){
        existing["curseforge_id"]=c["id"].clone();existing["provider"]="both".into();return;
    }
    let id=canonical.unwrap_or_else(||format!("cf:{}",c["id"]));
    hits.push(json!({"project_id":id,"title":c["name"],"description":c["summary"],"author":c["authors"].as_array().and_then(|a|a.first()).and_then(|a|a["name"].as_str()).unwrap_or(""),"icon_url":c["logo"]["url"],"downloads":c["downloadCount"],"provider":if id.starts_with("cf:"){"curseforge"}else{"both"},"curseforge_id":c["id"]}));
}
#[cfg(test)]mod tests{
    use super::*;
    #[test]fn duplicates_merge_but_names_and_forks_do_not(){
        let c=json!({"id":394468,"name":"Sodium","links":{"sourceUrl":"https://github.com/CaffeineMC/sodium"}});
        let m=json!({"project_id":"AANobbMI","title":"Sodium","source_url":"https://github.com/CaffeineMC/sodium.git"});
        assert!(same_repository(&m,&c));
        assert!(!same_repository(&m,&json!({"name":"Sodium","links":{"sourceUrl":"https://github.com/other/sodium"}})));
        assert!(!same_repository(&json!({"title":"Sodium"}),&c));
        assert!(repository("https://github.com.evil.test/CaffeineMC/sodium").is_none());
        let mut hits=vec![m];merge(&mut hits,&c,Some("AANobbMI".into()));assert_eq!(hits.len(),1);assert_eq!(hits[0]["provider"],"both");assert_eq!(hits[0]["title"],"Sodium");
        merge(&mut hits,&json!({"id":999,"name":"Sodium"}),None);assert_eq!(hits.len(),2);assert_eq!(hits[1]["project_id"],"cf:999");
    }
}
