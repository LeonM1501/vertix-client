use crate::{error::{AppError,CommandError,Result},options_sync::{self,Categories},state::{State,profile_state::Profile}};
use serde::{Serialize,Deserialize};
use std::collections::BTreeMap;
use uuid::Uuid;

#[derive(Clone,Default,Serialize,Deserialize)]
#[serde(default)]
pub struct SyncConfig {
    pub enabled:bool,
    pub controls_source:Option<Uuid>,
    pub video_source:Option<Uuid>,
    pub loader_sources:BTreeMap<String,Uuid>,
    pub instances:BTreeMap<Uuid,Categories>,
    #[serde(default)] pub snapshots:BTreeMap<String,BTreeMap<String,String>>,
}
fn path()->std::path::PathBuf{crate::config::standard_meta_dir().join("vertix-settings-sync.json")}
async fn load()->Result<SyncConfig>{match tokio::fs::read(path()).await{Ok(b)=>Ok(serde_json::from_slice(&b)?),Err(e)if e.kind()==std::io::ErrorKind::NotFound=>Ok(SyncConfig::default()),Err(e)=>Err(e.into())}}
async fn store(config:&SyncConfig)->Result<()>{let p=path();tokio::fs::create_dir_all(p.parent().unwrap()).await?;crate::utils::file_utils::write_atomic(p,serde_json::to_vec_pretty(config)?).await}
fn sources(config:&SyncConfig)->Vec<(String,Uuid,u8)>{let mut list=Vec::new();if let Some(id)=config.controls_source{list.push(("controls".into(),id,0));}if let Some(id)=config.video_source{list.push(("video".into(),id,2));}list.extend(config.loader_sources.iter().map(|(loader,id)|(format!("loader:{loader}"),*id,1)));list}
async fn capture(state:&State,config:&mut SyncConfig,only:Option<Uuid>)->Result<()> {
    for (key,id,group) in sources(config){
        if only.is_some_and(|other|other!=id){continue;}
        let profile=state.profile_manager.get_profile(id).await?;
        if let Some(loader)=key.strip_prefix("loader:"){if loader!=profile.loader.as_str(){return Err(AppError::Other("Die Mod-Tastenvorlage muss denselben Modloader verwenden.".into()));}}
        let root=crate::instance_content::isolated_root(state,&profile).await?;
        let body=tokio::fs::read_to_string(root.join("options.txt")).await.map_err(|_|AppError::Other(format!("{} hat noch keine gespeicherten Minecraft-Einstellungen. Starte und beende diese Instanz zuerst.",profile.name)))?;
        config.snapshots.insert(key,options_sync::select(&body,group));
    }Ok(())
}
fn values(config:&SyncConfig,profile:&Profile)->BTreeMap<String,String>{
    if !config.enabled{return BTreeMap::new();}
    let categories=config.instances.get(&profile.id).cloned().unwrap_or_else(Categories::all);
    let mut values=BTreeMap::new();
    for (key,source,_) in sources(config){
        let enabled=if key=="controls"{categories.controls}else if key=="video"{categories.video}else{categories.mod_controls&&key==format!("loader:{}",profile.loader.as_str())};
        if enabled&&source!=profile.id{if let Some(snapshot)=config.snapshots.get(&key){values.extend(snapshot.clone());}}
    }values
}
/// Called while the launch preparation owns CONTENT_LOCK, before Minecraft reads options.
pub async fn before_launch(state:&State,profile:&Profile)->Result<usize>{
    let config=load().await?;let selected=values(&config,profile);if selected.is_empty(){return Ok(0);}
    let root=crate::instance_content::isolated_root(state,profile).await?;
    if !root.join("options.txt").exists(){
        use crate::config::ProjectDirsExt;
        let game=profile.game_version.clone();let jar=crate::config::LAUNCHER_DIRECTORY.meta_dir().join("versions").join(&game).join(format!("{game}.jar"));
        let data_version=tokio::task::spawn_blocking(move||{
            use std::io::Read;
            let mut archive=zip::ZipArchive::new(std::fs::File::open(jar).ok()?).ok()?;
            let mut version=archive.by_name("version.json").ok()?;if version.size()>1024*1024{return None;}
            let mut body=String::new();version.read_to_string(&mut body).ok()?;
            serde_json::from_str::<serde_json::Value>(&body).ok()?["world_version"].as_u64()
        }).await.map_err(|e|AppError::Other(e.to_string()))?;
        if let Some(data_version)=data_version{return options_sync::seed(&root,&selected,data_version).await;}
    }
    options_sync::apply(&root,&selected).await
}
/// Capture only designated templates after the process has ended; other instances never overwrite them.
pub async fn after_exit(id:Uuid)->Result<()> {
    let _guard=crate::instance_content::CONTENT_LOCK.lock().await;
    let state=State::get().await?;let mut config=load().await?;
    if !config.enabled||!sources(&config).iter().any(|(_,source,_)|*source==id){return Ok(());}
    capture(&state,&mut config,Some(id)).await?;store(&config).await
}
#[tauri::command]
pub async fn get_settings_sync()->std::result::Result<SyncConfig,CommandError>{Ok(load().await?)}
#[tauri::command]
pub async fn save_settings_sync(mut config:SyncConfig,refresh_sources:Option<bool>)->std::result::Result<SyncConfig,CommandError>{
    let _guard=crate::instance_content::CONTENT_LOCK.lock().await;let state=State::get().await?;
    if config.loader_sources.keys().any(|k|!matches!(k.as_str(),"fabric"|"forge"|"neoforge"|"quilt")){return Err(AppError::Other("Unbekannter Modloader in der Synchronisierung.".into()).into());}
    // Snapshots supplied by the WebView are never trusted as file values.
    let previous=load().await?;let previous_sources=sources(&previous);let was_enabled=previous.enabled;
    config.snapshots=previous.snapshots;
    if config.enabled{
        let mut refresh=Vec::new();
        for (key,id,_) in sources(&config){
            if !was_enabled||refresh_sources.unwrap_or(false)||!previous_sources.iter().any(|(old,source,_)|old==&key&&*source==id)||!config.snapshots.contains_key(&key){
                crate::instance_content::ensure_stopped(&state,id).await?;refresh.push(id);
            }
        }
        refresh.sort();refresh.dedup();for id in refresh{capture(&state,&mut config,Some(id)).await?;}
    }
    store(&config).await?;Ok(config)
}
#[derive(Serialize)]pub struct ApplyReport{pub changed_options:usize,pub skipped_running:Vec<String>}
#[tauri::command]
pub async fn apply_settings_sync()->std::result::Result<ApplyReport,CommandError>{
    let _guard=crate::instance_content::CONTENT_LOCK.lock().await;let state=State::get().await?;let config=load().await?;
    let mut report=ApplyReport{changed_options:0,skipped_running:Vec::new()};
    for profile in state.profile_manager.list_profiles().await?{
        if values(&config,&profile).is_empty(){continue;}
        if crate::instance_content::ensure_stopped(&state,profile.id).await.is_err(){report.skipped_running.push(profile.name);continue;}
        report.changed_options+=before_launch(&state,&profile).await?;
    }Ok(report)
}

#[cfg(test)]mod tests{
    use super::*;
    #[test]fn loader_templates_and_instance_exceptions_are_separate(){
        let template=Uuid::new_v4();let mut p:Profile=serde_json::from_value(serde_json::json!({"name":"Forge","path":"forge","game_version":"1.20.1","loader":"forge"})).unwrap();
        let mut c=SyncConfig{enabled:true,controls_source:Some(template),video_source:Some(template),..Default::default()};
        c.loader_sources.insert("forge".into(),template);c.loader_sources.insert("fabric".into(),Uuid::new_v4());
        c.snapshots.insert("controls".into(),BTreeMap::from([("key_key.inventory".into(),"key.keyboard.e".into())]));
        c.snapshots.insert("loader:forge".into(),BTreeMap::from([("key_mute".into(),"key.keyboard.m".into())]));
        c.snapshots.insert("loader:fabric".into(),BTreeMap::from([("key_mute".into(),"key.keyboard.n".into())]));
        assert_eq!(values(&c,&p)["key_mute"],"key.keyboard.m");
        c.instances.insert(p.id,Categories{controls:true,..Default::default()});assert!(!values(&c,&p).contains_key("key_mute"));assert_eq!(values(&c,&p).len(),1);
        p.id=template;assert!(values(&c,&p).is_empty());
    }
}
