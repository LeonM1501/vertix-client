//! Minecraft options are merged by category, never copied wholesale between loaders.
use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::{collections::BTreeMap, path::Path};

#[derive(Clone, Default, Serialize, Deserialize, Debug)]
#[serde(default)]
pub struct Categories { pub controls: bool, pub mod_controls: bool, pub video: bool }
impl Categories { pub fn all() -> Self { Self { controls:true, mod_controls:true, video:true } } }

pub fn vanilla_key(key: &str) -> bool {
    let Some(key)=key.strip_prefix("key_key.") else {return false};
    matches!(key,"forward"|"back"|"left"|"right"|"jump"|"sneak"|"sprint"|"inventory"|"swapOffhand"|"drop"|"use"|"attack"|"pickItem"|"chat"|"command"|"socialInteractions"|"playerlist"|"screenshot"|"togglePerspective"|"smoothCamera"|"fullscreen"|"spectatorOutlines"|"advancements"|"saveToolbarActivator"|"loadToolbarActivator"|"quickActions")
        || key.strip_prefix("hotbar.").is_some_and(|n|matches!(n,"1"|"2"|"3"|"4"|"5"|"6"|"7"|"8"|"9"))
}
pub fn video_key(key:&str)->bool {
    matches!(key,"guiScale"|"renderDistance"|"simulationDistance"|"graphicsMode"|"fancyGraphics"|"ao"|"ambientOcclusion"|"mipmapLevels"|"biomeBlendRadius"|"renderClouds"|"clouds"|"particles"|"entityShadows"|"entityDistanceScaling"|"fov"|"fovEffectScale"|"screenEffectScale"|"darknessEffectScale"|"gamma"|"enableVsync"|"maxFps"|"bobView"|"attackIndicator"|"showSubtitles"|"hideLightningFlashes"|"highContrast"|"menuBackgroundBlurriness")
}
pub fn category(key:&str)->Option<u8>{if vanilla_key(key)||matches!(key,"mouseSensitivity"|"invertYMouse"|"mouseWheelSensitivity"|"discrete_mouse_scroll"|"toggleCrouch"|"toggleSprint"){Some(0)}else if key.starts_with("key_"){Some(1)}else if video_key(key){Some(2)}else{None}}
pub fn parse(body:&str)->BTreeMap<String,String>{body.lines().filter_map(|line|line.split_once(':').map(|(k,v)|(k.to_owned(),v.to_owned()))).collect()}
pub fn select(body:&str, group:u8)->BTreeMap<String,String>{parse(body).into_iter().filter(|(k,_)|category(k)==Some(group)).collect()}

/// Only replace options already understood by the destination Minecraft/mod version.
/// Unknown lines, resource packs, server addresses and device settings stay intact.
pub fn merge(body:&str, values:&BTreeMap<String,String>)->String {
    let newline=if body.contains("\r\n"){"\r\n"}else{"\n"};
    let mut output=body.lines().map(|line|match line.split_once(':') {Some((key,_)) if values.contains_key(key)=>format!("{key}:{}",values[key]),_=>line.to_owned()}).collect::<Vec<_>>().join(newline);
    if body.ends_with('\n'){output.push_str(newline);}output
}
pub async fn apply(root:&Path, values:&BTreeMap<String,String>)->Result<usize>{
    let path=root.join("options.txt");
    let old=match tokio::fs::read_to_string(&path).await {Ok(body)=>body,Err(e) if e.kind()==std::io::ErrorKind::NotFound=>return Ok(0),Err(e)=>return Err(e.into())};
    let new=merge(&old,values);if new==old{return Ok(0);}
    let changed=parse(&old).iter().filter(|(k,v)|values.get(*k).is_some_and(|n|n!=*v)).count();
    let backups=root.join(".vertix-options-backups");tokio::fs::create_dir_all(&backups).await?;
    tokio::fs::write(backups.join(format!("options-{}.txt",uuid::Uuid::new_v4())),old.as_bytes()).await?;
    crate::utils::file_utils::write_atomic(&path,new.as_bytes()).await?;Ok(changed)
}

/// New instances have no options file yet. A target-version stamp prevents
/// Minecraft from treating modern key names as legacy integer bindings.
pub async fn seed(root:&Path,values:&BTreeMap<String,String>,data_version:u64)->Result<usize>{
    if values.is_empty()||data_version<1519{return Ok(0);}
    let path=root.join("options.txt");if path.exists(){return apply(root,values).await;}
    tokio::fs::create_dir_all(root).await?;
    let mut body=format!("version:{data_version}\n");let mut count=0;
    for (key,value) in values {if category(key).is_some(){body.push_str(&format!("{key}:{value}\n"));count+=1;}}
    // create_new keeps another writer's freshly created file intact.
    use tokio::io::AsyncWriteExt;
    match tokio::fs::OpenOptions::new().write(true).create_new(true).open(&path).await{
        Ok(mut file)=>{file.write_all(body.as_bytes()).await?;file.sync_all().await?;Ok(count)},
        Err(e)if e.kind()==std::io::ErrorKind::AlreadyExists=>apply(root,values).await,
        Err(e)=>Err(e.into())
    }
}

#[cfg(test)]mod tests {
    use super::*;
    #[test]fn vanilla_does_not_include_mods(){assert!(vanilla_key("key_key.inventory"));assert!(vanilla_key("key_key.hotbar.9"));assert!(!vanilla_key("key_key.hotbar.10"));assert_eq!(category("key_key.voice_chat.mute"),Some(1));assert_eq!(category("soundDevice"),None);}
    #[test]fn merge_preserves_foreign_options_and_colons(){let src="key_key.inventory:key.keyboard.e\nkey_key.voice.mute:key.keyboard.m\nguiScale:3\nresourcePacks:[\"file/a:b.zip\"]\n";let dst="key_key.inventory:key.keyboard.i\r\nkey_key.other:key.keyboard.n\r\nguiScale:2\r\nresourcePacks:[]\r\n";let mut map=select(src,0);map.extend(select(src,2));assert_eq!(merge(dst,&map),"key_key.inventory:key.keyboard.e\r\nkey_key.other:key.keyboard.n\r\nguiScale:3\r\nresourcePacks:[]\r\n");}
    #[tokio::test]async fn writes_backup_only_on_change(){let tmp=tempfile::tempdir().unwrap();tokio::fs::write(tmp.path().join("options.txt"),"guiScale:2\n").await.unwrap();let values=BTreeMap::from([("guiScale".into(),"3".into())]);assert_eq!(apply(tmp.path(),&values).await.unwrap(),1);assert_eq!(apply(tmp.path(),&values).await.unwrap(),0);assert_eq!(std::fs::read_dir(tmp.path().join(".vertix-options-backups")).unwrap().count(),1);}
    #[tokio::test]async fn new_instance_gets_target_version_and_never_inherits_resources(){let tmp=tempfile::tempdir().unwrap();let values=BTreeMap::from([("key_key.inventory".into(),"key.keyboard.r".into()),("resourcePacks".into(),"unwanted".into())]);assert_eq!(seed(tmp.path(),&values,3465).await.unwrap(),1);let body=tokio::fs::read_to_string(tmp.path().join("options.txt")).await.unwrap();assert!(body.starts_with("version:3465\n"));assert!(!body.contains("resourcePacks"));assert_eq!(seed(tmp.path(),&values,3465).await.unwrap(),0);}
}
