//! Vertix authentication via the official Minecraft SISU / Xbox Live flow.
//! Uses the official Minecraft Launcher client identifier (00000000402b5328)
//! to authenticate directly with Mojang / Microsoft without 403 Forbidden errors.
use crate::config::{ProjectDirsExt, LAUNCHER_DIRECTORY};
use crate::error::{AppError, CommandError, Result};
use crate::minecraft::minecraft_auth::Credentials;
use crate::state::State;
use chrono::{Duration, Utc};
use serde::Serialize;
use tauri::{Manager, UserAttentionType, WebviewUrl, WebviewWindowBuilder};
use tokio::sync::{Mutex, Notify};
use uuid::Uuid;

pub const CLIENT_ID: &str = "00000000402b5328";
static OPERATION: Mutex<()> = Mutex::const_new(());
static CANCEL: Notify = Notify::const_new();

#[derive(Serialize)]
pub struct AccountStatus {
    pub client_id: &'static str,
    pub signed_in: bool,
    pub username: Option<String>,
    pub account_id: Option<Uuid>,
    pub accounts: Vec<AccountSummary>,
}

#[derive(Serialize)]
pub struct AccountSummary { pub id: Uuid, pub username: String, pub active: bool }

#[derive(Serialize)]
pub struct PlayerSkin { pub base64: String, pub variant: String }

#[tauri::command]
pub async fn get_vertix_skin(account_id: Uuid) -> std::result::Result<PlayerSkin, CommandError> {
    let state = State::get().await?;
    if !state.minecraft_account_manager_v2.get_all_accounts().await?.iter().any(|a| a.id == account_id) {
        return Err(failure("Dieses Konto ist nicht mehr gespeichert.").into());
    }
    let uuid = account_id.simple().to_string();
    let (base64, variant) = if let Some(skin) = state.active_skin_manager.get(&uuid).await {
        (skin.base64_data, skin.variant)
    } else {
        let (base64, variant) = tokio::time::timeout(std::time::Duration::from_secs(20),
            crate::utils::mc_utils::fetch_skin_base64_for_uuid(&uuid)).await
            .map_err(|_| failure("Der Minecraft-Skin ist gerade nicht erreichbar."))??;
        (base64, variant.to_string())
    };
    if base64.len() > 2 * 1024 * 1024 { return Err(failure("Der Minecraft-Skin ist zu groß.").into()); }
    Ok(PlayerSkin { base64, variant })
}

fn account_status(accounts: Vec<Credentials>) -> AccountStatus {
    let active=accounts.iter().find(|a|a.active).or_else(||accounts.first());
    let account_id=active.map(|a|a.id);
    AccountStatus { client_id:CLIENT_ID, signed_in:active.is_some(), username:active.map(|a|a.username.clone()), account_id,
        accounts:accounts.into_iter().map(|a|AccountSummary{id:a.id,username:a.username,active:Some(a.id)==account_id}).collect() }
}

fn failure(message: impl Into<String>) -> AppError {
    AppError::Other(message.into())
}

#[tauri::command]
pub async fn get_vertix_account() -> std::result::Result<AccountStatus, CommandError> {
    let state = State::get().await?;
    // Listing accounts must neither refresh credentials nor send tokens to the WebView.
    Ok(account_status(state.minecraft_account_manager_v2.get_all_accounts().await?))
}

#[tauri::command]
pub async fn select_vertix_account(account_id:Uuid)->std::result::Result<AccountStatus,CommandError>{
    let _guard=OPERATION.try_lock().map_err(|_|failure("Bitte die laufende Anmeldung zuerst abschließen."))?;
    State::get().await?.minecraft_account_manager_v2.set_active_account(account_id).await?;
    get_vertix_account().await
}

#[tauri::command]
pub async fn remove_vertix_account(account_id:Uuid)->std::result::Result<AccountStatus,CommandError>{
    let _guard=OPERATION.try_lock().map_err(|_|failure("Bitte die laufende Anmeldung zuerst abschließen."))?;
    let state=State::get().await?;
    state.minecraft_account_manager_v2.remove_account(account_id).await?;
    let remaining=state.minecraft_account_manager_v2.get_all_accounts().await?;
    if !remaining.iter().any(|a|a.active){if let Some(first)=remaining.first(){state.minecraft_account_manager_v2.set_active_account(first.id).await?;}}
    get_vertix_account().await
}

#[tauri::command]
pub async fn sign_out_vertix() -> std::result::Result<(), CommandError> {
    let _guard = OPERATION
        .try_lock()
        .map_err(|_| failure("Bitte die laufende Anmeldung zuerst abschließen."))?;
    let state = State::get().await?;
    if let Some(active) = state.minecraft_account_manager_v2.get_active_account().await? {
        state.minecraft_account_manager_v2.remove_account(active.id).await?;
    }
    // Remove legacy session file if present from earlier versions
    let legacy_file = LAUNCHER_DIRECTORY.root_dir().join("microsoft-session.bin");
    let _ = tokio::fs::remove_file(legacy_file).await;
    Ok(())
}

#[tauri::command]
pub fn cancel_vertix_login(app: tauri::AppHandle) {
    if let Some(window) = app.get_webview_window("signin") {
        let _ = window.close();
    }
    CANCEL.notify_waiters();
}

#[tauri::command]
pub async fn sign_in_vertix(app: tauri::AppHandle) -> std::result::Result<AccountStatus, CommandError> {
    let _guard = OPERATION
        .try_lock()
        .map_err(|_| failure("Eine Anmeldung oder Kontoprüfung läuft bereits."))?;
    let state = State::get().await?;

    let flow = state.minecraft_account_manager_v2.login_begin(None).await?;

    if let Some(existing) = app.get_webview_window("signin") {
        let _ = existing.close();
        tokio::time::sleep(std::time::Duration::from_millis(150)).await;
    }

    let external_url = flow.redirect_uri.parse().map_err(|_| {
        failure("Ungültige Weiterleitungs-URL von Microsoft.")
    })?;

    let window = WebviewWindowBuilder::new(&app, "signin", WebviewUrl::External(external_url))
        .title("Bei Minecraft anmelden")
        .always_on_top(true)
        .center()
        .inner_size(520.0, 700.0)
        .min_inner_size(400.0, 500.0)
        .build()
        .map_err(|e| failure(format!("Anmeldefenster konnte nicht geöffnet werden: {e}")))?;

    let _ = window.request_user_attention(Some(UserAttentionType::Critical));

    let start_time = Utc::now();
    let exchange = async {
        while (Utc::now() - start_time) < Duration::minutes(10) {
            match window.url() {
                Ok(current_url) => {
                    let current_url_str = current_url.as_str();
                    if current_url_str.starts_with("https://login.live.com/oauth20_desktop.srf") {
                        if let Some((_, code)) = current_url.query_pairs().find(|(k, _)| k == "code") {
                            let _ = window.close();
                            return Ok(code.to_string());
                        }
                        if let Some((_, err)) = current_url.query_pairs().find(|(k, _)| k == "error") {
                            let _ = window.close();
                            return Err(failure(format!("Microsoft-Anmeldung abgebrochen ({err}).")));
                        }
                    }
                }
                Err(_) => {
                    return Err(failure("Anmeldung durch Schließen des Fensters abgebrochen."));
                }
            }
            tokio::time::sleep(std::time::Duration::from_millis(100)).await;
        }
        let _ = window.close();
        Err(failure("Anmeldung nach 10 Minuten abgelaufen."))
    };

    let code = tokio::select! {
        res = exchange => res?,
        _ = CANCEL.notified() => {
            let _ = window.close();
            return Err(failure("Anmeldung abgebrochen.").into());
        }
    };

    state.minecraft_account_manager_v2.login_finish(&code, flow).await?;
    get_vertix_account().await
}

pub(crate) async fn credentials() -> Result<Option<Credentials>> {
    let _guard = OPERATION
        .try_lock()
        .map_err(|_| failure("Bitte die laufende Anmeldung zuerst abschließen."))?;
    let state = State::get().await?;
    state.minecraft_account_manager_v2.get_active_account().await
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn official_client_id_is_used() {
        assert_eq!(CLIENT_ID, "00000000402b5328");
    }

    #[test]
    fn account_status_serialization() {
        let status = AccountStatus {
            client_id: CLIENT_ID,
            signed_in: true,
            username: Some("TestPlayer".into()),
            account_id:None,
            accounts:Vec::new(),
        };
        let json = serde_json::to_string(&status).unwrap();
        assert!(json.contains("TestPlayer"));
        assert!(json.contains("00000000402b5328"));
    }

    #[test]
    fn summaries_choose_active_or_first_and_never_expose_credentials(){
        fn account(name:&str,active:bool)->Credentials{serde_json::from_value(serde_json::json!({"id":Uuid::new_v4(),"username":name,"access_token":"secret-access-token","refresh_token":"secret-refresh-token","expires":Utc::now(),"norisk_credentials":{"production":null,"experimental":null},"active":active})).unwrap()}
        let a=account("Alice",false);let b=account("Bob",true);let id=b.id;
        let status=account_status(vec![a.clone(),b]);assert_eq!(status.account_id,Some(id));assert_eq!(status.accounts.iter().filter(|a|a.active).count(),1);
        let json=serde_json::to_string(&status).unwrap();assert!(!json.contains("secret-"));assert!(!json.contains("access_token"));assert!(!json.contains("refresh_token"));
        assert_eq!(account_status(vec![a.clone()]).account_id,Some(a.id));assert!(!account_status(Vec::new()).signed_in);
    }
}
