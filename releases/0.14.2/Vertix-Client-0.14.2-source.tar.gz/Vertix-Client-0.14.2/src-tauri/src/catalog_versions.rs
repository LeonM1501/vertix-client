use serde_json::Value;
use std::cmp::Ordering;

fn release_key(v: &Value) -> Option<(Vec<u64>,u8,u64)> {
    let mut name=v["version_number"].as_str()?.to_lowercase();
    let mut games:Vec<&str>=v["game_versions"].as_array()?.iter().filter_map(Value::as_str).collect();
    games.sort_by_key(|s|std::cmp::Reverse(s.len()));
    for game in games {name=name.replace(game,"");}
    let re=regex::Regex::new(r"(?i)(\d+\.\d+(?:\.\d+){0,2})(?:[-.]?(alpha|beta|rc|pre)[.-]?(\d*))?").unwrap();
    let c=re.captures(&name)?;
    let mut numbers=c[1].split('.').map(|s|s.parse().unwrap_or(0)).collect::<Vec<u64>>();
    while numbers.len()>2 && numbers.last()==Some(&0){numbers.pop();}
    let stage=match c.get(2).map(|m|m.as_str()) {Some("alpha")=>0,Some("beta")=>1,Some("pre")=>2,Some("rc")=>3,_=>4};
    Some((numbers,stage,c.get(3).and_then(|m|m.as_str().parse().ok()).unwrap_or(0)))
}
fn modrinth(v:&Value)->bool {v["_provider"]!="curseforge"}
/// Ordering is newest-first; a later reupload of the same release never beats Modrinth.
pub fn compare(a:&Value,b:&Value)->Ordering {
    let stable=|v:&Value|v["version_type"]=="release";
    let release=stable(b).cmp(&stable(a));if release!=Ordering::Equal{return release;}
    let order=match(release_key(a),release_key(b)){
        (Some(x),Some(y))=>y.cmp(&x),
        _ if a["version_number"]==b["version_number"]=>Ordering::Equal,
        _=>b["date_published"].as_str().unwrap_or("").cmp(a["date_published"].as_str().unwrap_or("")),
    };
    order.then_with(||modrinth(b).cmp(&modrinth(a))).then_with(||b["date_published"].as_str().cmp(&a["date_published"].as_str())).then_with(||a["id"].as_str().cmp(&b["id"].as_str()))
}
#[cfg(test)]
mod tests {
    use super::*;use serde_json::json;
    fn version(name:&str,provider:&str,date:&str)->Value {json!({"id":name,"version_number":name,"_provider":provider,"game_versions":["1.21.1"],"version_type":"release","date_published":date})}
    #[test]fn newer_release_beats_newer_upload_and_ties_prefer_modrinth(){
        let mr=version("0.6.13","modrinth","2026-01-01");
        assert_eq!(compare(&mr,&version("sodium-fabric-0.6.13+mc1.21.1.jar","curseforge","2026-02-01")),Ordering::Less);
        assert_eq!(compare(&version("sodium-fabric-0.6.14+mc1.21.1.jar","curseforge","2025-01-01"),&mr),Ordering::Less);
        assert_eq!(compare(&mr,&version("0.6.12","curseforge","2026-12-01")),Ordering::Less);
        assert_eq!(compare(&version("0.6.13.0","curseforge","2026-02-01"),&mr),Ordering::Greater);
    }
}
