fn main() {
    // Unit-test executables also call Windows dialog code; activate Common Controls v6.
    // Tauri embeds its own manifest in the app; add this only for the test harness.
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows")
        && std::env::var_os("CARGO_FEATURE_TEST_MANIFEST").is_some() {
        if std::env::var("CARGO_CFG_TARGET_ENV").as_deref() == Ok("msvc") {
            println!("cargo:rustc-link-arg=/MANIFEST:EMBED");
            println!("cargo:rustc-link-arg=/MANIFESTDEPENDENCY:type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'");
        } else {
            // GNU clang does not accept MSVC /MANIFEST switches. Link a normal COFF resource.
            let out=std::path::PathBuf::from(std::env::var_os("OUT_DIR").unwrap());
            let manifest=out.join("test-controls.manifest");
            std::fs::write(&manifest,r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0"><dependency><dependentAssembly><assemblyIdentity type="win32" name="Microsoft.Windows.Common-Controls" version="6.0.0.0" processorArchitecture="*" publicKeyToken="6595b64144ccf1df" language="*"/></dependentAssembly></dependency></assembly>"#).unwrap();
            let rc=out.join("test-controls.rc");
            std::fs::write(&rc,format!("1 24 \"{}\"\n",manifest.display().to_string().replace('\\',"/"))).unwrap();
            let object=out.join("test-controls.o");
            let result=std::process::Command::new("windres").arg("-i").arg(&rc).arg("-O").arg("coff").arg("-o").arg(&object).status().expect("windres is required for GNU Windows test manifests");
            assert!(result.success(),"test manifest compilation failed");
            println!("cargo:rustc-link-arg={}",object.display());
        }
    }
    println!("cargo:rerun-if-env-changed=NRC_CAPTURE_RUNTIME_SHA256");
    println!("cargo:rerun-if-env-changed=NRC_CAPTURE_RUNTIME_URL");
    tauri_build::build()
}
