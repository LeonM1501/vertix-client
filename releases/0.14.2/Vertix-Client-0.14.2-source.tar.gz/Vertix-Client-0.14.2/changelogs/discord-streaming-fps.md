# Discord Streaming ohne eigenes FPS-Limit

Core 1.6.1 entfernt den separaten Streaming-FPS-Regler. Der aktivierte
Streaming-Modus verändert das Minecraft-FPS-Limit nicht und verwendet weiter
die vorhandene randlose Vollbildbehandlung. Minecrafts eigene Limits im Menü,
bei Inaktivität und für minimierte Fenster sowie das separat aktivierbare
Hintergrund-FPS-Modul bleiben bestehen.

Alte gespeicherte `stream_fps`-Werte werden beim Laden ignoriert; der
Aktivierungszustand des Moduls bleibt erhalten. Die Änderungen gelten für
Fabric 26.2 und 26.3 sowie Forge 1.20.1. Core-JARs werden vor dem Launcher
gebaut und eingebettet. Dieser Stand ist lokal vorbereitet und nicht als
Launcher-Update veröffentlicht.

Prüfung: Isolierte Fabric-Spieltests mit 120 und 200 FPS in einer Testwelt,
Streaming an und aus sowie den vorhandenen Vollbildwechseln; zusätzlich
Test einer alten Konfiguration mit aktiviertem Modul und `stream_fps:30`.
Forge-1.20.1-Entwicklungslauf prüft ebenfalls 120 und 200 FPS mit aktivem und
inaktivem Streaming. Drei Rust-Tests prüfen Core-Zuordnung und Austausch.
Der Fabric-26.3-Test bestand alle Assertions, musste aber beim anschließenden
Speichern seiner isolierten Testwelt beendet werden. Keine persönliche Welt
und kein Discord-Stream wurden dafür verwendet.
