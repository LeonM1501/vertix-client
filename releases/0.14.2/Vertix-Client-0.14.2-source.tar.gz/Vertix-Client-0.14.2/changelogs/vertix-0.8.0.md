# Vertix Client 0.8.0 / Core 1.3.0

- Eigene und manuell hinzugefügte Mods bleiben beim Synchronisieren erhalten. Übertragene alte Verwaltungslisten sind kein Grund mehr, Dateien zu entfernen. Lokal veränderte Dateien werden nicht durch einen Download überschrieben. Ein fehlgeschlagener Download entfernt keine weiterhin aktivierte Mod.
- Weitere Inhalte lassen sich während des Spielens hinzufügen. Mods werden für den nächsten Start vorbereitet, lokale Dateien und neue Pakete vorgemerkt. Vertix zeigt ausstehende Inhalte an. Entfernen, Deaktivieren und Versionswechsel der Instanz bleiben während eines laufenden Spiels gesperrt.
- Der Dateiimport erkennt Mod-JARs, Shader, Ressourcenpakete, Datenpakete und Welt-ZIPs anhand ihres Inhalts. Verschachtelte Paketordner werden normalisiert; Welten werden automatisch nach `saves` entpackt. Datenpakete erhalten eine Zielwelt. Vorhandene Dateien und Welten werden nicht überschrieben.
- Die Protokollansicht liest die vollständige `latest.log`, einschließlich Dateien über 256 KB. Erkannte Zugangstokens werden weiterhin ausgeblendet.
- Modnamen öffnen Projektseiten mit Beschreibung, Bildern, Versionsfiltern, Veröffentlichungswahl und kompatiblen Zielinstanzen. Lokale Dateien werden über ihre Prüfsumme auf Modrinth zugeordnet; eigene unveröffentlichte Mods zeigen lokale Dateiinformationen.
- Instanzbilder können aus eigenen Bildern oder Symbolen mit einem Hintergrund erstellt werden. Sie erscheinen in Bibliothek, Startseite, Instanzansicht und angehefteten Verknüpfungen. Instanzen lassen sich an die Navigation anheften.
- Alle sechs Launcher-Designs verwenden eine klarere Startseite, kompakte Instanzkarten und abgestimmte Inhaltsansichten. Anordnung und Darstellungsoptionen bleiben wählbar. Eigenes Vertix-Branding ohne Glow.
- Ingame-Modmenü mit kompakten zweispaltigen Karten, Symbolen und klaren Aktivzuständen. HUD-Anzeigen lassen sich bei geöffnetem Menü direkt verschieben. Der HUD-Editor ergänzt Raster, Einrasten, Ausrichtungslinien, Rechtsklick-Einstellungen und das Rückgängigmachen von Positionsänderungen.

Nach dem Client-Update Minecraft neu starten. Core 1.3.0 wird beim nächsten Vorbereiten einer unterstützten Fabric-Instanz mit Minecraft 26.2 oder 26.3 eingesetzt. Bereits verschwundene eigene Dateien kann das Update nicht rekonstruieren; vorhandene Sicherungen bleiben dafür nutzbar.
