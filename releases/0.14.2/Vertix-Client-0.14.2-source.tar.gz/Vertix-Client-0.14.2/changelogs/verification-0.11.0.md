# Prüfung 0.11.0

- TypeScript und bestehende UI-/Dateischutz- und Mod-Update-Prüfungen bestanden, einschließlich Downgrade-Vermeidung und Teilfehlern einer Update-Warteschlange.
- Fünf native Archivtests bestanden: Pfade und unbekannte Abhängigkeiten, Client-/Server-Auswahl, CurseForge-Datei-IDs und primärer Loader, Vorrang von Client-Overrides und Archiv-Ausbrüche.
- Vier native Importtests bestanden, einschließlich Live-Test gegen offizielle Modrinth- und CurseForge-Dienste: gepinnter Download und SHA1/SHA512, Zurückweisung falscher Hashes ohne installierte Datei, zusätzliche lokale Dateien nur bei passendem Hash, Client-Overrides, umbenannte Sodium-JAR, korrekte Versionserkennung ohne Dateiveränderung oder Eigentumsübernahme. CurseForge-Dateidownload, SHA1 und Fingerprint-Endpunkt ebenfalls erfolgreich geprüft.
- Zwei native Mod-Identitätstests bestanden: Metadaten mit bekanntem Mod-Namen erfinden keine Remote-Zuordnung; ausdrücklicher Austausch ist hashgebunden, mehrere lokale Versionen und veränderte Dateien bleiben geschützt.
- Browserprüfung des tatsächlichen Bibliotheksbuttons und Importdialogs. Vollständige Vorschau mit ausdrücklich bezeichneten Testdaten: Name ändern, optionale Dateien auswählen. Browser-Dateiaktionen gesperrt. Dies ersetzt keine Prüfung des nativen Dateidialogs oder der Registrierung im persönlichen Profilbestand.
- Persönliche Profile, Welten und installierter Client unverändert. Sämtliche Datei- und Netzwerktests in eigenen temporären Verzeichnissen. Der lokal geschützte CurseForge-Key wird nur im API-Header verwendet.
- Der Nutzer hat die optimierte Windows-Release-Kompilierung ausdrücklich abgebrochen. Auslieferung als unoptimierter Testbuild mit custom-protocol und eingebetteter Produktionsoberfläche; Debug-Symbole entfernt. Abschließende Build-/Downloadnachweise folgen unten.

Format- und API-Referenzen: https://support.modrinth.com/en/articles/8802351-modrinth-modpack-format-mrpack und https://docs.curseforge.com/rest-api/

Rohbelege unter artifacts/verification/import-0.11.0, artifacts/pack-import-live-tests.log, artifacts/pack-import-tests.log und artifacts/pack-identity-tests.log.

## Abschließender Build und Veröffentlichung

- Dev-Profil mit --features custom-protocol erfolgreich (4m33s). Eingebettete Produktionsoberfläche, kein notwendiger localhost-Server. Tauri entscheidet den Produktionsmodus über custom-protocol, unabhängig von Rust-debug_assertions. Debug-Symbole nur aus der Artefaktkopie entfernt; NSIS erfolgreich gepackt.
- EXE 103.704.064 Bytes; beide exakten Core-JARs 1.5.0 nachgewiesen. x64-DLL-Imports geprüft; libunwind.dll und WebView2Loader.dll mitgeliefert. Persönlicher Installer/Client wurde nicht ausgeführt oder ersetzt.
- Source, neues EXE und Setup gegen den lokal DPAPI-geschützten API-Key geprüft: keine Zugangsdaten enthalten. Archiv ohne .git, node_modules, target oder temporäre Artefakte.
- Öffentliches Release v0.11.0, Commit 49ed5215486e5c2a1317ef011a4af808e699cb8f, Source-Snapshot 42e2b1c2596a6a4dec1f87d363ffe7452264a24a. Workflow 39839176296 erfolgreich.
- Setup erneut öffentlich geladen: 24.172.216 Bytes, SHA-256 e7baeed23f7242cfd804f950942162195a0b77b44b00b598ca7533d00a5507ad.
- Source erneut öffentlich geladen: 4.272.480 Bytes, SHA-256 b282b112287ab22dbed413d9385d9a1e062b12ccd56da1171ae90efd7efb957b. GitHub-Asset-Digests identisch.
- Normaler GitHub-Raw-Kanal zeigte unmittelbar nach Veröffentlichung noch 0.10.1 (Cache). Gültiges neues Manifest nach Downloadprüfung kurzzeitig lokal für die 30-Sekunden-Prüfung des laufenden Clients hinterlegt; anschließend wird der vorherige Zustand wiederhergestellt. Dies ist nur eine sofortige Anzeigehilfe, das Update ist öffentlich für andere PCs verfügbar.
- Rohbelege unter artifacts/verification/release-0.11.0.
