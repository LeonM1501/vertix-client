# Prüfung 0.8.1 / Core 1.3.1

18. Oktober 2026:

- TypeScript-Prüfung und Vite-Produktionsbuild bestanden.
- Core 1.3.1 gegen die tatsächlichen Minecraft-Clientbibliotheken von 26.2 und 26.3 gebaut.
- Beide isolierten Spieltests bestanden: Modübersicht rendern, HUD bei geöffnetem Modmenü verschieben, HUD-Editor verwenden und Einstellungsfenster per Rechtsklick öffnen.
- Screenshots der neuen Tabs und des gruppierten, halbtransparenten Einstellungsfensters geprüft. Die Tests verwenden eigene Konfigurationen und eine Offline-Spielidentität, keine persönlichen Welten.
- R-Shift öffnet `VertixMenuScreen` ohne Elternfenster; ESC und Schließen führen zurück ins Spiel. Die bisherigen Modul-IDs und gespeicherten Werte bleiben unverändert.

Beim ersten Testlauf lagen mehrere Fabric-Loader-Versionen im lokalen Cache; der Test startete deshalb nicht. Das Testskript verwendet jetzt je Bibliotheksartefakt nur eine Version. Die anschließenden Läufe mit 26.2 und 26.3 waren erfolgreich.
