# Vertix Core 1.7.1 – FreeCam und Profile

Patch-Release für Vertix Client 0.14.1. Core 1.7.0-Funktionen bleiben enthalten.

- FreeCam mit Modul-Hotkey, getrennter Kameraposition und -ausrichtung sowie Unterdrückung von Angriffs-/Benutzungseingaben.
- Frei belegbare Hotkeys für Module; Belegung und Aktivzustand werden gemeinsam gespeichert.
- Profile speichern Minecraft-Videooptionen zusätzlich zu Core-Einstellungen, HUD und Tastenbelegungen.
- Performance-Profile passen Sichtweite und Entity-Reichweite nicht an. Schnell/Maximum reduzieren weiterhin Partikel, Biome Blend und bei Maximum Ambient Occlusion.
- Low-Fire kann das eigene World-Fire-Ressourcenpaket verwalten.
- Zoom und FreeCam teilen die korrigierte Mausrad-/Mausbewegungs-Anbindung; Forge-Eingaben nutzen die passenden Ereignisdaten.

Bedienung und Prüfgrenzen: [Client 0.14.1](0.14.1.md). Herkunft der Originalintegrationen: [THIRD_PARTY.md](../vertix-core-mod/THIRD_PARTY.md).
