# Vertix Core 1.7.0 – Zoom, Performance und eigene Profile

Core 1.7.0 ist Bestandteil des Vertix-Client-Updates 0.14.0. Die Installation aktualisiert die Clientdateien; persönliche Profile, Instanzen und Welten bleiben erhalten.

## Bedienung

- **Zoom:** C halten (in Minecraft umlegbar), weicher zeitbasierter Übergang. Vergrößerung 1,25–16; optionales Mausrad bis 32-fach. Ohne Mausrad bleibt die eingestellte Vergrößerung konstant. FOV und Mausempfindlichkeit in `options.txt` werden nicht umgeschrieben.
- **FPS Modus:** vorhandene Qualitätsstufen plus getrennte Schalter und Regler für Item-Renderdistanz, dichte Item-Gruppen und ihren geschützten Nahbereich, TNT-Renderdistanz, Partikelentfernung und Partikelbudget. „Grafik anpassen“ lässt sich ausschalten, um nur die zusätzlichen Render-Optimierungen zu nutzen. FPS-Limit/VSync bleiben Minecrafts Einstellungen.
- **Crystal Optimizer:** separates Modul für Kristall-Reichweite, kosmetische Beams und Sockel sowie ein eigenes Limit für Explosionspartikel. Das Partikellimit gilt auch für TNT und lässt sich ausschalten. Nahe Kristalle innerhalb von 16 Blöcken bleiben sichtbar. Keine Änderungen an Trefferberechnung, Platzierung, Schaden oder Server-Simulation.
- **Eigene Profile:** R-Shift → Profile → Name eingeben → Speichern. Es werden alle Core-Modulzustände, Einstellungen, HUD-Positionen und die Minecraft-Tastenbelegungen gespeichert. „Tasten“ öffnet die Steuerung; anschließend das Profil speichern. Ein vorhandener Name aktualisiert das Profil. Anklicken lädt es, „x“ entfernt es. Normal/PvP/Performance bleiben als Vorlagen erhalten.
- **Session HUD:** „Session-Timer“ unabhängig von Ping, Tempo und Uhrzeit ausschaltbar. Sind alle Zeilen aus, wird kein leerer Kasten angezeigt.
- **Potion Timer:** echte Effekt-Icons mit Restsekunden direkt darunter, horizontal oder vertikal. Keine Listenbox. Doppelte Vanilla-HUD-Icons werden ausgeblendet, solange das Modul aktiv ist.
- **Darstellung:** global Vertix, Minecraft-Rahmen oder Transparent. Jedes HUD-Modul bietet unter Darstellung → Stil eine eigene Überschreibung. Transparenter Text erhält einen Schatten; Inhalte und interaktive Bedienelemente bleiben sichtbar. Der HUD-Editor zeigt weiterhin Positionshilfen.
- **AppleSkin:** unveränderte Original-Mod, standardmäßig an. Tooltip, Sättigung, Nahrungsvorschau, Erschöpfung und Heilungsvorschau direkt im Core schaltbar.
- **Gamma Utils:** auf Fabric unveränderte Original-Mod, im Core schaltbar und mit Helligkeitsregler. Forge 1.20.1 verwendet eine native Lichtmap-Anbindung.
- **TotemCounter von uku:** auf Fabric unverändertes Original für Pop-Zählung/Nametags/Tab, mit eigenem gestaltbaren Core-HUD für Inventarzahl und eigene Pops. Forge verwendet einen eigenen Paket-/Inventarzähler.
- **Enchantment Outlines / Glowing Glints:** eigenes Modul. Lädt das Originalpack bei der ersten Aktivierung von Modrinth, prüft SHA-512 und aktiviert nur die eigene Pack-Datei. Ausschalten entfernt die Auswahl, nicht die Datei oder andere Ressourcenpakete. Minecraft 1.20.1 braucht zusätzlich passende CIT-Unterstützung.
- **Low Fire, Low Totem, Low Shield:** drei getrennte Module mit eigenem Regler. Nur die betreffende Ego-Darstellung wird abgesenkt beziehungsweise die Totem-Animation verkleinert. Schwertschwingen und normale schwebende/rotierende Item-Modelle bleiben unverändert.

## Was intern optimiert wird

Die Entscheidung fällt vor der Entity-Modellaufbereitung. Gleiche Item-Stacks außerhalb des Nahbereichs werden innerhalb kleiner räumlicher Zellen durch ein echtes Item-Modell vertreten; unterschiedliche Komponenten, Namen und Verzauberungen bleiben getrennt. Die Entities werden nicht gelöscht, zusammengeführt oder serverseitig verändert. Innerhalb von standardmäßig acht Blöcken bleiben alle Items darstellbar; dieser Abstand lässt sich für stärkere Optimierung reduzieren. Entfernungen und Budgets werden einmal pro Tick gelesen, statt für jede Entity die Module und Einstellungen erneut zu durchsuchen.

Das Partikelbudget greift vor Konstruktion und Aufnahme der Partikel: Dadurch entfällt auch spätere Tick-Arbeit. TNT-Renderdistanz beschränkt ausschließlich Modelle; Explosionen und Blockänderungen laufen regulär weiter. Es werden weder Gameplay-Ticks ausgesetzt noch Item-Physik oder Waffenanimationen durch Marvins Verhalten ersetzt.

## Speicherung und Herkunft

Profile bleiben in der gemeinsamen Core-Konfiguration und ihrer Instanzkopie erhalten. UTF-8 wird explizit verwendet. Speichern nutzt eine eindeutige temporäre Datei und ersetzt die Konfiguration atomar; die alte Datei wird nicht mehr vorher gelöscht. Ein fehlgeschlagener Profilspeichervorgang zeigt einen Fehler statt einer Erfolgsmeldung. HUD-Positionen werden bei einer vorübergehenden Auflösungsänderung nicht automatisch überschrieben.

Die Original-JARs und benötigten Bibliotheken sind versionsgebunden, mit SHA-512 im Integrationsmanifest dokumentiert und tragen ihre ursprünglichen Lizenzinformationen. Details: [THIRD_PARTY.md](../vertix-core-mod/THIRD_PARTY.md). Das Ressourcenpaket wird nicht in Vertix weiterverteilt. Marvins JAR wurde nur als lokale Funktionsreferenz gelesen; kein Code und keine anderen Funktionen werden daraus eingebettet. Eine parallel installierte Marvin-Mod kann ihre eigenen Animationen weiterhin verändern.

## Prüfung und Grenzen

- Fabric 26.2: isolierte Offline-Welt mit Java/JIT, 25 Module, Profile samt unterschiedlichen Tastenbelegungen und Unicode-Namen, Speichern/Laden/Löschen, fehlgeschlagener atomarer Schreibvorgang, Stil-Überschreibung ohne Kontext-Leck, AppleSkin-/Gamma-Utils-/TotemCounter-Anbindung und beide Zoom-Arten bestanden. Auch mit bereits vorhandenen identischen AppleSkin- und Fabric-API-JARs gestartet.
- 1.500 Item-Entities, unterschiedliche benannte Items und Nahbereichsschutz geprüft; mehr als 1.400 zusätzliche Modelle übersprungen. Von 400 angefragten Rauchpartikeln werden höchstens 128 erzeugt. 32 sichtbare TNT-Modelle sowie acht echte serverseitige TNT-Explosionen in einer separaten Testwelt. Screenshots von Minecraft-Menü, transparentem HUD und verzaubertem Schwert mit Originalpack.
- Framezeiten werden bei unveränderten Grafikwerten in zwei Aus/An-Vergleichen erfasst. Die Messungen schwanken; einzelne frühe Durchläufe waren deutlich schneller, andere leicht langsamer. Ein bestimmter FPS-Gewinn wird daraus nicht zugesagt. Die belegte Reduktion von Modellen und Partikeln bleibt davon getrennt.
- Forge 1.20.1: Menütest mit 25 Modulen, AppleSkin-Schalter, Profilen, umgelegter Menütaste, HUD-Platzhaltern und Speicherung bestanden. Drei Launcher-Tests zu Installation, Upgrade und Erhalt fremder Dateien bestanden.
- Fabric 26.3: Core-Prüfungen und Aktivieren/Deaktivieren des Originalpacks im Menü sowie Aktivierung in einer Offline-Welt mit deaktiviertem JIT bestanden. Der normale JIT-Teststart stürzte in dieser Testumgebung auch ohne Vertix Core und mit zwei Java-Laufzeiten nativ ab. Die Ursache ist nicht geklärt; die normale Laufzeit ist damit nicht abschließend geprüft.
- Keine Veröffentlichung, kein Test mit dem vollständigen persönlichen Modpack oder einem Multiplayer-Server. Keine Zusage FPS-neutraler TNT-Mengen: Serverberechnung, Chunk-Neuaufbau und andere Mods können weiterhin Last verursachen.

Reproduzierbar mit `scripts/test-streaming.ps1 -TestClass CoreExpansionRuntimeTest` für Fabric und Forge `runClient -Psmoke`. Alle Welt-, Profil- und Download-Dateien dieser Läufe liegen unter den isolierten Testverzeichnissen, nicht in persönlichen Instanzen.
