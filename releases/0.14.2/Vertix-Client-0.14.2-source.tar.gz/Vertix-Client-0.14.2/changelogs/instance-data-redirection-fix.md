# Lokaler Datenabgleich am 25.10.2026

Ursache der wechselnden Instanzinhalte war eine Windows-AppData-Umleitung
zwischen dem normalen Windows-Start und dem Start aus dem Codex-Kontext.
`GetFinalPathNameByHandleW` zeigte bei gleichem sichtbarem Pfad verschiedene
Dateiablagen: normale Roaming-Daten und den privaten Codex-LocalCache.
Die Datenbank lag im normalen Ordner; unter anderem ihre WAL-/SHM-Dateien,
Instanzdateien, Einstellungen und Logs konnten im privaten Bereich liegen.
Das war ein lokales Ablageproblem; kein nachgewiesener automatischer
Löschvorgang durch den Mod-Synchronisierer.

## Durchgeführte Reparatur

- Vertix und das für die Diagnose gestartete Minecraft beendet.
- Reparatur außerhalb der umgeleiteten Dateisicht über Windows Explorer ausgeführt.
- Normale Datenbank und vorhandene Zielinstanzen vorher gesichert.
- Fehlende Dateien von Test, 26.2 und CPVP und PVP aus der privaten Ablage
  übernommen; 998 Dateien kopiert und gegen SHA256 verglichen.
- Bei CPVP die ursprünglichen Optionen und Mod-Konfigurationen aus der
  erhaltenen privaten Ablage wiederhergestellt. Der neuere zurückgesetzte
  Stand bleibt in der Sicherung. Andere Dateikonflikte nach Änderungszeit
  entschieden; beide Ausgangsstände bleiben erhalten.
- Globale Vertix-Core-Einstellungen aus der erhaltenen Ablage übernommen.
- Den bisherigen privaten `LocalCache/Roaming/vertix`-Ordner umbenannt und
  dort eine NTFS-Verzeichnisverbindung zur normalen Roaming-Vertix-Ablage
  angelegt. Damit verwenden beide Dateisichten denselben Speicherort,
  einschließlich neu angelegter Dateien und SQLite-Begleitdateien.
- Keine Konto-/Token-Dateien kopiert, kein Installer oder Release ersetzt.

Normale Daten bleiben unter `%APPDATA%/vertix`.
Sicherung: `%APPDATA%/vertix/backups/Dateiabgleich-20261025-230316`.
Die private Ausgangsablage liegt unverändert neben der Verbindung unter
`%LOCALAPPDATA%/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Roaming/vertix-vor-abgleich-20261025-230316`.
Diese lokalen Sicherungen enthalten persönliche Spieldaten und gehören nicht
in Source-Archive oder Releases. Die Verbindung nicht durch einen neuen
unabhängigen Ordner ersetzen: Das würde wieder zwei Dateistände erzeugen.

## Nachweise

Unter `artifacts/instance-data-repair` liegen die lokalen Diagnose- und
Reparaturberichte. Vorher wurden die voneinander abweichenden Dateisichten
mit physischen Handle-Pfaden belegt. Nachher bestanden die SQLite-
Integritätsprüfung und ein Schreib-/Lesetest über beide Startkontexte:
Die neu angelegte Testdatei wurde auch aus dem normalen Windows-Prozess
gesehen und anschließend wieder entfernt. Die physischen Pfade zeigen
jetzt auf die normale Roaming-Ablage.

Der über Windows Explorer gestartete installierte Client zeigte alle drei
Instanzen. Der anschließend darüber gestartete CPVP-Client lud sowohl
`marvin_pvp_enhancements` als auch `file/texturepack_dark_ui_clean_v4.zip`.
Vorher-/Nachhervergleich von 29 Mod-, Pack- und Konfigurationsdateien:
keine Datei fehlte, Mod-JARs und Ressourcenpaket blieben bytegleich.
Nur das Verwaltungsmanifest und die von der PvP-Mod geschriebene
Koordinatenstatusdatei änderten sich. SQLite blieb integer. Die Prüfung
erfolgte bis zum Spielmenü; keine persönliche Welt und kein Server wurden
für diesen Test betreten. `game-verification.json` hält das Ergebnis fest.

Die lokale Source-Arbeitskopie wurde zuvor per Fast-Forward auf den zu
Client 0.13.0 gehörenden Stand `eda0755` gebracht. Der vorher lokal
geänderte Projektkontext war bereits bytegleich mit diesem Stand und
wurde zusätzlich im Git-Stash erhalten. Es waren keine Änderungen am
Launcher-Programmcode und kein neuer Build erforderlich.
