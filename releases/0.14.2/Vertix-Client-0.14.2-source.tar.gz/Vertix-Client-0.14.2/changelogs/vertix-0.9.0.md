# Vertix Client 0.9.0 – vorbereiteter Stand

- Gemeinsame Suche nach Mods auf Modrinth und CurseForge, einschließlich Minecraft- und Modloader-Filtern. Ressourcenpakete, Shader und Datenpakete verwenden weiterhin Modrinth.
- Doppelte Projekte werden über gemeinsame veröffentlichte Datei-Prüfsummen oder eine übereinstimmende GitHub-Projektquelle zugeordnet. Gleiche Namen allein reichen nicht: eigenständige Mods und Forks bleiben getrennt.
- Die automatische Auswahl vergleicht kompatible Veröffentlichungen. Neuere Mod-Versionen haben Vorrang vor späteren Uploads einer älteren Version; bei gleicher Version wird Modrinth bevorzugt. Die bestehende Bevorzugung stabiler Releases bleibt erhalten.
- Projektseiten, Installationsauswahl und automatische Mod-Updateprüfung verwenden dieselbe gemeinsame Versionsliste. Beim Wechsel der Quelle wird der bisherige Profileintrag ersetzt, statt eine zweite Kopie hinzuzufügen. Der aktivierte/deaktivierte Profilstatus bleibt erhalten.
- CurseForge API-Key unter Einstellungen → Inhaltsquellen prüfen und speichern. Windows-DPAPI bindet die gespeicherte Datei an das Benutzerkonto. Weder Profile noch Source, Installer oder Download-URLs enthalten den Key. API- und CDN-Anfragen verwenden den vertraulich markierten HTTP-Header; Weiterleitungen dürfen den Key nicht auf fremde Hosts übertragen.
- Wenn CurseForge nicht verfügbar ist, bleibt die Modrinth-Suche nutzbar. Fehlende oder nicht freigegebene CurseForge-Downloads werden nicht durch erratene CDN-Adressen ersetzt.

Noch nicht veröffentlicht: CurseForge hat den für die Live-Prüfung bereitgestellten Key mit HTTP 403 abgewiesen. Ein authentifizierter CurseForge-Download und ein vollständiger Installationstest über beide Plattformen sind deshalb noch offen. Core bleibt unverändert bei 1.3.1.
