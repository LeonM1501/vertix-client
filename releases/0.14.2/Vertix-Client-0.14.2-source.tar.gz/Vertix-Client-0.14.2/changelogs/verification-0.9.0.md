# Prüfstand 0.9.0 / Core 1.4.0 — veröffentlicht am 22. Oktober 2026

- TypeScript-Prüfung und Vite-Produktionsbuild erfolgreich.
- Native Rust-Prüfung erfolgreich.
- Nativer Windows-Release-Build und NSIS-Installer erfolgreich erstellt. PE-Importprüfung bestanden; benötigte x64-DLLs liegen dem Installer bei. Zugangsdatenprüfung für Source, Frontend-Bundle und EXE bestanden.
- Neun native Regressionstests erfolgreich: bestehender Mod-/Import-/Logschutz plus echte Produktionsfunktionen zur Projektzusammenführung und Versionssortierung. Gleiche Projektnamen mit verschiedenen Quellen bleiben getrennt; Sodium mit verifizierter Zuordnung erscheint einmal. Neue Versionen schlagen ältere Reuploads; gleiche Versionen bevorzugen Modrinth.
- Beim abschließenden Wiederholen bestanden neun native Regressionen sowie alle Skripte für Darstellung/RAM, Kompatibilität, Mod-Updates, Instanzbilder, Beschreibungen und Katalog-Routing.
- Bestehende Frontend-Kompatibilitäts-, Mod-Update-, Beschreibungs- und Instanzbildtests erfolgreich. Zusätzliche Updatefälle für plattformübergreifende Gleichstände und Downgrade-Vermeidung erfolgreich.
- `node scripts/test-catalog-routing.cjs`: gemeinsame Desktop-Such-/Projekt-/Versionsbefehle, plattformgetrennte IDs und gemeinsame Profil-ID, unveränderter Ressourcenpaket-Weg sowie Passwortfeld ohne Credentials in Suchanfragen geprüft.
- Historischer Stand vom 19. Oktober: Der damalige Key wurde mit HTTP 403 abgelehnt. Am 22. Oktober wurde ein neuer freigeschalteter Key erfolgreich gegen `GET /v1/games/432` geprüft (HTTP 200) und ausschließlich lokal mit Windows DPAPI CurrentUser unter `%APPDATA%/vertix/providers/curseforge.bin` gespeichert. Kein Key im Source, Report oder Build.
- Live-Prüfung am 22. Oktober: Suchabfrage erfolgreich; Sodium über exakten Slug gefunden (Projekt 394468), fünf kompatible Fabric-Dateien für Minecraft 1.21.1 abgefragt. Autorfreigegebener Testdownload `sodium-fabric-0.8.13+mc1.21.1.jar` (Datei 8756581, 1.574.609 Bytes) über eine erlaubte HTTPS-Weiterleitung innerhalb forgecdn.net erfolgreich. SHA-1 gegen API-Metadaten bestätigt: `003c114c85ca88ef3362e018deb6aca0c682d6a1`.
- Nachweis: `artifacts/verification/curseforge-live-2026-10-22/report.json` und die heruntergeladene Test-JAR. Direkte Live-API-/CDN-Prüfung mit lokal entschlüsseltem Key; keine Installation in eine persönliche Instanz und kein zusätzlicher Nachweis des vollständigen zusammengeführten Katalog-UI-Ablaufs.

Es wurden keine persönlichen Instanzen, Welten oder installierten Programmdateien verändert. Der vorbereitete Installer wird separat unter `artifacts/releases/0.9.0` gebaut; das öffentliche Update-Manifest bleibt bei 0.8.1. Auch die erfolgreiche API-Prüfung veröffentlicht kein Update; Core 1.4.0 ist weiterhin nur lokal vorbereitet.

## Abschließende Live-Katalogprüfung

Öffentliche Projekt-/Versionsantworten beider Anbieter für Sodium wurden am 22. Oktober separat gesichert. Das manuelle Beispiel `scripts/native-content-tests/examples/catalog_live.rs` prüfte die tatsächlichen Produktionsfunktionen `catalog_identity` und `catalog_versions` gegen diese Daten: identische verifizierte GitHub-Source, genau ein gemeinsamer Sodium-Treffer, 44 Versionsdateien und bei gemeinsamem SHA-1 der obersten Version Vorrang für Modrinth (`mc1.21.1-0.8.13-fabric`). Nachweis unter `artifacts/verification/curseforge-live-2026-10-22/catalog-result.log`; keine Zugangsdaten im Fixture. Der vollständige WebView-Ablauf wurde hierdurch nicht simuliert.

Der frisch gebaute Release bindet die bereits unter 26.2 und 26.3 geprüften Core-1.4.0-JARs ein. Details und ein zusätzlicher nativer Java-Laufzeitabsturz während der Entwicklungsprüfung: `verification-core-1.4.0.md`. Bestehender UI-Test unter 26.2 und kompletter 26.3-Test ohne JIT waren ebenfalls erfolgreich. Das Update ändert keine produktiven Java-Argumente.

Die Windows-Buildroutine berücksichtigt jetzt `CARGO_TARGET_DIR`, damit sie bei externem Buildcache genau das frisch gebaute EXE kopiert.

## Veröffentlichung bestätigt

- Release: https://github.com/LeonM1501/vertix-client/releases/tag/v0.9.0 (öffentlich, stabil).
- Öffentlicher Commit: `bf238ef8752b43dbc2e4fd46cf2ab6e550a5d825`. Workflow https://github.com/LeonM1501/vertix-client/actions/runs/39768313704 erfolgreich.
- Korrespondierender Source-Snapshot: `72bc8d152a9e883f096122f4c18a4a809a5d3c25`; Archiv ohne Caches/temporäre Daten und ohne selbstreferenziellen Root-Manifest-Hash.
- Frischer Windows-Release-Build erfolgreich; beide exakten Core-1.4.0-JARs im EXE nachgewiesen. Native x64-Imports geprüft, passende WebView2Loader.dll/libunwind.dll beigepackt. NSIS-Build erfolgreich. Das Buildskript wurde mit externem `CARGO_TARGET_DIR` praktisch verwendet.
- Installer: 7.631.079 Bytes; SHA-256 `66800bdc9fd3390e333122567fb18a299c20cf5c619d3799de5d2704ad235170`.
- Source: 3.728.432 Bytes; SHA-256 `8a21db15b0699f8db65d18890d980236766266a620b424e50e790ab38bee172e`.
- Normaler öffentlicher `main/version.json` liefert 0.9.0. Setup und Source wurden über die tatsächlichen Manifest-URLs erneut heruntergeladen und beide Hashes bestätigt. GitHub-Release-Assets haben dieselben Größen und SHA-256-Digests. Nachweis: `artifacts/verification/release-0.9.0/public-downloads.json`.
- Zugangsdatenprüfung bestand für sämtliche Source-Dateien, jedes Mitglied des Source-Archivs, Frontend und neues EXE. Der lokale DPAPI-Key ist nicht verteilt; andere PCs konfigurieren einen eigenen gültigen Key.
- Persönliche Installation, Welten, Profile und Desktop-Setup blieben unverändert. Kein Endnutzer-Update auf diesem Konto installiert; die stille NSIS-Installation wurde in diesem Release-Lauf nicht gegen die echte Benutzerregistrierung ausgeführt.
