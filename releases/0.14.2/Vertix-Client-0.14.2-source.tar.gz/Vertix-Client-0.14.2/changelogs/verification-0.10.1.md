# Prüfung 0.10.1

- TypeScript und Vite-Produktionsbuild bestanden.
- Bestehende Icon-Persistenzprüfung bestanden: root/legacy-extra, Fallback und bisherige Symbole.
- 24 PNGs mit eindeutigen IDs, 256×256, RGBA/Transparenz, Payload unter bestehendem nativen Limit, Profil-JSON-Roundtrip und React-Bildausgabe geprüft.
- Browserprüfung an isolierter Vorschau 127.0.0.1:1435: Grasblock auswählen, Hintergrund wechseln, 128/40/28/20px-Vorschau, Suche nach TNT, Blockwechsel und Auswahlstatus erfolgreich. Screenshot artifacts/verification/upgrade-0.10.1/block-editor.png.
- Persönliche Instanzen unverändert. Browser-Vorschau hat keinen nativen Speichern-Zugang; Persistenz durch bereits vorhandenes PNG-Schema und Roundtrip-Prüfung abgedeckt. Kein neuer Backend-Datentyp.
- Ingame-Code unverändert gegenüber vollständig geprüftem Core 1.5.0 aus 0.10.0. Client-Build und Veröffentlichung werden abschließend dokumentiert.

## Abschließender Build und Veröffentlichung

- Nativer optimierter Release erfolgreich (8m05s), NSIS erfolgreich. Beide exakten Core-1.5.0-JARs im neuen EXE geprüft. Endnutzer-Installer nicht auf persönlicher Installation ausgeführt.
- Renderer im isolierten Verzeichnis erneut ausgeführt: alle 24 eingebetteten PNGs bytegenau reproduziert.
- Credential-Abgleich gegen lokal DPAPI-geschützten Key: Source-Archiv, neues EXE und Setup bestanden. Source ohne .git, node_modules, target oder temporäre Artefakte.
- Release https://github.com/LeonM1501/vertix-client/releases/tag/v0.10.1 veröffentlicht; Workflow 39819048470 erfolgreich. Öffentlicher Commit `2ce405732f8d8d438571fbf09b1b178efe69dad3`, Source-Snapshot `d98ea97d577d043e4153ed6e5d91ede130a46461`.
- Setup erneut öffentlich geladen: 7.898.703 Bytes, SHA-256 `bb4a75864e9e2ddabff379cae42c7d2290d37dfa89e651f3638612555d94de3b`.
- Source erneut öffentlich geladen: 4.252.383 Bytes, SHA-256 `a634b97293a0ec235e9a7ebf0bdb99e7dc84903dfe0bdf58b1643cfdac1f413a`. GitHub-Asset-Digests stimmen ebenfalls überein.
- Direkt nach Veröffentlichung lieferte die normale main/version.json-Adresse noch den gecachten 0.10.0-Stand; die Commit-Adresse enthielt das korrekte 0.10.1-Manifest. GitHub Raw verwendet max-age=300. Rohbelege unter artifacts/verification/release-0.10.1.
