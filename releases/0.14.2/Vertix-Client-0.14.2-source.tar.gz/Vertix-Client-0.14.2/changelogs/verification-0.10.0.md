# Prüfstand 0.10.0 / Core 1.5.0 — 22. Oktober 2026

## Spiel und Leistung

- Beide Core-JARs gegen die jeweilige offizielle Minecraft-JAR kompiliert. JDK 24 liest Klasse 69 mit Warnungen; Spiele laufen mit Java 25. Keine Test-Mixins in produktiven JARs.
- PerformanceLogicTest: Eigentümerschaft temporärer Optionen, Erhalt manueller Änderungen, Wiederherstellung, konstanter Frameverlauf, Stutter/1%-Low, Ringpuffer-Grenzen und lange Unterbrechungen bestanden.
- Isolierter 26.2-Lauf mit bisherigem Java bestanden: artifacts/verification/upgrade-0.10.0/ui-26.2-943a5bd31eb74554b765ca47e62df03e.
- Die bisherige Zulu-25-Laufzeit zeigte unter 26.3 vor Weltstart erneut einen nativen Fehler in jvm.dll (Windows-Ereignis 1000, Offset a88377), wie schon bei 1.4.0. Auch der zusätzliche C1-Lauf hatte keinen erfolgreichen Abschluss. Keine bestimmte JVM-Ursache daraus abgeleitet.
- Frisch von Eclipse Adoptium bezogenes Temurin 25, Archiv-SHA-256 gegen die offizielle API geprüft. Vollständiger 26.3-Lauf mit normalem JIT bestanden: artifacts/verification/upgrade-0.10.0-temurin/ui-26.3-610eeb3fe5fe469091a185b152abd3d0.
- Zusätzlich mit Sodium, Lithium und FerriteCore geprüft, Minecraft-Version und Datei-SHA-1 gegen Modrinth kontrolliert. 26.2: artifacts/verification/upgrade-0.10.0-pack/ui-26.2-ff02179e04ea433480cceffbb5844995; 26.3: artifacts/verification/upgrade-0.10.0-pack/ui-26.3-2e02456b0a0e4e70aecc790c92d43413. Beide bestanden mit Temurin und normalem JIT.
- Assertions: Grafikreduzierung, Rücknahme zweier Profile, manuelle Änderungen bleiben erhalten, ursprüngliche options.txt trotz aktivem Profil und Resume danach, Zoom/Rücknahme und FOV-Speicherschutz, Hintergrundlimit ohne Erhöhung niedrigerer Limits, echte Renderdaten, Favoriten-Speicherung. HUD, Editor, Modmenü und Einstellungen aufgenommen und visuell geprüft.
- Automatikpfad verwendet unter Windows ab Java 25 Temurin. Gültige eigene Java-Pfade bleiben vorrangig. Metadaten erfordern HTTPS, offiziellen Downloadhost und SHA-256; vorhandener Downloadhelper prüft vor dem Entpacken. Laufzeit nur im isolierten Testverzeichnis installiert.
- Kein repräsentativer vergleichender FPS-Benchmark. Tests belegen Funktion, Kompatibilität und Grafikänderungen, keinen festen FPS-Gewinn. Der aktive FPS-Modus setzt kein zusätzliches FPS-Limit.

## Client und Katalog

- test-upgrade-ui.cjs: Schutz lokaler Dateien, kein Loaderwechsel, Vormerken, zugängliche Schnellsuche und Modrinth-Rangfolgenpfad bestanden.
- test-log-diagnostics.cjs: Zeilenbezug, RAM/Laufwerk/Java/Mod-Konflikte, keine doppelten Hinweise und keine unbelegte konkrete Absturzursache bestanden.
- Bestehende Appearance-/RAM-Prüfung bestanden; Designpräferenzen bleiben erhalten. Slate ist eine zusätzliche Anordnung.
- Browser-Bedienprüfung am isolierten Vorschau-Ursprung 127.0.0.1:1435: Slate, Instanz-Schnellsuche, Performance-Tab mit echten API-Versionen, Merkliste nach Reload, Strg+K und Enter geprüft. Screenshots unter artifacts/verification/upgrade-0.10.0/browser.
- Persönliche Instanzen, Welten und installierte App unverändert. Browser verwendet lokale Designvorschau. Fremde Performance-Mods sind nicht im Installer gebündelt.

Abschließende Nachweise folgen unten.

## Abschließende Prüfungen

- TypeScript und Vite-Produktionsbuild erfolgreich. Bestehende Kompatibilitäts-, Update-, Instanzbild-, Beschreibungs-, Katalogrouting- und Appearance/RAM-Prüfungen bestanden.
- Neun native Inhaltsregressionen bestanden. Der neue echte native Live-Test `popularity_matches_modrinth_first_and_deep_page` bestand für Offset 0 und 1020 gegen Modrinths API. Es ist genau dieser explizite Test ausgeführt worden; die übrigen App-Tests waren gefiltert.
- Der optionale Windows-Testmanifest-Buildpfad akzeptiert jetzt GNU-LLVM: COFF-Ressource statt inkompatibler MSVC-Schalter. Der normale Release-Buildpfad bleibt dabei unverändert.
- 30 responsive Menülayouts und zwölf HUD-Viewports einschließlich Einrasten bestanden.
- Frischer optimierter Windows-Release mit custom-protocol erfolgreich (9m02s); keine localhost-Abhängigkeit im Produkt. x64-Imports geprüft; passende libunwind.dll und WebView2Loader.dll beigepackt. NSIS erfolgreich erstellt.
- Die beiden exakten Core-1.5.0-JARs im neuen EXE nachgewiesen. Versionsmetadaten und MIT-Texte geprüft; kein Test-Mixin im Produkt. Zugangsdatenprüfung bestand für Source, neues EXE und Frontend.
- Der Browsernachweis zeigt persistente Merkliste nach Reload sowie tatsächliche Nutzung von Strg+K und Enter. Es wurden ausschließlich Vorschau-Daten am Test-Ursprung verändert.

Der Endnutzer-Installer wurde nicht auf der persönlichen Installation ausgeführt. Sämtliche Spieltests verwendeten eigene Testwelten, Offline-Identitäten und eigene APPDATA-Verzeichnisse.

## Veröffentlichung

- Öffentliches Release: https://github.com/LeonM1501/vertix-client/releases/tag/v0.10.0, veröffentlicht ohne Entwurfs-/Prerelease-Markierung.
- Öffentlicher Commit: `3f709ea6c3e68ae61e67e94e841b2e01c2120c34`; Code-Snapshot im Source-Archiv: `dfba1605b87aa94e3e3937c81c011fe5dc3412b3`. Spätere private Manifest-/Nachweisdokumentation ändert diesen korrespondierenden Code-Snapshot nicht.
- Workflow 39816786418 erfolgreich. Beide öffentlichen Downloads erneut vollständig abgerufen, Dateigrößen und SHA-256 bestätigt. Die SHA-256-Digests beider GitHub-Release-Assets stimmen ebenfalls überein.
- Setup: 7.667.418 Bytes, SHA-256 `d1170aaaede33033bbc5a6faf312bfe22430401d0d99c881aa0c7c6a533c619e`.
- Source: 4.011.139 Bytes, SHA-256 `f90994b8f9a01c8eaf43d6661387fc4035ebc19d1300d36ad931e361efa84cfb`; 673 Archiv-Einträge ohne Entwicklungs-Caches oder temporäre Artefakte. Credential-Abgleich gegen DPAPI-lokal gespeicherten Key im kompletten Source-Archiv und Setup bestanden; Key wird nicht verteilt.
- Lokale Rohbelege: `artifacts/verification/release-0.10.0/` sowie `artifacts/releases/0.10.0/prepared.json`.
