# uku’s Armor HUD: Herkunft und Integration

- Upstream: https://github.com/uku3lig/armor-hud
- Festgehaltener Stand: `233932b08a0fb30501e1104bead784914aff85c4` (Branch 26.3).
- Lizenz: MIT, Copyright (c) 2021 BerdinskiyBear; gepflegt von uku3lig und Mitwirkenden.
- Vollständiger ursprünglicher Lizenztext: `LICENSE` in diesem Ordner; zusätzlich unverändert in jeder Core-JAR unter `assets/vertix/licenses/uku-armor-hud-MIT.txt`.

Der Quellcode wurde als Archiv heruntergeladen und unter `artifacts/upstream/uku-armor-hud` entpackt. Dieser lokale Referenz-/Buildordner gehört nicht in die Source-Verteilung. Keine Upstream-Buildskripte wurden ausgeführt.

`ArmorHudLogic.java` adaptiert die Slot-Auswahl aus `ArmorHudMod.getArmorItems`, die relative/absolute Haltbarkeitswarnung und die Haltbarkeitsdarstellung aus dem HUD-Renderer. Vertix ergänzt ein unabhängiges Datenmodell, Grenzprüfungen, konfigurierbare Ausgabeformate, Bildschirmgrenzen und eine Warnung nur beim Überschreiten eines Grenzwerts. Die übernommenen Regeln bleiben mit MIT-Herkunft gekennzeichnet.

`ArmorHudModule.java` integriert diese Regeln in das bestehende Modul `armor_hud`. Rendering, Slot-Symbole, Vertix-Oberflächen, Einstellungsgruppen, Konfigurationsspeicherung und Anbindung an den HUD-Editor sind Vertix-Code. Die komplette eigenständige Upstream-Mod, deren Mixins, Konfigurationsbibliothek, Bilder und Audiodateien werden nicht eingebunden. Der optionale Warnton nutzt einen bestehenden Minecraft-Sound.

Änderungen am Aussehen oder Umbenennungen ersetzen keine Lizenzhinweise. Die ursprünglichen Hinweise bleiben erhalten; die gesamte Vertix-Core-Mod bleibt GPL-3.0-only, der adaptierte Helfer behält seinen MIT-Hinweis.
