import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Search } from 'lucide-react';
export type QuickAction={id:string;title:string;detail:string;run:()=>void};
export function QuickSwitch({actions,onClose}:{actions:QuickAction[];onClose:()=>void}){
  const [query,setQuery]=useState(''),[active,setActive]=useState(0);const input=useRef<HTMLInputElement>(null);
  const results=actions.filter(a=>(a.title+' '+a.detail).toLocaleLowerCase('de').includes(query.toLocaleLowerCase('de'))).slice(0,12);
  useEffect(()=>{const id=requestAnimationFrame(()=>input.current?.focus());return()=>cancelAnimationFrame(id);},[]);
  const choose=(a:QuickAction)=>{onClose();a.run();};
  return <div className="quick-switch" onKeyDown={e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();setActive(n=>(n+(e.key==='ArrowDown'?1:-1)+results.length)%Math.max(1,results.length));}else if(e.key==='Enter'&&results[active]){e.preventDefault();choose(results[active]);}else if(e.key==='Escape'){e.stopPropagation();onClose();}}}>
    <label className="quick-input"><Search size={20}/><input ref={input} value={query} placeholder="Instanz, Seite oder Aktion suchen …" aria-label="Schnellzugriff durchsuchen" onChange={e=>{setQuery(e.target.value);setActive(0);}} role="combobox" aria-expanded="true" aria-controls="quick-results" aria-activedescendant={results[active]?'quick-'+results[active].id:undefined}/><kbd>ESC</kbd></label>
    <div id="quick-results" role="listbox" aria-label="Suchergebnisse">{results.map((a,i)=><button id={'quick-'+a.id} role="option" aria-selected={i===active} className={i===active?'active':''} key={a.id} onMouseEnter={()=>setActive(i)} onClick={()=>choose(a)}><span><strong>{a.title}</strong><small>{a.detail}</small></span><ArrowUpRight size={17}/></button>)}{!results.length&&<p className="quick-empty">Keine passende Instanz oder Aktion gefunden.</p>}</div>
    <footer><span>↑ ↓ auswählen</span><span>Enter öffnen</span><span>Strg + K</span></footer>
  </div>;
}
