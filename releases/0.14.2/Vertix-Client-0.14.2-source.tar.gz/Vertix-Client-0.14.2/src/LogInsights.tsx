import { useMemo, useState } from 'react';
import { ChevronDown, FileSearch } from 'lucide-react';
import { diagnoseLog } from './logDiagnostics';
export function LogDiagnostics({log}:{log:string}){const [open,setOpen]=useState(true);const hints=useMemo(()=>diagnoseLog(log),[log]);if(!log)return null;
  return <section className="log-diagnostics"><button className="diagnostics-heading" aria-expanded={open} onClick={()=>setOpen(v=>!v)}><FileSearch size={18}/><span>Lokaler Problem-Finder</span><small>{hints.length?`${hints.length} Hinweise`:'Keine eindeutige Fehlermeldung'}</small><ChevronDown size={16}/></button>{open&&<div className="diagnostics-body"><p>Regelbasierte Hinweise aus diesem Protokoll. Es wird nichts hochgeladen und nichts automatisch verändert.</p>{hints.map(h=><article key={h.title}><strong>{h.title}<small>Zeile {h.line}</small></strong><p>{h.meaning}</p><code>{h.excerpt}</code><p>{h.next}</p></article>)}{!hints.length&&<p>Kein bekanntes Fehlermuster gefunden. Das vollständige Protokoll darunter bleibt für die weitere Diagnose verfügbar.</p>}</div>}</section>;
}
