export type SkinPart = { name: string; x: number; y: number; w: number; h: number; d: number; uv: [number, number]; overlay?: [number, number]; mirrored?: boolean };
export function skinParts(slim: boolean, legacy: boolean): SkinPart[] {
  const arm = slim && !legacy ? 3 : 4;
  return [
    { name:'head', x:4, y:0, w:8, h:8, d:8, uv:[0,0], overlay:[32,0] },
    { name:'body', x:4, y:8, w:8, h:12, d:4, uv:[16,16], overlay:legacy?undefined:[16,32] },
    { name:'right-arm', x:4-arm, y:8, w:arm, h:12, d:4, uv:[40,16], overlay:legacy?undefined:[40,32] },
    { name:'left-arm', x:12, y:8, w:arm, h:12, d:4, uv:legacy?[40,16]:[32,48], overlay:legacy?undefined:[48,48], mirrored:legacy },
    { name:'right-leg', x:4, y:20, w:4, h:12, d:4, uv:[0,16], overlay:legacy?undefined:[0,32] },
    { name:'left-leg', x:8, y:20, w:4, h:12, d:4, uv:legacy?[0,16]:[16,48], overlay:legacy?undefined:[0,48], mirrored:legacy },
  ];
}
export function skinFaces(p: SkinPart, uv = p.uv) {
  const [u,v]=uv, {w,h,d}=p;
  return [
    {name:'front',u:u+d,v:v+d,w,h,rotation:'rotateY(0deg)',offset:d/2},
    {name:'back',u:u+2*d+w,v:v+d,w,h,rotation:'rotateY(180deg)',offset:d/2},
    {name:'right',u,v:v+d,w:d,h,rotation:'rotateY(-90deg)',offset:w/2},
    {name:'left',u:u+d+w,v:v+d,w:d,h,rotation:'rotateY(90deg)',offset:w/2},
    {name:'top',u:u+d,v,w,h:d,rotation:'rotateX(90deg)',offset:h/2},
    {name:'bottom',u:u+d+w,v,w,h:d,rotation:'rotateX(-90deg)',offset:h/2},
  ];
}
