import { useEffect, useId, useRef, useState } from 'react';
import { Check, ChevronDown, MoreHorizontal, Plus, Trash2, UserRound } from 'lucide-react';
import type { AccountStatus } from './api';

export function AccountMenu({status,disabled,onAdd,onSelect,onRemove}:{status:AccountStatus|null;disabled:boolean;onAdd:()=>void;onSelect:(id:string)=>Promise<void>;onRemove:(id:string)=>Promise<void>}){
  const [open,setOpen]=useState(false),[busy,setBusy]=useState(false);
  const root=useRef<HTMLDivElement>(null),trigger=useRef<HTMLButtonElement>(null),id=useId();
  useEffect(()=>{
    if(!open)return;
    const outside=(e:PointerEvent)=>{if(!root.current?.contains(e.target as Node))setOpen(false);};
    const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'){setOpen(false);trigger.current?.focus();}};
    document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);
    return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);};
  },[open]);
  async function select(accountId:string){setBusy(true);try{await onSelect(accountId);setOpen(false);trigger.current?.focus();}finally{setBusy(false);}}
  async function remove(accountId:string){setBusy(true);try{await onRemove(accountId);trigger.current?.focus();}finally{setBusy(false);}}
  return <div className="account-control" ref={root}>
    <button ref={trigger} className="account-button" aria-label="Microsoft-Konten" aria-expanded={open} aria-controls={id} aria-haspopup="dialog" aria-busy={busy} onClick={()=>setOpen(v=>!v)} disabled={disabled}>
      <div className="avatar"><UserRound size={16}/></div><span>{status?.username||'Bei Minecraft anmelden'}<small>{status?.signed_in?'Microsoft-Konto verbunden':'Microsoft-Anmeldung'}</small></span><ChevronDown size={14}/>
    </button>
    {open&&<div id={id} className="account-dropdown" role="dialog" aria-label="Minecraft-Konten">
      <div className="account-dropdown-heading"><strong>Deine Konten</strong><small>Für den nächsten Spielstart</small></div>
      <div className="account-list">{(status?.accounts||[]).map(a=><div key={a.id} className="account-row">
        <button className="account-choice" disabled={disabled||busy} aria-pressed={a.active} aria-label={`${a.username}${a.active?' (aktiv)':' auswählen'}`} onClick={()=>{void select(a.id);}}><span className="avatar"><UserRound size={17}/></span><span><strong>{a.username}</strong><small>{a.active?'Aktives Konto':'Microsoft · Java Edition'}</small></span>{a.active&&<Check size={16}/>}</button>
        <details name={`${id}-account-actions`} className="account-row-actions"><summary aria-label={`Optionen für ${a.username}`}><MoreHorizontal size={17}/></summary><button className="account-remove" aria-label={`${a.username} vom Gerät entfernen`} disabled={disabled||busy} onClick={()=>{void remove(a.id);}}><Trash2 size={14}/>Vom Gerät entfernen</button></details>
      </div>)}</div>
      {!status?.accounts?.length&&<p className="account-empty">Noch kein Konto hinzugefügt.</p>}
      <button className="account-add" disabled={disabled||busy} onClick={()=>{setOpen(false);onAdd();}}><Plus size={18}/>Microsoft-Konto hinzufügen</button>
      <p className="account-menu-note">Entfernen meldet nur dieses Konto in Vertix ab. Instanzen und Welten bleiben erhalten.</p>
    </div>}
  </div>;
}
