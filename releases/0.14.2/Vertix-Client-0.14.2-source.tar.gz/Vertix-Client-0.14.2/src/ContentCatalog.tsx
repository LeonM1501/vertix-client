import { ProjectDetails } from "./ProjectDetails";
import { useEffect, useState } from 'react';
import { Box, ChevronLeft, ChevronRight, Download, LoaderCircle, Package, Search, Bookmark, X } from 'lucide-react';
import * as api from './api';
import { InstanceDialog } from './Instance';
import { compatibleVersion, type ContentVersion, type CatalogKind } from './contentCompatibility';
const message = (e: unknown) => typeof e === 'string' ? e : e instanceof Error ? e.message : JSON.stringify(e);
const kindLabels: Record<CatalogKind, string> = { mod: 'Mods', shader: 'Shader', resourcepack: 'Ressourcenpakete' };
export function ContentCatalog({ profiles, onReload, notify, initialKind = 'mod' }: { profiles: api.Profile[]; onReload: () => Promise<unknown>; notify: (text: string, error?: boolean) => void; initialKind?: CatalogKind }) {
  type Saved={kind:CatalogKind;project:api.Project};
  const [saved,setSaved]=useState<Saved[]>(()=>{try{const value=JSON.parse(localStorage.getItem('vertix-saved-content-v1')||'[]');return Array.isArray(value)?value.filter(v=>v&&['mod','shader','resourcepack'].includes(v.kind)&&typeof v.project?.project_id==='string'&&typeof v.project?.title==='string').slice(0,200):[];}catch{return [];}});
  const [savedOnly,setSavedOnly]=useState(false);
  function bookmark(project:api.Project){setSaved(current=>{const next=current.some(v=>v.kind===kind&&v.project.project_id===project.project_id)?current.filter(v=>v.kind!==kind||v.project.project_id!==project.project_id):[...current,{kind,project}].slice(-200);try{localStorage.setItem('vertix-saved-content-v1',JSON.stringify(next));}catch{notify('Merkliste konnte nicht dauerhaft gespeichert werden.',true);}return next;});}
  const [kind, setKind] = useState<CatalogKind>(initialKind);
  const [query, setQuery] = useState(''), [loader, setLoader] = useState(''), [version, setVersion] = useState(''), [sort, setSort] = useState('downloads'), [page, setPage] = useState(0);
  const [versions, setVersions] = useState<string[]>([]), [hits, setHits] = useState<api.Project[]>([]), [total, setTotal] = useState(0), [loading, setLoading] = useState(true), [warning, setWarning] = useState(''), [error, setError] = useState(''), [attempt, setAttempt] = useState(0), [project, setProject] = useState<api.Project | null>(null);
  useEffect(() => { const c = new AbortController(); api.minecraftVersions(c.signal).then(setVersions).catch(() => {}); return () => c.abort(); }, []);
  useEffect(() => {
    const c = new AbortController(); if(savedOnly){setLoading(false);setError('');setWarning('');return()=>c.abort();} setLoading(true); setError('');
    const timer = setTimeout(() => {
      api.catalogSearch({kind,query,loader,version,sort,page},c.signal).then(result => { if (!c.signal.aborted) { setHits(result.hits); setTotal(result.total_hits); setWarning(result.warning||''); } }).catch(e => { if (!c.signal.aborted) setError(message(e)); }).finally(() => { if (!c.signal.aborted) setLoading(false); });
    }, 250);
    return () => { clearTimeout(timer); c.abort(); };
  }, [kind, query, loader, version, sort, page, attempt, savedOnly]);
  const shown=savedOnly?saved.filter(v=>v.kind===kind&&(v.project.title+' '+v.project.description).toLocaleLowerCase('de').includes(query.toLocaleLowerCase('de'))).map(v=>v.project):hits;
  const shownTotal=savedOnly?shown.length:total;
  const [details, setDetails] = useState<string | null>(null);
  if (details) return <ProjectDetails id={details} kind={kind} profiles={profiles} onClose={()=>setDetails(null)} onReload={onReload} notify={notify}/>;
  return <div className="content-catalog">
    <div className="page-heading"><div><div className="eyebrow">NEUES FÜR DEINE WELTEN</div><h1>Inhalte entdecken</h1><p>Die passende Instanz wählst du beim Installieren.</p></div><Package size={28} /></div>
    <nav className="browse-types" aria-label="Inhaltstyp">{(Object.keys(kindLabels) as CatalogKind[]).map(value => <button key={value} type="button" aria-pressed={kind === value} className={kind === value ? 'active' : ''} onClick={() => { setKind(value); setLoader(''); setQuery(''); setPage(0); setProject(null); }}>{kindLabels[value]}</button>)}</nav>
    <div className="catalog-shortcuts"><button className={`button small ${savedOnly?'light':''}`} aria-pressed={savedOnly} onClick={()=>{setSavedOnly(v=>!v);setPage(0);}}><Bookmark size={15}/>{savedOnly?'Alle Inhalte':'Merkliste'} ({saved.filter(v=>v.kind===kind).length})</button><span>{savedOnly?'Gespeicherte Projekte. Die passende Version wird beim Installieren geprüft.':sort==='downloads'?'Beliebt übernimmt die Reihenfolge von Modrinth. Versionsvergleich weiterhin mit beiden Quellen.':'Gemeinsame Suche auf Modrinth und CurseForge.'}</span></div>
    {kind === 'shader' && <p className="instance-notice">Shader benötigen Iris oder OptiFine in der Zielinstanz. Das Shaderpaket wählst du danach in den Grafikeinstellungen von Minecraft aus.</p>}
    <div className="toolbar catalog-filters"><label className="search-field"><Search size={18} /><input aria-label={`${kindLabels[kind]} suchen`} placeholder={`${kindLabels[kind]} durchsuchen …`} value={query} onChange={e => { setQuery(e.target.value); setPage(0); }} /></label>
      {kind === 'mod' && <label>Modloader<select disabled={savedOnly} aria-label="Modloader filtern" value={loader} onChange={e => { setLoader(e.target.value); setPage(0); }}><option value="">Alle Modloader</option>{['fabric','forge','neoforge','quilt'].map(v => <option key={v} value={v}>{v === 'neoforge' ? 'NeoForge' : v[0].toUpperCase() + v.slice(1)}</option>)}</select></label>}
      <label>Minecraft<select disabled={savedOnly} aria-label="Minecraft-Version filtern" value={version} onChange={e => { setVersion(e.target.value); setPage(0); }}><option value="">Alle Versionen</option>{versions.map(v => <option key={v}>{v}</option>)}</select></label>
      <label>Sortieren<select disabled={savedOnly} aria-label="Inhalte sortieren" value={sort} onChange={e => { setSort(e.target.value); setPage(0); }}><option value="downloads">Beliebt (Modrinth)</option><option value="relevance">Relevanz</option><option value="updated">Zuletzt aktualisiert</option><option value="newest">Neu erschienen</option></select></label>
      {(query||loader||version)&&<button className="button clear-filters" onClick={()=>{setQuery('');setLoader('');setVersion('');setPage(0);}}><X size={14}/>Zurücksetzen</button>}
    </div>
    {warning && <p className="instance-notice" role="status">{warning}</p>}
    {loading&&!savedOnly ? <div className="table-empty"><LoaderCircle className="spin" /><p>Inhalte werden geladen …</p></div> : error ? <div className="table-empty" role="alert"><p>{error}</p><button className="button" onClick={() => setAttempt(n => n + 1)}>Erneut versuchen</button></div> : <>
      <p className="catalog-count">{shownTotal.toLocaleString('de')} {savedOnly?'gemerkte Projekte':'Ergebnisse'}</p><div className="browse-results">{shown.map(hit => <article className="browse-result" key={hit.project_id}>{hit.icon_url ? <img src={hit.icon_url} alt="" loading="lazy" /> : <div className="browse-icon"><Package size={32} /></div>}<div className="browse-result-copy"><div><h2><button className="project-title-link" onClick={()=>setDetails(hit.project_id)}>{hit.title}</button></h2><span>von {hit.author}</span></div><p>{hit.description}</p><div className="result-tags"><span>{kindLabels[kind]}</span><span>{hit.provider==='both'?'Modrinth + CurseForge':hit.provider==='curseforge'?'CurseForge':'Modrinth'}</span>{loader && <span>{loader}</span>}{version && <span>{version}</span>}</div></div><div className="browse-result-action"><button className="bookmark-button" aria-pressed={saved.some(v=>v.kind===kind&&v.project.project_id===hit.project_id)} aria-label={`${hit.title} merken`} title="Projekt merken" onClick={()=>bookmark(hit)}><Bookmark size={17} fill={saved.some(v=>v.kind===kind&&v.project.project_id===hit.project_id)?'currentColor':'none'}/></button><button className="button small light" onClick={() => setProject(hit)}><Download size={15} />Installieren</button><span>{hit.downloads.toLocaleString('de')} Downloads</span></div></article>)}</div>
      {!shown.length && <div className="table-empty"><Search size={30} /><h2>Keine passenden Inhalte gefunden.</h2><p>Ändere deine Suche oder die Filter.</p></div>}
      {!savedOnly && !!shown.length && <div className="browse-pagination"><span>Seite {page + 1} von {Math.ceil(total / 20).toLocaleString('de')}</span><button className="button" disabled={page === 0} onClick={() => setPage(n => n - 1)}><ChevronLeft size={16} />Zurück</button><button className="button" disabled={(page + 1) * 20 >= total} onClick={() => setPage(n => n + 1)}>Weiter<ChevronRight size={16} /></button></div>}
    </>}
    {project && <InstallChooser key={project.project_id} kind={kind} project={project} profiles={profiles} onClose={() => setProject(null)} onReload={onReload} notify={notify} />}
  </div>;
}

function InstallChooser({ project, profiles, onClose, onReload, notify, kind }: { project: api.Project; profiles: api.Profile[]; onClose: () => void; onReload: () => Promise<unknown>; notify: (text: string, error?: boolean) => void; kind: CatalogKind }) {
  const [versions, setVersions] = useState<ContentVersion[]>([]), [loading, setLoading] = useState(true), [error, setError] = useState(''), [attempt, setAttempt] = useState(0), [busy, setBusy] = useState<string | null>(null), [installed, setInstalled] = useState<string[]>([]);
  useEffect(() => { const c = new AbortController(); setLoading(true); setError(''); api.catalogVersions(project.project_id, c.signal, undefined, undefined, kind).then(data => { if (!c.signal.aborted) setVersions(data); }).catch(e => { if (!c.signal.aborted) setError(message(e)); }).finally(() => { if (!c.signal.aborted) setLoading(false); }); return () => c.abort(); }, [project.project_id, attempt]);
  async function install(profile: api.Profile, versionId: string) {
    if (busy) return;
    if (!api.desktop) { notify('Inhalte installierst du in der Desktop-App.', true); return; }
    setBusy(profile.id); setError('');
    try {
      await api.call('install_instance_content', { request: { profile_id: profile.id, project_id: project.project_id, kind, world: null, version_id: versionId } });
      setInstalled(ids => [...ids, profile.id]); await onReload(); notify(`${project.title} in ${profile.name} installiert.`);
    } catch (e) { setError(message(e)); } finally { setBusy(null); }
  }
  return <InstanceDialog title="Wo möchtest du den Inhalt installieren?" className="install-chooser" onClose={() => { if (!busy) onClose(); }}><p className="dialog-copy">{project.title} · Für jede Instanz wird die passende Veröffentlichung geprüft.</p>
    {error && <p className="inline-error" role="alert">{error} {!versions.length && <button className="text-button" onClick={() => setAttempt(n => n + 1)}>Erneut versuchen</button>}</p>}
    <div className="install-instance-list">{profiles.map(profile => {
      const match = compatibleVersion(versions, profile, kind), already = installed.includes(profile.id) || (kind === 'mod' && profile.mods.some(m => api.modProjectId(m) === project.project_id));
      const running = ['running','starting','stopping'].includes((profile.state || '').toLowerCase());
      return <div className="install-instance" key={profile.id}><Box size={24} /><div><strong>{profile.name}</strong><small>{profile.game_version} · {profile.loader}</small><p className={match.version ? '' : 'incompatible'}>{loading ? 'Kompatibilität wird geprüft …' : !versions.length && error ? 'Kompatibilität konnte nicht geprüft werden' : match.reason || `Passende Version: ${match.version?.version_number}`}</p></div><button className="button small light" disabled={loading || !!busy || !match.version || already} onClick={() => match.version && install(profile, match.version.id)}>{busy === profile.id ? <LoaderCircle className="spin" size={15} /> : null}{already ? 'Installiert' : running ? 'Vormerken' : 'Installieren'}</button></div>;
    })}</div>{!profiles.length && <div className="table-empty"><Box size={28} /><p>Erstelle zuerst eine Instanz unter „Meine Instanzen“.</p></div>}<div className="dialog-actions"><button className="button" disabled={!!busy} onClick={onClose}>Schließen</button></div>
  </InstanceDialog>;
}
