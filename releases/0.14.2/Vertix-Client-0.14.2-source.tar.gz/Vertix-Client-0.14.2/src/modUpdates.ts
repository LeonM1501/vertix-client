import { getJSON, catalogVersions, desktop, call, type ContentItem, type Profile } from './api';
export type ModVersion = { id: string; version_number: string; version_type: string; date_published: string; files: unknown[]; game_versions?:string[]; _provider?:string };
export type ModUpdate = { versionId: string; version: string; projectId: string; title: string };
export function newerModVersion(versions: ModVersion[], installed: ModVersion): ModVersion | undefined {
  const candidate = versions.find(v => v.version_type === 'release' && v.files.length) || versions.find(v => v.files.length);
  if (!candidate || candidate.id === installed.id) return;
  const key=(v:ModVersion):number[]|null=>{
    let name=v.version_number||'';for(const game of [...(v.game_versions||[])].sort((a,b)=>b.length-a.length))name=name.split(game).join('');
    const match=name.match(/(\d+\.\d+(?:\.\d+){0,2})(?:[-.]?(alpha|beta|rc|pre)[.-]?(\d*))?/i);if(!match)return null;
    const numbers=match[1].split('.').map(Number);while(numbers.length>2&&numbers[numbers.length-1]===0)numbers.pop();
    while(numbers.length<4)numbers.push(0);numbers.push(({alpha:0,beta:1,pre:2,rc:3} as Record<string,number>)[(match[2]||'').toLowerCase()]??4,Number(match[3]||0));return numbers;
  };
  const a=key(candidate),b=key(installed);
  if(a&&b){for(let i=0;i<a.length;i++){if(a[i]!==b[i])return a[i]>b[i]?candidate:undefined;}
    return candidate._provider!=='curseforge'&&installed._provider==='curseforge'?candidate:undefined;
  }
  const before = Date.parse(installed.date_published), after = Date.parse(candidate.date_published);
  return Number.isFinite(before) && Number.isFinite(after) && after > before ? candidate : undefined;
}
export async function checkModUpdates(profile: Profile, items: ContentItem[], signal: AbortSignal): Promise<{ updates: Record<string, ModUpdate>; failures: number }> {
  const queue = items.filter(i => i.kind === 'mod' && i.project_id && i.version_id);
  const updates: Record<string, ModUpdate> = {}; let failures = 0, cursor = 0;
  async function worker() {
    while (cursor < queue.length && !signal.aborted) {
      const item = queue[cursor++];
      try {
        const params = new URLSearchParams({ loaders: JSON.stringify([profile.loader]), game_versions: JSON.stringify([profile.game_version]) });
        const versions:ModVersion[] = desktop ? await catalogVersions(item.project_id!,signal,profile.game_version,profile.loader) as ModVersion[] : await getJSON<ModVersion[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(item.project_id!)}/version?${params}`, signal);
        const current = versions.find(v => v.id === item.version_id) || (desktop ? await call<ModVersion>('catalog_version',{versionId:item.version_id}) : await getJSON<ModVersion>(`https://api.modrinth.com/v2/version/${encodeURIComponent(item.version_id!)}`, signal));
        const update = newerModVersion(versions, current);
        if (update) updates[item.id] = { versionId: update.id, version: update.version_number, projectId: item.project_id!, title: item.title };
      } catch { if (!signal.aborted) failures++; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(4, queue.length) }, worker));
  return { updates, failures };
}
