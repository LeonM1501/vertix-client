import { useEffect, useState } from 'react';
import { LoaderCircle, RotateCcw } from 'lucide-react';
import * as api from './api';
import { skinFaces, skinParts } from './skinGeometry';

type Skin = { base64: string; variant: 'classic' | 'slim' };
const px = (n:number) => `calc(${n} * var(--skin-pixel))`;
export function SkinPreview({ accountId, username }: { accountId?: string | null; username?: string | null }) {
  const [skin,setSkin]=useState<Skin|null>(null), [loading,setLoading]=useState(false), [failed,setFailed]=useState(false), [retry,setRetry]=useState(0);
  const [loaded,setLoaded]=useState(''), [legacy,setLegacy]=useState(false), [rotation,setRotation]=useState(-25);
  useEffect(()=>{
    let cancelled=false;
    setSkin(null); setFailed(false); setLoading(false);
    if(api.desktop && accountId){
      setLoading(true);
      api.call<Skin>('get_vertix_skin',{accountId}).then(value=>{if(!cancelled)setSkin(value);}).catch(()=>{if(!cancelled)setFailed(true);}).finally(()=>{if(!cancelled)setLoading(false);});
    }
    return ()=>{cancelled=true;};
  },[accountId,retry]);
  const source=skin?`data:image/png;base64,${skin.base64}`:'/skins/steve.png';
  const ready=loaded===source;
  return <div className="skin-preview">
    <div className="skin-name"><span className="eyebrow">{accountId?'DEIN SPIELER':'DEIN SPIELRAUM'}</span><strong>{username||'Bereit für deine Welt.'}</strong></div>
    <div className="skin-stage" role="img" aria-label={accountId && skin && ready?`3D-Skin von ${username}`:'Minecraft-Standardskin als Vorschau'}>
      <svg className="skin-floor" viewBox="0 0 600 160" aria-hidden="true"><path d="M0 150L230 0M120 160L260 0M240 160L290 0M360 160L320 0M480 160L350 0M600 150L380 0M0 150H600M70 100H530M145 58H455M205 25H395"/></svg>
      <div className="skin-platform"/>
      <div className="skin-model" style={{transform:`translateX(-50%) rotateX(-6deg) rotateY(${rotation}deg)`,visibility:ready?'visible':'hidden'}}>
        {skinParts(skin?.variant==='slim',legacy).map(p=><div key={p.name} className={`skin-part skin-${p.name}`} style={{left:px(p.x),top:px(p.y),width:px(p.w),height:px(p.h),transform:p.mirrored?'scaleX(-1)':undefined}}>
          {[p.uv,...(p.overlay?[p.overlay]:[])].map((uv,index)=><div key={index} className={`skin-cube ${index?'skin-overlay':''}`}>
            {skinFaces(p,uv).map(f=><i key={f.name} className={`skin-face skin-face-${f.name}`} style={{width:px(f.w),height:px(f.h),backgroundImage:`url("${source}")`,backgroundSize:`${px(64)} ${px(legacy?32:64)}`,backgroundPosition:`${px(-f.u)} ${px(-f.v)}`,transform:`translate(-50%,-50%) ${f.rotation} translateZ(${px(f.offset)})`}}/>)}</div>)}
        </div>)}
      </div>
      {(!ready||loading)&&<LoaderCircle size={22} className="skin-loading spin" aria-label="Skin wird geladen"/>}
    </div>
    <img className="skin-texture" src={source} alt="" onLoad={e=>{const image=e.currentTarget;if(image.naturalWidth>=64&&image.naturalWidth<=1024&&[1,2].includes(image.naturalWidth/image.naturalHeight)){setLegacy(image.naturalWidth/image.naturalHeight===2);setLoaded(source);}else{setSkin(null);setFailed(true);}}} onError={()=>{if(skin){setSkin(null);setFailed(true);}}}/>
    <div className="skin-controls"><label>Drehen<input aria-label="Skin drehen" type="range" min="-180" max="180" step="1" value={rotation} onChange={e=>setRotation(Number(e.target.value))}/></label><button className="icon-button" aria-label="Skin-Drehung zurücksetzen" onClick={()=>setRotation(-25)}><RotateCcw size={14}/></button></div>
    <div className="skin-caption" role="status">{loading?'Dein Skin wird geladen …':failed?<><span>Skin gerade nicht erreichbar · Standardvorschau</span><button onClick={()=>setRetry(n=>n+1)}>Erneut laden</button></>:!accountId?'Melde dich an, um deinen Skin zu sehen.':!api.desktop?'Skin-Vorschau ist in der Desktop-App verfügbar.':null}</div>
  </div>;
}
