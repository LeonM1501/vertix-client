import { useEffect, useRef, useState } from 'react';
import { listen } from '@tauri-apps/api/event';
import { FileArchive, FolderOpen, LoaderCircle } from 'lucide-react';
import * as api from './api';
export type PackPreview={ticket:string;format:string;name:string;game_version:string;loader:string;loader_version:string|null;files:number;optional:number;skipped_server:number;curseforge_key_required:boolean};
const errorText=(e:unknown)=>typeof e==='string'?e:e instanceof Error?e.message:e&&typeof e==='object'&&'message'in e?String(e.message):'Der Import konnte nicht abgeschlossen werden.';
export function PackImport({onImported,onBusy,sourcePath,initialPreview}:{initialPreview?:PackPreview;sourcePath?:string;onImported:(id:string)=>Promise<void>;onBusy:(busy:boolean)=>void}){
  const [preview,setPreview]=useState<PackPreview|null>(initialPreview||null),[name,setName]=useState(initialPreview?.name||''),[optional,setOptional]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[progress,setProgress]=useState(''),[provided,setProvided]=useState(0);
  const ticket=useRef<string|null>(initialPreview?.ticket||null);
  useEffect(()=>()=>{if(ticket.current&&api.desktop)void api.call('discard_modpack',{ticket:ticket.current}).catch(()=>{});},[]);
  useEffect(()=>{if(!api.desktop||!busy)return;const unlisten=listen<{message:string}>('vertix-pack-progress',e=>setProgress(e.payload.message));return()=>{void unlisten.then(f=>f());};},[busy]);
  const working=(value:boolean)=>{setBusy(value);onBusy(value);};
  const lastPath=useRef('');
  useEffect(()=>{if(sourcePath&&lastPath.current!==sourcePath){lastPath.current=sourcePath;void choose(sourcePath);}},[sourcePath]);
  async function choose(path?:string){working(true);setError('');setProgress('Archiv prüfen …');try{const next=path?await api.call<PackPreview>('inspect_modpack_path',{path}):await api.call<PackPreview|null>('choose_modpack');if(next){if(ticket.current)await api.call('discard_modpack',{ticket:ticket.current});ticket.current=next.ticket;setPreview(next);setName(next.name);setOptional(false);setProvided(0);}}catch(e){setError(errorText(e));}finally{working(false);setProgress('');}}
  async function addFiles(){if(!preview)return;working(true);setError('');setProgress('Zusätzliche Dateien kopieren und prüfen …');try{const n=await api.call<number>('add_modpack_files',{ticket:preview.ticket});setProvided(v=>v+n);}catch(e){setError(errorText(e));}finally{working(false);setProgress('');}}
  async function install(){if(!preview||!name.trim())return;working(true);setError('');setProgress('Import vorbereiten …');try{const id=await api.call<string>('import_modpack',{ticket:preview.ticket,name:name.trim(),includeOptional:optional});ticket.current=null;await onImported(id);}catch(e){setError(errorText(e));}finally{working(false);setProgress('');}}
  return <div className="pack-import"><div className="pack-import-intro"><FileArchive size={32}/><div><h3>Dein Modpack zieht mit.</h3><p>Modrinth <strong>.mrpack</strong> oder CurseForge <strong>.zip</strong>: Version, Loader, Mods und mitgelieferte Konfigurationen in eine neue Instanz übernehmen.</p></div></div>
    <button className="button" disabled={busy||!api.desktop} onClick={()=>void choose()}><FolderOpen size={17}/>{preview?'Anderes Archiv wählen':'Modpack-Datei auswählen'}</button>
    {!api.desktop&&<p className="preview-note">Der Dateiimport ist in der Desktop-App verfügbar.</p>}
    {preview&&<div className="pack-import-preview"><span className="eyebrow">{preview.format.toUpperCase()} · GEPRÜFTES ARCHIV</span><label className="field">Instanzname<input maxLength={256} disabled={busy} value={name} onChange={e=>setName(e.target.value)}/></label><dl><div><dt>Minecraft</dt><dd>{preview.game_version}</dd></div><div><dt>Modloader</dt><dd>{preview.loader}{preview.loader_version?' '+preview.loader_version:''}</dd></div><div><dt>Downloads</dt><dd>{preview.files-preview.optional} erforderlich{preview.optional>0&&` · ${preview.optional} optional`}</dd></div></dl>
      {preview.optional>0&&<label className="pack-optional"><input type="checkbox" checked={optional} disabled={busy} onChange={e=>setOptional(e.target.checked)}/>Optionale Dateien zusätzlich installieren</label>}
      {preview.skipped_server>0&&<p>{preview.skipped_server} reine Server-Dateien werden ausgelassen.</p>}
      {preview.curseforge_key_required&&(preview.files-preview.optional>0||optional)&&<p role="alert" className="inline-error">Für CurseForge-Downloads zuerst einen gültigen API-Key unter Einstellungen → Inhaltsquellen hinterlegen.</p>}
      <button className="button small" disabled={busy||!api.desktop} onClick={()=>void addFiles()}><FolderOpen size={15}/>Zusätzliche Dateien{provided>0?` (${provided})`: ''}</button><p className="pack-import-note">Falls ein Autor keinen API-Download erlaubt: die Datei auf CurseForge herunterladen und hier hinzufügen. Vertix akzeptiert sie nur mit passender Prüfsumme.</p>
      <p className="pack-import-note">Die festgelegten Dateiversionen bleiben erhalten. Mitgelieferte Welten und Ressourcen werden übernommen. Minecraft, Java und Loader bereitet Vertix beim ersten Start vor.</p>
    </div>}
    {error&&<p role="alert" className="inline-error">{error}</p>}{busy&&<p role="status" className="pack-import-progress"><LoaderCircle className="spin" size={16}/>{progress}</p>}
    <div className="dialog-actions"><button className="button light" disabled={busy||!api.desktop||!preview||!name.trim()||(preview.curseforge_key_required&&(preview.files-preview.optional>0||optional))} onClick={install}>{busy?<LoaderCircle className="spin" size={17}/>:<FileArchive size={17}/>}Als neue Instanz importieren</button></div>
  </div>;
}
