import { useEffect, useRef } from 'react';
import { ArrowRight, Check, ChevronDown, Layers3, LoaderCircle, Play, Plus, Package, SlidersHorizontal } from 'lucide-react';
import type { AccountStatus, Profile } from './api';
import type { Design } from './Appearance';
import type { CatalogKind } from './contentCompatibility';
import { ProfileIcon } from './ProfileIcon';
import { SkinPreview } from './SkinPreview';

export function Home({ design, account, profiles, selected, launching, progress, onSelect, onLaunch, onCreate, onOpen, onLibrary, onDiscover }: {
  design: Design; account: AccountStatus|null; profiles: Profile[]; selected?: Profile; launching: boolean; progress: string; onSelect: (id:string)=>void; onLaunch: () => void; onCreate: () => void; onOpen: (id: string) => void; onLibrary: () => void; onDiscover: (kind?: CatalogKind) => void;
}) {
  const picker=useRef<HTMLDetailsElement>(null);
  useEffect(()=>{
    const close=(e:PointerEvent)=>{if(!picker.current?.contains(e.target as Node))picker.current?.removeAttribute('open');};
    document.addEventListener('pointerdown',close);
    return()=>document.removeEventListener('pointerdown',close);
  },[]);
  useEffect(()=>{if(launching)picker.current?.removeAttribute('open');},[launching]);
  const recent=[...profiles].sort((a,b)=>(b.last_played||'').localeCompare(a.last_played||'')).slice(0,3);
  return <div className={`home home-launchpad home-${design}`}>
    <header className="launchpad-heading"><div><span className="eyebrow">DEIN SPIEL. DEIN SETUP.</span><h1>Spielen.</h1></div><button className="button" onClick={onCreate}><Plus size={16}/>Neue Instanz</button></header>
    <div className="launchpad-layout">
      <section className="player-panel" aria-label="Spieler und Schnellstart">
        <span className="player-panel-label">VERTIX / JAVA EDITION</span>
        <SkinPreview key={account?.account_id||'guest'} accountId={account?.account_id} username={account?.username}/>
        <div className="home-launch-area">
          <div className="home-launch-control">
            <button className="home-play" disabled={launching} onClick={selected?onLaunch:onCreate}>{launching?<LoaderCircle className="spin" size={22}/>:selected?<Play size={22} fill="currentColor"/>:<Plus size={22}/>}<span><strong>{launching?'Wird vorbereitet …':selected?'Spielen':'Instanz erstellen'}</strong><small>{selected?.name||'Dein nächstes Abenteuer'}</small></span></button>
            {!!profiles.length&&<details className="instance-picker" ref={picker} onKeyDown={e=>{if(e.key==='Escape'){picker.current?.removeAttribute('open');picker.current?.querySelector('summary')?.focus();}}}>
              <summary aria-label="Instanz auswählen" aria-disabled={launching} onClick={e=>{if(launching)e.preventDefault();}}><ChevronDown size={20}/></summary>
              <div className="instance-picker-list"><header><span>INSTANZ WÄHLEN</span><small>{profiles.length} verfügbar</small></header>{profiles.map(p=><button key={p.id} aria-label={`${p.name} auswählen · ${p.game_version} · ${p.loader}`} disabled={launching} aria-pressed={p.id===selected?.id} onClick={()=>{onSelect(p.id);picker.current?.removeAttribute('open');picker.current?.querySelector('summary')?.focus();}}><ProfileIcon profile={p} size={35}/><span><strong>{p.name}</strong><small>{p.game_version} · {p.loader}</small></span>{selected?.id===p.id&&<Check size={16}/>}</button>)}</div>
            </details>}
          </div>
          <p className="home-launch-meta" role="status">{launching?progress:selected?`Minecraft ${selected.game_version} · ${selected.loader} · ${selected.settings.memory.max/1024} GB RAM`:'Vanilla oder Modpack. Du entscheidest.'}</p>
          {selected&&<button className="text-button home-manage" onClick={()=>onOpen(selected.id)}><SlidersHorizontal size={14}/>Instanz verwalten<ArrowRight size={14}/></button>}
        </div>
      </section>
      <aside className="launchpad-aside">
        <section className="home-library"><div className="section-heading"><h2><Layers3 size={16}/>Deine Instanzen</h2><button className="icon-button" aria-label="Alle Instanzen öffnen" onClick={onLibrary}><ArrowRight size={17}/></button></div><p>Ein Setup für jede Welt.</p><div className="home-recent">{recent.map(p=><button key={p.id} onClick={()=>onOpen(p.id)}><ProfileIcon profile={p} size={43}/><span><strong>{p.name}</strong><small>{p.game_version} · {p.loader}</small></span><ArrowRight size={14}/></button>)}{!recent.length&&<button onClick={onCreate}><Plus size={22}/><span><strong>Deine erste Instanz</strong><small>Version und Loader auswählen</small></span></button>}</div><button className="home-library-link" onClick={onLibrary}>Bibliothek öffnen<span>{profiles.length}<ArrowRight size={14}/></span></button></section>
        <section className="home-content"><Package size={22}/><span className="eyebrow">MEHR AUS DEINER WELT</span><h2>Mach es zu deinem Spiel.</h2><p>Neue Möglichkeiten für dein nächstes Abenteuer.</p><div>{(['mod','shader','resourcepack'] as CatalogKind[]).map((kind,i)=><button key={kind} onClick={()=>onDiscover(kind)}>{['Mods entdecken','Shader entdecken','Ressourcen entdecken'][i]}<ArrowRight size={15}/></button>)}</div></section>
      </aside>
    </div>
  </div>;
}
