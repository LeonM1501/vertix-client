import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import rehypeSanitize from 'rehype-sanitize';
function safeURL(value: string) {
  if(value.startsWith('#'))return value;
  try {const url=new URL(value,'https://modrinth.com');return url.protocol==='https:'?url.href:'';}catch{return '';}
}
export function SafeMarkdown({text}:{text:string}) {
  return <article className="project-description"><Markdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeRaw,rehypeSanitize]} urlTransform={safeURL} components={{a:({node,...props})=><a {...props} target="_blank" rel="noreferrer"/>,img:({node,...props})=><img {...props} loading="lazy" referrerPolicy="no-referrer"/>}}>{text}</Markdown></article>;
}