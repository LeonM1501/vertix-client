# Änderungen in Core 1.3.0

Modkarten besitzen klare Symbole und unterscheidbare Aktivzustände. Der HUD-Editor bietet Raster, abschaltbares Einrasten an Bildschirmmitte und anderen Anzeigen, Ausrichtungslinien, Rechtsklick-Einstellungen sowie das Zurücksetzen der Positionen auf den Stand beim Öffnen. Graphit/Offwhite, keine übernommenen NoRisk-Assets.

# Vertix Core 1.3.0

Clientseitige Fabric-Mod des Vertix-Launchers, GPL-3.0-only. R-Shift öffnet das Hauptmenü. „Mod Menü“ öffnet Module, Suche und Kategorien; Profile und HUD-Editor sind separat erreichbar. ESC geht eine Ebene zurück, R-Shift schließt das Menü. Einstellungen und HUD-Positionen werden über den bestehenden ConfigManager gespeichert.

## Unterstützte Versionen

Fabric, Minecraft **26.2** und **26.3**, Java 25+, Fabric Loader 0.19.3+. Für jede Minecraft-Version wird eine eigene JAR kompiliert. 26.3 verwendet SDL-Eingabecodes; `InputConstants` wird beim jeweiligen Build aufgelöst. Die Mod behauptet keine Kompatibilität zu 1.21, Forge, NeoForge oder Quilt.

Die kleine Fabric Key Mapping API ist versionsgenau als unveränderte verschachtelte JAR enthalten. Eine zusätzlich installierte vollständige Fabric API ist für Vertix Core nicht nötig. Herkunft und Prüfsummen: `dependencies/manifest.json`; Lizenz und Fabric-Metadaten sind in den jeweiligen JARs enthalten. Quellen: https://github.com/FabricMC/fabric (Apache-2.0).

## Discord Streaming

R-Shift → Mod Menü → Performance → **Discord Streaming** aktivieren. Das optionale Modul begrenzt Minecraft standardmäßig auf 60 FPS (30–240 einstellbar), damit GPU-Leistung für Discord übrig bleibt. Ein niedrigeres Spiel-/AFK-Limit bleibt erhalten. Unter Windows wird Vollbild randlos; beim Ausschalten werden das zusätzliche Limit und der Fensterwechsel zurückgenommen. Es gibt keine automatische Discord-Erkennung. Das Modul ist standardmäßig aus und wird über die vorhandene Modulkonfiguration gespeichert.

Die beiden `src/26.2/java`- und `src/26.3/java`-Window-Mixins sind getrennte Implementierungen: GLFW für 26.2, Minecrafts vorhandene SDL-Funktion für 26.3. Der Build nimmt genau die zur Version gehörenden Quellen auf.

Ein isolierter Offline-Lauf prüft Mod-Laden, FPS-Begrenzung und Rücknahme, wiederholte Vollbildwechsel und Wiederherstellung der Fenstergröße:

```powershell
./scripts/test-streaming.ps1 -Version 26.2 -MetadataRoot '<Metadaten mit beiden Spiel-JARs und Bibliotheken>' -JdkHome '<JDK>'
./scripts/test-streaming.ps1 -Version 26.3 -MetadataRoot '<Metadaten mit beiden Spiel-JARs und Bibliotheken>' -JdkHome '<JDK>'
```

Der Test verwendet ein eigenes Spiel- und Konfigurationsverzeichnis unter `artifacts/verification/0.7.0`, keine echten Anmeldedaten, und beendet seine eigene Spielinstanz nach den Prüfungen. Der Test-Mixin wird nie in die produktiven Core-JARs aufgenommen. Das prüft keinen echten Discord-Stream und keinen GPU-Leistungsgewinn.

Mit `-JavaHome '<Java-25-Runtime>'` kann die Laufzeit unabhängig vom Compiler gewählt werden, beispielsweise die vom Launcher verwaltete Java-25-Runtime. `-AssetsRoot` wählt einen vorbereiteten offiziellen Assets-Ordner; 26.3 benötigt den Index 34 einschließlich der zugehörigen Dateien.

Core gehört zur Laufzeit ausschließlich in den Mod-Ordner, nicht zusätzlich in den JVM-Classpath. Der Test nimmt Core nur zum Kompilieren in den Classpath auf. Die abschließenden 26.3-Prüfungen bestanden mit der normalen Java-25-Runtime und JIT; ein früherer Interpreterlauf ist zusätzlich als Diagnoseartefakt erhalten. Die tatsächliche Streamleistung wurde nicht vermessen.

## Build ausführen

Zuerst die beiden Minecraft-Versionen in Vertix vorbereiten, damit die offiziellen Spiel-JARs und Bibliotheken vorhanden sind. Dann im Projektstamm:

```powershell
./vertix-core-mod/build.ps1 -JdkHome 'C:/Program Files/Java/jdk-25'
# Optional: -MinecraftMetadataRoot '<Vertix-Metadatenordner>'
```

Ein vollständiges JDK ab 24 wird akzeptiert; JDK 25 vermeidet die Klassenversionswarnungen beim Lesen der Minecraft-JARs. Der Build verwendet nur den eigenen Java-Source und die offiziellen vorhandenen Bibliotheken. Frische Staging-Verzeichnisse verhindern alte Klassen im Paket. Ergebnisse liegen unter `src-tauri/resources/mods/vertix-core-fabric-<minecraft>-1.3.0.jar`; der Rust-Build bindet beide ein.

Layoutprüfung ohne Spielstart:

```powershell
javac -d artifacts/core-layout-test vertix-core-mod/src/main/java/client/vertix/core/gui/MenuLayout.java vertix-core-mod/src/test/java/MenuLayoutTest.java
java -cp artifacts/core-layout-test MenuLayoutTest
```

Die Launcher-Integration aktualisiert Core beim Profilstart und beim Vorbereiten für den offiziellen Launcher. Sie vergleicht den Dateiinhalt, schreibt atomar und bereinigt ausschließlich genau benannte ältere Core-Artefakte. Config-Dateien und andere lokale Mods bleiben erhalten.
