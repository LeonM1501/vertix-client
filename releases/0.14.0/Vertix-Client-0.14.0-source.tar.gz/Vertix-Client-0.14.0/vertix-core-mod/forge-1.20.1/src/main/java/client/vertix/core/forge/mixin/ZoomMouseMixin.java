package client.vertix.core.forge.mixin;
import net.minecraft.client.MouseHandler;
import client.vertix.core.modules.qol.ZoomModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public class ZoomMouseMixin {
    @Inject(method="onScroll",at=@At("HEAD"),cancellable=true)
    private void scroll(long window,double horizontal,double vertical,CallbackInfo ci){var z=ZoomModule.instance();if(z!=null&&z.scroll(vertical))ci.cancel();}
    @ModifyArg(method="turnPlayer",at=@At(value="INVOKE",target="Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"),index=0)
    private double x(double value){var z=ZoomModule.instance();return z==null?value:value*z.mouseScale();}
    @ModifyArg(method="turnPlayer",at=@At(value="INVOKE",target="Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"),index=1)
    private double y(double value){var z=ZoomModule.instance();return z==null?value:value*z.mouseScale();}
}
