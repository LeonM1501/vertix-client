package client.vertix.core.forge.mixin;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.vertex.PoseStack;
import client.vertix.core.modules.pvp.TotemCounterModule;
import client.vertix.core.api.Setting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(EntityRenderer.class)
public class TotemNameMixin {
    @ModifyArg(method="render",at=@At(value="INVOKE",target="Lnet/minecraft/client/renderer/entity/EntityRenderer;renderNameTag(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"),index=1)
    private Component name(Entity entity,Component text,PoseStack pose,MultiBufferSource buffers,int light){var m=TotemCounterModule.instance();if(m==null||!(entity instanceof Player)||!m.getSetting("nametags",Setting.BooleanSetting.class).getValue())return text;int count=m.pops(entity.getUUID());return count>0?text.copy().append(" -"+count):text;}
}
