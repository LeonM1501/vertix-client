package client.vertix.core.forge.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.*;
import client.vertix.core.modules.visual.LowOverlayModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemInHandRenderer.class)
public class LowHeldItemMixin {
    @Inject(method="renderArmWithItem",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V",ordinal=0,shift=At.Shift.AFTER))
    private void start(AbstractClientPlayer player,float delta,float pitch,InteractionHand hand,float swing,ItemStack stack,float equip,PoseStack pose,MultiBufferSource nodes,int light,CallbackInfo ci){if(stack.is(Items.SHIELD))pose.translate(0,-LowOverlayModule.amount("low_shield"),0);if(stack.is(Items.TOTEM_OF_UNDYING))pose.translate(0,-LowOverlayModule.amount("low_totem"),0);}
}
