package client.vertix.core.forge.mixin;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.Camera;
import client.vertix.core.modules.qol.ZoomModule;
import client.vertix.core.modules.visual.LowOverlayModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(GameRenderer.class)
public class CameraMixin {
    @Shadow private net.minecraft.world.item.ItemStack itemActivationItem;
    @Inject(method="getFov",at=@At("RETURN"),cancellable=true)
    private void zoom(Camera camera,float partial,boolean useSetting,CallbackInfoReturnable<Double> ci){var z=ZoomModule.instance();if(z!=null&&useSetting)ci.setReturnValue(ci.getReturnValue()*z.multiplier());}
    @ModifyArg(method="renderItemActivationAnimation",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;scale(FFF)V"),index=0)
    private float sx(float value){return value*(float)(1-LowOverlayModule.totemAmount(itemActivationItem)*.65);}
    @ModifyArg(method="renderItemActivationAnimation",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;scale(FFF)V"),index=1)
    private float sy(float value){return value*(float)(1-LowOverlayModule.totemAmount(itemActivationItem)*.65);}
    @ModifyArg(method="renderItemActivationAnimation",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;scale(FFF)V"),index=2)
    private float sz(float value){return value*(float)(1-LowOverlayModule.totemAmount(itemActivationItem)*.65);}
}
