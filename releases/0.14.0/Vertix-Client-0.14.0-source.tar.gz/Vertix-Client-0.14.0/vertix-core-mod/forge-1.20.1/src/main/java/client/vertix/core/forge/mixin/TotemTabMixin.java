package client.vertix.core.forge.mixin;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import client.vertix.core.modules.pvp.TotemCounterModule;
import client.vertix.core.api.Setting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(PlayerTabOverlay.class)
public class TotemTabMixin {
    @Inject(method="getNameForDisplay",at=@At("RETURN"),cancellable=true)
    private void name(PlayerInfo player,CallbackInfoReturnable<Component> ci){var m=TotemCounterModule.instance();if(m==null||!m.getSetting("tab",Setting.BooleanSetting.class).getValue())return;int count=m.pops(player.getProfile().getId());if(count>0)ci.setReturnValue(ci.getReturnValue().copy().append(" -"+count));}
}
