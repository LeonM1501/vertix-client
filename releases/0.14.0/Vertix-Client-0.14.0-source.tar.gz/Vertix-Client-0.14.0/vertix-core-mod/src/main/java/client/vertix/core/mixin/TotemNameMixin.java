package client.vertix.core.mixin;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import client.vertix.core.modules.pvp.TotemCounterModule;
import client.vertix.core.api.Setting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(EntityRenderer.class)
public class TotemNameMixin {
    @Inject(method="getNameTag",at=@At("RETURN"),cancellable=true)
    private void name(Entity entity,CallbackInfoReturnable<Component> ci){var m=TotemCounterModule.instance();if(TotemCounterModule.bundled()||m==null||!(entity instanceof Player)||!m.getSetting("nametags",Setting.BooleanSetting.class).getValue())return;int pops=m.pops(entity.getUUID());if(pops>0&&ci.getReturnValue()!=null)ci.setReturnValue(ci.getReturnValue().copy().append(" -"+pops));}
}
