package client.vertix.core.modules.qol;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.performance.OptionOverrides;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.server.level.ParticleStatus;

/** Temporary graphics profiles. Options.save writes the user's originals, not our overrides. */
public class PerformanceModeModule extends Module {
    private final Setting.ModeSetting profile=new Setting.ModeSetting("profile","Qualitätsstufe","Weniger Sichtweite und Effekte; FPS-Limit und VSync bleiben deine Wahl.","Ausgewogen","Ausgewogen","Schnell","Maximum");
    private final Setting.BooleanSetting clouds=new Setting.BooleanSetting("clouds","Wolken ausblenden","Reduziert sichtbare Effekte.",true);
    private final Setting.BooleanSetting shadows=new Setting.BooleanSetting("shadows","Entity-Schatten aus","Deaktiviert nur Entity-Schatten.",true);
    private final Setting.BooleanSetting graphics=new Setting.BooleanSetting("graphics","Grafik anpassen","Ausschalten für ausschließlich interne Render-Optimierungen.",true);
    private final OptionOverrides overrides=new OptionOverrides();
    private String appliedProfile;
    private boolean mutating,shuttingDown,resumeAfterSave;
    private int saveDepth;
    public PerformanceModeModule(){super("fps_mode","FPS Modus","Drei temporäre Grafikprofile. Vorherige Werte kommen beim Ausschalten zurück.",Category.PERFORMANCE,false,false,0,0);addSetting(profile);addSetting(clouds);addSetting(shadows);addSetting(graphics);
        addSetting(new Setting.NumberSetting("item_distance","Item-Renderdistanz","Nur entfernte Item-Modelle ausblenden.",48,16,128,8,true));
        addSetting(new Setting.BooleanSetting("dense_items","Dichte Item-Gruppen","Gleiche Items pro kleiner Zelle nur einmal rendern; im Nahbereich alle sichtbar.",true));
        addSetting(new Setting.NumberSetting("item_protection_radius","Item-Nahbereich","Abstand, in dem alle Items einzeln sichtbar bleiben; 0 bündelt auch daneben.",8,0,16,1,true));
        addSetting(new Setting.NumberSetting("tnt_distance","TNT-Renderdistanz","Entfernte TNT-Modelle begrenzen; Zündung und Explosion bleiben unverändert.",64,24,192,8,true));
        addSetting(new Setting.NumberSetting("particle_budget","Partikel pro Tick","Budget begrenzt Erstellung und Tick-Arbeit bei Explosionen.",128,16,1024,16,true));
        addSetting(new Setting.NumberSetting("particle_distance","Partikel-Entfernung","Entfernte kosmetische Partikel gar nicht erst erzeugen.",48,16,128,8,true));
    }
    public static PerformanceModeModule instance(){var core=VertixCoreMod.getInstance();return core==null||core.getModuleManager()==null?null:(PerformanceModeModule)core.getModuleManager().getModule("fps_mode");}
    private <T> void set(String id,OptionInstance<T> option,T value){overrides.set(id,option::get,option::set,value);}
    private String signature(){return profile.getValue()+clouds.getValue()+shadows.getValue()+graphics.getValue();}
    private void apply(Minecraft mc){
        if(mc.options==null||mc.player==null||shuttingDown)return;
        if(!graphics.getValue()){appliedProfile=signature();return;}
        mutating=true;
        try{
            int tier=profile.getIndex(),chunks=new int[]{12,8,5}[tier];var o=mc.options;
            set("distance",o.renderDistance(),Math.min(o.renderDistance().get(),chunks));
            set("entities",o.entityDistanceScaling(),Math.min(o.entityDistanceScaling().get(),new double[]{.75,.6,.5}[tier]));
            if(clouds.getValue())set("clouds",o.cloudStatus(),CloudStatus.OFF);
            if(shadows.getValue())set("shadows",o.entityShadows(),false);
            if(tier>0){set("ao",o.ambientOcclusion(),false);set("blend",o.biomeBlendRadius(),0);}
            ParticleStatus target=tier==0?ParticleStatus.DECREASED:ParticleStatus.MINIMAL;
            if(o.particles().get().ordinal()<target.ordinal())set("particles",o.particles(),target);
            appliedProfile=signature();
        }finally{mutating=false;}
    }
    private void restore(){mutating=true;try{overrides.restore();appliedProfile=null;}finally{mutating=false;}}
    @Override public void onTick(Minecraft mc){
        if(saveDepth>0||shuttingDown)return;
        if(mc.player==null){if(appliedProfile!=null)restore();return;}
        if(!signature().equals(appliedProfile)){restore();apply(mc);}
    }
    @Override public void onEnable(){shuttingDown=false;}
    @Override public void onDisable(){restore();}
    public void beforeOptionsSave(){if(mutating||shuttingDown)return;if(saveDepth++==0){resumeAfterSave=appliedProfile!=null;restore();}}
    public void afterOptionsSave(){if(mutating||shuttingDown||saveDepth==0)return;if(--saveDepth==0&&resumeAfterSave&&isEnabled())apply(Minecraft.getInstance());}
    public void shutdown(){shuttingDown=true;restore();}
    public String status(){return isEnabled()?profile.getValue():"Aus";}
}
