package client.vertix.core.mixin;
import net.minecraft.client.Camera;
import client.vertix.core.modules.qol.ZoomModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Camera.class)
public class CameraMixin {
    @Inject(method="calculateFov",at=@At("RETURN"),cancellable=true)
    private void zoom(float partial,CallbackInfoReturnable<Float> ci){var z=ZoomModule.instance();if(z!=null)ci.setReturnValue((float)(ci.getReturnValue()*z.multiplier()));}
}
