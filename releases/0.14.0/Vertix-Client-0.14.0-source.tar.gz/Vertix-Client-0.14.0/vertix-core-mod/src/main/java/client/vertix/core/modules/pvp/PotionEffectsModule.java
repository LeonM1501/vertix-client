package client.vertix.core.modules.pvp;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
import client.vertix.core.gui.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;
import java.util.*;
public class PotionEffectsModule extends Module {
    private final Setting.BooleanSetting duration=new Setting.BooleanSetting("duration","Restdauer","Sekunden direkt am jeweiligen Effekt-Icon.",true);
    private final Setting.ModeSetting layout=new Setting.ModeSetting("layout","Anordnung","Icons nebeneinander oder untereinander.","Horizontal","Horizontal","Vertikal");
    public PotionEffectsModule(){super("potion_effects","Potion Timer","Effekt-Icons mit einer Zahl statt einer Menübox.",Category.PVP,true,true,200,4);addSetting(duration);addSetting(layout);}
    @Override public void renderHud(GuiGraphicsExtractor g,DeltaTracker d,Minecraft mc){
        if(mc.player==null)return;
        var list=mc.player.getActiveEffects().stream().filter(MobEffectInstance::showIcon).sorted(Comparator.comparing(MobEffectInstance::getDescriptionId)).toList();
        boolean horizontal=layout.getValue().equals("Horizontal");width=horizontal?Math.max(24,list.size()*30):30;height=horizontal?28:Math.max(28,list.size()*28);
        for(int i=0;i<list.size();i++)draw(g,mc,list.get(i),x+(horizontal?i*30:0),y+(horizontal?0:i*28));
    }
    private void draw(GuiGraphicsExtractor g,Minecraft mc,MobEffectInstance effect,int px,int py){
        EffectIcons.draw(g,mc,effect,px+4,py);
        if(duration.getValue())HudStyle.centered(g,mc.font,effect.isInfiniteDuration()?"∞":Integer.toString(Math.max(0,(effect.getDuration()+19)/20)),px+13,py+18,HudStyle.TEXT);
    }
    @Override public void renderHudPlaceholder(GuiGraphicsExtractor g,Minecraft mc){boolean horizontal=layout.getValue().equals("Horizontal");width=horizontal?60:30;height=horizontal?28:56;draw(g,mc,new MobEffectInstance(net.minecraft.world.effect.MobEffects.SPEED,2100),x,y);draw(g,mc,new MobEffectInstance(net.minecraft.world.effect.MobEffects.STRENGTH,600),x+(horizontal?30:0),y+(horizontal?0:28));}
}
