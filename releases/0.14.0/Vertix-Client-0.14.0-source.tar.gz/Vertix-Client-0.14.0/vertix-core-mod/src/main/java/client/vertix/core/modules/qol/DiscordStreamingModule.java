package client.vertix.core.modules.qol;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;

public class DiscordStreamingModule extends Module {
    public DiscordStreamingModule() {
        super("discord_streaming", "Discord Streaming", "Randloses Vollbild unter Windows für Discord-Streams.", Category.PERFORMANCE, false, false, 0, 0);
    }

    public static DiscordStreamingModule active() {
        VertixCoreMod core = VertixCoreMod.getInstance();
        if (core == null || core.getModuleManager() == null) return null;
        Module module = core.getModuleManager().getModule("discord_streaming");
        return module instanceof DiscordStreamingModule streaming && streaming.isEnabled() ? streaming : null;
    }

}
