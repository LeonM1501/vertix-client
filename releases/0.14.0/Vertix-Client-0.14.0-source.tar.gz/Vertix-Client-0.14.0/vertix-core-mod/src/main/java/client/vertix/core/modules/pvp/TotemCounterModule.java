package client.vertix.core.modules.pvp;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
import client.vertix.core.gui.*;
import client.vertix.core.performance.RenderOptimizer;
import net.minecraft.client.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import java.util.*;
/** Core HUD with the original uku counter on Fabric and a native Forge fallback. */
public final class TotemCounterModule extends Module {
    private final Map<UUID,Integer> pops=new HashMap<>();
    private Object level;
    public TotemCounterModule(){super("totem_counter","TotemCounter","Totems im Inventar und Pops pro Spieler (nach uku). Reset bei Tod oder Weltwechsel.",Category.PVP,false,true,96,4);addSetting(new Setting.BooleanSetting("tab","Pops in Tab","Pops in der Spielerliste anzeigen.",true));addSetting(new Setting.BooleanSetting("nametags","Pops am Nametag","Gezählte Pops hinter dem Spielernamen.",true));}
    private String applied;
    private static Boolean available;
    public static boolean bundled(){if(available!=null)return available;try{Class.forName("net.uku3lig.totemcounter.TotemCounter",false,TotemCounterModule.class.getClassLoader());return available=true;}catch(ClassNotFoundException e){return available=false;}}
    public void sync(){
        if(!bundled())return;
        String signature=""+isEnabled()+getSetting("nametags",Setting.BooleanSetting.class).getValue()+getSetting("tab",Setting.BooleanSetting.class).getValue();if(signature.equals(applied))return;
        try{
            var type=Class.forName("net.uku3lig.totemcounter.config.TotemCounterConfig");var config=type.getMethod("get").invoke(null);
            type.getMethod("setDisplayEnabled",boolean.class).invoke(config,false);
            type.getMethod("setCounterEnabled",boolean.class).invoke(config,isEnabled()&&getSetting("nametags",Setting.BooleanSetting.class).getValue());
            type.getMethod("setShowInTab",boolean.class).invoke(config,isEnabled()&&getSetting("tab",Setting.BooleanSetting.class).getValue());
            type.getMethod("setColoredXpBar",boolean.class).invoke(config,false);
            applied=signature;
        }catch(ReflectiveOperationException e){throw new IllegalStateException("TotemCounter-Anbindung fehlgeschlagen",e);}
    }
    public static TotemCounterModule instance(){return (TotemCounterModule)RenderOptimizer.module("totem_counter");}
    @Override public void onTick(Minecraft mc){if(level!=mc.level){level=mc.level;pops.clear();}if(mc.level!=null)for(var p:mc.level.players())if(!p.isAlive())pops.remove(p.getUUID());}
    @Override public void onDisable(){pops.clear();level=null;}
    public void event(Entity entity,byte status){if(bundled())return;if(!isEnabled()||!(entity instanceof Player))return;if(status==35)pops.merge(entity.getUUID(),1,Integer::sum);else if(status==3)pops.remove(entity.getUUID());}
    public int pops(UUID uuid){
        if(!isEnabled())return 0;
        if(bundled())try{var map=(Map<?,?>)Class.forName("net.uku3lig.totemcounter.TotemCounter").getMethod("getPops").invoke(null);return map.containsKey(uuid)?((Number)map.get(uuid)).intValue():0;}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        return pops.getOrDefault(uuid,0);
    }
    @Override public void renderHud(GuiGraphicsExtractor g,DeltaTracker d,Minecraft mc){if(mc.player==null)return;int count=0;var inv=mc.player.getInventory();for(int i=0;i<inv.getContainerSize();i++){var stack=inv.getItem(i);if(stack.is(Items.TOTEM_OF_UNDYING))count+=stack.getCount();}draw(g,mc,count,pops(mc.player.getUUID()));}
    private void draw(GuiGraphicsExtractor g,Minecraft mc,int count,int popped){String text=count+" | Pops "+popped;width=mc.font.width(text)+36;height=26;HudStyle.panel(g,x,y,width,height);RenderUtils.drawItem(g,Items.TOTEM_OF_UNDYING.getDefaultInstance(),x+5,y+5);HudStyle.text(g,mc.font,text,x+26,y+9,HudStyle.TEXT);}
    @Override public void renderHudPlaceholder(GuiGraphicsExtractor g,Minecraft mc){draw(g,mc,12,3);}
}
