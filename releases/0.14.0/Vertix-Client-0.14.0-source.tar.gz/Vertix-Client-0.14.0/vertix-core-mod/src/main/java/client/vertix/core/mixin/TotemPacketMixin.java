package client.vertix.core.mixin;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.client.Minecraft;
import client.vertix.core.modules.pvp.TotemCounterModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPacketListener.class)
public class TotemPacketMixin {
    @Inject(method="handleEntityEvent",at=@At("TAIL"))
    private void event(ClientboundEntityEventPacket packet,CallbackInfo ci){var m=TotemCounterModule.instance();var mc=Minecraft.getInstance();if(m!=null&&mc.level!=null)m.event(packet.getEntity(mc.level),packet.getEventId());}
}
