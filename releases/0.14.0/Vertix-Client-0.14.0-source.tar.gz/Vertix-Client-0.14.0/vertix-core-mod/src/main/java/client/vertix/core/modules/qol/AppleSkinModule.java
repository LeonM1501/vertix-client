package client.vertix.core.modules.qol;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
import net.minecraft.client.Minecraft;
/** Controls the bundled, unmodified AppleSkin through its public config fields. */
public final class AppleSkinModule extends Module {
    private String applied;
    public AppleSkinModule(){super("appleskin","AppleSkin","Original AppleSkin: Nahrung, Sättigung und Heilung direkt im Vertix-Menü.",Category.QOL,true,false,0,0);
        for(String[] entry:new String[][]{{"tooltip","Tooltip"},{"saturation","Sättigung"},{"food","Nahrungsvorschau"},{"exhaustion","Erschöpfung"},{"health","Heilungsvorschau"}})addSetting(new Setting.BooleanSetting(entry[0],entry[1],"AppleSkin-Anzeige ein- oder ausblenden.",true));
    }
    private boolean flag(String id){return isEnabled()&&getSetting(id,Setting.BooleanSetting.class).getValue();}
    public void sync(){
        String signature=""+isEnabled()+flag("tooltip")+flag("saturation")+flag("food")+flag("exhaustion")+flag("health");if(signature.equals(applied))return;
        try{
            Class<?> type=Class.forName("squeek.appleskin.ModConfig");
            String[][] fields={{"showFoodValuesInTooltip","SHOW_FOOD_VALUES_IN_TOOLTIP","tooltip"},{"showFoodValuesInTooltipAlways","ALWAYS_SHOW_FOOD_VALUES_TOOLTIP","tooltip"},{"showSaturationHudOverlay","SHOW_SATURATION_OVERLAY","saturation"},{"showFoodValuesHudOverlay","SHOW_FOOD_VALUES_OVERLAY","food"},{"showFoodExhaustionHudUnderlay","SHOW_FOOD_EXHAUSTION_UNDERLAY","exhaustion"},{"showFoodHealthHudOverlay","SHOW_FOOD_HEALTH_HUD_OVERLAY","health"}};
            Object config;
            try{config=type.getField("INSTANCE").get(null);if(config==null)return;}catch(NoSuchFieldException forge){config=null;}
            for(var field:fields){
                if(config!=null)type.getField(field[0]).setBoolean(config,flag(field[2]));
                else{Object value=type.getField(field[1]).get(null);value.getClass().getMethod("set",Object.class).invoke(value,flag(field[2]));}
            }
            applied=signature;
        }catch(ReflectiveOperationException e){if(applied==null)System.err.println("[Vertix] AppleSkin-Anbindung fehlgeschlagen: "+e);applied=signature;}
    }
}
