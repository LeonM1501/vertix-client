package client.vertix.core.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import client.vertix.core.modules.visual.LowOverlayModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ScreenEffectRenderer.class)
public class LowEffectsMixin {
    @ModifyArg(method="lambda$submitFire$0",at=@At(value="INVOKE",target="Lorg/joml/Matrix4f;translate(FFF)Lorg/joml/Matrix4f;",ordinal=0),index=1)
    private static float fire(float y){return y-(float)LowOverlayModule.amount("low_fire");}
    @Inject(method="renderItemActivationAnimation",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V",ordinal=0,shift=At.Shift.AFTER))
    private void totemStart(net.minecraft.client.renderer.state.level.PlayerRenderState player,PoseStack pose,float delta,SubmitNodeCollector nodes,CallbackInfo ci){double amount=LowOverlayModule.totemAmount(player.itemActivation==null?null:player.itemActivation.item);pose.translate(0,-amount,0);float scale=(float)(1-amount*.65);pose.scale(scale,scale,scale);}
}
