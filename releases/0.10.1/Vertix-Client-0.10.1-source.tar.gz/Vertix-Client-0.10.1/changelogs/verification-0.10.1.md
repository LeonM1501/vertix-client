# Prüfung 0.10.1

- TypeScript und Vite-Produktionsbuild bestanden.
- Bestehende Icon-Persistenzprüfung bestanden: root/legacy-extra, Fallback und bisherige Symbole.
- 24 PNGs mit eindeutigen IDs, 256×256, RGBA/Transparenz, Payload unter bestehendem nativen Limit, Profil-JSON-Roundtrip und React-Bildausgabe geprüft.
- Browserprüfung an isolierter Vorschau 127.0.0.1:1435: Grasblock auswählen, Hintergrund wechseln, 128/40/28/20px-Vorschau, Suche nach TNT, Blockwechsel und Auswahlstatus erfolgreich. Screenshot artifacts/verification/upgrade-0.10.1/block-editor.png.
- Persönliche Instanzen unverändert. Browser-Vorschau hat keinen nativen Speichern-Zugang; Persistenz durch bereits vorhandenes PNG-Schema und Roundtrip-Prüfung abgedeckt. Kein neuer Backend-Datentyp.
- Ingame-Code unverändert gegenüber vollständig geprüftem Core 1.5.0 aus 0.10.0. Client-Build und Veröffentlichung werden abschließend dokumentiert.
