// Paints the built-in capes pixel by pixel. The Java mod uses the same formulas (CapeArt.java), so launcher and game match.
export type CapeRecipe = { id: string; name: string; pattern: string; colors: string[] };
type Rgb = [number, number, number];

const rgb = (hex: string): Rgb => { const n = parseInt(hex.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const mix = (a: Rgb, b: Rgb, t: number): Rgb => [0, 1, 2].map(i => Math.round(a[i] + (b[i] - a[i]) * Math.max(0, Math.min(1, t)))) as Rgb;
// Deterministic per-pixel noise so every client paints identical stars and flames.
const hash = (x: number, y: number) => { let h = (x * 374761393 + y * 668265263) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967295; };

/** Colour of one pixel of the cape front (w x h, normally 10 x 16). */
export function capePixel(recipe: CapeRecipe, x: number, y: number, w: number, h: number): Rgb {
  const a = rgb(recipe.colors[0]), b = rgb(recipe.colors[1] ?? recipe.colors[0]), v = y / Math.max(1, h - 1), u = x / Math.max(1, w - 1);
  switch (recipe.pattern) {
    case 'stripes': return Math.floor((x + y) / 2) % 2 === 0 ? a : b;
    case 'checker': return (Math.floor(x / 2) + Math.floor(y / 2)) % 2 === 0 ? a : b;
    case 'waves': return mix(a, b, v + Math.sin(u * Math.PI * 2 + v * 6) * 0.18);
    case 'stars': { const base = mix(a, b, v * 0.8); return hash(x, y) > 0.9 ? mix(base, [255, 255, 255], 0.85) : base; }
    case 'flames': { const edge = 1 - v - Math.sin(u * 9 + hash(x, 0) * 3) * 0.12; return edge > 0.55 ? mix(b, a, (edge - 0.55) * 2.4) : mix([24, 6, 6], b, edge / 0.55); }
    case 'aurora': { const band = Math.sin(u * 5 + v * 3) * 0.5 + 0.5; return mix([8, 10, 28], mix(a, b, u), band * (1 - Math.abs(v - 0.45) * 1.6)); }
    default: return mix(a, b, v);
  }
}

/** Full 64x32 cape texture as a data URL, laid out like CapeTextures.paint in the mod. */
const capeTextures = new Map<string, string>();
export function capeTexture(recipe: CapeRecipe): string {
  const known = capeTextures.get(recipe.id); if (known) return known;
  const canvas = document.createElement('canvas'); canvas.width = 64; canvas.height = 32;
  const ctx = canvas.getContext('2d'); if (!ctx) return '';
  const image = ctx.createImageData(64, 32), edge = mix([0, 0, 0], rgb(recipe.colors[1] ?? recipe.colors[0]), 0.75);
  const put = (x: number, y: number, c: Rgb) => { const o = (y * 64 + x) * 4; image.data.set([c[0], c[1], c[2], 255], o); };
  for (let y = 0; y < 32; y++) for (let x = 0; x < 64; x++) put(x, y, edge);
  for (let y = 0; y < 16; y++) for (let x = 0; x < 10; x++) { const c = capePixel(recipe, x, y, 10, 16); put(1 + x, 1 + y, c); put(12 + x, 1 + y, mix([0, 0, 0], c, 0.6)); }
  ctx.putImageData(image, 0, 0);
  const url = canvas.toDataURL(); capeTextures.set(recipe.id, url);
  return url;
}

/** Draws the cape front scaled into a canvas. */
export function paintCape(canvas: HTMLCanvasElement, recipe: CapeRecipe, w = 10, h = 16) {
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d'); if (!ctx) return;
  const image = ctx.createImageData(w, h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const [r, g, bl] = capePixel(recipe, x, y, w, h), o = (y * w + x) * 4;
    image.data[o] = r; image.data[o + 1] = g; image.data[o + 2] = bl; image.data[o + 3] = 255;
  }
  ctx.putImageData(image, 0, 0);
}
