import { useEffect, useRef, useState } from 'react';
import { Check, Flag, LoaderCircle, Trash2, Upload, X } from 'lucide-react';
import { drawAura, drawHat, drawWings } from './cosmeticArt';
import * as api from './api';
import { capeTexture, paintCape, type CapeRecipe } from './capeArt';
import { SkinPreview } from './SkinPreview';

const API = 'https://vertix-api.vertixclient.workers.dev';
type Item = { id: string; name: string; colors?: string[]; animated?: boolean };
type Catalog = { capes: CapeRecipe[]; hats: Item[]; wings: Item[]; auras: Item[]; nametags: Item[] };
type Loadout = { hat: string | null; wings: string | null; aura: string | null; cape: string | null; nametag: string };
type UploadedCape = { id: string; url: string; status: string };
type Session = { token: string; uuid: string; name: string };
const EMPTY: Loadout = { hat: null, wings: null, aura: null, cape: null, nametag: 'default' };
const TABS = [['cape', 'Capes'], ['hat', 'Hüte'], ['wings', 'Flügel'], ['aura', 'Auren'], ['nametag', 'Nametag']] as const;
type Tab = typeof TABS[number][0];
// The session token lives only in memory; the launcher signs in again via Mojang after a restart.
let session: Session | null = null;
// Tauri commands reject with { message, kind }; fetch rejects with Error.
const errorText = (e: unknown) => e instanceof Error ? e.message : typeof e === 'string' ? e : e && typeof e === 'object' && 'message' in e ? String((e as { message: unknown }).message) : 'Unbekannter Fehler.';

async function call<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(API + path, { ...init, headers: { ...(session ? { authorization: `Bearer ${session.token}` } : {}), ...(init.body && !(init.body instanceof Blob) ? { 'content-type': 'application/json' } : {}), ...init.headers } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Der Vertix-Server antwortet nicht.');
  return data as T;
}

/** Renders the actual cosmetic from the shared voxel art instead of an icon. */
function ArtTile({ kind, id }: { kind: 'hat' | 'wings' | 'aura'; id: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => { if (ref.current) (kind === 'hat' ? drawHat : kind === 'wings' ? drawWings : drawAura)(ref.current, id); }, [kind, id]);
  return <canvas ref={ref} className={`cosmetic-art ${kind}`} aria-hidden="true" />;
}

function CapeTile({ recipe }: { recipe: CapeRecipe }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => { if (ref.current) paintCape(ref.current, recipe); }, [recipe]);
  return <canvas ref={ref} className="cape-art" aria-hidden="true" />;
}

const gradient = (item?: Item) => item?.colors && item.colors.length > 1 ? `linear-gradient(90deg, ${item.colors.join(', ')})` : undefined;
function NametagPreview({ name, style }: { name: string; style?: Item }) {
  return <span className={`nametag-preview ${style?.animated ? 'animated' : ''}`}><img src="/vertix.svg" alt="" /><span style={{ backgroundImage: gradient(style), color: style?.colors?.length === 1 ? style.colors[0] : undefined }}>{name}</span></span>;
}

export function Cosmetics({ notify, accountName, accountId }: { notify: (text: string, error?: boolean) => void; accountName: string | null; accountId: string | null }) {
  const [catalog, setCatalog] = useState<Catalog | null>(null), [loadout, setLoadout] = useState<Loadout>(EMPTY), [saved, setSaved] = useState<Loadout>(EMPTY);
  const [uploads, setUploads] = useState<UploadedCape[]>([]), [tab, setTab] = useState<Tab>('cape'), [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState(''), [busy, setBusy] = useState(false), [reportName, setReportName] = useState('');
  const file = useRef<HTMLInputElement>(null);

  async function load() {
    setState('loading'); setError('');
    try {
      const cat = await call<Catalog>('/v1/catalog'); setCatalog(cat);
      if (!api.desktop) { setState('ready'); return; }
      if (!session) session = await api.call<Session>('cosmetics_login');
      const me = await call<{ loadout: Loadout | null; uploads: UploadedCape[] }>('/v1/me');
      const current = { ...EMPTY, ...(me.loadout ?? {}) }; setLoadout(current); setSaved(current); setUploads(me.uploads); setState('ready');
    } catch (e) { session = null; setError(errorText(e)); setState('error'); }
  }
  useEffect(() => { void load(); }, []);

  const dirty = JSON.stringify(loadout) !== JSON.stringify(saved);
  async function save() {
    setBusy(true);
    try { const r = await call<{ loadout: Loadout }>('/v1/me/cosmetics', { method: 'PUT', body: JSON.stringify(loadout) }); setLoadout(r.loadout); setSaved(r.loadout); notify('Cosmetics gespeichert. Andere Vertix-Spieler sehen sie in wenigen Sekunden.'); }
    catch (e) { notify(errorText(e), true); } finally { setBusy(false); }
  }
  async function upload(picked: File) {
    // Check the cape layout locally first so players get instant feedback.
    const url = URL.createObjectURL(picked);
    try {
      const img = await new Promise<HTMLImageElement>((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => bad(new Error('Das Bild konnte nicht gelesen werden.')); i.src = url; });
      if (picked.type !== 'image/png') throw new Error('Bitte eine PNG-Datei wählen.');
      if (img.width !== img.height * 2 || img.width < 64 || img.width > 1024 || img.width % 64) throw new Error('Capes brauchen 2:1, zum Beispiel 64×32 oder 128×64 Pixel.');
      setBusy(true);
      const r = await call<UploadedCape>('/v1/me/capes', { method: 'POST', body: picked, headers: { 'content-type': 'image/png' } });
      setUploads(list => [{ ...r, status: 'active' }, ...list]); setLoadout(l => ({ ...l, cape: `upload:${r.id}` }));
      notify('Cape hochgeladen. Speichern, um es zu tragen.');
    } catch (e) { notify(errorText(e), true); } finally { URL.revokeObjectURL(url); setBusy(false); }
  }
  async function remove(id: string) {
    setBusy(true);
    try { await call(`/v1/me/capes/${id}`, { method: 'DELETE' }); setUploads(list => list.filter(c => c.id !== id)); const clear = (l: Loadout) => l.cape === `upload:${id}` ? { ...l, cape: null } : l; setLoadout(clear); setSaved(clear); }
    catch (e) { notify(errorText(e), true); } finally { setBusy(false); }
  }
  async function report() {
    const name = reportName.trim(); if (!name) return;
    setBusy(true);
    try { await call(`/v1/capes/by-name/${encodeURIComponent(name)}/report`, { method: 'POST', body: JSON.stringify({ reason: 'Gemeldet im Launcher' }) }); setReportName(''); notify(`Cape von ${name} gemeldet. Danke!`); }
    catch (e) { notify(errorText(e), true); } finally { setBusy(false); }
  }

  if (state === 'loading') return <div className="cosmetics-status"><LoaderCircle className="spin" size={22} />Verbinde mit Vertix …</div>;
  if (state === 'error' || !catalog) return <div className="cosmetics-status"><p>{error || 'Cosmetics konnten nicht geladen werden.'}</p><button className="button light" onClick={() => void load()}>Erneut versuchen</button></div>;
  const pick = (slot: Exclude<Tab, 'nametag'>, id: string) => setLoadout(l => ({ ...l, [slot]: l[slot] === id ? null : id }));
  const items: Item[] = tab === 'hat' ? catalog.hats : tab === 'wings' ? catalog.wings : tab === 'aura' ? catalog.auras : [];
  const style = catalog.nametags.find(n => n.id === loadout.nametag);
  const builtin = catalog.capes.find(c => c.id === loadout.cape), cape = builtin ? capeTexture(builtin) : uploads.find(c => `upload:${c.id}` === loadout.cape)?.url ?? null;

  return <div className="cosmetics">
    <div className="page-heading"><div><h1>Cosmetics</h1><p>Nur Spieler mit Vertix sehen deine Cosmetics und das Vertix-Logo neben deinem Namen.</p></div>
      <div className="profile-create-actions"><button className="button light" disabled={!dirty || busy || !api.desktop} onClick={() => void save()}>{busy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}Speichern</button></div></div>
    {!api.desktop && <p className="instance-notice">Vorschau im Browser: Speichern und Hochladen gehen in der Desktop-App.</p>}
    <div className="cosmetics-stage"><SkinPreview accountId={accountId} username={session?.name || accountName} cape={cape} hat={loadout.hat} wings={loadout.wings} autoRotate><div className="cosmetics-stage-tag"><NametagPreview name={session?.name || accountName || 'Spieler'} style={style} /></div></SkinPreview></div>
    <div className="cosmetics-hero"><span>{[loadout.hat, loadout.wings, loadout.aura].filter(Boolean).length + (loadout.cape ? 1 : 0)} Cosmetics aktiv</span></div>
    <div className="instance-tabs" role="tablist">{TABS.map(([id, label]) => <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}>{label}</button>)}</div>

    {tab === 'cape' && <div className="cosmetic-grid">
      <button className={`cosmetic-card upload ${busy ? 'busy' : ''}`} disabled={busy || !api.desktop} onClick={() => file.current?.click()}><Upload size={22} /><strong>Eigenes Cape</strong><small>PNG · 64×32 bis 1024×512</small></button>
      <input ref={file} type="file" accept="image/png" hidden onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) void upload(f); }} />
      {uploads.map(c => <div key={c.id} className={`cosmetic-card ${loadout.cape === `upload:${c.id}` ? 'selected' : ''}`}>
        <button className="cosmetic-pick" disabled={c.status !== 'active'} onClick={() => setLoadout(l => ({ ...l, cape: l.cape === `upload:${c.id}` ? null : `upload:${c.id}` }))}><img className="cape-upload" src={c.url} alt="Eigenes Cape" /><strong>{c.status === 'active' ? 'Eigenes Cape' : 'Ausgeblendet'}</strong><small>{c.status === 'active' ? 'Hochgeladen' : 'Nach Meldungen ausgeblendet'}</small></button>
        <button className="icon-button cosmetic-delete" aria-label="Cape löschen" onClick={() => void remove(c.id)}><Trash2 size={15} /></button>
      </div>)}
      {catalog.capes.map(c => <button key={c.id} className={`cosmetic-card ${loadout.cape === c.id ? 'selected' : ''}`} onClick={() => pick('cape', c.id)}><CapeTile recipe={c} /><strong>{c.name}</strong><small>Vertix-Cape</small></button>)}
    </div>}

    {(tab === 'hat' || tab === 'wings' || tab === 'aura') && <div className="cosmetic-grid">
      {items.map(item => { const on = loadout[tab] === item.id; return <button key={item.id} className={`cosmetic-card ${on ? 'selected' : ''}`} onClick={() => pick(tab, item.id)}><ArtTile kind={tab} id={item.id} /><strong>{item.name}</strong><small>{on ? 'Ausgerüstet' : 'Antippen zum Tragen'}</small></button>; })}
    </div>}

    {tab === 'nametag' && <div className="cosmetic-grid nametags">
      {catalog.nametags.map(n => <button key={n.id} className={`cosmetic-card ${loadout.nametag === n.id ? 'selected' : ''}`} onClick={() => setLoadout(l => ({ ...l, nametag: n.id }))}><NametagPreview name={session?.name || accountName || 'Spieler'} style={n} /><strong>{n.name}</strong></button>)}
    </div>}

    <section className="cosmetics-report"><Flag size={16} /><span>Unpassendes Cape gesehen?</span>
      <input placeholder="Spielername" value={reportName} maxLength={16} onChange={e => setReportName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') void report(); }} />
      <button className="button small" disabled={busy || !reportName.trim() || !api.desktop} onClick={() => void report()}>Melden</button>
      {reportName && <button className="icon-button" aria-label="Leeren" onClick={() => setReportName('')}><X size={14} /></button>}
    </section>
  </div>;
}
