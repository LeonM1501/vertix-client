import { type ReactNode, memo, useEffect, useMemo, useRef, useState } from 'react';
import { LoaderCircle, RotateCcw } from 'lucide-react';
import * as api from './api';
import { skinFaces, skinParts } from './skinGeometry';
import { hatArt, wingArt, wingTexture } from './cosmeticArt';

type Skin = { base64: string; variant: 'classic' | 'slim' };
const px = (n:number) => `calc(${n} * var(--skin-pixel))`;
const wrap = (deg:number) => ((deg + 180) % 360 + 360) % 360 - 180;
const clampPitch = (deg:number) => Math.max(-60, Math.min(60, deg));
const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
// Survives page switches so the preview never flashes the default skin while reloading.
const skinCache=new Map<string,Skin>();
const START={yaw:-25,pitch:-6};
export function SkinPreview({ accountId, username, cape, hat, wings, autoRotate=false, children }: { accountId?: string | null; username?: string | null; cape?: string | null; hat?: string | null; wings?: string | null; autoRotate?: boolean; children?: ReactNode }) {
  const [skin,setSkin]=useState<Skin|null>(()=>accountId?skinCache.get(accountId)??null:null), [loading,setLoading]=useState(false), [failed,setFailed]=useState(false), [retry,setRetry]=useState(0);
  const [loaded,setLoaded]=useState(''), [legacy,setLegacy]=useState(false);
  // Rotation lives in refs and is written straight to the DOM, so dragging never re-renders the ~150 face elements.
  const model=useRef<HTMLDivElement>(null), stage=useRef<HTMLDivElement>(null);
  const view=useRef({...START,vYaw:0,vPitch:0,idleSince:0,frame:0});
  const drag=useRef<{x:number;y:number;t:number;moved:boolean}|null>(null);
  const apply=()=>{const v=view.current;if(model.current)model.current.style.transform=`translateX(-50%) rotateX(${v.pitch}deg) rotateY(${v.yaw}deg)`;stage.current?.setAttribute('aria-valuenow',String(Math.round(wrap(v.yaw))));};
  // Momentum after a flick, then (on request) a slow idle spin a few seconds after the last touch.
  const animate=()=>{
    const v=view.current;cancelAnimationFrame(v.frame);
    let last=performance.now();
    const step=(now:number)=>{
      const dt=Math.min(.05,(now-last)/1000);last=now;
      if(drag.current){v.frame=0;return;}
      const coasting=Math.abs(v.vYaw)>2||Math.abs(v.vPitch)>2;
      if(coasting){v.yaw+=v.vYaw*dt;v.pitch=clampPitch(v.pitch+v.vPitch*dt);const decay=Math.pow(.04,dt);v.vYaw*=decay;v.vPitch*=decay;v.idleSince=now;}
      else if(autoRotate&&!reducedMotion()&&now-v.idleSince>2500){v.yaw+=18*dt;v.pitch+=(START.pitch-v.pitch)*Math.min(1,dt*2);}
      else if(!autoRotate){v.frame=0;apply();return;}
      apply();v.frame=requestAnimationFrame(step);
    };
    v.frame=requestAnimationFrame(step);
  };
  useEffect(()=>{apply();if(autoRotate)animate();return()=>cancelAnimationFrame(view.current.frame);},[autoRotate]);
  const reset=()=>{Object.assign(view.current,START,{vYaw:0,vPitch:0,idleSince:performance.now()});apply();if(autoRotate)animate();};
  const turn=(yaw:number,pitch=0)=>{const v=view.current;v.yaw+=yaw;v.pitch=clampPitch(v.pitch+pitch);v.idleSince=performance.now();apply();if(autoRotate)animate();};
  const parts=useMemo(()=>skinParts(skin?.variant==='slim',legacy),[skin?.variant,legacy]);
  const [waving,setWaving]=useState(false);
  // Wave once the skin is visible (after the intro, if one is playing) and whenever the intro ends.
  useEffect(()=>{const wave=()=>setWaving(true);window.addEventListener('vertix-wave',wave);return()=>window.removeEventListener('vertix-wave',wave);},[]);
  useEffect(()=>{
    let cancelled=false;
    const cached=accountId?skinCache.get(accountId)??null:null;
    setSkin(cached); setFailed(false); setLoading(false);
    if(api.desktop && accountId){
      setLoading(!cached);
      api.call<Skin>('get_vertix_skin',{accountId}).then(value=>{skinCache.set(accountId,value);if(!cancelled)setSkin(value);}).catch(()=>{if(!cancelled&&!cached)setFailed(true);}).finally(()=>{if(!cancelled)setLoading(false);});
    }
    return ()=>{cancelled=true;};
  },[accountId,retry]);
  const source=skin?`data:image/png;base64,${skin.base64}`:'/skins/steve.png';
  const ready=loaded===source;
  useEffect(()=>{if(ready&&!document.documentElement.dataset.intro)setWaving(true);},[ready]);
  return <div className="skin-preview">
    <div className="skin-name"><span className="eyebrow">{accountId?'DEIN SPIELER':'DEIN SPIELRAUM'}</span><strong>{username||'Bereit für deine Welt.'}</strong></div>
    <div className="skin-stage" ref={stage} role="slider" tabIndex={0} aria-valuemin={-180} aria-valuemax={180} aria-valuetext="Ziehen oder Pfeiltasten drehen das Modell in alle Richtungen" aria-label={accountId && skin && ready?`3D-Skin von ${username}`:'Minecraft-Standardskin als Vorschau'}
      onPointerDown={e=>{cancelAnimationFrame(view.current.frame);Object.assign(view.current,{vYaw:0,vPitch:0});drag.current={x:e.clientX,y:e.clientY,t:performance.now(),moved:false};e.currentTarget.setPointerCapture(e.pointerId);}}
      onPointerMove={e=>{const d=drag.current;if(!d)return;const dx=e.clientX-d.x,dy=e.clientY-d.y,now=performance.now(),dt=Math.max(1,now-d.t)/1000;if(Math.abs(dx)+Math.abs(dy)>3)d.moved=true;const v=view.current;v.yaw+=dx*.55;v.pitch=clampPitch(v.pitch-dy*.45);v.vYaw=dx*.55/dt;v.vPitch=-dy*.45/dt;Object.assign(d,{x:e.clientX,y:e.clientY,t:now});apply();}}
      onPointerUp={()=>{const d=drag.current;drag.current=null;if(d&&!d.moved)setWaving(true);if(d&&performance.now()-d.t>80)Object.assign(view.current,{vYaw:0,vPitch:0});view.current.idleSince=performance.now();animate();}}
      onPointerCancel={()=>{drag.current=null;animate();}} onDoubleClick={reset}
      onKeyDown={e=>{const k:Record<string,[number,number]>={ArrowLeft:[-15,0],ArrowRight:[15,0],ArrowUp:[0,10],ArrowDown:[0,-10]};if(k[e.key]){e.preventDefault();turn(...k[e.key]);}}}>
      <svg className="skin-floor" viewBox="0 0 600 160" aria-hidden="true"><path d="M0 150L230 0M120 160L260 0M240 160L290 0M360 160L320 0M480 160L350 0M600 150L380 0M0 150H600M70 100H530M145 58H455M205 25H395"/></svg>
      <div className="skin-platform"/>
      <div ref={model} className={`skin-model${waving?' waving':''}`} onAnimationEnd={e=>{if(e.animationName==='skin-wave')setWaving(false);}} style={{visibility:ready?'visible':'hidden'}}>
        {parts.map(p=><div key={p.name} className={`skin-part skin-${p.name}`} style={{left:px(p.x),top:px(p.y),width:px(p.w),height:px(p.h),transform:p.mirrored?'scaleX(-1)':undefined}}>
          {[p.uv,...(p.overlay?[p.overlay]:[])].map((uv,index)=><div key={index} className={`skin-cube ${index?'skin-overlay':''}`}>
            {skinFaces(p,uv).map(f=><i key={f.name} className={`skin-face skin-face-${f.name}`} style={{width:px(f.w),height:px(f.h),backgroundImage:`url("${source}")`,backgroundSize:`${px(64)} ${px(legacy?32:64)}`,backgroundPosition:`${px(-f.u)} ${px(-f.v)}`,transform:`translate(-50%,-50%) ${f.rotation} translateZ(${px(f.offset)})`}}/>)}</div>)}
          {p.name==='head'&&<HatModel id={hat??null}/>}
          {p.name==='body'&&<WingModel id={wings??null}/>}
        </div>)}
        {cape&&<div className="skin-part skin-cape" style={{left:px(3),top:px(8),width:px(10),height:px(16),transform:`translateZ(${px(-2.6)}) rotateX(-9deg) rotateY(180deg)`}}>
          <div className="skin-cube">{skinFaces({name:'cape',x:3,y:8,w:10,h:16,d:1,uv:[0,0]}).map(f=><i key={f.name} className={`skin-face skin-face-${f.name}`} style={{width:px(f.w),height:px(f.h),backgroundImage:`url("${cape}")`,backgroundSize:`${px(64)} ${px(32)}`,backgroundPosition:`${px(-f.u)} ${px(-f.v)}`,transform:`translate(-50%,-50%) ${f.rotation} translateZ(${px(f.offset)})`}}/>)}</div>
        </div>}
      </div>
      {children}
      {(!ready||loading)&&<LoaderCircle size={22} className="skin-loading spin" aria-label="Skin wird geladen"/>}
    </div>
    <img className="skin-texture" src={source} alt="" onLoad={e=>{const image=e.currentTarget;if(image.naturalWidth>=64&&image.naturalWidth<=1024&&[1,2].includes(image.naturalWidth/image.naturalHeight)){setLegacy(image.naturalWidth/image.naturalHeight===2);setLoaded(source);}else{setSkin(null);setFailed(true);}}} onError={()=>{if(skin){setSkin(null);setFailed(true);}}}/>
    <div className="skin-controls"><span>Ziehen zum Drehen · 360°</span><button className="icon-button" aria-label="Skin-Drehung zurücksetzen" onClick={reset}><RotateCcw size={14}/></button></div>
    <div className="skin-caption" role="status">{loading?'Dein Skin wird geladen …':failed?<><span>Skin gerade nicht erreichbar · Standardvorschau</span><button onClick={()=>setRetry(n=>n+1)}>Erneut laden</button></>:!accountId?'Melde dich an, um deinen Skin zu sehen.':!api.desktop?'Skin-Vorschau ist in der Desktop-App verfügbar.':null}</div>
  </div>;
}

/** Hat boxes in head space (model pixels, top of head at y = -8, face towards -z), drawn as CSS cubes. */
const HatModel = memo(function HatModel({ id }: { id: string | null }) {
  const art = hatArt(id); if (!art) return null;
  return <div className={`skin-hat${art.bob ? ' bob' : ''}`}>{art.boxes.map(([a, b, c, d, e, f, top, bottom, glow], i) => {
    const w = d - a, h = e - b, depth = f - c, side = `linear-gradient(#${top},#${bottom})`;
    const faces: [string, number, number, string, number, string][] = [
      ['front', w, h, 'rotateY(0deg)', depth / 2, side], ['back', w, h, 'rotateY(180deg)', depth / 2, side],
      ['right', depth, h, 'rotateY(-90deg)', w / 2, side], ['left', depth, h, 'rotateY(90deg)', w / 2, side],
      ['top', w, depth, 'rotateX(90deg)', h / 2, `#${top}`], ['bottom', w, depth, 'rotateX(-90deg)', h / 2, `#${bottom}`],
    ];
    return <div key={i} className={`skin-box${glow ? ' glow' : ''}`} style={{ left: px(a + 4), top: px(b + 8), width: px(w), height: px(h), transform: `translateZ(${px(-(c + f) / 2)})` }}>
      {faces.map(([name, fw, fh, rotation, offset, background]) => <i key={name} className={`skin-face skin-face-${name}`} style={{ width: px(fw), height: px(fh), background, transform: `translate(-50%,-50%) ${rotation} translateZ(${px(offset)})` }} />)}
    </div>;
  })}</div>;
});

/** Both wings as textured planes hinged behind the shoulders, flapping like in game. */
const WingModel = memo(function WingModel({ id }: { id: string | null }) {
  const art = wingArt(id); if (!art || !id) return null;
  const texture = wingTexture(id), w = art.rows[0].length * art.scale, h = art.rows.length * art.scale;
  return <>{[-1, 1].map(side => <div key={side} className={`skin-wing${id === 'butterfly' ? ' fast' : ''}`} style={{ left: px(4 + side), top: px(2.5), ['--side' as string]: side, transform: `translateZ(${px(-2.3)}) rotateY(${side * 24}deg) rotateZ(${-side * 18}deg) scaleX(${side})` }}>
    <div className="skin-wing-flap"><i style={{ left: px(-art.anchor[0] * art.scale), top: px(-art.anchor[1] * art.scale), width: px(w), height: px(h), backgroundImage: `url("${texture}")` }} /></div>
  </div>)}</>;
});
