import client.vertix.core.performance.*;
public class PerformanceLogicTest {
    private static void check(boolean value,String label){if(!value)throw new AssertionError(label);}
    public static void main(String[] args){
        var values=new java.util.HashMap<String,Integer>();values.put("view",24);values.put("manual",10);
        var overrides=new OptionOverrides();overrides.set("view",()->values.get("view"),v->values.put("view",v),8);overrides.set("manual",()->values.get("manual"),v->values.put("manual",v),5);
        values.put("manual",7);overrides.restore();check(values.get("view")==24,"restore owned option");check(values.get("manual")==7,"preserve manual edit");check(overrides.isEmpty(),"release ownership");overrides.restore();
        var stats=new FrameStats();long now=1_000_000;stats.record(now);for(int i=0;i<100;i++){now+=10_000_000;stats.record(now);}stats.refresh();check(stats.snapshot().frames()==100&&stats.snapshot().lowFps()==100,"steady interval");
        now+=100_000_000;stats.record(now);stats.refresh();check(stats.snapshot().lowFps()==18,"average of slowest 1 percent");check(stats.snapshot().averageMs()>10,"stutter retained");
        for(int i=0;i<700;i++){now+=8_000_000;stats.record(now);}stats.refresh();check(stats.snapshot().frames()==512&&stats.snapshot().graph().length==100,"bounded history");check(stats.snapshot().lowFps()==125,"old samples expired");
        stats.record(now+6_000_000_000L);check(stats.snapshot().frames()==0,"resume after long interruption");System.out.println("Performance option ownership, manual edits, frame history, stutters and 1%-low checks passed.");
    }
}
