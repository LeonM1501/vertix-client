package client.vertix.test;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.*;
import client.vertix.core.modules.qol.*;
import net.minecraft.client.*;
import net.minecraft.client.input.*;
import net.minecraft.world.level.*;
import com.mojang.blaze3d.platform.InputConstants;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Minecraft.class)
public class UpgradeRuntimeTest {
    @Unique private boolean vertix$started;
    @Unique private int vertix$ticks,vertix$fov;
    @Unique private double vertix$sensitivity;
    @Unique private PerformanceModeModule vertix$mode;
    @Unique private Module vertix$fps;
    @Unique private VertixMenuScreen vertix$menu;
    @Unique private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    @Inject(method="tick",at=@At("TAIL"))
    private void vertix$test(CallbackInfo ci){
        Minecraft mc=(Minecraft)(Object)this;var core=VertixCoreMod.getInstance();
        if(!vertix$started){if(!(mc.gui.screen() instanceof net.minecraft.client.gui.screens.TitleScreen)||mc.gui.overlay()!=null)return;vertix$started=true;
            for(Module m:core.getModuleManager().getModules())m.setEnabled(false);
            var settings=new LevelSettings("Vertix Upgrade Test",GameType.CREATIVE,new LevelSettings.DifficultySettings(net.minecraft.world.Difficulty.PEACEFUL,false,false),true,WorldDataConfiguration.DEFAULT);
            mc.createWorldOpenFlows().createFreshLevel("upgrade-test",settings,new net.minecraft.world.level.levelgen.WorldOptions(42L,false,false),net.minecraft.world.level.levelgen.presets.WorldPresets::createTestWorldDimensions,null);return;}
        if(mc.player==null)return;int tick=++vertix$ticks;
        if(tick==20){
            mc.setScreenAndShow(null);mc.options.renderDistance().set(20);mc.options.entityDistanceScaling().set(1.0);mc.options.cloudStatus().set(CloudStatus.FANCY);mc.options.ambientOcclusion().set(true);mc.options.save();
            vertix$mode=PerformanceModeModule.instance();vertix$mode.getSetting("profile",Setting.ModeSetting.class).setValue("Schnell");vertix$mode.setEnabled(true);
            vertix$fov=mc.options.fov().get();vertix$sensitivity=mc.options.sensitivity().get();
        }
        if(tick==35){
            check(mc.options.renderDistance().get()<=8,"graphics distance cap");check(mc.options.entityDistanceScaling().get()<=.6,"entity distance cap");check(mc.options.cloudStatus().get()==CloudStatus.OFF,"cloud override");check(!mc.options.ambientOcclusion().get(),"ambient override");
            mc.options.save();
            try{String saved=java.nio.file.Files.readString(mc.gameDirectory.toPath().resolve("options.txt"));check(saved.contains("renderDistance:20"),"save must preserve original graphics options");}catch(java.io.IOException e){throw new AssertionError(e);}
            check(mc.options.renderDistance().get()<=8,"graphics overrides resume after save");
            mc.options.renderDistance().set(6);vertix$mode.setEnabled(false);
            check(mc.options.renderDistance().get()==6,"manual graphics change must survive disabling");check(mc.options.cloudStatus().get()==CloudStatus.FANCY,"clouds restore");check(mc.options.ambientOcclusion().get(),"ambient restore");check(mc.options.entityDistanceScaling().get()==1,"entity distance restore");
        }
        if(tick==40){vertix$mode.getSetting("profile",Setting.ModeSetting.class).setValue("Maximum");vertix$mode.setEnabled(true);}
        if(tick==50){check(mc.options.renderDistance().get()<=5,"maximum profile");vertix$mode.setEnabled(false);check(mc.options.renderDistance().get()==6,"maximum restore");var saver=(BackgroundFpsModule)core.getModuleManager().getModule("background_fps");check(saver.limit(240,false)==30&&saver.limit(10,false)==10&&saver.limit(240,true)==240,"background limit policy");ZoomModule.instance().setEnabled(true);core.getKeyZoom().setDown(true);}
        if(tick==65){check(mc.options.fov().get()<vertix$fov,"hold zoom");mc.options.save();try{String file=java.nio.file.Files.readString(mc.gameDirectory.toPath().resolve("options.txt"));String value=file.lines().filter(l->l.startsWith("fov:")).findFirst().orElseThrow().substring(4);double parsed=Double.parseDouble(value);check(Math.abs(parsed-(vertix$fov-70)/40.0)<.001||parsed==vertix$fov,"zoom must not persist in options.txt");}catch(java.io.IOException e){throw new AssertionError(e);}core.getKeyZoom().setDown(false);}
        if(tick==70){check(mc.options.fov().get()==vertix$fov,"zoom FOV restore");check(mc.options.sensitivity().get()==vertix$sensitivity,"zoom mouse restore");}
        if(tick==80){vertix$fps=core.getModuleManager().getModule("fps");vertix$fps.setEnabled(true);vertix$fps.getSetting("view",Setting.ModeSetting.class).setValue("Graph");vertix$fps.setX(12);vertix$fps.setY(12);var session=core.getModuleManager().getModule("session");session.setEnabled(true);session.setX(200);session.setY(12);}
        if(tick==110){check(core.getFrameStats().snapshot().frames()>20,"real render-frame sampling");capture(mc,"upgrade-live-hud.png");}
        if(tick==120){mc.setScreenAndShow(new HudEditorScreen(null));}
        if(tick==140){capture(mc,"upgrade-hud-editor.png");vertix$fps.setFavorite(true);core.getConfigManager().saveConfig(core.getModuleManager().getModules());vertix$fps.setFavorite(false);core.getConfigManager().loadConfig(core.getModuleManager().getModules());check(vertix$fps.isFavorite(),"favorites persistence");}
        if(tick==160){vertix$menu=new VertixMenuScreen();mc.setScreenAndShow(vertix$menu);var layout=new MenuLayout(mc.getWindow().getGuiScaledWidth(),mc.getWindow().getGuiScaledHeight());var nav=layout.nav(client.vertix.core.api.Category.PERFORMANCE.ordinal());vertix$menu.mouseClicked(new MouseButtonEvent(nav.x()+4,nav.y()+4,new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0)),false);}
        if(tick==180){capture(mc,"upgrade-performance-menu.png");var layout=new MenuLayout(mc.getWindow().getGuiScaledWidth(),mc.getWindow().getGuiScaledHeight());var card=layout.card(1,0);vertix$menu.mouseClicked(new MouseButtonEvent(card.x()+10,card.y()+10,new MouseButtonInfo(InputConstants.MOUSE_BUTTON_RIGHT,0)),false);}
        if(tick==200)capture(mc,"upgrade-performance-settings.png");
        if(tick==230){System.out.println("VERTIX_PERFORMANCE_AND_UPGRADE_TEST_PASSED");System.out.println("VERTIX_UI_TEST_PASSED");mc.stop();}
    }
    @Unique private static void capture(Minecraft mc,String name) {
        try {
            Object target;
            try {target=mc.getClass().getMethod("getMainRenderTarget").invoke(mc);} catch(NoSuchMethodException ignored) {target=mc.gameRenderer.getClass().getMethod("mainRenderTarget").invoke(mc.gameRenderer);}
            java.util.function.Consumer<net.minecraft.network.chat.Component> log=message->System.out.println(message.getString());
            try {Screenshot.class.getMethod("grab",java.io.File.class,String.class,com.mojang.blaze3d.pipeline.RenderTarget.class,int.class,java.util.function.Consumer.class).invoke(null,mc.gameDirectory,name,target,1,log);}
            catch(NoSuchMethodException ignored) {Screenshot.class.getMethod("grab",java.io.File.class,String.class,com.mojang.blaze3d.pipeline.RenderTarget.class,java.util.function.Consumer.class).invoke(null,mc.gameDirectory,name,target,log);}
        } catch(Exception e) {throw new AssertionError(e);}
    }
}
