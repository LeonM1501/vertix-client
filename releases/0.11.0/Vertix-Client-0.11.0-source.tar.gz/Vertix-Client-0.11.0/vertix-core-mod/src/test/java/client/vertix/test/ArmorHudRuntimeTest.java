package client.vertix.test;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.HudEditorScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import com.mojang.blaze3d.platform.InputConstants;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Real rendering, input and persistence test; only runs in an isolated offline game. */
@Mixin(Minecraft.class)
public class ArmorHudRuntimeTest {
    @Unique private boolean vertix$started;
    @Unique private int vertix$ticks,vertix$normalWidth;
    @Unique private Module vertix$armor;
    @Unique private HudEditorScreen vertix$editor;
    @Unique private static void mode(Module m,String key,String value){m.getSetting(key,Setting.ModeSetting.class).setValue(value);}
    @Unique private static void toggle(Module m,String key,boolean value){m.getSetting(key,Setting.BooleanSetting.class).setValue(value);}
    @Unique private static void number(Module m,String key,double value){m.getSetting(key,Setting.NumberSetting.class).setValue(value);}
    @Inject(method="tick",at=@At("TAIL"))
    private void vertix$armorTest(CallbackInfo callback){
        Minecraft mc=(Minecraft)(Object)this;
        if(!vertix$started){
            if(!(mc.gui.screen() instanceof net.minecraft.client.gui.screens.TitleScreen)||mc.gui.overlay()!=null)return;
            for(Module m:VertixCoreMod.getInstance().getModuleManager().getModules())m.setEnabled(false);
            vertix$armor=VertixCoreMod.getInstance().getModuleManager().getModule("armor_hud");vertix$armor.setEnabled(true);
            vertix$editor=new HudEditorScreen(null);mc.setScreenAndShow(vertix$editor);vertix$started=true;
        }
        if(vertix$ticks>=30&&mc.player==null)return;
        int tick=++vertix$ticks;
        if(tick==20)capture(mc,"armor-title-placeholder.png");
        if(tick==30){
            var settings=new net.minecraft.world.level.LevelSettings("Vertix isolated armor test",net.minecraft.world.level.GameType.CREATIVE,
                new net.minecraft.world.level.LevelSettings.DifficultySettings(net.minecraft.world.Difficulty.PEACEFUL,false,false),true,net.minecraft.world.level.WorldDataConfiguration.DEFAULT);
            mc.createWorldOpenFlows().createFreshLevel("armor-test",settings,new net.minecraft.world.level.levelgen.WorldOptions(42L,false,false),
                net.minecraft.world.level.levelgen.presets.WorldPresets::createTestWorldDimensions,null);
            return;
        }
        if(tick==40){
            for(Module m:VertixCoreMod.getInstance().getModuleManager().getModules())m.setEnabled(false);
            vertix$armor=VertixCoreMod.getInstance().getModuleManager().getModule("armor_hud");vertix$armor.setEnabled(true);vertix$armor.setX(16);vertix$armor.setY(16);
            mode(vertix$armor,"durability_display","Prozent + Balken");mode(vertix$armor,"surface_style","Einzelne Slots");
            var chest=new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.IRON_CHESTPLATE);chest.setDamageValue(231);
            mc.player.setItemSlot(net.minecraft.world.entity.EquipmentSlot.CHEST,chest);
            mc.player.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD,new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.IRON_HELMET));
            mc.setScreenAndShow(null);
        }
        if(tick==44)capture(mc,"armor-ingame.png");
        if(tick==45){vertix$editor=new HudEditorScreen(null);mc.setScreenAndShow(vertix$editor);}
        if(tick==60){vertix$normalWidth=vertix$armor.getWidth();if(vertix$normalWidth<100)throw new AssertionError("horizontal layout");capture(mc,"armor-horizontal.png");}
        if(tick==80){mode(vertix$armor,"orientation","Vertikal");mode(vertix$armor,"durability_display","Rest / Gesamt");mode(vertix$armor,"surface_style","Vertix");toggle(vertix$armor,"held",false);number(vertix$armor,"scale",1.25);vertix$armor.setX(320);vertix$armor.setY(16);}
        if(tick==100){if(vertix$armor.getHeight()<=vertix$armor.getWidth())throw new AssertionError("vertical layout");capture(mc,"armor-vertical.png");}
        if(tick==120){mode(vertix$armor,"visibility","Nur kritisch");mode(vertix$armor,"orientation","Horizontal");mode(vertix$armor,"durability_display","Balken");mode(vertix$armor,"surface_style","Minimal");}
        if(tick==140){if(vertix$armor.getWidth()>=vertix$normalWidth)throw new AssertionError("critical filtering");capture(mc,"armor-critical.png");}
        if(tick==160){
            mode(vertix$armor,"visibility","Alle Slots");mode(vertix$armor,"surface_style","Einzelne Slots");mode(vertix$armor,"durability_display","Prozent + Balken");
            toggle(vertix$armor,"held",true);number(vertix$armor,"scale",1);number(vertix$armor,"slot_gap",6);vertix$armor.setX(16);vertix$armor.setY(16);
            var config=VertixCoreMod.getInstance().getConfigManager();var modules=VertixCoreMod.getInstance().getModuleManager().getModules();config.saveConfig(modules);
            mode(vertix$armor,"orientation","Vertikal");toggle(vertix$armor,"held",false);number(vertix$armor,"slot_gap",0);config.loadConfig(modules);
            if(!vertix$armor.getSetting("orientation",Setting.ModeSetting.class).getValue().equals("Horizontal")||!vertix$armor.getSetting("held",Setting.BooleanSetting.class).getValue()||vertix$armor.getSetting("slot_gap",Setting.NumberSetting.class).getValue()!=6)throw new AssertionError("settings did not survive config reload");
        }
        if(tick==180){
            int x=vertix$armor.getX(),y=vertix$armor.getY();var left=new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0);
            vertix$editor.mouseClicked(new MouseButtonEvent(x+3,y+3,left),false);vertix$editor.mouseDragged(new MouseButtonEvent(x+43,y+53,left),40,50);vertix$editor.mouseReleased(new MouseButtonEvent(x+43,y+53,left));
            if(vertix$armor.getX()==x&&vertix$armor.getY()==y)throw new AssertionError("armor editor drag");
        }
        if(tick==200){var right=new MouseButtonInfo(InputConstants.MOUSE_BUTTON_RIGHT,0);vertix$editor.mouseClicked(new MouseButtonEvent(vertix$armor.getX()+3,vertix$armor.getY()+3,right),false);}
        if(tick==220)capture(mc,"armor-settings.png");
        if(tick==240)vertix$editor.mouseScrolled(100,100,0,-30);
        if(tick==260)capture(mc,"armor-settings-style.png");
        if(tick==290){
            for(String file:new String[]{"armor-title-placeholder.png","armor-ingame.png","armor-horizontal.png","armor-vertical.png","armor-critical.png","armor-settings.png","armor-settings-style.png"})if(!new java.io.File(mc.gameDirectory,"screenshots/"+file).isFile())throw new AssertionError("missing "+file);
            System.out.println("VERTIX_ARMOR_HUD_TEST_PASSED");System.out.println("VERTIX_UI_TEST_PASSED");mc.stop();
        }
    }
    @Unique private static void capture(Minecraft mc,String name) {
        try {
            Object target;
            try {target=mc.getClass().getMethod("getMainRenderTarget").invoke(mc);} catch(NoSuchMethodException ignored) {target=mc.gameRenderer.getClass().getMethod("mainRenderTarget").invoke(mc.gameRenderer);}
            java.util.function.Consumer<net.minecraft.network.chat.Component> log=message->System.out.println(message.getString());
            try {Screenshot.class.getMethod("grab",java.io.File.class,String.class,com.mojang.blaze3d.pipeline.RenderTarget.class,int.class,java.util.function.Consumer.class).invoke(null,mc.gameDirectory,name,target,1,log);}
            catch(NoSuchMethodException ignored) {Screenshot.class.getMethod("grab",java.io.File.class,String.class,com.mojang.blaze3d.pipeline.RenderTarget.class,java.util.function.Consumer.class).invoke(null,mc.gameDirectory,name,target,log);}
        } catch(Exception e) {throw new AssertionError(e);}
    }
}
