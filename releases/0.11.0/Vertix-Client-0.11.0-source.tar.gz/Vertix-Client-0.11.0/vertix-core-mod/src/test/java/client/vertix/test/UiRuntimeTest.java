package client.vertix.test;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Module;
import client.vertix.core.gui.HudEditorScreen;
import client.vertix.core.gui.VertixMenuScreen;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Actual render/input smoke test in its own offline game; never shipped. */
@Mixin(Minecraft.class)
public class UiRuntimeTest {
    @Unique private boolean vertix$started;
    @Unique private int vertix$ticks;
    @Unique private HudEditorScreen vertix$editor;
    @Unique private Module vertix$fps;
    @Inject(method="tick",at=@At("TAIL"))
    private void vertix$ui(CallbackInfo callback) {
        Minecraft mc=(Minecraft)(Object)this;
        if(!vertix$started){if(!(mc.gui.screen() instanceof net.minecraft.client.gui.screens.TitleScreen))return;vertix$started=true;}
        int tick=++vertix$ticks;
        if(tick==40){vertix$fps=VertixCoreMod.getInstance().getModuleManager().getModule("fps");vertix$fps.setEnabled(true);vertix$fps.setX(100);vertix$fps.setY(2);mc.setScreenAndShow(new VertixMenuScreen());}
        if(tick==50){var menu=(VertixMenuScreen)mc.gui.screen();var button=new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0);if(!menu.mouseClicked(new MouseButtonEvent(103,5,button),false))throw new AssertionError("Menu HUD click");menu.mouseDragged(new MouseButtonEvent(83,5,button),-20,0);menu.mouseReleased(new MouseButtonEvent(83,5,button));if(vertix$fps.getX()==100)throw new AssertionError("HUD must move while menu stays open");}
        if(tick==60)capture(mc,"vertix-mod-menu.png");
        if(tick==80){vertix$fps=VertixCoreMod.getInstance().getModuleManager().getModule("fps");vertix$fps.setEnabled(true);vertix$editor=new HudEditorScreen(new VertixMenuScreen());mc.setScreenAndShow(vertix$editor);}
        if(tick==100){
            int x=vertix$fps.getX(),y=vertix$fps.getY();
            var button=new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0);
            if(!vertix$editor.mouseClicked(new MouseButtonEvent(x+vertix$fps.getWidth()/2,y+vertix$fps.getHeight()/2,button),false))throw new AssertionError("HUD click");
            vertix$editor.mouseDragged(new MouseButtonEvent(183,123,button),180-x,120-y);
            vertix$editor.mouseReleased(new MouseButtonEvent(183,123,button));
            if(vertix$fps.getX()==x&&vertix$fps.getY()==y)throw new AssertionError("HUD did not move");
        }
        if(tick==120)capture(mc,"vertix-hud-editor.png");
        if(tick==140){var button=new MouseButtonInfo(InputConstants.MOUSE_BUTTON_RIGHT,0);vertix$editor.mouseClicked(new MouseButtonEvent(vertix$fps.getX()+3,vertix$fps.getY()+3,button),false);}
        if(tick==160)capture(mc,"vertix-hud-settings.png");
        if(tick==190){
            for(String file:new String[]{"vertix-mod-menu.png","vertix-hud-editor.png","vertix-hud-settings.png"})if(!new java.io.File(mc.gameDirectory,"screenshots/"+file).isFile())throw new AssertionError("Missing render capture: "+file);
            System.out.println("VERTIX_UI_TEST_PASSED");mc.stop();
        }
    }
    @Unique private static void capture(Minecraft mc,String name) {
        try {
            Object target;
            try {target=mc.getClass().getMethod("getMainRenderTarget").invoke(mc);} catch(NoSuchMethodException ignored) {target=mc.gameRenderer.getClass().getMethod("mainRenderTarget").invoke(mc.gameRenderer);}
            java.util.function.Consumer<net.minecraft.network.chat.Component> log=message->System.out.println(message.getString());
            try {Screenshot.class.getMethod("grab",java.io.File.class,String.class,com.mojang.blaze3d.pipeline.RenderTarget.class,int.class,java.util.function.Consumer.class).invoke(null,mc.gameDirectory,name,target,1,log);}
            catch(NoSuchMethodException ignored) {Screenshot.class.getMethod("grab",java.io.File.class,String.class,com.mojang.blaze3d.pipeline.RenderTarget.class,java.util.function.Consumer.class).invoke(null,mc.gameDirectory,name,target,log);}
        } catch(Exception e) {throw new AssertionError(e);}
    }
}
