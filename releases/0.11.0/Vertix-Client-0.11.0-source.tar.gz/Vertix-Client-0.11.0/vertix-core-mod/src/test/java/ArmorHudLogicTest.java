import client.vertix.core.modules.qol.armor.ArmorHudLogic;
import client.vertix.core.modules.qol.armor.ArmorHudLogic.*;
import java.util.List;
public class ArmorHudLogicTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        Piece healthy=new Piece(0,true,100,0),empty=new Piece(1,false,0,0),critical=new Piece(2,true,100,95),unbreakable=new Piece(3,true,0,0);
        var input=List.of(healthy,empty,critical,unbreakable);
        check(ArmorHudLogic.select(input,Visibility.ALWAYS,false,.1,5).size()==4,"all slots");
        check(ArmorHudLogic.select(List.of(empty),Visibility.IF_ANY_PRESENT,false,.1,5).isEmpty(),"empty equipment hides widget");
        check(ArmorHudLogic.select(input,Visibility.IF_ANY_PRESENT,false,.1,5).size()==4,"preserve empty placeholders if equipped");
        var selected=ArmorHudLogic.select(input,Visibility.NOT_EMPTY,true,.1,5);
        check(selected.size()==3&&selected.get(0).index()==3&&selected.get(2).index()==0,"reverse must preserve equipment identities");
        check(ArmorHudLogic.select(input,Visibility.DAMAGED_PIECES,false,.1,5).equals(List.of(critical)),"critical filter");
        check(!ArmorHudLogic.warning(unbreakable,1,200)&&!ArmorHudLogic.warning(empty,1,200),"non-damageable and empty slots must not warn");
        check(ArmorHudLogic.warning(new Piece(0,true,1000,980),.01,20),"absolute warning independent of percentage");
        check(ArmorHudLogic.warning(new Piece(0,true,1000,900),.1,5),"percentage boundary inclusive");
        check(!ArmorHudLogic.warning(new Piece(0,true,1000,899),.1,5),"healthy boundary");
        check(ArmorHudLogic.text(critical,"Prozent").equals("5%"),"percentage text");
        check(ArmorHudLogic.text(new Piece(0,true,100,43),"Prozent").equals("57%"),"percentage must not round down due to floating point");
        check(ArmorHudLogic.text(critical,"Rest / Gesamt").equals("5 / 100"),"remaining/max text");
        check(ArmorHudLogic.text(unbreakable,"Restwert").isEmpty(),"no durability for non-damageable items");
        check(ArmorHudLogic.text(new Piece(0,true,100,200),"Restwert").equals("0"),"overdamage is clamped");
        check(ArmorHudLogic.crossedThreshold(healthy,critical,true,.1,5),"crossing triggers sound");
        check(!ArmorHudLogic.crossedThreshold(critical,new Piece(0,true,100,96),true,.1,5),"no sound on every low-durability tick");
        check(!ArmorHudLogic.crossedThreshold(healthy,critical,false,.1,5),"replacement must not trigger sound");
        int cases=0;
        for(boolean vertical:new boolean[]{true,false})for(int count:new int[]{1,4,6})for(int[] viewport:new int[][]{{320,240},{480,270},{640,360},{960,540}})for(double scale:new double[]{.5,1,2}){
            var layout=ArmorHudLogic.layout(count,vertical,true,78,12,scale,viewport[0],viewport[1]);
            check(layout.screenWidth()<=viewport[0]-2&&layout.screenHeight()<=viewport[1]-2,"scaled HUD exceeds viewport");
            check(layout.cellWidth()>=28&&layout.cellHeight()>=26,"item/count space");cases++;
        }
        check(ArmorHudLogic.layout(0,false,true,40,2,1,320,240).screenWidth()==0,"empty HUD has no phantom hitbox");
        System.out.println("Armor HUD selection, warning, text, sound transitions and "+cases+" scaled layouts passed.");
    }
}
