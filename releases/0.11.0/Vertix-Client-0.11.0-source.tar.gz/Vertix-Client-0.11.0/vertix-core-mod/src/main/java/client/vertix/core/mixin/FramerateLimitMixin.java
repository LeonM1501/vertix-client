package client.vertix.core.mixin;

import client.vertix.core.modules.qol.DiscordStreamingModule;
import com.mojang.blaze3d.platform.FramerateLimitTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FramerateLimitTracker.class)
public class FramerateLimitMixin {
    @Inject(method = "getFramerateLimit", at = @At("RETURN"), cancellable = true)
    private void vertix$streamLimit(CallbackInfoReturnable<Integer> cir) {
        DiscordStreamingModule streaming = DiscordStreamingModule.active();
        int limit=cir.getReturnValue();
        if(streaming!=null)limit=streaming.limit(limit);
        var core=client.vertix.core.VertixCoreMod.getInstance();
        if(core!=null&&core.getModuleManager()!=null){var module=core.getModuleManager().getModule("background_fps");if(module instanceof client.vertix.core.modules.qol.BackgroundFpsModule saver&&saver.isEnabled())limit=saver.limit(limit,net.minecraft.client.Minecraft.getInstance().isWindowActive());}
        cir.setReturnValue(limit);
    }
}
