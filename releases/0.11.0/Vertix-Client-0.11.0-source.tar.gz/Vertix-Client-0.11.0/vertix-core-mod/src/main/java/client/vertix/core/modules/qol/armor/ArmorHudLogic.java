/* SPDX-License-Identifier: MIT
 * Copyright (c) 2021 BerdinskiyBear
 * Adapted from uku3lig/armor-hud, commit 233932b08a0fb30501e1104bead784914aff85c4.
 * Vertix changes: independent data model, bounds checks, text modes and scaled layout.
 * Full upstream notice: assets/vertix/licenses/uku-armor-hud-MIT.txt.
 */
package client.vertix.core.modules.qol.armor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ArmorHudLogic {
    public enum Visibility { ALWAYS, IF_ANY_PRESENT, NOT_EMPTY, DAMAGED_PIECES }
    public record Piece(int index, boolean present, int maxDamage, int damage) {}
    public record Layout(int cellWidth, int cellHeight, int width, int height, float scale) {
        public int screenWidth() { return (int)Math.ceil(width * scale); }
        public int screenHeight() { return (int)Math.ceil(height * scale); }
    }
    private ArmorHudLogic() {}
    public static int remaining(int max, int damage) { return Math.max(0, max - Math.max(0, damage)); }
    public static boolean warning(Piece piece, double percentage, int absolute) {
        if (!piece.present() || piece.maxDamage() <= 0) return false;
        double ratio = (double)remaining(piece.maxDamage(),piece.damage()) / piece.maxDamage();
        return ratio <= Math.clamp(percentage,0,1) || remaining(piece.maxDamage(),piece.damage()) <= Math.max(0,absolute);
    }
    public static List<Piece> select(List<Piece> pieces, Visibility mode, boolean reversed, double percentage, int absolute) {
        // Upstream getArmorItems rules, retaining the original slot identities.
        List<Piece> result = new ArrayList<>(switch (mode) {
            case ALWAYS -> pieces;
            case IF_ANY_PRESENT -> pieces.stream().allMatch(p -> !p.present()) ? List.of() : pieces;
            case NOT_EMPTY -> pieces.stream().filter(Piece::present).toList();
            case DAMAGED_PIECES -> pieces.stream().filter(p -> warning(p,percentage,absolute)).toList();
        });
        if (reversed) Collections.reverse(result);
        return result;
    }
    public static String text(Piece piece, String mode) {
        if (!piece.present() || piece.maxDamage() <= 0) return "";
        int left=remaining(piece.maxDamage(),piece.damage());
        return switch(mode) {
            case "Restwert" -> String.valueOf(left);
            case "Rest / Gesamt" -> left+" / "+piece.maxDamage();
            case "Prozent", "Prozent + Balken" -> Math.min(100,(long)left*100/piece.maxDamage())+"%";
            default -> "";
        };
    }
    public static boolean crossedThreshold(Piece previous, Piece current, boolean sameItem, double percentage, int absolute) {
        return sameItem && previous != null && current.damage()>previous.damage()
                && !warning(previous,percentage,absolute) && warning(current,percentage,absolute);
    }
    public static Layout layout(int count, boolean vertical, boolean labels, int maxLabelWidth, int gap,
                                double requestedScale, int screenWidth, int screenHeight) {
        if(count<=0)return new Layout(0,0,0,0,1);
        int cellWidth=vertical ? (labels ? 38+maxLabelWidth : 28) : Math.max(28,maxLabelWidth+8);
        int cellHeight=vertical ? 26 : labels ? 38 : 26;
        int width=8+(vertical?cellWidth:count*cellWidth+(count-1)*gap);
        int height=8+(vertical?count*cellHeight+(count-1)*gap:cellHeight);
        double chosen=Double.isFinite(requestedScale)?Math.clamp(requestedScale,.5,2):1;
        double fit=Math.min(Math.max(1,screenWidth-4)/(double)width,Math.max(1,screenHeight-4)/(double)height);
        return new Layout(cellWidth,cellHeight,width,height,(float)Math.min(chosen,fit));
    }
}
