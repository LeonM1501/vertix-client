package client.vertix.core.modules.qol;

import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.gui.HudStyle;
import client.vertix.core.gui.RenderUtils;
import client.vertix.core.modules.qol.armor.ArmorHudLogic;
import client.vertix.core.modules.qol.armor.ArmorHudLogic.Piece;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.*;

/** Vertix renderer/settings around the MIT-licensed uku/BerdinskiyBear HUD rules. */
public class ArmorHudModule extends Module {
    // Existing setting IDs stay valid for saved configurations.
    private final Setting.ModeSetting orientation=mode("orientation","Ausrichtung","Horizontal","Horizontal","Vertikal");
    private final Setting.BooleanSetting durability=bool("durability","Haltbarkeit",true),held=bool("held","Hand-Items",true);
    private final Setting.BooleanSetting mainHand=bool("main_hand","Haupthand",true),offHand=bool("off_hand","Nebenhand",true);
    private final Setting.ModeSetting visibility=mode("visibility","Sichtbarkeit","Belegte Slots","Alle Slots","Wenn ausgerüstet","Belegte Slots","Nur kritisch");
    private final Setting.BooleanSetting reversed=bool("reversed","Reihenfolge umkehren",false);
    private final Setting.ModeSetting display=mode("durability_display","Haltbarkeitsformat","Prozent","Prozent","Restwert","Rest / Gesamt","Balken","Prozent + Balken");
    private final Setting.BooleanSetting warning=bool("warning","Warnsymbol",true);
    private final Setting.NumberSetting warningPercent=number("warning_percent","Warnung unter Prozent",10,0,50,1,true),warningValue=number("warning_value","Warnung unter Restwert",20,0,200,1,true);
    private final Setting.BooleanSetting warningSound=bool("warning_sound","Warnton bei Grenzwert",false),warningMotion=bool("warning_motion","Warnsymbol bewegen",false);
    private final Setting.ColorSetting warningColor=color("warning_color","Warnfarbe",0xFFFFC978);
    private final Setting.ModeSetting style=mode("surface_style","Hintergrund","Vertix","Vertix","Einzelne Slots","Minimal");
    private final Setting.NumberSetting opacity=number("bg_opacity","Hintergrund-Deckkraft",HudStyle.DEFAULT_OPACITY,0,1,.05,false),scale=number("scale","Größe",1,.5,2,.05,false),gap=number("slot_gap","Slot-Abstand",2,0,12,1,true);
    private final Setting.BooleanSetting emptyIcons=bool("empty_icons","Leere Slot-Symbole",true),coloredDurability=bool("durability_colors","Haltbarkeitsfarben",false);
    private final Setting.ColorSetting textColor=color("color","Textfarbe",HudStyle.TEXT);
    private final Setting.BooleanSetting hideSpectator=bool("hide_spectator","Im Zuschauermodus ausblenden",true);
    private record Slot(EquipmentSlot type,ItemStack stack,Piece preview) {
        Slot(EquipmentSlot type,ItemStack stack){this(type,stack,null);}
    }
    private record Previous(Object item,Piece piece) {}
    private final Map<EquipmentSlot,Previous> previous=new EnumMap<>(EquipmentSlot.class);
    private Object lastLevel;
    private long lastSound;

    public ArmorHudModule(){
        super("armor_hud","Armor HUD","Rüstungs-HUD mit Slot-Filtern, Haltbarkeit und Warnungen. Auf Basis von uku's Armor HUD.",Category.HUD,true,true,4,88);
        for(Setting<?> s:List.of(orientation,visibility,reversed,held,mainHand,offHand,hideSpectator,durability,display,warning,warningPercent,warningValue,warningSound,warningMotion,warningColor,style,opacity,scale,gap,emptyIcons,coloredDurability,textColor))addSetting(s);
        width=140;height=46;
    }
    private static Setting.BooleanSetting bool(String id,String name,boolean value){return new Setting.BooleanSetting(id,name,name,value);}
    private static Setting.ModeSetting mode(String id,String name,String value,String... choices){return new Setting.ModeSetting(id,name,name,value,choices);}
    private static Setting.NumberSetting number(String id,String name,double value,double min,double max,double step,boolean integer){return new Setting.NumberSetting(id,name,name,value,min,max,step,integer);}
    private static Setting.ColorSetting color(String id,String name,int value){return new Setting.ColorSetting(id,name,name,value);}
    @Override public String getSettingGroup(Setting<?> s){
        String id=s.getId();if(id.startsWith("warning"))return "Warnungen";
        if(id.equals("durability")||id.equals("durability_display"))return "Haltbarkeit";
        if(List.of("surface_style","bg_opacity","scale","slot_gap","empty_icons","durability_colors","color").contains(id))return "Darstellung";
        return "Anzeige";
    }
    private List<Slot> slots(Minecraft client){
        List<Slot> slots=new ArrayList<>();
        if(held.getValue()&&mainHand.getValue())slots.add(new Slot(EquipmentSlot.MAINHAND,client.player.getMainHandItem()));
        for(var type:List.of(EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET))slots.add(new Slot(type,client.player.getItemBySlot(type)));
        if(held.getValue()&&offHand.getValue())slots.add(new Slot(EquipmentSlot.OFFHAND,client.player.getOffhandItem()));
        return slots;
    }
    private static Piece piece(int index,ItemStack stack){return new Piece(index,!stack.isEmpty(),stack.isDamageableItem()?stack.getMaxDamage():0,stack.getDamageValue());}
    private static double bounded(Setting.NumberSetting s,double min,double max){double n=s.getValue();return Double.isFinite(n)?Math.clamp(n,min,max):min;}
    private double percent(){return bounded(warningPercent,0,50)/100;}
    private int absolute(){return (int)bounded(warningValue,0,200);}
    private ArmorHudLogic.Visibility visibility(){return switch(visibility.getValue()){
        case "Alle Slots"->ArmorHudLogic.Visibility.ALWAYS;case "Wenn ausgerüstet"->ArmorHudLogic.Visibility.IF_ANY_PRESENT;
        case "Nur kritisch"->ArmorHudLogic.Visibility.DAMAGED_PIECES;default->ArmorHudLogic.Visibility.NOT_EMPTY;
    };}
    @Override public void onDisable(){previous.clear();lastLevel=null;}
    @Override public void onTick(Minecraft client){
        if(client.player==null||client.level!=lastLevel){previous.clear();lastLevel=client.level;}
        if(client.player==null)return;boolean alert=false;
        List<Slot> current=slots(client);
        previous.keySet().removeIf(type->current.stream().noneMatch(s->s.type()==type));
        for(Slot slot:current){
            Piece now=piece(0,slot.stack());Previous before=previous.put(slot.type(),new Previous(slot.stack().getItem(),now));
            if(before!=null&&ArmorHudLogic.crossedThreshold(before.piece(),now,before.item()==slot.stack().getItem(),percent(),absolute()))alert=true;
        }
        long time=System.nanoTime();
        if(alert&&warningSound.getValue()&&!client.player.isSpectator()&&time-lastSound>4_000_000_000L){client.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP,.35F,.8F);lastSound=time;}
    }
    @Override public void renderHud(GuiGraphicsExtractor g,DeltaTracker delta,Minecraft client){
        if(!isEnabled()||client.player==null)return;
        if(hideSpectator.getValue()&&client.player.isSpectator()){width=height=0;return;}
        renderItems(g,client,slots(client));
    }
    private void renderItems(GuiGraphicsExtractor g,Minecraft client,List<Slot> slots){
        List<Piece> input=new ArrayList<>();for(int i=0;i<slots.size();i++){Slot s=slots.get(i);Piece p=s.preview();input.add(p==null?piece(i,s.stack()):new Piece(i,p.present(),p.maxDamage(),p.damage()));}
        List<Piece> selected=ArmorHudLogic.select(input,visibility(),reversed.getValue(),percent(),absolute());
        if(selected.isEmpty()){width=height=0;return;}
        boolean vertical=orientation.getValue().equals("Vertikal");String format=durability.getValue()?display.getValue():"";
        boolean bars=durability.getValue()&&(format.equals("Balken")||format.equals("Prozent + Balken"));
        List<String> labels=selected.stream().map(p->ArmorHudLogic.text(p,format)).toList();
        int labelWidth=labels.stream().mapToInt(client.font::width).max().orElse(0),spacing=(int)bounded(gap,0,12);
        var layout=ArmorHudLogic.layout(selected.size(),vertical,labelWidth>0,labelWidth,spacing,bounded(scale,.5,2),g.guiWidth(),g.guiHeight());
        width=layout.screenWidth();height=layout.screenHeight();
        setX(Math.clamp(x,2,Math.max(2,g.guiWidth()-width-2)));setY(Math.clamp(y,2,Math.max(2,g.guiHeight()-height-2)));
        g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale(layout.scale(),layout.scale());
        try{
            if(style.getValue().equals("Vertix"))HudStyle.panel(g,0,0,layout.width(),layout.height(),bounded(opacity,0,1));
            for(int i=0;i<selected.size();i++){
                Piece p=selected.get(i);Slot slot=slots.get(p.index());ItemStack stack=slot.stack();
                int cx=4+(vertical?0:i*(layout.cellWidth()+spacing)),cy=4+(vertical?i*(layout.cellHeight()+spacing):0);
                boolean low=ArmorHudLogic.warning(p,percent(),absolute());
                if(style.getValue().equals("Einzelne Slots"))HudStyle.panel(g,cx,cy,layout.cellWidth(),layout.cellHeight(),bounded(opacity,0,1));
                if(low&&warning.getValue())RenderUtils.drawOutline(g,cx,cy,layout.cellWidth(),layout.cellHeight(),warningColor.getValue());
                int ix=vertical?cx+4:cx+(layout.cellWidth()-16)/2,iy=cy+4;
                if(stack.isEmpty()){if(emptyIcons.getValue()||slot.preview()!=null)emptySlot(g,slot.type(),ix,iy);}else{
                    RenderUtils.drawItem(g,stack,ix,iy);
                    // Counts are separate so disabling durability also hides vanilla bars.
                    if(stack.getCount()>1){String count=String.valueOf(stack.getCount());RenderUtils.drawText(g,client.font,count,ix+18-client.font.width(count),iy+10,HudStyle.TEXT,true);}
                }
                    int durabilityColor=coloredDurability.getValue()&&!stack.isEmpty()?0xFF000000|stack.getBarColor():textColor.getValue();
                    if(bars&&p.maxDamage()>0){int fill=(int)Math.round(14.0*ArmorHudLogic.remaining(p.maxDamage(),p.damage())/p.maxDamage());RenderUtils.drawRect(g,ix,iy+18,16,3,0xCC101010);RenderUtils.drawRect(g,ix+1,iy+19,Math.clamp(fill,0,14),1,durabilityColor);}
                    String label=labels.get(i);int color=low&&warning.getValue()?warningColor.getValue():durabilityColor;
                    if(!label.isEmpty()){if(vertical)RenderUtils.drawText(g,client.font,label,cx+29,cy+9,color,false);else RenderUtils.drawCenteredText(g,client.font,label,cx+layout.cellWidth()/2,cy+26,color,false);}
                    if(low&&warning.getValue()){int bob=warningMotion.getValue()?(int)Math.round(Math.sin(System.nanoTime()/250_000_000.0)):0;RenderUtils.drawText(g,client.font,"!",cx+layout.cellWidth()-5,cy+2+bob,warningColor.getValue(),false);}
            }
        }finally{g.pose().popMatrix();}
    }
    private static void emptySlot(GuiGraphicsExtractor g,EquipmentSlot slot,int x,int y){
        int c=0x906F747D; // Original Vertix line icons; no upstream artwork.
        switch(slot){
            case HEAD->{RenderUtils.drawOutline(g,x+3,y+3,10,10,c);RenderUtils.drawRect(g,x+6,y+10,4,4,0x40101010);}
            case CHEST->{RenderUtils.drawOutline(g,x+4,y+3,8,11,c);RenderUtils.drawRect(g,x+1,y+4,3,5,c);RenderUtils.drawRect(g,x+12,y+4,3,5,c);}
            case LEGS->{RenderUtils.drawOutline(g,x+4,y+2,8,12,c);RenderUtils.drawRect(g,x+7,y+8,2,6,c);}
            case FEET->{RenderUtils.drawOutline(g,x+2,y+7,5,7,c);RenderUtils.drawOutline(g,x+9,y+7,5,7,c);}
            case MAINHAND->{RenderUtils.drawRect(g,x+7,y+2,2,10,c);RenderUtils.drawRect(g,x+4,y+10,8,2,c);RenderUtils.drawRect(g,x+7,y+12,2,3,c);}
            default->RenderUtils.drawOutline(g,x+3,y+2,10,13,c);
        }
    }
    @Override public void renderHudPlaceholder(GuiGraphicsExtractor g,Minecraft client){
        // Since 26.3, item components are bound only after loading world datapacks.
        // The editor is also available on the title screen: never instantiate items there.
        boolean ready;
        try {ready=Items.IRON_SWORD.components()!=null;}
        catch(NullPointerException|IllegalStateException notBoundYet){ready=false;}
        List<Slot> slots=new ArrayList<>();
        if(held.getValue()&&mainHand.getValue())slots.add(preview(EquipmentSlot.MAINHAND,Items.IRON_SWORD,250,0,ready));
        slots.add(preview(EquipmentSlot.HEAD,Items.IRON_HELMET,165,0,ready));
        slots.add(preview(EquipmentSlot.CHEST,Items.IRON_CHESTPLATE,240,231,ready));
        slots.add(preview(EquipmentSlot.LEGS,Items.IRON_LEGGINGS,225,0,ready));
        slots.add(preview(EquipmentSlot.FEET,Items.IRON_BOOTS,195,0,ready));
        if(held.getValue()&&offHand.getValue())slots.add(preview(EquipmentSlot.OFFHAND,Items.SHIELD,336,0,ready));
        renderItems(g,client,slots);
    }
    private static Slot preview(EquipmentSlot type,net.minecraft.world.item.Item item,int max,int damage,boolean ready){
        if(!ready)return new Slot(type,ItemStack.EMPTY,new Piece(0,true,max,damage));
        ItemStack stack=new ItemStack(item);stack.setDamageValue(damage);return new Slot(type,stack);
    }
}
