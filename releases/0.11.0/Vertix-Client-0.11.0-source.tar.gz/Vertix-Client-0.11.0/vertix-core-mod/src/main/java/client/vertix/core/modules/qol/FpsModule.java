package client.vertix.core.modules.qol;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
import client.vertix.core.gui.*;
import client.vertix.core.performance.FrameStats;
import net.minecraft.client.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import java.util.Locale;

public class FpsModule extends Module {
    private final Setting.BooleanSetting label=new Setting.BooleanSetting("label","FPS-Label","FPS hinter der Zahl anzeigen.",true);
    private final Setting.ModeSetting view=new Setting.ModeSetting("view","Ansicht","Kompakt, Messwerte oder ein echter Frametime-Verlauf.","Kompakt","Kompakt","Details","Graph");
    private final Setting.ColorSetting color=new Setting.ColorSetting("color","Textfarbe","Farbe der Hauptzeile.",HudStyle.TEXT);
    private final Setting.NumberSetting opacity=new Setting.NumberSetting("bg_opacity","Deckkraft","Hintergrund der Anzeige.",HudStyle.DEFAULT_OPACITY,0,1,.05,false);
    public FpsModule(){super("fps","FPS & Frametime","FPS, mittlere Framezeit und 1%-Low aus den letzten 512 Frames.",Category.HUD,true,true,4,64);addSetting(label);addSetting(view);addSetting(color);addSetting(opacity);width=54;height=20;}
    private void draw(GuiGraphicsExtractor g,Minecraft mc,boolean preview){
        String title=(preview?144:mc.getFps())+(label.getValue()?" FPS":"");
        boolean detailed=!view.getValue().equals("Kompakt"),graph=view.getValue().equals("Graph");
        width=detailed?164:mc.font.width(title)+16;height=graph?78:detailed?44:20;
        HudStyle.panel(g,x,y,width,height,opacity.getValue());
        HudStyle.text(g,mc.font,title,x+8,y+6,color.getValue());
        if(!detailed)return;
        FrameStats.Snapshot stats=VertixCoreMod.getInstance().getFrameStats().snapshot();
        String info=preview?"6.9 ms   |   1% Low 112":stats.frames()<20?"Messung läuft ...":String.format(Locale.ROOT,"%.1f ms   |   1%% Low %d",stats.averageMs(),stats.lowFps());
        HudStyle.text(g,mc.font,info,x+8,y+20,HudStyle.MUTED);
        if(graph){
            int gx=x+8,gy=y+36,gw=width-16,gh=25;
            RenderUtils.drawRect(g,gx,gy+gh,gw,1,0x804F5359);
            int target=gy+gh-(int)(16.67/50*gh);for(int i=0;i<gw;i+=5)RenderUtils.drawRect(g,gx+i,target,2,1,0x606F747D);
            double[] values=stats.graph();
            if(preview){values=new double[74];for(int i=0;i<values.length;i++)values[i]=i%19==0?22:6.9+Math.sin(i*.7)*2;}
            for(int i=0;i<values.length;i++){int h=Math.clamp((int)Math.round(values[i]/50*gh),1,gh);int bx=gx+i*gw/values.length;int bw=Math.max(1,gw/values.length);RenderUtils.drawRect(g,bx,gy+gh-h,bw,h,values[i]>33.3?0xFFBEB3A0:0xFFA9B1B9);}
            HudStyle.text(g,mc.font,"16.7 ms = 60 FPS",gx,y+65,0xFF8D949C);
        }
        var mode=PerformanceModeModule.instance();if(mode!=null&&mode.isEnabled())HudStyle.text(g,mc.font,"FPS",x+width-24,y+6,HudStyle.MUTED);
    }
    @Override public void renderHud(GuiGraphicsExtractor g,DeltaTracker d,Minecraft mc){draw(g,mc,false);}
    @Override public void renderHudPlaceholder(GuiGraphicsExtractor g,Minecraft mc){draw(g,mc,true);}
}
