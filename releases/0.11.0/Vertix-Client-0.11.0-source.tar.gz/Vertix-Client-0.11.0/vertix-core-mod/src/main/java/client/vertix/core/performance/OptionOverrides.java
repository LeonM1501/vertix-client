package client.vertix.core.performance;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Restores only values still owned by this session; manual edits always survive. */
public final class OptionOverrides {
    private final Map<String,Runnable> restores = new LinkedHashMap<>();
    public <T> void set(String id,Supplier<T> read,Consumer<T> write,T value) {
        if(restores.containsKey(id))throw new IllegalStateException("Duplicate override: "+id);
        T original=read.get();
        if(Objects.equals(original,value))return;
        write.accept(value);
        T applied=read.get();
        restores.put(id,()->{if(Objects.equals(read.get(),applied))write.accept(original);});
    }
    public boolean isEmpty(){return restores.isEmpty();}
    public void restore(){for(Runnable restore:restores.values())restore.run();restores.clear();}
}
