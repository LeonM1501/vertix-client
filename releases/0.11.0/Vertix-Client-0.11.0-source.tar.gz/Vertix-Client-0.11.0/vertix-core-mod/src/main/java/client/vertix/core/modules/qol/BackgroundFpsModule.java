package client.vertix.core.modules.qol;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
public class BackgroundFpsModule extends Module {
    private final Setting.NumberSetting limit=new Setting.NumberSetting("limit","Hintergrund-FPS","Nur bei inaktivem Fenster. Das aktive Spiel wird nicht begrenzt.",30,10,120,5,true);
    public BackgroundFpsModule(){super("background_fps","Hintergrund-Ruhe","Spart GPU-Leistung beim Wechsel in andere Fenster.",Category.PERFORMANCE,false,false,0,0);addSetting(limit);}
    public int limit(int normal,boolean focused){return focused?normal:Math.min(normal,Math.clamp(limit.getValue().intValue(),10,120));}
}
