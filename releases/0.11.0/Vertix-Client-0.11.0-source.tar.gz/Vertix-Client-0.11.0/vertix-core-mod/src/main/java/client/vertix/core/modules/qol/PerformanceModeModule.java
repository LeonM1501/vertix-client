package client.vertix.core.modules.qol;

import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.Category;
import client.vertix.core.api.Module;
import client.vertix.core.api.Setting;
import client.vertix.core.performance.OptionOverrides;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.server.level.ParticleStatus;

/** Temporary graphics profiles. Options.save writes the user's originals, not our overrides. */
public class PerformanceModeModule extends Module {
    private final Setting.ModeSetting profile=new Setting.ModeSetting("profile","Qualitätsstufe","Weniger Sichtweite und Effekte; FPS-Limit und VSync bleiben deine Wahl.","Ausgewogen","Ausgewogen","Schnell","Maximum");
    private final Setting.BooleanSetting clouds=new Setting.BooleanSetting("clouds","Wolken ausblenden","Reduziert sichtbare Effekte.",true);
    private final Setting.BooleanSetting shadows=new Setting.BooleanSetting("shadows","Entity-Schatten aus","Deaktiviert nur Entity-Schatten.",true);
    private final OptionOverrides overrides=new OptionOverrides();
    private String appliedProfile;
    private boolean mutating,shuttingDown,resumeAfterSave;
    private int saveDepth;
    public PerformanceModeModule(){super("fps_mode","FPS Modus","Drei temporäre Grafikprofile. Vorherige Werte kommen beim Ausschalten zurück.",Category.PERFORMANCE,false,false,0,0);addSetting(profile);addSetting(clouds);addSetting(shadows);}
    public static PerformanceModeModule instance(){var core=VertixCoreMod.getInstance();return core==null||core.getModuleManager()==null?null:(PerformanceModeModule)core.getModuleManager().getModule("fps_mode");}
    private <T> void set(String id,OptionInstance<T> option,T value){overrides.set(id,option::get,option::set,value);}
    private String signature(){return profile.getValue()+clouds.getValue()+shadows.getValue();}
    private void apply(Minecraft mc){
        if(mc.options==null||mc.player==null||shuttingDown)return;
        mutating=true;
        try{
            int tier=profile.getIndex(),chunks=new int[]{12,8,5}[tier];var o=mc.options;
            set("distance",o.renderDistance(),Math.min(o.renderDistance().get(),chunks));
            set("entities",o.entityDistanceScaling(),Math.min(o.entityDistanceScaling().get(),new double[]{.75,.6,.5}[tier]));
            if(clouds.getValue())set("clouds",o.cloudStatus(),CloudStatus.OFF);
            if(shadows.getValue())set("shadows",o.entityShadows(),false);
            if(tier>0){set("ao",o.ambientOcclusion(),false);set("blend",o.biomeBlendRadius(),0);}
            ParticleStatus target=tier==0?ParticleStatus.DECREASED:ParticleStatus.MINIMAL;
            if(o.particles().get().ordinal()<target.ordinal())set("particles",o.particles(),target);
            appliedProfile=signature();
        }finally{mutating=false;}
    }
    private void restore(){mutating=true;try{overrides.restore();appliedProfile=null;}finally{mutating=false;}}
    @Override public void onTick(Minecraft mc){
        if(saveDepth>0||shuttingDown)return;
        if(mc.player==null){if(appliedProfile!=null)restore();return;}
        if(!signature().equals(appliedProfile)){restore();apply(mc);}
    }
    @Override public void onEnable(){shuttingDown=false;}
    @Override public void onDisable(){restore();}
    public void beforeOptionsSave(){if(mutating||shuttingDown)return;if(saveDepth++==0){resumeAfterSave=appliedProfile!=null;restore();}}
    public void afterOptionsSave(){if(mutating||shuttingDown||saveDepth==0)return;if(--saveDepth==0&&resumeAfterSave&&isEnabled())apply(Minecraft.getInstance());}
    public void shutdown(){shuttingDown=true;restore();}
    public String status(){return isEnabled()?profile.getValue():"Aus";}
}
