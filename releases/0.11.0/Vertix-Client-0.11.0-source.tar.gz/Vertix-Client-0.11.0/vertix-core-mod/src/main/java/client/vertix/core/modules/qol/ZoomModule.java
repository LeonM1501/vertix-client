package client.vertix.core.modules.qol;
import client.vertix.core.VertixCoreMod;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
import net.minecraft.client.Minecraft;

/** Hold-to-zoom using vanilla FOV, with no changes left in options.txt. */
public class ZoomModule extends Module {
    private final Setting.NumberSetting factor=new Setting.NumberSetting("factor","Vergrößerung","Vanilla-FOV begrenzt die maximale Vergrößerung.",2.5,1.5,3,0.25,false);
    private final Setting.BooleanSetting smooth=new Setting.BooleanSetting("smooth","Weicher Übergang","Gleicht die FOV über mehrere Ticks an.",true);
    private final Setting.BooleanSetting steady=new Setting.BooleanSetting("steady","Ruhige Maus","Reduziert die Empfindlichkeit nur beim Zoomen.",true);
    private Integer originalFov,lastFov;
    private Double originalSensitivity,lastSensitivity;
    public ZoomModule(){super("zoom","Zoom","C gedrückt halten. Taste in Minecrafts Steuerung frei belegbar.",Category.QOL,false,false,0,0);addSetting(factor);addSetting(smooth);addSetting(steady);}
    public static ZoomModule instance(){var c=VertixCoreMod.getInstance();return c==null||c.getModuleManager()==null?null:(ZoomModule)c.getModuleManager().getModule("zoom");}
    @Override public void onTick(Minecraft mc){
        var key=VertixCoreMod.getInstance().getKeyZoom();
        if(mc.player==null||mc.gui.screen()!=null||key==null||!key.isDown()){restore();return;}
        if(originalFov==null){originalFov=mc.options.fov().get();originalSensitivity=mc.options.sensitivity().get();}
        int target=Math.max(30,(int)Math.round(originalFov/Math.clamp(factor.getValue(),1.5,3)));
        int current=mc.options.fov().get(),next=smooth.getValue()&&Math.abs(target-current)>1?(int)Math.round((current+target)/2.0):target;
        mc.options.fov().set(next);lastFov=mc.options.fov().get();
        if(steady.getValue()){mc.options.sensitivity().set(originalSensitivity/2);lastSensitivity=mc.options.sensitivity().get();}
    }
    public void restore(){
        var mc=Minecraft.getInstance();
        if(mc!=null&&mc.options!=null){
            if(originalFov!=null&&mc.options.fov().get().equals(lastFov))mc.options.fov().set(originalFov);
            if(originalSensitivity!=null&&mc.options.sensitivity().get().equals(lastSensitivity))mc.options.sensitivity().set(originalSensitivity);
        }
        originalFov=lastFov=null;originalSensitivity=lastSensitivity=null;
    }
    @Override public void onDisable(){restore();}
}
