package client.vertix.core.modules.qol;
import client.vertix.core.api.*;
import client.vertix.core.api.Module;
import client.vertix.core.gui.HudStyle;
import net.minecraft.client.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class SessionModule extends Module {
    private final Setting.BooleanSetting ping=new Setting.BooleanSetting("ping","Ping","Serverlatenz oder Einzelspieler anzeigen.",true);
    private final Setting.BooleanSetting clock=new Setting.BooleanSetting("clock","Lokale Uhrzeit","Die Uhrzeit dieses PCs anzeigen.",false);
    private final Setting.BooleanSetting speed=new Setting.BooleanSetting("speed","Geschwindigkeit","Horizontale Geschwindigkeit in Blöcken pro Sekunde.",true);
    private final Setting.ColorSetting color=new Setting.ColorSetting("color","Textfarbe","Farbe der Hauptzeile.",HudStyle.TEXT);
    private final Setting.NumberSetting opacity=new Setting.NumberSetting("bg_opacity","Deckkraft","Hintergrund der Anzeige.",HudStyle.DEFAULT_OPACITY,0,1,.05,false);
    private Object level;
    private long start,lastTick;
    private double previousX,previousZ,velocity;
    private static final DateTimeFormatter CLOCK=DateTimeFormatter.ofPattern("HH:mm");
    public SessionModule(){super("session","Session HUD","Spielzeit, Ping, Geschwindigkeit und optionale Uhrzeit.",Category.HUD,false,true,4,172);for(var s:List.of(ping,clock,speed,color,opacity))addSetting(s);}
    @Override public void onTick(Minecraft mc){
        if(mc.player==null){level=null;return;}
        long now=System.nanoTime();double x=mc.player.getX(),z=mc.player.getZ();
        if(level!=mc.level){level=mc.level;start=now;lastTick=now;previousX=x;previousZ=z;velocity=0;return;}
        double seconds=(now-lastTick)/1e9,distance=Math.hypot(x-previousX,z-previousZ);
        if(seconds>0&&seconds<1)velocity=distance<64?velocity*.7+distance/seconds*.3:0;
        previousX=x;previousZ=z;lastTick=now;
    }
    @Override public void onDisable(){level=null;start=0;}
    private void draw(GuiGraphicsExtractor g,Minecraft mc,boolean preview){
        List<String> lines=new ArrayList<>();long seconds=preview?24*60:Math.max(0,(System.nanoTime()-start)/1_000_000_000L);
        lines.add(String.format(Locale.ROOT,"SESSION  %02d:%02d:%02d",seconds/3600,seconds/60%60,seconds%60));
        if(ping.getValue()){
            var info=mc.player==null||mc.getConnection()==null?null:mc.getConnection().getPlayerInfo(mc.player.getUUID());
            lines.add(preview?"Ping  32 ms":mc.hasSingleplayerServer()?"Einzelspieler":info==null?"Ping  --":"Ping  "+info.getLatency()+" ms");
        }
        if(speed.getValue())lines.add(String.format(Locale.ROOT,"Tempo  %.1f bl/s",preview?4.3:velocity));
        if(clock.getValue())lines.add("Uhr  "+LocalTime.now().format(CLOCK));
        width=lines.stream().mapToInt(mc.font::width).max().orElse(80)+16;height=lines.size()*12+10;
        HudStyle.panel(g,x,y,width,height,opacity.getValue());
        for(int i=0;i<lines.size();i++)HudStyle.text(g,mc.font,lines.get(i),x+8,y+6+i*12,i==0?color.getValue():HudStyle.MUTED);
    }
    @Override public void renderHud(GuiGraphicsExtractor g,DeltaTracker d,Minecraft mc){if(mc.player!=null&&start!=0)draw(g,mc,false);}
    @Override public void renderHudPlaceholder(GuiGraphicsExtractor g,Minecraft mc){draw(g,mc,true);}
}
