package client.vertix.core.performance;

import java.util.Arrays;

/** Fixed-size frame interval history. Sorting happens once per second, never per frame. */
public final class FrameStats {
    public record Snapshot(double averageMs,int lowFps,int frames,double[] graph) {}
    private final double[] samples=new double[512];
    private int count,cursor;
    private long last;
    private Snapshot snapshot=new Snapshot(0,0,0,new double[0]);
    public void record(long nanos){
        if(last!=0){double ms=(nanos-last)/1_000_000.0;if(ms>0&&ms<=5000){samples[cursor]=ms;cursor=(cursor+1)%samples.length;count=Math.min(samples.length,count+1);}else clear();}
        last=nanos;
    }
    public void clear(){count=cursor=0;last=0;snapshot=new Snapshot(0,0,0,new double[0]);}
    public Snapshot snapshot(){return snapshot;}
    public void refresh(){
        if(count==0)return;
        double[] sorted=Arrays.copyOf(samples,count);Arrays.sort(sorted);
        double total=0,worst=0;int tail=Math.max(1,(int)Math.ceil(count*.01));
        for(double ms:sorted)total+=ms;
        for(int i=count-tail;i<count;i++)worst+=sorted[i];
        int size=Math.min(100,count);double[] graph=new double[size];
        for(int i=0;i<size;i++)graph[i]=samples[(cursor-size+i+samples.length)%samples.length];
        snapshot=new Snapshot(total/count,(int)Math.round(1000/(worst/tail)),count,graph);
    }
}
