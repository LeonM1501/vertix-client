package client.vertix.core.mixin;
import client.vertix.core.modules.qol.PerformanceModeModule;
import net.minecraft.client.Options;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Options.class)
public class OptionsMixin {
    @Inject(method="save",at=@At("HEAD")) private void vertix$saveOriginals(CallbackInfo ci){var zoom=client.vertix.core.modules.qol.ZoomModule.instance();if(zoom!=null)zoom.restore();var mode=PerformanceModeModule.instance();if(mode!=null)mode.beforeOptionsSave();}
    @Inject(method="save",at=@At("RETURN")) private void vertix$resumeGraphics(CallbackInfo ci){var mode=PerformanceModeModule.instance();if(mode!=null)mode.afterOptionsSave();}
}
