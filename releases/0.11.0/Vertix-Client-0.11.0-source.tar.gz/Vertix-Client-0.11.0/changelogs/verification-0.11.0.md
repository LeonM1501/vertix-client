# Prüfung 0.11.0

- TypeScript und bestehende UI-/Dateischutz- und Mod-Update-Prüfungen bestanden, einschließlich Downgrade-Vermeidung und Teilfehlern einer Update-Warteschlange.
- Fünf native Archivtests bestanden: Pfade und unbekannte Abhängigkeiten, Client-/Server-Auswahl, CurseForge-Datei-IDs und primärer Loader, Vorrang von Client-Overrides und Archiv-Ausbrüche.
- Vier native Importtests bestanden, einschließlich Live-Test gegen offizielle Modrinth- und CurseForge-Dienste: gepinnter Download und SHA1/SHA512, Zurückweisung falscher Hashes ohne installierte Datei, zusätzliche lokale Dateien nur bei passendem Hash, Client-Overrides, umbenannte Sodium-JAR, korrekte Versionserkennung ohne Dateiveränderung oder Eigentumsübernahme. CurseForge-Dateidownload, SHA1 und Fingerprint-Endpunkt ebenfalls erfolgreich geprüft.
- Zwei native Mod-Identitätstests bestanden: Metadaten mit bekanntem Mod-Namen erfinden keine Remote-Zuordnung; ausdrücklicher Austausch ist hashgebunden, mehrere lokale Versionen und veränderte Dateien bleiben geschützt.
- Browserprüfung des tatsächlichen Bibliotheksbuttons und Importdialogs. Vollständige Vorschau mit ausdrücklich bezeichneten Testdaten: Name ändern, optionale Dateien auswählen. Browser-Dateiaktionen gesperrt. Dies ersetzt keine Prüfung des nativen Dateidialogs oder der Registrierung im persönlichen Profilbestand.
- Persönliche Profile, Welten und installierter Client unverändert. Sämtliche Datei- und Netzwerktests in eigenen temporären Verzeichnissen. Der lokal geschützte CurseForge-Key wird nur im API-Header verwendet.
- Der Nutzer hat die optimierte Windows-Release-Kompilierung ausdrücklich abgebrochen. Auslieferung als unoptimierter Testbuild mit custom-protocol und eingebetteter Produktionsoberfläche; Debug-Symbole entfernt. Abschließende Build-/Downloadnachweise folgen unten.

Format- und API-Referenzen: https://support.modrinth.com/en/articles/8802351-modrinth-modpack-format-mrpack und https://docs.curseforge.com/rest-api/

Rohbelege unter artifacts/verification/import-0.11.0, artifacts/pack-import-live-tests.log, artifacts/pack-import-tests.log und artifacts/pack-identity-tests.log.
